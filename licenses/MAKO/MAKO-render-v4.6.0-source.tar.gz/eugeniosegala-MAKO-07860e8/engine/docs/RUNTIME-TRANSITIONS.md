# Runtime configuration transitions

This guide defines how a saved profile becomes running Renderer state. The [configuration reference](CONFIGURATION-REFERENCE.md) defines fields, [Adaptive validation](ADAPTIVE-VALIDATION.md) owns scheduling, [Spatial scaling architecture](SCALING.md) owns extent policy, [HDR pipeline architecture](HDR-PIPELINE.md) owns colour transitions, and [WSI isolation](WSI-ISOLATION.md) owns process-start discovery. [Memory management](MEMORY-MANAGEMENT.md) explains allocation ownership, replacement peaks, and accounting.

## Lifetime boundaries

A setting belongs to the earliest boundary that can safely establish all state it affects.

Native Remote Play follows the ordinary saved `current_profile` selection through the existing configuration watcher when its launcher sets `MAKO_FOLLOW_CURRENT_PROFILE=1`. Saving a clone under a new name changes the runtime profile identity without resetting unchanged live policy. Subsequent edits and power-source changes use the same projection and live-update planner as local games; selecting a new profile does not bypass startup resources, private handoffs, or restart requirements. Ordinary local matching remains unchanged. The [Remote Play lifecycle](../../plugin/docs/BACKEND-ARCHITECTURE.md#native-remote-play-lifecycle) documents selection-following shader cache updates in the editors.

| Boundary | State | Completion |
| --- | --- | --- |
| Process start | Frame Generation provisioning, Scaling enablement, Game Swapchain Images compatibility, layer membership and order, Gamescope WSI isolation, HDR exposure, Zink, audio compatibility, and the shared FP16 precision choice | Start a new game process |
| Process-wide backend | DLL, GPU, and Ultra Performance policy | Construct a new backend, normally by restarting the process |
| Game-owned swapchain | Spatial extents and pacing shape | Natural recreation, or one eligible maintenance1-backed extent request |
| Private spatial context | Scaling method, sharpness and HDR10 input precision | Prepare, drain MAKO-owned work, and atomically replace |
| Private FG context | Flow Scale, lighter model, and generated-output capacity | Prepare, drain MAKO-owned work, and atomically replace |
| Live policy | Frame Generation `0x`/active execution state, refresh guard, Fixed/Adaptive policy, target, caps, and cadence controls | Next successful reload and application present; policy edits received during confirmed Steam UI focus coalesce until gameplay returns |
| Compositor feedback | Confirmed refresh, explicit VRR/tearing state, and application HDR state | Background sample, independent of profile reload |
| Dormant value | A setting for an inactive mode or unavailable private resource | Save now; apply when its owning mode or resource becomes active |

The process-wide backend is created lazily when the first active swapchain needs it. FP16 is captured at process start even when the backend is still dormant, so MAKO Scaler and a later FG backend cannot disagree after a config reload. LS1 always uses FP32 independently of that baseline. Once built, pending DLL, GPU, and Ultra changes are compared with the actual construction baseline, not merely the previous file.

## Update flow

`Root::update()` is reached from application presentation, but work is bounded and change-driven:

1. Compositor refresh, presentation, and HDR feedback update their owned state independently.
2. Configuration is checked at most every 250 ms. When any saved profile has AC/battery sets, the watcher requests a background system-supply reading at most every two seconds and consumes the last confirmed source through an atomic cache. Startup allows up to 50 ms for the first reading, then uses Base if it is still unavailable. No power-supply I/O or worker join runs in presentation; a stalled read retains confirmed state and cannot accumulate requests or workers. Watchers without power sets create no sampler. Removing the sets leaves an existing worker idle after its outstanding read; re-enabling them requests a fresh sample. The worker is joined at watcher teardown before its code and state can be unloaded; that lifetime join can wait for an outstanding driver read to return. An unchanged file is not reparsed.
3. A changed file is parsed and profile matching is repeated. A confirmed power-source change repeats matching against the existing configuration, without a file write or parse. The resolved power set retains the profile identity and enters the same transition planner.
4. Process-static fields are projected back to their applied values while compatible fields continue.
5. Each live swapchain receives a `ProfileUpdatePlan` based on its applied profile, private resources, generated capacity, and current extent support.
6. The live-safe merge is applied with only the necessary state resets; other values stay pending at their owning boundary.

Every application-owned swapchain creation forces one configuration freshness check so a replacement cannot combine new upper-layer policy with a stale lower-layer snapshot.

AC/battery selection resolves the complete `GameConf` before this update flow; it does not maintain a separate list of live settings or apply a second transition policy. New Renderer fields use the normal parser, writer, editor, and lifetime owner and travel with their selected power set. `power-profile-update` exercises matching, saved inactive-mode edits, same-name power changes, mixed live/private/restart requests, pending extents, reversion, and missing startup provisioning through these production owners. Shared shader edits continue through their existing vkBasalt owner rather than becoming power-specific Renderer fields.

Shader files follow the bundled vkBasalt owner rather than the Renderer transition planner. Its existing 250 ms configuration watcher applies bundled and custom effect selections, order, paths, and configuration options after layer activation at launch. It prepares a complete replacement graph while retaining the previous graph, drains its graphics queue before retirement, and releases intermediate images when the chain becomes shorter. A missing shader, include, or texture, or an invalid compilation keeps the previous graph; a later configuration save retries. Source/include/texture edits alone are not watched; **Refresh** advances `makoReloadGeneration` after pending saves finish and rebuilds the selected graph without changing effect selection. The [backend code map](../../plugin/docs/BACKEND-ARCHITECTURE.md) owns the independent editor bindings and generation contract. Layer activation remains process-start state.

## Requested, applied, and pending state

The transition engine keeps three facts distinct:

| Fact | Owner | Meaning |
| --- | --- | --- |
| Requested profile | `Root::active_profile` | Latest matching saved profile |
| Applied profile | `Swapchain::profile` | Values true for this live context |
| Backend baseline | `Root::backendGlobal`, `Root::backendProfile` | Process-wide inputs used to construct the backend |

`ProfileUpdatePlan::appliedProfile` is a merge. It starts from the requested profile, restores values that cannot cross the current boundary, then classifies the remaining effective differences. A pending restart or recreation must not block an independent live update.

With `adaptive_target_refresh_rate` enabled, the applied Adaptive target is projected from confirmed Gamescope refresh at swapchain creation, profile application, refresh transitions, and private FG resource commit. The commit uses the current matching choice, latest requested fallback, and current display feedback, so resource preparation cannot leave a newly activated Adaptive scheduler using a stale Fixed target. The requested `target_fps` retains the saved fallback; missing or zero feedback restores it. Scheduler policy, caps, bridge output, and pacing consume the applied target together. A changed effective target resets scheduling even when Smooth Cadence is off, without allocating resources or writing configuration. Refresh changes during confirmed Steam UI suspension use the existing policy-reset gate and coalesce until gameplay returns. Fixed mode leaves the option dormant.

For example, a write that changes Base FPS Cap and Flow Scale applies the cap while preparing a private FG replacement. The old Flow Scale remains applied until handoff. Selecting `0x` later still applies immediately, and reverting Flow Scale before handoff cancels the replacement.

## Transition matrix

| Setting or input | Boundary | Effect |
| --- | --- | --- |
| Frame Generation provisioning | Restart | Adds or removes LSFG application-device interop, backend ownership, and private resources. Scaling-only processes retain the combined Renderer without those FG resources. |
| Frame Generation `0x` | Live | Releases the effective base cap, resets relevant scheduler and recovery state, and takes the real-frame path without LSFG work. |
| Frame Generation `2x`–`5x` or Adaptive | Live when startup provisioning succeeded; otherwise restart | Reuses retained interop and private resources, then warms temporal history where required. |
| Refresh threshold and Gamescope refresh | Live | Re-evaluates effective enablement and refresh-targeted scheduling. A refresh pause releases Steady and target-derived Fractional caps while retaining the saved manual Base FPS Cap; resuming restores Adaptive cap ownership. Explicit `0x` still makes all caps dormant. |
| Gamescope VRR and Allow Tearing feedback | Live | Explicit requested/capable/active VRR can change Steady Adaptive's higher-multiplier cap eligibility, enable full-batch FIFO for a validated higher Steady rung, or hand an already accepted constant Fractional rung to FIFO. Fixed Smooth Cadence and qualified Adaptive handoffs retain ordered FIFO pacing. Only affected pacing helpers reset; Allow Tearing is diagnostic only. |
| Per-profile Gamescope VRR choice | Live during a matched MAKO launch | A separate launch helper temporarily changes Gamescope's live VRR value for On or Off and restores the prior value when the game ends. Follow Steam does nothing. MAKO Renderer observes the resulting feedback on its normal sampling cycle. |
| Fixed/Adaptive mode or multiplier | Live within current capacity; otherwise private FG replacement or recreation | Dormant mode values are saved without resetting the active mode. |
| Adaptive target, display-refresh matching, ceiling, Smooth Cadence, Fractional Real Frame Priority, and Dynamic Cadence Recovery | Live within capacity | Rebuilds only the scheduler and real-frame pacing state whose assumptions changed. Automatic adds no priority cap; qualified native presentation follows the [Fractional policy](ADAPTIVE-VALIDATION.md#fractional-real-frame-priority). |
| Dynamic Cadence probe interval | Live | Reschedules an inactive probe without discarding validated cadence or an active confirmation. |
| GPU Headroom reserve | Live while Frame Generation is active | Resets only headroom and source-pacing state; no private resource replacement. Off, stale telemetry, refresh pause, confirmed menu suspension and ordered-acquire recovery release its cap. Scaling-only profiles keep it dormant. |
| Base FPS Cap, Adaptive auto-cap, and explicit Fractional priority cap | Live while generation is active; dormant while Off | Resets the real-frame pacer and affected scheduler policy. Fractional/Steady switches reset scheduler policy even when their numeric caps match, so VRR pacing uses the new mode. Explicit Fractional priority owns the effective cap only in Fractional Adaptive. |
| Scaling enable | Restart | Existing and naturally recreated contexts retain process-start scaling and layer membership. |
| Game Swapchain Images compatibility | Restart | Existing contexts retain the process-start WSI image-count policy. |
| Scaling method | Private spatial replacement when active; dormant otherwise | Applies at the next present, retains extents and WSI objects, and keeps the old method on failure. |
| Scaling sharpness | Private spatial replacement when active; dormant otherwise | Coalesces edits for 500 ms before replacement. |
| HDR Quality | Private FG and spatial replacements for HDR10; live shader graph replacement | Defaults to Performance. Quality/Balanced retain full HDR10 motion analysis and linear-light generation; Balanced/Performance share compact buffers. Only affected owners rebuild, tracking committed precision independently. Reverting cancels its candidate; failed preparation retains old resources. SDR, scRGB FG and WSI formats are unchanged. See [HDR precision](HDR-PIPELINE.md#hdr-quality). |
| Scale Factor | Extent no-op or game-owned recreation | Applies immediately when effective extents stay identical. Otherwise, an eligible spatial owner may request one recreation after a retirement-fenced present; other paths wait for natural recreation. |
| Quality Supersampling | Extent no-op or game-owned recreation | Uses the same extent boundary as Scale Factor on a variable managed Gamescope surface; fixed and direct geometry are unaffected. |
| Flow Scale and Lighter FG Model | Private FG replacement | Coalesces for 500 ms, prepares a complete candidate, drains MAKO-owned work, switches atomically, and warms history. |
| Generated-output capacity | Private FG replacement when the current WSI pool fits; otherwise recreation | Keeps the old active policy until enough resources and WSI headroom exist. Managed Gamescope waits for natural recreation; a compatible non-Gamescope maintenance1 context may request one. |
| Pacing | Natural recreation | Does not change a live swapchain or its transport. |
| DLL, FP16, GPU, and Ultra Performance | Restart | Existing contexts retain the actual backend baseline. |
| Steam overlay removal, WSI compatibility, external layer, HDR exposure, Zink, and ALSA | Restart | These affect discovery or application initialization. |
| Stable HDR application feedback | Private colour transition | May rebuild MAKO-owned colour and backend resources, never the game-owned transport. |
| Active profile match | Live for compatible fields | Losing the match disables generation immediately; static differences remain pending. |

Normal profiles reserve capacity for the larger configured Fixed or Adaptive ceiling. Ultra Performance reserves only its startup-active policy. A later capacity increase can still use private replacement when the lower WSI pool has `application minimum + generated capacity` images; otherwise it remains pending for recreation.

Scaling with Gamescope WSI off provisions the optional surface association at process start. Changing scaler method or suspending private scaling does not replace that connection or switch to full WSI. On the next game launch, the independent Scaling/WSI combination chooses the combined surface adapter, the existing full WSI chain, or ordinary surface handling.

## Private replacement contract

Private spatial, FG, and colour changes use one last-value-wins coordinator:

1. Coalesce the request when required.
2. Construct a complete candidate while the old resources remain usable.
3. Poll only MAKO-owned work; never call `vkDeviceWaitIdle`.
4. Commit atomically after drain proof.
5. Warm temporal history when the replacement affects Frame Generation.
6. Retain the old resources and retry later if construction or drain fails.

Private transitions never destroy the application swapchain or replace its WSI-facing synchronization. During a drain, presentation uses native or reconstructed real frames. A superseded candidate is discarded rather than partially applied.

## Recreation and retirement

On the managed Gamescope split, a Scale Factor or Quality Supersampling extent change may request application-visible recreation only from the upper spatial-resource owner. A compatible non-Gamescope maintenance1 context may request recreation for private-resource growth that cannot fit the current WSI pool. Recovery requests use the same successful, retirement-protected lower-present boundary; MAKO never destroys the active game-owned swapchain itself. Repeated cadence stalls or low FPS alone do not authorize performance-driven recreation.

The surface owner accepts recovery authority only from explicit Gamescope focus transitions, live generation-policy transitions, and generated-image acquire outcomes measured against the configured transport budget. Entering confirmed Steam UI focus clears incomplete ordered-acquire retry state across exact Fixed, Fixed + Dynamic Cadence Recovery, Fractional Adaptive, and Smooth/Steady Adaptive. A confirmed return or live mode, multiplier, cap, target, Smooth Cadence, or Dynamic Cadence Recovery change starts fresh history and arms one recreation permission. Policy edits received while confirmed Steam UI focus already suspends generation are last-value-wins: they do not repeatedly rebuild the scheduler or arm parallel permissions, and the final scheduler policy is constructed once when gameplay returns. The return event supplies the single transport permission. The first generated-image acquire batch completed within its configured budget consumes that permission without action; `VK_TIMEOUT`, `VK_NOT_READY`, budget exhaustion, or a cumulative acquire-deadline overrun may instead consume it by requesting one retirement-protected recreation. There is no seconds-long event window, failure-count qualifier, output-FPS comparison, or surface cooldown. Replacement contexts initialize from the current Gamescope return sequence, preventing the same old event from rearming a recreation loop. Ordinary gameplay FPS, cadence loss, scaling cost, post-processing cost, target deficit, and slow successful lower presents cannot obtain transport-recovery authority or request recreation; exact Fixed never launches a cadence-collapse probe. Backend/fence and acquire safety remain independent. [Adaptive validation](ADAPTIVE-VALIDATION.md) owns the direct-outcome state machines and negative cases.

Presentation retirement is provisioned for Frame Generation, scaling, and the isolated bridge, including HDR with Scaling disabled and shader-only bridge use. It follows owned resources and transport rather than the Scaling toggle. Supported maintenance1 devices supply per-image fences; unsupported devices retain natural recreation and cannot use guarded retries. Natural and requested recreation remove the old context from live updates immediately. Lower WSI destruction waits for same-surface replacement progress, a 50 ms compositor grace, and retirement fences. When an application or upper layer passes a null `oldSwapchain` after destroying its predecessor, MAKO completes the exact retained same-device, same-surface retirement before querying the replacement memory budget or selecting scaling extents, then forwards replacement creation. The memory query must follow completed cleanup rather than charge old WSI/private buffers against their replacement; the compositor grace and retirement fences remain mandatory. Non-null `oldSwapchain` contexts retain their application-owned lifetime. Surface destruction is the terminal same-surface boundary.

A scaled null-old replacement presents its first acquired application image directly before private spatial work. On the isolated Gamescope scaling surface, every replacement also creates a fresh compositor protocol object and publishes the replacement's actual image count and format before its first present; the old compositor pacing lifetime is not reused. A known replacement with Frame Generation active then presents real frames for 250 ms and warms three new history frames inside scheduler stabilization. A replacement created while Frame Generation is Off does not arm that FG-only interval.

The immutable pre/post-FG spatial placement is selected from source and presentation extents at swapchain creation. A live method, sharpness, mode, multiplier, Flow Scale, or model change cannot alter that geometry.

## State resets

Reset only state whose assumptions changed:

- enable/disable clears affected pacing, admission, acquire recovery, and history state;
- mode, target, ceiling, Smooth Cadence, or recovery-policy changes rebuild scheduler policy and affected real-frame pacing, coalesced into one final reset on return when confirmed Steam UI focus owns the transition;
- configured cap changes reset the real-frame pacer and scheduler observations; a bounded scheduler rescue changes only its effective automatic cap and output clock, with rollback owned by the same rescue;
- probe-interval-only changes update only the timer;
- an explicit Gamescope VRR pacing-owner change resets the fixed-refresh budget and real-frame pacing helpers, but not scheduler history, validated multiplier, acquire recovery, or recreation authority;
- applied 3x–5x integer pacing may verify its real-frame cost against a recent trial baseline or obtain a fresh adjacent lower-load sample through the existing efficiency probe after a delayed handoff; a measured rejection restores the adjacent lower workload and output clock without history warm-up, resource replacement, or transport recovery, while interrupted evidence is discarded;
- private-resource, mode, multiplier, refresh, or transport-recovery changes clear transient transport evidence when its assumptions are no longer valid; and
- dormant or deferred values reset nothing until they apply.

A broad “configuration changed” reset would discard validated cadence after unrelated edits and is not allowed.

## Frame Generation provisioning, 0x, and Ultra Performance

Disabling Frame Generation provisioning before launch omits LSFG device interop and backend/private generation ownership. A Scaling-only profile still loads the combined Renderer because it owns reconstruction, but it creates no Frame Generation resources. Decky can omit the Renderer layer when Frame Generation provisioning, Scaling and HDR exposure are all off; a selected post-processing layer remains independent. HDR-only launches retain the Renderer for its surface bridge without provisioning FG or scaling resources.

The `0x` execution state submits no LSFG model work, generated-image acquisition, or generated presents. The saved cap is dormant. When provisioning is on, the process retains interop, backend, private images, and synchronization so `0x` can return to an active factor live. Failed provisioning leaves real-frame or independent scaling active and reports restart pending.

Ultra Performance remains a process-start policy: the global FP16 choice, Flow Scale 0.7, lighter model, active-policy-sized capacity, and LS1 Performance when scaling is enabled. It never enables scaling. Compatible live controls still work, but changing Ultra itself waits for restart and cannot partially mutate the active backend.

## Runtime status and diagnostics

With diagnostics enabled, `runtime-transition-pending`, `runtime-transition-prepared`, `runtime-transition-failed`, `runtime-transition-applied`, and `runtime-transition-recreation-requested` identify the configuration boundary and result. `gamescope-focus` and `ordered-acquire-*` distinguish observed focus, explicit acquire failure, bounded retry, and transition-scoped recreation. Swapchain create, replacement, retirement, WSI-prime, backend-stabilization, and memory records provide lifecycle evidence. The diagnostics helper continues to recognize retired slow-acquire, lower-present, and performance-watchdog operation names when collecting logs from older installations.

Each context also publishes an atomic schema-5 requested-versus-applied record under the configuration directory's `runtime-state/`. It includes process identity, transition phase, pending boundaries, effective generation and scaling state, extents, method, factor, placement, fallback, and active constraint. Context teardown removes its own record and lock.

`spatial_scaling.active` requires both private spatial work and Scaling enabled in the applied profile. HDR's internal display-size resize does not activate the user-facing Scaling feature, including across window-mode replacements. A requested toggle waiting for restart does not change the applied state. Extents and pipeline details retain the actual transport geometry even when the Scaling feature is off.

Before the first primary context publishes, one process-wide pass removes only unlocked stale MAKO runtime files from that exact directory. It is non-recursive and best-effort; held locks, unrelated names, symlinks, ownership uncertainty, and failures are preserved and never block startup. Status I/O is observational and cannot change presentation.

Follow [Collect diagnostics](COLLECT_DIAGNOSTICS.md) to capture a session; use `mako-diagnostics --list` to select a narrower `config`, `startup`, `recovery`, or `performance` report.

## Adding a setting

Before adding or changing a field, define:

1. its schema and validation owner;
2. the earliest safe lifetime boundary;
3. requested, applied, and construction-baseline state;
4. behavior in mixed writes and inactive modes;
5. the smallest scheduler, pacing, history, recovery, or resource reset;
6. behavior inside an active Ultra Performance process;
7. diagnostics that prove application; and
8. portable, sanitizer, Vulkan, hardware, and package evidence.

Extend `ProfileUpdatePlan` and the existing transition owner rather than adding a second reload path.

## Validation

Run portable and sanitizer coverage from `engine/`:

```bash
scripts/test-adaptive-scheduler.sh
MAKO_ENABLE_SANITIZERS=ON scripts/test-adaptive-scheduler.sh
```

`profile_update_tests.cpp` must cover a field alone, mixed with live and deferred fields, superseded or reverted requests, insufficient resources, inactive modes, and process-static baselines as applicable. Vulkan-facing changes also need the MAKO Gym suites selected by [Testing MAKO](../../TESTING.md). Mark unavailable hardware rows **not tested**.

### External descriptor ownership during resource construction

Exported image-memory and timeline-semaphore descriptors are scoped until the backend context call. The backend consumes the complete batch on entry, including early rejection, and closes every descriptor it has not yet handed to an importing Vulkan wrapper when construction fails. Each wrapper closes its current descriptor on failure before import succeeds; successful Vulkan import transfers ownership to the driver, so later bind/view failures must not close the descriptor number again. Image export happens after image-view construction succeeds. This covers initial provisioning, failed live private replacements, and CLI setup without changing present-loop work, retirement limits, or synchronization policy. Portable fault tests exercise partial export/import and descriptor-number reuse; MAKO Gym owns the repeated real-resource plateau evidence.

## Code and test ownership

| Responsibility | Source of truth |
| --- | --- |
| Parsing, watched configuration, and background power sampling | `mako-common/src/configuration/config.cpp`, `mako-common/src/configuration/power_source.*`, `mako-common/include/mako-common/configuration/config.hpp` |
| Polling, profile selection, and backend baselines | `mako-render/src/instance.*` |
| Merge and transition classification | `mako-render/src/profile_update.hpp` |
| Private transitions and live application | `mako-render/src/runtime_transition.hpp`, `mako-render/src/swapchain/resources.cpp`, `mako-render/src/swapchain/profile.cpp` |
| Real-frame and generated presentation | `mako-render/src/swapchain/present.cpp`, `mako-render/src/swapchain/present/` |
| Process-start transport policy | `mako-render/src/presentation_policy.hpp`, `scripts/mako-launch` |
| Status and diagnostics | `mako-render/src/runtime_status.*`, `mako-render/src/present_diagnostics.*` |
| Deterministic tests | `mako-render/tests/profile_update_tests.cpp`, `runtime_transition_tests.cpp`, `runtime_status_tests.cpp` |
