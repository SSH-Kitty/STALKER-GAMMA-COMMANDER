# Spatial scaling architecture

MAKO Renderer can reconstruct a lower-resolution Vulkan swapchain to the presentation extent, with or without Frame Generation. Scaling is disabled by default and is independent from Fixed or Adaptive scheduling. [Configuration](CONFIGURATION.md) owns user settings; [runtime transitions](RUNTIME-TRANSITIONS.md) owns live, deferred, and restart boundaries. [Memory management](MEMORY-MANAGEMENT.md) explains allocation, pooling, accounting, and resource cleanup around the admission policy below.

## Scaling methods

| Method | Implementation | Requirements |
| --- | --- | --- |
| `native` — Native Resolution | Model-free linear reconstruction through Vulkan blits | None beyond the normal Renderer requirements |
| `mako` — MAKO Scaler | Repository-owned single-pass spatial reconstruction with sharpening and anti-ringing | None beyond the normal Renderer requirements |
| `ls1` — LS1 Quality | Complete proprietary LS1 graph | A lawful, user-supplied `Lossless.dll` and an architecture-matched `libvkd3d-shader.so.1` |
| `ls1-performance` — LS1 Performance | Lower-cost proprietary LS1 graph | A lawful, user-supplied `Lossless.dll` and an architecture-matched `libvkd3d-shader.so.1` |

MAKO never packages, uploads, or modifies `Lossless.dll`. It reads the selected resources from the user's file, validates their containers and bindings, translates supported LS1 or LSFG DirectX bytecode during setup, and keeps the resulting shader modules inside the process. Compatibility is capability-based rather than tied to an allowlist of DLL versions. `mako-cli inspect-dll --dll <path>` performs the GPU-independent checks; Vulkan pipeline construction remains device-specific.

LS1 and LSFG use the shared resolver in `mako-backend/src/extraction/model_resources.cpp`. It first checks the requested model at the established resource IDs, including known LS1 reflection when present. If those resources do not match, it searches for a unique complete supported table whose IDs have shifted by one common offset. LS1 discovery requires all five variants of both modes and their SM5.0 reflected interfaces; LSFG discovery requires both modes, both precision lanes, matching descriptor interfaces, and the established precision order. The runtime LSFG registry resolves both modes together so their shared stages come from one table. Extra unrelated resources and changed file hashes do not prevent loading. Resolution successes and failures are cached on the immutable process-local archive, outside the frame path; replacing the DLL creates a new archive and resolution cache.

When no supported Vulkan LSFG registry exists at the selected precision, `mako-backend/src/extraction/lsfg_shader_set.cpp` validates the existing DirectX LSFG graph and translates it through the same dynamically loaded `libvkd3d-shader.so.1` owner used by LS1. Its canonical and relocated DirectX tables require exact SM5.0 resource reflection, and relocation requires both modes together. The Vulkan registry remains preferred. Ordinary builds translate DirectX only when FP16 is off; an FP16 request requires a supported native FP16 registry and fails explicitly if it is missing. The separately selected [experimental native build](BUILDING-FROM-SOURCE.md#experimental-forced-lsfg-fp16) uses the same FP16 setting to convert a supported FP32-only graph, including DirectX translation, to explicit half arithmetic. Native FP16 still takes priority and FP16-off never invokes conversion. Conversion is unqualified for image quality and logs that status. MAKO never silently substitutes FP32 for an FP16 request. Translation and conversion are confined to initialization and cached on the immutable DLL archive in process memory; replacing the DLL gets a fresh cache. Neither the DLL nor its resources are rewritten or saved.

Discovery is bounded to 4,096 resources and rejects partial or ambiguous relocated tables. It does not infer arbitrary stage reorderings, new model architectures, or compatibility from similar hashes or binding counts alone. Translation and Vulkan pipeline checks still apply. This supports compatible resource relocation on fresh installations without retaining an older DLL, but cannot guarantee compatibility with every future Lossless Scaling update or its separate `lsfg-vk.dll` backend.

`mako-cli inspect-dll --dll <path> --lsfg` performs an LSFG-only preflight through the complete runtime shader loader at the selected FP16 precision, without LS1 translation or GPU setup. Add `--no-fp16` to select FP32, including the DirectX fallback. Native Vulkan registries need no translation library; a DirectX-only LSFG DLL requires an architecture-matched translator. Like the selected LS1 probe, it emits only `{"schema_version":1,"compatible":true|false}` and exits 0 for compatible or 1 for a model failure. Unknown options or unavailable inspectors are not model-failure evidence. MAKO Decky uses this alongside the selected LS1 probe to show a top warning and update guidance; [Decky configuration](../../plugin/docs/CONFIGURATION.md) describes the controls and warnings.

If LS1 discovery, translation, format support, or pipeline creation fails, the swapchain falls back to MAKO Scaler and records the requested method, active method, and reason. Native Resolution and MAKO Scaler do not require the licensed file or translator.

For one saved selection, `mako-cli inspect-dll --dll <path> --ls1 ls1 --sharpness 0.8` (or `--ls1 ls1-performance`) calls the same selected-variant loader as the runtime and emits only `{"schema_version":1,"compatible":true|false}` on stdout. Exit 0 means the selected resources translated; exit 1 with a valid status means LS1 setup failed. Command errors, absent inspectors, and malformed output are unknown to consumers. On the established resource layout, unrelated LSFG families or other LS1 variants do not veto this probe; relocated-table discovery requires the complete LS1 table described above. MAKO Decky runs it off its event loop after a 500 ms control debounce, checks file identities every 30 seconds while the LS1 controls are present, and caches one result per model family for at most five minutes. DLL or inspector replacement invalidates that cache immediately at the next check, including same-size/restored-mtime replacements; expiry also retries translator changes. No probe writes a profile or persists licensed resources. Actual runtime fallback retains the requested LS1 method, constructs MAKO Scaler, and publishes the requested/active distinction. A working fallback remains active until another private-scaler construction boundary, avoiding periodic translation in the frame path.

## Arithmetic precision

The [experimental forced-LSFG build](BUILDING-FROM-SOURCE.md#experimental-forced-lsfg-fp16) converts eligible feature arithmetic to FP16 while retaining precision-sensitive image stages, sampling, and bit-pattern dependencies at FP32. That guide owns the conversion rules and observed procedural failures; game image quality remains unqualified. Native FP16 selection and the FP16-off path are unchanged.

The global `allow_fp16` setting is a restart-bound precision choice shared by LSFG Frame Generation and MAKO Scaler, including Ultra Performance, swapchain recreation, live scaler replacement, and fallback construction. MAKO Scaler has generated FP32 and FP16 colour variants for both RGBA8 and RGBA16F storage. Pixel coordinates and cubic sample locations remain FP32 to preserve subpixel accuracy at large extents; SDR storage stays RGBA8 rather than expanding merely because arithmetic is FP16. Native Resolution uses the driver's blit path without a configurable arithmetic precision.

Scaling requests `shaderFloat16` on the application device only when its feature and extension are supported, reuses an existing Vulkan 1.2 or extension feature structure without duplicating it, and copies known feature-chain prefixes without modifying application input storage. An unknown prefix preserves the original request instead of truncating a Vulkan structure. A physical support bit alone is not proof that FP16 was enabled on the logical device. If FP16 is unavailable on that logical device, MAKO Scaler reports the limitation and uses the existing Native Resolution blit, preserving the source/presentation geometry without substituting FP32 compute. Select FP32 to enable compute scaling on that device.

LS1 Quality and LS1 Performance always translate and run at FP32, independently of `allow_fp16` and the logical device's FP16 support. `inspect-dll --ls1` uses the same fixed-FP32 loader. MAKO Decky explicitly passes `--no-fp16` for compatibility with older inspectors and retains the RPC's precision argument without applying it to LS1. If LS1 discovery or construction fails, its MAKO Scaler fallback follows `allow_fp16` and retains the requested/active distinction and failure reason. Spatial quality and profiling commands also accept `--allow-fp16` and `--no-fp16` for MAKO Scaler. Combined validation applies the selected precision to LSFG and MAKO Scaler while LS1 remains FP32.

## Activation and ownership

Scaling must be enabled before the process starts because it changes layer membership and swapchain geometry. Frame Generation provisioning is an independent process-start choice: a Scaling-only profile keeps the combined Renderer but omits LSFG device interop, backend ownership, and generated-frame resources. Once a scaled process is provisioned, method and sharpness changes replace only private scaler resources. A factor or supersampling change may need a game-owned swapchain recreation when it changes the effective source/presentation pair.

Standalone `mako-launch` and MAKO Decky with Gamescope WSI off use one combined Renderer role for scaling and Frame Generation, including inside Gamescope. Scaling does not load Gamescope WSI automatically. When both Scaling and the independent Gamescope WSI compatibility option are enabled in a supported session, MAKO Decky uses three ordered roles:

```text
Application
    -> VK_LAYER_MAKO_render
       reconstruction + Frame Generation
    -> VK_LAYER_FROG_gamescope_wsi_x86_64
    -> VK_LAYER_MAKO_spatial_scaling
       capability virtualization + lower extent
    -> Vulkan driver
    -> Gamescope compositor
```

The lower spatial role owns surface capabilities and physical lower-swapchain extent expansion. It performs no presentation-time GPU work. The upper role owns reconstruction, optional Frame Generation, private resources, and runtime status. The split must be selected explicitly; implicit-manifest directory order is not an ordering contract. [WSI isolation](WSI-ISOLATION.md) owns the launch and proof requirements.

With Scaling on and Gamescope WSI off, the combined Renderer provisions a minimal X11-to-Wayland surface association at process start. Application queries retain concrete X11 extents and the shared format intersection; only internal driver queries use variable Wayland geometry. The application request remains the source and scaler policy selects the output. The adapter supplies one protocol object per swapchain, preserves distinct generated/real output timing, and adds no WSI layer or limiter. An explicit HDR opt-in reuses this owner for colour-space and metadata requests; disabled HDR adds none of that activity. Missing session, protocol, library, or window proof preserves native surface handling. [WSI isolation](WSI-ISOLATION.md#guarded-gamescope-wsi-paths) owns association lifetime, readiness lead, output clocks, and timing bounds.

## Pipeline placement

The upper role selects one immutable pipeline order from the presentation extent. Extents at or below 2,304,000 pixels, equivalent to 1920×1200, reconstruct once before Frame Generation:

```text
application source -> reconstruction -> real frame
                                   -> Frame Generation -> generated frame(s)
                                   -> ordered presentation
```

Larger presentation extents run Frame Generation at the source extent and reconstruct each delivered real or generated image before presentation:

```text
application source -> Frame Generation -> source-size real/generated images
                                      -> reconstruction -> presentation
```

The threshold is a pixel budget, not a width/height clamp. It keeps Deck and 1080p-class output to one reconstruction per application frame while avoiding presentation-sized Frame Generation resources at higher resolutions. Multiplier and Fixed/Adaptive changes do not alter the selected placement. With Frame Generation off, each real frame is reconstructed once.

The pre-Frame Generation path can write directly into the exported Frame Generation source when the device proves the required usage and format support. Otherwise it uses the private-output copy path. This is an optimization only; failure does not change the source/presentation contract.

<a id="extent-ownership"></a>

## Extent policy

Each active scaled swapchain has two extents:

- **Source:** the image size presented to the application and sampled by the scaler.
- **Presentation:** the physical lower WSI size and final output resolution.

Dimensions greater than one are rounded down to even values. Scaling remains inactive when the factor is 1.0, the extents cannot differ safely, or a required capability cannot be proven. An enabled 1.0 profile retains the live reconstruction lane but uses Frame Generation-only WSI relief topology until a factor above 1.0 can activate scaling.

### Fixed-extent surfaces

For a surface with a concrete `currentExtent`, MAKO advertises a source extent derived from the presentation extent and configured factor. Swapchain creation activates scaling only when the application requests the exact advertised source under the current surface and policy contract. If the application instead requests the native presentation extent, MAKO preserves that choice and creates a native context.

In the managed split chain, the upper and lower roles exchange capability and create decisions through same-thread, one-shot relays because Gamescope WSI may replace the surface handle between them. A missing, stale, or mismatched lower decision fails closed instead of creating a transient context with the wrong geometry.

The lower split role must observe a Wayland surface created through Gamescope WSI. If it sees the application's XCB or Xlib surface, Gamescope WSI did not establish the required ownership boundary; scaling stays native with `inactive_reason=gamescope-wsi-surface-unproven`. The direct combined Renderer owns its application surface and does not require this split-only proof.

### Variable-extent surfaces

For a surface whose `currentExtent` is variable, the application request is the source. MAKO enlarges it by one aspect-preserving effective factor, subject to Vulkan surface limits and memory admission.

The managed Gamescope split chain and the combined Renderer's isolated Gamescope surface adapter require a positively identified output target from the server-zero feedback resolver and treat it as the normal presentation ceiling. If the source already fills that target, scaling stays native with `inactive_reason=gamescope-presentation-target-no-headroom`. Quality Supersampling may exceed the target, but it cannot bypass Vulkan limits, memory admission, or the requirement to prove the Gamescope target. Ordinary combined surfaces use available Gamescope target feedback without requiring this adapter-specific proof. Direct non-Gamescope operation applies the factor without inventing a compositor target.

For the isolated X11 surface adapter, applications continue to query a concrete live window size through both Vulkan capability APIs. The private Wayland surface remains variable only inside the Renderer, where the existing source/output and unsupported-scaling checks apply. This preserves startup compatibility for XCB/Xlib applications without a game-specific exclusion. See [WSI isolation](WSI-ISOLATION.md) for the contract and diagnostic fields.

The adapter observes window geometry at capability queries and swapchain protocol creation. Extents matching those observations follow the window contract; stale window-bound swapchains return `VK_ERROR_OUT_OF_DATE_KHR` before lower acquisition can signal application synchronization. An intentional rendering override remains valid when it matches neither observation, and explicit presentation scaling retains the lower driver contract. Invalidation persists until replacement, including if the window returns to its earlier size. There is no per-frame geometry polling. [WSI isolation](WSI-ISOLATION.md#guarded-gamescope-wsi-paths) owns both acquire entrypoints, protocol retirement, return codes, and diagnostics.

The memory policy admits a presentation extent from device-local heap size and, when available, the driver's live budget and usage. For a null-old replacement whose predecessor the application already destroyed, complete the existing fence-protected retirement before sampling that budget. Query the driver again without subtracting guessed released bytes; a delayed budget update can still require native fallback. When a live source-resolution change is rejected only by that live estimate, its requested output remains inside the same-placement presentation envelope already proven on the surface, and the native replacement presents successfully with maintenance1 retirement protection, MAKO preserves the proof and requests one further game-owned recreation after three seconds to re-sample the driver. Output growth, placement changes, cold starts, other inactive reasons, and a second rejection cannot use this retry. The policy otherwise preserves already proven envelopes across safe live transitions and fails closed when the enlarged swapchain and private resources do not fit. Runtime status reports the requested and effective factor plus the active constraint or inactive reason; it does not promise an exact free-memory measurement.

A native hop to the exact proven display extent preserves the preceding split for both explicit SDR/HDR scaling and automatic HDR display resizing on the same variable surface. A native-only launch does not create split proof, an unrelated extent clears it, and growing the source still requires live headroom. Memory-only retries use the display-clamped requested output, including when Scaling is disabled and HDR requests an internal resize; each source/policy episode retains its single retirement-protected retry.

The static memory envelope keeps a 3840×2160 compatibility floor for unified-memory apertures; the live budget has no such floor. Separate graph estimates charge Frame Generation at presentation resolution through 1920×1200 pixels and source resolution above it. Both retain a conservative full-Flow Quality allowance for live changes, and 5× reserves four generated outputs. FP16 changes arithmetic rather than these SDR allocation formats. Proven-envelope reuse requires the same Frame Generation placement; a post-FG-to-pre-FG downshift needs fresh admission even when its dimensions shrink. Source growth is charged at the conservative 256-byte resource rate independently of cheaper output-only pixels.

Memory admission is a conservative allocation estimate, not a measurement of spare GPU execution time or a promise that a scaling factor will sustain the target FPS. It uses the selected application's Vulkan device and its largest device-local heap, not GPU-name tiers, clock rates, or total system RAM. The [Vulkan memory-budget contract](https://docs.vulkan.org/refpages/latest/refpages/source/VkPhysicalDeviceMemoryBudgetPropertiesEXT.html) defines budget and usage as changing estimates; the reserve and static fallback cannot guarantee allocation success, predict driver-specific tiling/alignment, or model every multi-heap/cross-device topology. Actual resource creation and the existing failure handling remain authoritative. MAKO Gym compares the cold graph estimate against observed private Vulkan allocations plus nominal WSI bytes, and exercises live memory pressure separately from performance tests.

## Swapchain and queue requirements

Scaling supports ordinary opaque, unprotected, single-array-layer swapchains. The selected source format must support the sampled, transfer, and storage operations used by the active method; LS1 uses RGBA8 for ordinary SDR and RGBA16F reconstruction for HDR/high-precision pipelines. Linear-scRGB LS1 inputs use the colour conversion boundary described in [HDR handling](HDR-PIPELINE.md#scaling-and-shaders).

The application must create an ordinary graphics-and-compute queue family supported by the surface, and presentation must use a registered queue from that family. Unsupported shapes, formats, queues, protected presentation, shared-present modes, or managed multi-swapchain present batches fail closed before consuming application waits. The original real frame remains the fallback whenever private reconstruction cannot be used safely.

Frame Generation normally reserves WSI images for the largest configured generated batch. The restart-only Game Swapchain Images compatibility option preserves the application's requested minimum instead; generated output can then be skipped under compositor pressure because no reserved image is guaranteed. [WSI isolation](WSI-ISOLATION.md) owns the presentation and image-count policy.

## Configuration

```toml
[[profile]]
name = "Scaled game"
active_in = ["Game.exe"]

scaling_enabled = true
scaling_method = "ls1"
scaling_factor = 1.5
scaling_supersampling = false
scaling_sharpness = 0.8
```

Set `frame_generation_provisioned = false` before launch for scaling-only operation without FG resources. `frame_generation_enabled = false` pauses already provisioned generation live and retains its resources. Fixed and Adaptive controls remain unchanged when Frame Generation is enabled. Environment-only profiles use `MAKO_SCALING_ENABLED`, `MAKO_SCALING_METHOD`, `MAKO_SCALING_FACTOR`, `MAKO_SCALING_SUPERSAMPLING`, and `MAKO_SCALING_SHARPNESS` with `MAKO_ENV=1`.

`MAKO_VKD3D_SHADER_PATH=/absolute/path/to/libvkd3d-shader.so.1` overrides the shared LS1/LSFG DirectX translator discovery for a nonstandard installation. It affects setup only.

See the [configuration reference](CONFIGURATION-REFERENCE.md) for exact defaults and ranges. See [Runtime configuration transitions](RUNTIME-TRANSITIONS.md) before changing factor, supersampling, method, or sharpness while a game is running.

## Validation

Portable CTest covers configuration, fixed and variable extent policy, Gamescope target handling, memory admission, swapchain shape and queue requirements, pipeline placement, private transitions, and embedded shader freshness. These tests do not prove Vulkan image quality, layer order, presentation, or hardware memory behavior.

Real-Vulkan changes need proportionate MAKO Gym evidence for both FP32 and FP16 where Frame Generation is involved. Select the applicable suites from [Testing MAKO](../../TESTING.md), including quality, spatial performance, synchronization, Gamescope, recovery, native Vulkan, DXVK, VKD3D-Proton, direct desktop, and supported Flatpak/runtime paths. Record unavailable hardware and matrix rows as not tested.

Require an active source/presentation split and one upper reconstruction owner; a selected method alone does not prove scaling ran. The [WSI presentation-evidence checklist](WSI-ISOLATION.md#presentation-evidence) owns loader order, lower-surface provenance, and isolated-bridge proof. Compare paths at identical source/output sizes, scaler, Frame Generation settings, scene, and refresh rate; native fallback is not a scaling performance improvement. Follow [Collect diagnostics](COLLECT_DIAGNOSTICS.md) and select `scaling`, `layers`, or `recovery` for a focused report.

## Code and test ownership

| Responsibility | Source of truth |
| --- | --- |
| Extent, placement, format, queue, and memory policy | `mako-render/src/spatial_scaling_policy.hpp` |
| Surface interception and split-role relays | `mako-render/src/entrypoint.cpp` |
| Swapchain activation and resources | `mako-render/src/instance.cpp`, `mako-render/src/spatial_scaler.cpp` |
| Scaling-only and combined presentation | `mako-render/src/swapchain/present.cpp`, `mako-render/src/swapchain/present/real_frames.cpp` |
| MAKO shader source and generated payload | `mako-render/src/shaders/`, `scripts/generate-spatial-scaling-spirv.py` |
| Shared LS1/LSFG resource resolution, validation, and DirectX translation | `mako-backend/src/extraction/`, `mako-cli inspect-dll` |
| Portable policy and transition coverage | `mako-render/tests/spatial_scaling_policy_tests.cpp`, `mako-render/tests/profile_update_tests.cpp` |
| GPU quality and runtime evidence | `mako-cli/src/tools/quality.cpp`, private MAKO Gym suites |
