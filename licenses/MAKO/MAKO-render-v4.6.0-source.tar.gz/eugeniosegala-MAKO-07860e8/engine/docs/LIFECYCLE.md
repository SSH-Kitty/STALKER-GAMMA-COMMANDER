# MAKO Renderer lifecycle

This guide explains how MAKO Renderer discovers its environment, creates and replaces resources, applies settings, paces frames, recovers from pressure, and shuts down. It is a conceptual inventory of lifecycle-affecting probes and policies rather than a source-file map. The exact setting contract remains in the [configuration reference](CONFIGURATION-REFERENCE.md), [Runtime configuration transitions](RUNTIME-TRANSITIONS.md), [Spatial scaling architecture](SCALING.md), [Adaptive validation](ADAPTIVE-VALIDATION.md), [HDR pipeline](HDR-PIPELINE.md), and [WSI isolation](WSI-ISOLATION.md). [Memory management](MEMORY-MANAGEMENT.md) covers allocation, pooling, accounting, and cleanup ownership.

## Safety model

MAKO separates proof from policy:

- Vulkan ownership, format support, queue support, image counts, external-memory support, and completion are established through Vulkan capabilities, return values, and fences. A timing or performance heuristic must never substitute for one of those proofs.
- Missing evidence fails closed when proceeding could corrupt presentation or violate ownership. Scaling is disabled when surface provenance, output geometry, queue support, format support, or memory admission cannot be established.
- Missing performance feedback normally fails open to native or less-managed presentation. It may reduce smoothness or efficiency, but it must not invent support.
- The application owns swapchain creation, recreation, and destruction. MAKO may request one spec-defined recreation signal when the active presentation boundary can support it, but it does not destroy an active application swapchain merely to apply a setting.
- The original application frame has priority. Frame Generation, scaling, or recovery failure falls back to the real frame wherever the negotiated swapchain geometry still makes that safe.

## Lifetime map

| Lifetime | Created by | What becomes fixed | What can still change |
| --- | --- | --- | --- |
| Process | Vulkan layer activation and profile match | Scaling enablement, layer-chain role, Gamescope isolation, HDR exposure, Game Swapchain Images compatibility, and launcher-owned compatibility behavior | The configuration can be re-read, but changes to process-static choices remain pending until restart |
| Vulkan device | The application's device creation | Available queues, device extensions, synchronization features, and optional swapchain-maintenance support | Per-swapchain policy can change within those capabilities |
| Private Frame Generation backend | The first active swapchain that needs Frame Generation | Selected GPU, DLL-derived model family, startup FP16 precision choice, and Ultra Performance topology | Per-swapchain Frame Generation contexts may be replaced; the process backend is shared |
| Surface | Application surface creation | Native window-system provenance and cached scaling eligibility | Current capabilities and output feedback are rechecked at swapchain creation |
| Application swapchain | Application creation or recreation | Source and presentation extents, scaling placement, transport, image pool, and generated-output headroom | Live policy and compatible private resources may change |
| Private scaling or Frame Generation context | Initial swapchain setup or a live private transition | Images, pipelines, model topology, and synchronization objects for that context | A complete replacement can be built beside the old context and switched atomically |
| Present policy | Each successful application present | Nothing beyond the current frame plan | Caps, Fixed or Adaptive decisions, refresh guards, admission, recovery, and diagnostics update continuously |
| Deferred retirement | Application destruction of a swapchain | The retired lower swapchain and its completion evidence | Later same-surface presents, replacement creation, surface destruction, or device destruction complete retirement |

The normal progression is:

```text
process/profile match
  -> device capability registration
  -> surface observation
  -> swapchain negotiation and private context construction
  -> warm-up
  -> steady presentation
  -> live policy update or private-context replacement
  -> application-requested recreation
  -> deferred retirement
  -> surface/device/instance shutdown
```

## Probe inventory and cost

Costs are qualitative: **negligible** is cached state, arithmetic, or a nonblocking readiness check; **low** is a syscall or a small set of window-system queries; **moderate** is a group of Vulkan capability queries; **high** is GPU allocation, pipeline/model construction, or a potentially blocking wait. Driver calls can exceed their expected cost, so bounded waits are called out separately.

### Periodic and change-driven probes

| Probe | Trigger or cadence | Rough work and cost | Effect and safety behavior |
| --- | --- | --- | --- |
| Configuration freshness | At most once every 250 ms while application presents are reaching MAKO; forced at every application swapchain creation | One filesystem metadata check, **low**. A changed file causes a full parse and process-identity rematch, **low to moderate** | The last valid configuration remains active after read or parse failure. A failed parse can be retried after 50 ms, although the outer 250 ms poll usually sets the effective retry cadence |
| Process identity | Once at startup and again only after a changed configuration parses successfully | Executable/name reads and, for Wine or Proton, a process-map scan, **low to moderate** | An unmatched profile leaves MAKO dormant and presentation native |
| Gamescope and display feedback | One synchronous startup sample, then every 250 ms when Gamescope is hinted or detected, otherwise every 1 second on ordinary X11; absent when there is no X display | Several X11 root-property round trips on a background thread, **low**, with no X11 work on the present thread | Publishes cached Gamescope identity, output size, refresh, VRR and game-versus-Steam focus. Only the legacy full-WSI path periodically reads HDR properties; the isolated bridge queries HDR capability on demand at surface creation. Unknown data does not manufacture support |
| Isolated Gamescope bridge feedback | Socket readiness on an admitted bridge connection, including while the game is idle | One event-driven reader drains the private Wayland queue, **low**, without a periodic timer or per-swapchain worker | Supplies completion and retirement feedback independently of Mesa; retries backpressured writes and joins before connection teardown. [WSI isolation](WSI-ISOLATION.md#guarded-gamescope-wsi-paths) owns synchronization and failure handling |
| Gamescope root discovery | Event-driven when the connection is stale, the observed display is not the required root, or Gamescope was hinted but not identified; retry no faster than once per second | Opening candidate X displays and reading identity properties, **moderate burst** | Only a server-zero display belonging to the same Gamescope process is accepted. Failed discovery retains no unsafe root claim |
| Cached display-feedback consumption | At most once every 250 ms on the presentation path | Lock and copy of cached state, **negligible** | Refresh and output geometry can update policy. HDR active state requires separate stability evidence |
| Legacy WSI HDR stability | Evaluated from feedback changes; 750 ms of uninterrupted agreement | Clock comparisons only, **negligible** | Prevents color-pipeline rebuilds from transient HDR evidence. Unknown evidence cancels the candidate and retains the last confirmed state |
| Runtime status publication | Only when requested/applied/pending state changes | Atomic small-file replacement, **low but not steady-state work** | Status is observational and cannot block rendering on cleanup errors. The first publisher performs one bounded cleanup of unlocked MAKO-owned stale entries |
| Diagnostic runtime health | Every five seconds only with presentation diagnostics enabled; slow collection/output backs off to 30 seconds | Bounded proc/sysfs reads and atomic memory snapshots on a worker, **low to moderate** | No Vulkan calls or policy changes; unavailable fields remain unknown. An outstanding driver read may delay teardown. [Memory evidence](MEMORY-MANAGEMENT.md#reading-memory-evidence) owns the details |
| GPU Headroom utilization | Only when enabled for provisioned Frame Generation; approximately five samples per second, with a five-second retry after missing or slow reads | One exact-device sysfs read on a shared background worker, **low**, with atomic consumption on presentation | Ten fresh samples form the average. Off invalidates readings and parks the worker; a game that leaves it Off creates no monitor. Missing or stale readings release the extra cap. [Renderer architecture](RENDERER-ARCHITECTURE.md#gpu-headroom-control) owns monitor lifetime and limits |

**Match Display Refresh Rate** uses the refresh value already read by the shared Gamescope monitor. Its toggle changes Adaptive target selection, not the monitor cadence. Focus, VRR and presentation policy still consume compositor feedback when matching is off; HDR queries follow the separate [HDR contract](HDR-PIPELINE.md#toggle-and-launch-contract). Enabling matching adds no X11 read, worker, or polling loop.

Diagnostic health sampling is opt-in and observational; it cannot change scheduling or recovery. Scheduler and recovery backoffs are separate from background probes.

### Event-driven capability and allocation probes

| Probe | Trigger | Rough work and cost | Effect and safety behavior |
| --- | --- | --- | --- |
| Device support | First application device creation | Queue-family, extension, feature, and optional maintenance capability enumeration, **moderate once per device** | Unsupported queues or synchronization features constrain later presentation rather than being guessed |
| Surface scaling eligibility | First relevant surface-capability observation, cached for the surface lifetime | Surface shape, queue support, format enumeration with at most three incomplete retries, and format-feature queries, **moderate once per physical-device/surface pair** | Any missing provenance, incompatible shape, unsupported queue, unsupported format, or stale relay fails scaling closed |
| Current swapchain capabilities | Every swapchain creation | Surface capabilities plus selected queue/format checks, **moderate** | The current maximum image count and extents are authoritative even when earlier observations were favorable |
| Memory admission | Every scaling-capable swapchain creation and relevant private-resource admission | Heap properties and memory budget/usage when available, followed by conservative allocation estimates, **moderate** | MAKO may reduce the effective scale or disable the feature. The estimate can reject a viable configuration, but it must not overrule an explicit Vulkan limit |
| Direct generated output | Frame Generation context construction | External-image format and usage capability queries, **moderate** | Supported devices can write directly to the presentation-compatible output; otherwise MAKO uses a private image and copy path |
| Private resource construction | Initial context creation or an accepted live transition | Image allocation, exported/imported synchronization, pipelines, model translation, and backend context creation, **high** | The old context stays active until a complete candidate is ready. Failure retains the old context and schedules a bounded retry |
| Frame Generation backend creation | Once, lazily, on the first swapchain that actually needs Frame Generation | DLL discovery and validation, GPU matching, a private Vulkan instance/device, resource extraction/translation, and pipelines, **high one-time cost** | Failure disables Frame Generation without changing the user-owned input. Licensed scaling resources are owned by the private scaling context instead; neither path performs periodic backend work |

### Per-present observations and probes

| Probe | Trigger or cadence | Rough work and cost | Effect and safety behavior |
| --- | --- | --- | --- |
| Cadence observation | Every application present | Steady-clock samples and allocation-free arithmetic, **negligible** | Drives Fixed refresh budgeting, Adaptive planning, and caps. It observes application delivery, not physical scanout, and cannot authorize transport recovery |
| GPU Headroom control | Every present while configured; utilization-driven cap decisions at most every two seconds | Cached utilization and bounded arithmetic, **negligible in presentation** | Adds a soft real-frame cap without changing model quality. A reduced generated capacity raises the real-frame floor immediately; [Adaptive validation](ADAPTIVE-VALIDATION.md#gpu-headroom) owns response and recovery |
| Optional AC/battery selection | Configuration checks at most every 250 ms; background reading requested at most every two seconds | Atomic cached source and a nonblocking request, **negligible in presentation** | One sampler per watcher with power sets performs driver reads away from presentation, retains confirmed state on stalled/failed reads, and accumulates no requests. Startup allows 50 ms before Base fallback; normal transition boundaries remain authoritative |
| Policy-plan admission | Every present that requests generated outputs | Arithmetic and state checks, **negligible** | May shorten or remove the synthetic plan before any backend work while preserving the real frame |
| Tight-headroom image admission | Once for each planned generated output in legacy full-WSI HDR or headroom-tight ordered paths | Zero-time image acquisition, **low per attempted output** | A miss drops synthetic work before the backend starts. Partial Adaptive admission is re-spaced rather than bunched |
| Private-context readiness | While a live replacement is pending | Zero-time fence and timeline checks, **negligible** | Presentation temporarily uses real frames instead of waiting for device-wide idle |
| Retired-image completion | When a protected image is reacquired and while retirement can progress | Zero-time maintenance-fence checks, **negligible** | Recreation is not signalled and destruction is not completed until ownership evidence is available |
| Generated-path recovery | Only after an explicit acquire, fence, or backend failure | Zero-time checks in normal recovery; after acquire backoff, one image uses the configured acquire budget or one confirmed display period, and is nonblocking if neither exists, **low to bounded high** | Failure returns to native drain and increases backoff. Success resumes after fresh history without inventing a performance classification |
| Render completion | Before reusing generated work in the normal ordered path | Fence wait capped at 150 ms, **bounded high** | A miss abandons generated output for the present and enters backend recovery; it does not sacrifice the real frame |
| Lower presentation | Every delivered image | Driver/compositor queue-present call, **potentially unbounded outside MAKO's control** | Returned duration is diagnostic only. MAKO cannot cancel a currently blocked driver call and does not infer recovery authority after it returns |
| Renderer-owned Vulkan presentation timing | First eligible non-bridge FIFO present initializes support; one history query per source batch, with clock calibration at startup, on domain changes and after one second during use | Bounded Vulkan timing/history calls, **low to moderate** | Calibrated queue completion trains preparation lead; unsupported capabilities or failed feedback retain existing pacing. Application-owned timing keeps its namespace. [WSI isolation](WSI-ISOLATION.md#gamescope-timing-capabilities-across-the-stack) owns negotiation, clock validation and fallback |
| Renderer-owned Google timing fallback | Every 32 scheduled outputs on the eligible optional WSI path | Count query and at most 128 timing records, **low** | Drains only MAKO-owned history; query failure disables the timing path. Application-owned timing and enabled presentation waits exclude this fallback |
| Optional diagnostics | Only when explicitly enabled | Clock reads around selected operations and conditional stderr writes; slow-operation default threshold 20 ms, plus one-second summaries for active scheduler diagnostics, **negligible until logging, potentially visible when verbose** | Diagnostics are observational. Logging overhead means performance measurements should compare equivalent diagnostic settings |

## Timing ledger

This table centralizes lifecycle timers. Frame-count gates are included because they act like time gates at the current cadence.

| Area | Current interval or threshold | Purpose |
| --- | --- | --- |
| Configuration | 250 ms poll; 50 ms earliest parse retry | Avoid a filesystem read/parse on every present while recovering quickly from an atomic editor update |
| X11 feedback | 250 ms under Gamescope; 1 second on ordinary X11 | Keep compositor state current without X11 round trips on the present thread |
| Root discovery | At most once per second | Bound repeated candidate-display probing |
| GPU Headroom | Approximately two seconds of utilization samples; three-second source warm-up; decisions at least two seconds apart | Avoid chasing spikes; readings older than one second or source gaps over 250 ms release the extra cap. See [controller details](ADAPTIVE-VALIDATION.md#gpu-headroom) |
| Legacy WSI HDR confirmation | 750 ms stable evidence | Reject transient output/application HDR state |
| Private resource coalescing | Immediate for Scaling enablement, method, supersampling or HDR Quality changes; 500 ms for other private-resource changes | Apply completed choices promptly while coalescing slider movement and related edits |
| Private transition retry | 1 second after a color-readiness exception; 5 seconds after construction failure | Avoid a rebuild or exception storm while retaining the old context |
| Private spatial drain | Up to 50 ms total in one present call | Bound replacement progress without device-wide idle |
| Replacement warm-up | 250 ms real-only, then three real history frames | Prevent interpolation across old/new swapchain history |
| Adaptive stabilization | 3 seconds at initial startup; 1 second after ordinary recreation, cadence reset, or recovery | Establish a trustworthy base cadence before increasing load |
| Adaptive ramp | 1 second target deficit; 250 ms step delay; 1 second evaluation, extended by 250 ms when target preference requires a settled delivery sample | Add one generated level at a time and measure its value |
| Adaptive ramp retry | 5, 15, 30, then 60 seconds after repeated rejection; two seconds of stability for rearm | Avoid oscillating into a known-unhelpful load level |
| Adaptive interrupted or failed probe | 2-second cooldown after interruption; 15-second cooldown after failure; 2 seconds of stable evidence before rearm | Keep a cadence disruption from immediately restarting the same load experiment |
| Adaptive near-target preference | 1 second of qualifying evidence; opposite evidence decays twice as fast; each sample contributes at most 100 ms | Prefer native pacing near target without allowing one long frame or rapid oscillation to dominate the decision |
| Smooth Cadence | 2 seconds candidate evidence; 1 second evaluation; 500 ms exit evidence | Enter or leave a constant-multiplier cadence only after stable evidence |
| Smooth Cadence retry | Normally 15 seconds; 60 seconds per ordered FIFO handoff rung | Prevent repeated pacing-mode churn without blocking a separately validated rung |
| Exact-rung automatic cap | 1 second qualification | Select target divided by the already validated 3x–5x multiplier only when that base rung is sustainable |
| Efficiency probe | 5 seconds healthy operation; 250 ms initial check with at most one 250 ms extension, then at least 1 second of complete delivered samples before acceptance | Test whether one less generated frame sustains the target; [Adaptive validation](ADAPTIVE-VALIDATION.md#lower-load-probe-retries) owns acceptance and interruption rules |
| Efficiency retry | 60, 120, or 300 seconds according to failure severity | Make damaging efficiency experiments increasingly rare |
| Smooth Cadence rescue | 1 second real-only measurement, then 1 second verification with the configured cap and workload restored; 15-second rescue cooldown | Requalify a user-enabled constant-cadence policy without retaining an uncapped state; see [rescue qualification](ADAPTIVE-VALIDATION.md#smooth-cadence-rescue) for the collapse trigger and interruption rules |
| Conservative discontinuity recovery | 1 second recovered evidence; at most 5 seconds before resuming from zero generated load | Bound HDR or other conservative real-only recovery after a cadence discontinuity |
| Generated-image drain | Fixed and fixed-refresh Adaptive: 250, 500, 1000, 2000, 5000, 15000, then 30000 ms after an acquire timeout, budget exhaustion, or configured cumulative deadline overrun | Pace bounded retries after the explicit transport budget is missed; Adaptive VRR instead uses zero-wait admission until returned-image turnover permits another bounded wait |
| Pipeline busy | 250 ms uninterrupted busy state | Treat a single busy frame as harmless but reset history after sustained pressure |
| Swapchain retirement | At least 50 ms compositor grace plus fence completion | Avoid destroying a lower swapchain still being observed or used |
| Device teardown retirement | Up to 250 ms total, then forced finalization | Bound application device destruction while still attempting orderly retirement |

## Configuration lifecycle

Process-static settings wait for restart; swapchain geometry and transport wait for application recreation; private-resource edits prepare and atomically replace MAKO-owned contexts; live policy applies on the next successful present. Inactive values remain dormant.

Requested, applied, pending, and effective state remain distinct. Independent live edits continue while other changes wait, the latest request wins, and reverting to the applied value cancels pending work. [Runtime transitions](RUNTIME-TRANSITIONS.md#transition-matrix) owns the field-by-field matrix, mixed-write behavior, and reset rules.

## Swapchain lifecycle

### Creation

For every application swapchain creation, MAKO:

1. Forces a fresh configuration check so multiple presentation roles use the same revision.
2. Resolves the surface provenance, Gamescope role, current output target, source and presentation extents, queue support, format support, surface limits, and memory admission.
3. Chooses immutable presentation transport, scaling placement and generated-output headroom, plus the initial colour pipeline. Confirmed legacy WSI HDR feedback may replace private colour resources under the [HDR transition contract](HDR-PIPELINE.md#presentation-transport-and-transitions).
4. Requests the application minimum image count plus generated capacity when allowed. Ordered Frame-Generation-only paths may reserve one relief image; combined scaling that is active or configured above 1.0 omits that relief reservation for compatibility. An enabled 1.0 scaler remains inactive and retains the FG-only relief topology. The surface maximum remains authoritative, and Game Swapchain Images compatibility preserves the application's original minimum from process start.
5. Creates the lower swapchain. If only an expanded minimum fails with initialization or host/device memory exhaustion, it retries exactly once with the application's original minimum.
6. Reads the images actually returned. Fewer images than the application minimum removes generated capacity rather than assuming headroom.
7. Builds the required scaling and Frame Generation resources. Scaling-context failure rolls back creation because presenting the smaller source rectangle directly would be visibly incorrect. Frame-Generation-only failure retains a valid native swapchain.

Scaling factor is clamped to 1–2, dimensions greater than one are rounded down to even values, and aspect ratio is preserved. Managed variable-size Gamescope surfaces require a confirmed output target. Non-opaque, protected, layered, or shared-present swapchains, unsupported formats or queues, and managed multi-swapchain batches fail closed.

For presentation extents up to 2,304,000 pixels, scaling normally reconstructs the real frame before Frame Generation so reconstruction runs once. Above that threshold, Frame Generation runs at source resolution and each delivered image is reconstructed afterward. The threshold is a performance-placement heuristic; both orders use capability and synchronization proofs, and the selected order stays fixed for that swapchain.

LS1 creation failure falls back to the open MAKO Scaler for the affected context. Direct generated output is used only when external-image capabilities prove it safe; otherwise a private output plus copy is used.

### Warm-up and steady presentation

A cold context begins with real history before generated delivery. A known replacement additionally holds real-only presentation for 250 ms and then gathers three real history frames. A null-old scaled replacement is primed by presenting one application image directly before private scaler work, which avoids first-use compositor deadlocks.

On each present, MAKO updates cached policy, filters unsupported presentation extensions, applies an optional base-frame deadline, records cadence, advances private transitions, chooses a Fixed or Adaptive frame plan, performs admission, schedules backend work, delivers generated images, and finally presents the original real image. When scaling is active, “native” recovery still means the real frame passes through the required scaler; it does not expose an incomplete source rectangle.

Any exception or failed generated path returns to the real frame. If a failure occurs after generated images were acquired, MAKO still initializes and retires those images before the real present so image ownership remains valid.

### Recreation

Applications naturally recreate swapchains for resize, mode changes, out-of-date results, and other WSI events. For a configuration-driven change, MAKO can request recreation only when all of the following are true:

- the requested setting genuinely changes swapchain-owned resources;
- the presentation role is allowed to own that change;
- swapchain-maintenance retirement fences are supported;
- a successful or suboptimal lower present has supplied retirement evidence; and
- the same request has not already been signalled.

Managed Gamescope geometry changes are requested only by the upper spatial owner. A compatible non-Gamescope boundary may also request recreation when generated capacity exceeds current WSI headroom. The request is one `OUT_OF_DATE` result; the application remains responsible for creating the replacement. Repeated polls do not loop the signal, while a distinct request can arm a new one. Transport-failure and transition-scoped recovery requests follow the separate rules under [Pressure and recovery policies](#pressure-and-recovery-policies).

Explicit old-swapchain linkage is preferred. When an application omits it, MAKO recognizes a replacement only from a unique exact same-device/surface live or retained context. This constrained inference prevents unrelated swapchains from donating temporal history or retirement state.

### Destruction and retirement

Application destruction immediately removes a context from live updates, but lower WSI destruction may be deferred. When maintenance fences and the default allocator permit it, MAKO retains the lower swapchain for at least 50 ms and until its image fences prove retirement. Later presents on the same surface advance this work through zero-time completion polls, including when the replacement fell back to native presentation. Collection skips a busy retirement mutex and retains the context while its backend, render, or spatial work is still in flight, so presentation does not enter the backend's 250 ms close wait. An idle context still incurs its normal resource-destruction cost when collected.

If a matching null-old replacement arrives while an exact retained swapchain remains, MAKO completes and destroys the retained object before creating the replacement, but does not pass that retained handle back through Gamescope. Surface destruction is terminal and waits for same-surface retirement. Custom allocation callbacks require synchronous destruction because their callback data cannot safely outlive the application call.

Device destruction waits up to 250 ms across deferred retirements and then force-finalizes remaining lower swapchains because the parent device is itself going away. Instance destruction joins the display-feedback monitor before unload. The private backend Vulkan device is intentionally retained for process lifetime to avoid loader-destruction hazards in mixed layer stacks; the operating system reclaims it at process exit. This is retained memory, not periodic work.

## Frame pacing and generation policies

### Fixed

Fixed 2x–5x requests one to four generated frames between real frames. Confirmed refresh limits outputs the display cannot consume; absent feedback preserves the requested multiplier. The refresh threshold fails open when feedback is missing. Gameplay cadence cannot change the selected multiplier or authorize recovery.

### Adaptive

Adaptive selects a deterministic per-present plan under the target and 2x–5x ceiling. It warms history, stabilizes cadence, and tests adjacent workload levels through the shared [Adaptive workload policy](ADAPTIVE-VALIDATION.md#adjacent-workload-promotion). The policy prefers the lowest qualified workload that reaches the target; below-target promotions must pay for their real-frame cost. Fractional output credit and partial-admission spacing remain scheduler-owned.

[Adaptive validation](ADAPTIVE-VALIDATION.md#adaptive-mode) owns qualification thresholds, pacing handoffs, retry rules, and hardware evidence. These performance decisions cannot prove Vulkan capability, completion, or transport failure.

### Base cap, Smooth Cadence, and Dynamic Cadence Recovery

The real-frame cap uses an absolute deadline and rebases after late frames; its intentional sleep can span the selected cap interval. Smooth Cadence can retain a qualified integer multiplier and hand pacing to FIFO under the documented refresh/VRR guards. Manual caps remain authoritative.

Dynamic Cadence Recovery is an opt-in ordered-SDR native-only probe with usable target/refresh capacity, with a 0.1–3 second interval (default two seconds). It disables base caps and requires three samples at least 25% faster before changing policy. The [pacing matrix](ADAPTIVE-VALIDATION.md#vrr-and-fixed-refresh-pacing-paths) and [recovery contract](ADAPTIVE-VALIDATION.md#dynamic-cadence-recovery) define mode-specific behavior.

### GPU Headroom

GPU Headroom optionally adds a real-frame cap driven by smoothed whole-device utilization. Fixed retains its multiplier; Adaptive retains its qualification and output-target policy. It is mutually exclusive with Dynamic Cadence Recovery and yields to generation-off, refresh pause, confirmed menu suspension and ordered-acquire recovery. [Adaptive validation](ADAPTIVE-VALIDATION.md#gpu-headroom) owns the floor, pacing handoff and bounded cap-release trial; the [configuration reference](CONFIGURATION-REFERENCE.md#gpu-headroom) owns supported values and driver limits.

## Pressure and recovery policies

MAKO separates explicit transitions, direct transport failure, and feature policy. Confirmed Steam UI focus suspends generated work and scheduler observations while preserving real/scaled presentation. Return refreshes three history frames, retains the proven generated level, and arms one recreation permission that is consumed by the first generated-image acquire batch completed within its configured budget. Unknown focus, an unproven policy after a live reset, and unsupported transports retain conservative settling but cannot authorize recreation. A second interruption restarts the full history warm-up in both Fixed and Adaptive modes. Focus changes require 250 ms agreement; samples expire after one second without monitor updates.

1. **Pre-admission:** remove synthetic outputs before backend work when headroom, policy, or nonblocking image acquisition says they cannot be delivered.
2. **Acquire-budget failure:** `VK_TIMEOUT`, `VK_NOT_READY`, exhaustion of the configured cumulative application-present budget, or completing the batch after that cumulative wall-clock budget is reached stops the affected generated delivery. Fixed and fixed-refresh Adaptive enter native backoff. Adaptive VRR preserves the real frame and arms zero-wait admission on later frames. The budget is explicit; FPS, cadence, resolution, scaling, and shader cost do not derive or change it.
3. **Bounded retry:** Fixed and fixed-refresh Adaptive retry after 250, 500, 1000, 2000, 5000, 15000, then 30000 ms; fresh history precedes one bounded generated-image acquire. A real-only policy frame leaves the retry pending without acquisition or a failure count. Adaptive VRR resumes generated delivery as soon as a complete batch is available, but re-arms blocking only after consecutive complete batches account for one returned-image turnover. Its ordinary pressure retry cannot start the long backoff or authorize recreation. [Transport recovery](ADAPTIVE-VALIDATION.md#transport-recovery) owns the detailed mode-specific rules.
4. **Transition-scoped recreation:** a confirmed menu return or explicit live generation-policy change arms one permission. An acquire batch completed within its configured budget consumes it. An acquire-budget failure may consume it by requesting one retirement-protected game-owned recreation; there are no separate event windows, FPS qualifiers, or failure-count thresholds.
5. **Backend recovery:** a render-fence miss or backend failure switches to real frames while readiness is polled with zero-time waits. This is direct synchronization safety and cannot select a multiplier or request recreation. Recovery resets temporal history before generation resumes.

Normal ordered generated-image acquisition can be unbounded when no compatibility timeout is configured and relief headroom is available. MAKO Decky configures 50 ms; Adaptive VRR and Fixed batches without an additional relief image also enforce at most 50 ms, with shorter configured limits taking precedence. Headroom-tight paths use nonblocking admission. The shared deadline covers the complete application-present batch, so higher multipliers do not multiply the wait. See [WSI acquisition policy](WSI-ISOLATION.md#presentation-and-swapchain-policy) for the mode-specific rules. An unbounded driver/compositor acquire remains MAKO’s largest controlled blocking exposure. The lower queue-present call itself is always driver-controlled and cannot be bounded by MAKO, and its returned duration is diagnostic only.

## Heuristic audit

| Heuristic or inference | Why it exists | Guardrails and failure mode |
| --- | --- | --- |
| 2,304,000-pixel scaling placement threshold | Balance reconstruction cost against Frame Generation resolution | Immutable per swapchain; both paths retain full capability and synchronization checks |
| Conservative memory admission | Avoid committing source, presentation, and model resources into already pressured heaps | Uses live budget when available, reserves non-MAKO headroom, reduces scale or fails closed |
| 750 ms HDR stability | Prevent transient compositor properties from rebuilding color resources | Unknown cancels the candidate; old confirmed pipeline remains active; construction is atomic |
| Exact same-device/surface null-old replacement inference | Recover lifecycle continuity from applications that omit explicit old-swapchain linkage | Requires a unique exact match and never reuses an unrelated context |
| 50 ms retirement grace | Cover compositor observation beyond the application's destroy call | Grace is not the proof: image retirement fences and terminal waits remain authoritative |
| Dynamic Cadence native-only probes | Implement the user's optional request to discover a hidden native-rate change under ordered FIFO | Disabled by default, bounded, verified, and able only to remove synthetic work |
| Adaptive workload promotion | Find a useful multiplier without a GPU-utilization API | One device-independent adjacent-load rule prefers measured target delivery, retains real-FPS cost checks below target, and preserves the best lower baseline after failure |
| GPU Headroom source cap | Leave execution capacity by reducing real-frame demand when sustained utilization is high | Optional, smoothed and rate-limited; respects the real-frame floor and existing caps. Missing telemetry removes the extra cap; utilization cannot authorize transport recovery |
| Near-target native preference | Avoid fractional generation when native cadence is already smooth enough | One second of confirming evidence and asymmetric decay |
| Gamescope VRR pacing ownership | Keep explicit requested or active VRR out of the higher-multiplier fixed-refresh cap ladder while allowing validated integer FIFO handoffs | Verified server-zero properties; eligible Fixed, proven Steady 2x, validated Steady 3x–5x, and accepted constant Fractional plans can use FIFO under their own guards; live changes reset only affected pacing helpers |
| Unbounded ordered acquisition where permitted | Avoid rejecting healthy but variably delayed compositor acquisition | Relief headroom and no configured or mode-specific deadline; see the acquisition policy above |

The first five rows affect placement, admission, state confirmation, or lifecycle association. Dynamic Cadence, Adaptive promotion and GPU Headroom affect their explicitly selected pacing behavior. None is allowed to assert Vulkan capability, completion, image ownership, transport failure, or recreation authority.

## What MAKO does not probe

- With diagnostics disabled, MAKO creates no diagnostic health worker. GPU Headroom has a separate opt-in utilization monitor that can drive its source cap; leaving Headroom Off creates no such monitor. Vulkan memory budget is queried only for resource admission.
- MAKO does not observe physical scanout timestamps. It consumes Gamescope's explicit VRR preference, capability, and active-state properties for pacing ownership, but present/acquire duration and application cadence remain proxies and cannot prove scanout.
- MAKO does not continuously rescan Vulkan capabilities. Device and surface facts are cached for their owning lifetime and current swapchain limits are rechecked at creation.
- MAKO does not infer safety from average frame rate. Capability, return-code, queue, fence, and ownership checks remain separate from performance decisions.
- MAKO does not support managed multi-swapchain present batches by guessing semaphore ownership; those shapes fail closed before synchronization is consumed.
- MAKO cannot preempt a blocking Vulkan driver call. Recovery begins after control returns.

These limits are deliberate, but they define where diagnostics and real-hardware evidence matter most. Any new probe should document its owner lifetime, trigger, worst-case foreground cost, cache invalidation, failure behavior, and whether it supplies safety evidence or only policy evidence.
