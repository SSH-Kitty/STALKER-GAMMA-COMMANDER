/* SPDX-License-Identifier: GPL-3.0-or-later */

#include "mako-common/vulkan/image.hpp"
#include "mako-common/helpers/errors.hpp"
#include "mako-common/helpers/file_descriptors.hpp"
#include "mako-common/helpers/pointers.hpp"
#include "mako-common/vulkan/image_memory_pool.hpp"
#include "mako-common/vulkan/vulkan.hpp"

#include <bitset>
#include <memory>
#include <optional>
#include <stdexcept>

#include <vulkan/vulkan_core.h>

using namespace vk;

namespace {
    /// create a image
    ls::owned_ptr<VkImage> createImage(const vk::Vulkan& vk,
            VkExtent2D extent, VkFormat format, VkImageUsageFlags usage,
            bool external) {
        VkImage handle{};

        const VkExternalMemoryImageCreateInfo externalInfo{
            .sType = VK_STRUCTURE_TYPE_EXTERNAL_MEMORY_IMAGE_CREATE_INFO,
            .handleTypes = VK_EXTERNAL_MEMORY_HANDLE_TYPE_OPAQUE_FD_BIT_KHR
        };
        const VkImageCreateInfo imageInfo{
            .sType = VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO,
            .pNext = external ? &externalInfo : nullptr,
            .imageType = VK_IMAGE_TYPE_2D,
            .format = format,
            .extent = {
                .width = extent.width,
                .height = extent.height,
                .depth = 1
            },
            .mipLevels = 1,
            .arrayLayers = 1,
            .samples = VK_SAMPLE_COUNT_1_BIT,
            .usage = usage,
            .sharingMode = VK_SHARING_MODE_EXCLUSIVE
        };
        auto res = vk.df().CreateImage(vk.dev(), &imageInfo, VK_NULL_HANDLE, &handle);
        if (res != VK_SUCCESS)
            throw ls::vulkan_error(res, "vkCreateImage() failed");

        return ls::owned_ptr<VkImage>(
            new VkImage(handle),
            [dev = vk.dev(), defunc = vk.df().DestroyImage](VkImage& image) {
                defunc(dev, image, VK_NULL_HANDLE);
            }
        );
    }
    /// allocate memory for a image
    ls::owned_ptr<VkDeviceMemory> allocateMemory(const vk::Vulkan& vk, VkImage image,
            std::optional<int> importFd, bool exportable,
            ls::FileDescriptorScope& imported) {
        VkDeviceMemory handle{};

        VkMemoryRequirements reqs{};
        vk.df().GetImageMemoryRequirements(vk.dev(), image, &reqs);

        auto mti = vk.findMemoryTypeIndex(
            reqs.memoryTypeBits,
            false
        );
        if (!mti.has_value())
            throw ls::vulkan_error("no suitable memory type found for image");

        const VkMemoryDedicatedAllocateInfoKHR dedicatedInfo{
            .sType = VK_STRUCTURE_TYPE_MEMORY_DEDICATED_ALLOCATE_INFO_KHR,
            .image = image,
        };
        const VkImportMemoryFdInfoKHR importInfo{
            .sType = VK_STRUCTURE_TYPE_IMPORT_MEMORY_FD_INFO_KHR,
            .pNext = &dedicatedInfo,
            .handleType = VK_EXTERNAL_MEMORY_HANDLE_TYPE_OPAQUE_FD_BIT_KHR,
            .fd = importFd.value_or(-1)
        };
        const VkExportMemoryAllocateInfo exportInfo{
            .sType = VK_STRUCTURE_TYPE_EXPORT_MEMORY_ALLOCATE_INFO,
            .pNext = &dedicatedInfo,
            .handleTypes = VK_EXTERNAL_MEMORY_HANDLE_TYPE_OPAQUE_FD_BIT_KHR
        };
        const void* pNextAlloc{};
        if (importFd.has_value())
            pNextAlloc = &importInfo;
        else if (exportable)
            pNextAlloc = &exportInfo;
        const VkMemoryAllocateInfo memoryInfo{
            .sType = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO,
            .pNext = pNextAlloc,
            .allocationSize = reqs.size,
            .memoryTypeIndex = *mti
        };
        auto res = vk.df().AllocateMemory(vk.dev(), &memoryInfo, VK_NULL_HANDLE, &handle);
        if (res != VK_SUCCESS)
            throw ls::vulkan_error(res, "vkAllocateMemory() failed");
        // A successful import transfers FD ownership to Vulkan, even if a
        // later bind or view creation fails. Never close that number again.
        imported.release();
        if (handle == VK_NULL_HANDLE)
            throw ls::vulkan_error(VK_ERROR_OUT_OF_DEVICE_MEMORY,
                "vkAllocateMemory() succeeded but returned a null handle");

        const auto memoryKind = importFd.has_value()
            ? DeviceMemoryKind::Imported
            : exportable
                ? DeviceMemoryKind::Exported
                : DeviceMemoryKind::Internal;
        const auto memoryAccounting = vk.deviceMemoryAccounting();
        memoryAccounting->recordAllocation(memoryKind, reqs.size);
        auto memory = ls::owned_ptr<VkDeviceMemory>(
            new VkDeviceMemory(handle),
            [dev = vk.dev(), defunc = vk.df().FreeMemory,
             memoryAccounting, memoryKind,
             allocationSize = reqs.size](VkDeviceMemory& value) {
                defunc(dev, value, VK_NULL_HANDLE);
                memoryAccounting->recordFree(memoryKind, allocationSize);
            }
        );

        res = vk.df().BindImageMemory(vk.dev(), image, handle, 0);
        if (res != VK_SUCCESS)
            throw ls::vulkan_error(res, "vkBindImageMemory() failed");

        return memory;
    }
    /// export only after the complete image is ready for its caller
    void exportMemory(const vk::Vulkan& vk, VkDeviceMemory memory, int& fd) {
        const VkMemoryGetFdInfoKHR fdInfo{
            .sType = VK_STRUCTURE_TYPE_MEMORY_GET_FD_INFO_KHR,
            .memory = memory,
            .handleType = VK_EXTERNAL_MEMORY_HANDLE_TYPE_OPAQUE_FD_BIT_KHR
        };
        int exportedFd{-1};
        const auto res = vk.df().GetMemoryFdKHR(vk.dev(), &fdInfo, &exportedFd);
        if (res != VK_SUCCESS)
            throw ls::vulkan_error(res, "vkGetMemoryFdKHR() failed");
        fd = exportedFd;
    }
    /// create an image view
    ls::owned_ptr<VkImageView> createImageView(const vk::Vulkan& vk,
            VkImage image, VkFormat format) {
        VkImageView handle{};

        const VkImageViewCreateInfo viewInfo{
            .sType = VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO,
            .image = image,
            .viewType = VK_IMAGE_VIEW_TYPE_2D,
            .format = format,
            .subresourceRange = {
                .aspectMask = VK_IMAGE_ASPECT_COLOR_BIT,
                .baseMipLevel = 0,
                .levelCount = 1,
                .baseArrayLayer = 0,
                .layerCount = 1
            }
        };
        auto res = vk.df().CreateImageView(vk.dev(), &viewInfo, VK_NULL_HANDLE, &handle);
        if (res != VK_SUCCESS)
            throw ls::vulkan_error(res, "vkCreateImageView() failed");

        return ls::owned_ptr<VkImageView>(
            new VkImageView(handle),
            [dev = vk.dev(), defunc = vk.df().DestroyImageView](VkImageView& view) {
                defunc(dev, view, VK_NULL_HANDLE);
            }
        );
    }
}

Image::Image(const vk::Vulkan& vk,
            VkExtent2D extent,
            VkFormat format,
            VkImageUsageFlags usage,
            std::optional<int> importFd,
            std::optional<int*> exportFd,
            std::shared_ptr<ImageMemoryPool> internalPool) :
        extent(extent), externalMemory(importFd.has_value() || exportFd.has_value()) {
    const int incomingFd = importFd.value_or(-1);
    ls::FileDescriptorScope imported{{&incomingFd, 1}};
    if (internalPool && (importFd || exportFd))
        throw std::invalid_argument(
            "external Vulkan images cannot use the internal image pool"
        );
    this->image = createImage(vk, extent, format, usage,
        importFd.has_value() || exportFd.has_value());
    if (internalPool) {
        this->pooledMemory = internalPool->bind(*this->image);
    } else {
        this->memory = allocateMemory(vk, *this->image, importFd,
            exportFd.has_value(), imported);
    }
    // Transfer-only images (for example Native Resolution scratch) are never
    // sampled or bound as attachments. Vulkan forbids creating views for this
    // usage, and copy/blit commands need only the image handle.
    constexpr VkImageUsageFlags transferUsage =
        VK_IMAGE_USAGE_TRANSFER_SRC_BIT | VK_IMAGE_USAGE_TRANSFER_DST_BIT;
    if ((usage & ~transferUsage) != 0)
        this->view = createImageView(vk, *this->image, format);
    else
        this->view = ls::owned_ptr<VkImageView>(new VkImageView(VK_NULL_HANDLE));
    if (exportFd)
        exportMemory(vk, *this->memory, **exportFd);
}

Image::Image(const vk::Vulkan& vk,
            const VkExtent2D extent,
            std::shared_ptr<ImageMemoryPool> internalPool,
            const VkFormat format,
            const VkImageUsageFlags usage)
    : Image(vk, extent, format, usage,
        std::nullopt, std::nullopt, std::move(internalPool)) {}
