/* SPDX-License-Identifier: GPL-3.0-or-later */

#include "mako-common/vulkan/command_buffer.hpp"
#include "mako-common/helpers/errors.hpp"
#include "mako-common/helpers/pointers.hpp"
#include "mako-common/vulkan/buffer.hpp"
#include "mako-common/vulkan/descriptor_set.hpp"
#include "mako-common/vulkan/fence.hpp"
#include "mako-common/vulkan/image.hpp"
#include "mako-common/vulkan/external_image.hpp"
#include "mako-common/vulkan/shader.hpp"
#include "mako-common/vulkan/vulkan.hpp"
#include "command_buffer_submit_storage.hpp"

#include <cstdint>
#include <optional>
#include <span>
#include <stdexcept>
#include <utility>

#include <vulkan/vulkan_core.h>

using namespace vk;

namespace {
    /// create a command buffer
    ls::owned_ptr<VkCommandBuffer> createCommandBuffer(const vk::Vulkan& vk) {
        VkCommandBuffer handle{};

        const VkCommandBufferAllocateInfo commandBufferInfo{
            .sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO,
            .commandPool = vk.cmdpool(),
            .level = VK_COMMAND_BUFFER_LEVEL_PRIMARY,
            .commandBufferCount = 1
        };
        auto res = vk.df().AllocateCommandBuffers(vk.dev(), &commandBufferInfo, &handle);
        if (res != VK_SUCCESS)
            throw ls::vulkan_error(res, "vkAllocateCommandBuffers() failed");

        auto setLoaderData = vk.loaderdatafunc();
        if (setLoaderData) {
            res = (*setLoaderData)(vk.dev(), handle);
            if (res != VK_SUCCESS)
                throw ls::vulkan_error(res, "vkSetDeviceLoaderData() failed");
        }

        return ls::owned_ptr<VkCommandBuffer>(
            new VkCommandBuffer(handle),
            [dev = vk.dev(), pool = vk.cmdpool(), defunc = vk.df().FreeCommandBuffers](
                VkCommandBuffer& commandBufferModule
            ) {
                defunc(dev, pool, 1, &commandBufferModule);
            }
        );
    }
}

CommandBuffer::CommandBuffer(const vk::Vulkan& vk)
        : commandBuffer(createCommandBuffer(vk)) {}

void CommandBuffer::begin(const vk::Vulkan& vk, const VkCommandBufferUsageFlags flags) const {
    const VkCommandBufferBeginInfo beginInfo = {
        .sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO,
        .flags = flags
    };
    auto res = vk.df().BeginCommandBuffer(*this->commandBuffer, &beginInfo);
    if (res != VK_SUCCESS)
        throw ls::vulkan_error(res, "vkBeginCommandBuffer() failed");
}

void CommandBuffer::insertBarriers(const vk::Vulkan& vk,
        const std::span<const vk::Barrier> barriers) const {
    vk.df().CmdPipelineBarrier(*this->commandBuffer,
        VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT, VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT,
        0,
        0, VK_NULL_HANDLE,
        0, VK_NULL_HANDLE,
        static_cast<uint32_t>(barriers.size()), barriers.data()
    );
}

void CommandBuffer::dispatch(const vk::Vulkan& vk,
        const vk::Shader& shader,
        const vk::DescriptorSet& set,
        const std::span<const vk::Barrier> barriers,
        uint32_t x, uint32_t y, uint32_t z) const {
    this->insertComputeBarriers(vk, barriers);
    this->dispatchAfterBarrier(vk, shader, set, x, y, z);
}

void CommandBuffer::insertComputeBarriers(const vk::Vulkan& vk,
        const std::span<const vk::Barrier> barriers) const {
    vk.df().CmdPipelineBarrier(*this->commandBuffer,
        VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
        VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
        0,
        0, VK_NULL_HANDLE,
        0, VK_NULL_HANDLE,
        static_cast<uint32_t>(barriers.size()), barriers.data()
    );
}

void CommandBuffer::dispatchAfterBarrier(const vk::Vulkan& vk,
        const vk::Shader& shader, const vk::DescriptorSet& set,
        uint32_t x, uint32_t y, uint32_t z) const {
    vk.df().CmdBindPipeline(*this->commandBuffer,
        VK_PIPELINE_BIND_POINT_COMPUTE,
        shader.pipeline()
    );
    vk.df().CmdBindDescriptorSets(*this->commandBuffer,
        VK_PIPELINE_BIND_POINT_COMPUTE,
        shader.pipelinelayout(),
        0, 1, &set.handle(),
        0, VK_NULL_HANDLE
    );
    vk.df().CmdDispatch(*this->commandBuffer, x, y, z);
    // The optional module writes a disjoint subset of the stage's images.
    // Its layout is identical, so descriptor bindings and outer barriers cover
    // both dispatches without an extra image dependency or queue submission.
    if (const auto pipeline = shader.independentPipeline(); pipeline != VK_NULL_HANDLE) {
        vk.df().CmdBindPipeline(*this->commandBuffer, VK_PIPELINE_BIND_POINT_COMPUTE, pipeline);
        vk.df().CmdDispatch(*this->commandBuffer, x, y, z);
    }
}

void CommandBuffer::blitImage(const vk::Vulkan& vk,
        const std::span<const vk::Barrier> preBarriers,
        std::pair<VkImage, VkImage> images, VkExtent2D extent,
        const std::span<const vk::Barrier> postBarriers) const {
    vk.df().CmdPipelineBarrier(*this->commandBuffer,
        VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT,
        0,
        0, VK_NULL_HANDLE,
        0, VK_NULL_HANDLE,
        static_cast<uint32_t>(preBarriers.size()), preBarriers.data()
    );

    const VkImageBlit region{
        .srcSubresource = {
            .aspectMask = VK_IMAGE_ASPECT_COLOR_BIT,
            .layerCount = 1
        },
        .srcOffsets = {
            { 0, 0, 0 },
            { static_cast<int32_t>(extent.width),
              static_cast<int32_t>(extent.height), 1 }
        },
        .dstSubresource = {
            .aspectMask = VK_IMAGE_ASPECT_COLOR_BIT,
            .layerCount = 1
        },
        .dstOffsets = {
            { 0, 0, 0 },
            { static_cast<int32_t>(extent.width),
              static_cast<int32_t>(extent.height), 1 }
        }
    };
    vk.df().CmdBlitImage(*this->commandBuffer,
        images.first, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,
        images.second, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
        1, &region,
        VK_FILTER_NEAREST
    );

    vk.df().CmdPipelineBarrier(*this->commandBuffer,
        VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT,
        0,
        0, VK_NULL_HANDLE,
        0, VK_NULL_HANDLE,
        static_cast<uint32_t>(postBarriers.size()), postBarriers.data()
    );
}

void CommandBuffer::copyBufferToImage(const vk::Vulkan& vk,
        const vk::Buffer& buffer, const vk::Image& image) const {
    const VkImageMemoryBarrier barrier{
        .sType = VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER,
        .srcAccessMask = VK_ACCESS_NONE,
        .dstAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT,
        .oldLayout = image.external() ? VK_IMAGE_LAYOUT_UNDEFINED : VK_IMAGE_LAYOUT_GENERAL,
        .newLayout = VK_IMAGE_LAYOUT_GENERAL,
        .srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED,
        .dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED,
        .image = image.handle(),
        .subresourceRange = {
            .aspectMask = VK_IMAGE_ASPECT_COLOR_BIT,
            .levelCount = 1,
            .layerCount = 1
        }
    };
    vk.df().CmdPipelineBarrier(*this->commandBuffer,
        VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT,
        0,
        0, VK_NULL_HANDLE,
        0, VK_NULL_HANDLE,
        1, &barrier
    );

    const VkBufferImageCopy region{
        .bufferImageHeight = 0,
        .imageSubresource = {
            .aspectMask = VK_IMAGE_ASPECT_COLOR_BIT,
            .layerCount = 1
        },
        .imageExtent = {
            .width = image.getExtent().width,
            .height = image.getExtent().height,
            .depth = 1
        }
    };
    vk.df().CmdCopyBufferToImage(*this->commandBuffer,
        buffer.handle(), image.handle(),
        VK_IMAGE_LAYOUT_GENERAL, 1, &region
    );
    if (image.external())
        releaseExternalImage(vk, *this->commandBuffer, image.handle(),
            VK_ACCESS_TRANSFER_WRITE_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT);
}

void CommandBuffer::copyImageToBuffer(const vk::Vulkan& vk,
        const vk::Image& image, const vk::Buffer& buffer) const {
    if (image.external())
        acquireExternalImage(vk, *this->commandBuffer, image.handle(),
            VK_ACCESS_TRANSFER_READ_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT);
    const VkImageMemoryBarrier barrier{
        .sType = VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER,
        .srcAccessMask = VK_ACCESS_SHADER_WRITE_BIT,
        .dstAccessMask = VK_ACCESS_TRANSFER_READ_BIT,
        .oldLayout = VK_IMAGE_LAYOUT_GENERAL,
        .newLayout = VK_IMAGE_LAYOUT_GENERAL,
        .srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED,
        .dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED,
        .image = image.handle(),
        .subresourceRange = {
            .aspectMask = VK_IMAGE_ASPECT_COLOR_BIT,
            .levelCount = 1,
            .layerCount = 1
        }
    };
    vk.df().CmdPipelineBarrier(*this->commandBuffer,
        VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT,
        0,
        0, VK_NULL_HANDLE,
        0, VK_NULL_HANDLE,
        1, &barrier
    );

    const VkBufferImageCopy region{
        .bufferImageHeight = 0,
        .imageSubresource = {
            .aspectMask = VK_IMAGE_ASPECT_COLOR_BIT,
            .layerCount = 1
        },
        .imageExtent = {
            .width = image.getExtent().width,
            .height = image.getExtent().height,
            .depth = 1
        }
    };
    vk.df().CmdCopyImageToBuffer(*this->commandBuffer,
        image.handle(), VK_IMAGE_LAYOUT_GENERAL,
        buffer.handle(), 1, &region
    );
}

void CommandBuffer::end(const vk::Vulkan& vk) const {
    auto res = vk.df().EndCommandBuffer(*this->commandBuffer);
    if (res != VK_SUCCESS)
        throw ls::vulkan_error(res, "vkEndCommandBuffer() failed");
}

namespace {
    VkSubmitInfo submitInfo(const vk::detail::CommandBufferSubmitStorage& storage,
            VkTimelineSemaphoreSubmitInfo& timelineInfo, std::span<const VkCommandBuffer> commands) {
        timelineInfo = {
            .sType = VK_STRUCTURE_TYPE_TIMELINE_SEMAPHORE_SUBMIT_INFO,
            .waitSemaphoreValueCount = static_cast<uint32_t>(storage.waitValues().size()),
            .pWaitSemaphoreValues = storage.waitValues().data(),
            .signalSemaphoreValueCount = static_cast<uint32_t>(storage.signalValues().size()),
            .pSignalSemaphoreValues = storage.signalValues().data(),
        };
        return {
            .sType = VK_STRUCTURE_TYPE_SUBMIT_INFO,
            .pNext = storage.usesTimelineSemaphores() ? &timelineInfo : nullptr,
            .waitSemaphoreCount = static_cast<uint32_t>(storage.waits().size()),
            .pWaitSemaphores = storage.waits().data(),
            .pWaitDstStageMask = storage.stages().data(),
            .commandBufferCount = static_cast<uint32_t>(commands.size()),
            .pCommandBuffers = commands.data(),
            .signalSemaphoreCount = static_cast<uint32_t>(storage.signals().size()),
            .pSignalSemaphores = storage.signals().data(),
        };
    }
}

void CommandBuffer::submit(const vk::Vulkan& vk,
        const std::span<const VkSemaphore> waitSemaphores,
        VkSemaphore waitTimelineSemaphore, uint64_t waitValue,
        const std::span<const VkSemaphore> signalSemaphores,
        VkSemaphore signalTimelineSemaphore, uint64_t signalValue,
        VkFence fence, const VkQueue queue) const {
    submitCommands(vk, {&*this->commandBuffer, 1},
        waitSemaphores, waitTimelineSemaphore, waitValue,
        signalSemaphores, signalTimelineSemaphore, signalValue, fence, queue);
}

void CommandBuffer::submitCommands(const vk::Vulkan& vk,
        const std::span<const VkCommandBuffer> commands,
        const std::span<const VkSemaphore> waitSemaphores,
        VkSemaphore waitTimelineSemaphore, uint64_t waitValue,
        const std::span<const VkSemaphore> signalSemaphores,
        VkSemaphore signalTimelineSemaphore, uint64_t signalValue,
        VkFence fence, const VkQueue queue) {
    if (commands.empty())
        throw std::invalid_argument("Command-buffer submission is empty");
    const vk::detail::CommandBufferSubmitStorage storage{
        waitSemaphores, waitTimelineSemaphore, waitValue,
        signalSemaphores, signalTimelineSemaphore, signalValue
    };
    VkTimelineSemaphoreSubmitInfo timelineInfo{};
    const auto info = submitInfo(storage, timelineInfo, commands);
    auto res = vk.df().QueueSubmit(
        queue == VK_NULL_HANDLE ? vk.queue() : queue,
        1, &info, fence
    );
    if (res != VK_SUCCESS)
        throw ls::vulkan_error(res, "vkQueueSubmit() failed");
}


void CommandBuffer::submit(const vk::Vulkan& vk) const {
    const VkSubmitInfo submitInfo{
        .sType = VK_STRUCTURE_TYPE_SUBMIT_INFO,
        .commandBufferCount = 1,
        .pCommandBuffers = &*this->commandBuffer
    };
    const vk::Fence fence{vk};
    auto res = vk.df().QueueSubmit(vk.queue(), 1, &submitInfo, fence.handle());
    if (res != VK_SUCCESS)
        throw ls::vulkan_error(res, "vkQueueSubmit() failed");

    if (!fence.wait(vk))
        throw ls::vulkan_error(VK_TIMEOUT, "Fence::wait() timed out");
}
