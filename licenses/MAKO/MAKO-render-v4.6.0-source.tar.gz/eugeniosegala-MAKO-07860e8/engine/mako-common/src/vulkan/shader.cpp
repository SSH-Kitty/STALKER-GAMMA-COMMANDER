/* SPDX-License-Identifier: GPL-3.0-or-later */

#include "mako-common/vulkan/shader.hpp"
#include "mako-common/helpers/errors.hpp"
#include "mako-common/helpers/pointers.hpp"
#include "mako-common/vulkan/vulkan.hpp"

#include <cstddef>
#include <cstdint>
#include <span>
#include <vector>

#include <vulkan/vulkan_core.h>

using namespace vk;

namespace {
    /// create a shader module
    ls::owned_ptr<VkShaderModule> createShaderModule(
            const vk::Vulkan& vk,
            const uint8_t* data, size_t data_len) {
        VkShaderModule handle{};

        const VkShaderModuleCreateInfo shaderModuleInfo{
            .sType = VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO,
            .codeSize = data_len,
            .pCode = reinterpret_cast<const uint32_t*>(data)
        };
        auto res = vk.df().CreateShaderModule(vk.dev(), &shaderModuleInfo, VK_NULL_HANDLE, &handle);
        if (res != VK_SUCCESS)
            throw ls::vulkan_error(res, "vkCreateShaderModule() failed");

        return ls::owned_ptr<VkShaderModule>(
            new VkShaderModule(handle),
            [dev = vk.dev(), defunc = vk.df().DestroyShaderModule](VkShaderModule& shaderModule) {
                defunc(dev, shaderModule, VK_NULL_HANDLE);
            }
        );
    }

    ls::owned_ptr<VkShaderModule> createShaderModule(
            const vk::Vulkan& vk,
            const std::span<const uint32_t> code) {
        VkShaderModule handle{};

        const VkShaderModuleCreateInfo shaderModuleInfo{
            .sType = VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO,
            .codeSize = code.size_bytes(),
            .pCode = code.data(),
        };
        const auto res = vk.df().CreateShaderModule(
            vk.dev(), &shaderModuleInfo, VK_NULL_HANDLE, &handle
        );
        if (res != VK_SUCCESS)
            throw ls::vulkan_error(res, "vkCreateShaderModule() failed");

        return ls::owned_ptr<VkShaderModule>(
            new VkShaderModule(handle),
            [dev = vk.dev(), defunc = vk.df().DestroyShaderModule](
                    VkShaderModule& shaderModule) {
                defunc(dev, shaderModule, VK_NULL_HANDLE);
            }
        );
    }
    /// create a descriptor set layout
    ls::owned_ptr<VkDescriptorSetLayout> createDescriptorSetLayout(
            const vk::Vulkan& vk,
            size_t sampledImages, size_t storageImages,
            size_t buffers, size_t samplers) {
        VkDescriptorSetLayout handle{};

        std::vector<VkDescriptorSetLayoutBinding> bindings;
        bindings.reserve(buffers + samplers + sampledImages + storageImages);

        for (size_t i = 0; i < buffers; i++)
            bindings.push_back({
                .binding = static_cast<uint32_t>(i),
                .descriptorType = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER,
                .descriptorCount = 1,
                .stageFlags = VK_SHADER_STAGE_COMPUTE_BIT
            });
        for (size_t i = 0; i < samplers; i++)
            bindings.push_back({
                .binding = static_cast<uint32_t>(i + 16),
                .descriptorType = VK_DESCRIPTOR_TYPE_SAMPLER,
                .descriptorCount = 1,
                .stageFlags = VK_SHADER_STAGE_COMPUTE_BIT
            });
        for (size_t i = 0; i < sampledImages; i++)
            bindings.push_back({
                .binding = static_cast<uint32_t>(i + 32),
                .descriptorType = VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE,
                .descriptorCount = 1,
                .stageFlags = VK_SHADER_STAGE_COMPUTE_BIT
            });
        for (size_t i = 0; i < storageImages; i++)
            bindings.push_back({
                .binding = static_cast<uint32_t>(i + 48),
                .descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_IMAGE,
                .descriptorCount = 1,
                .stageFlags = VK_SHADER_STAGE_COMPUTE_BIT
            });

        const VkDescriptorSetLayoutCreateInfo info{
            .sType = VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO,
            .bindingCount = static_cast<uint32_t>(bindings.size()),
            .pBindings = bindings.data()
        };
        auto res = vk.df().CreateDescriptorSetLayout(vk.dev(), &info, VK_NULL_HANDLE, &handle);
        if (res != VK_SUCCESS)
            throw ls::vulkan_error(res, "vkCreateDescriptorSetLayout() failed");

        return ls::owned_ptr<VkDescriptorSetLayout>(
            new VkDescriptorSetLayout(handle),
            [dev = vk.dev(), defunc = vk.df().DestroyDescriptorSetLayout](
                VkDescriptorSetLayout& layout
            ) {
                defunc(dev, layout, VK_NULL_HANDLE);
            }
        );
    }
    /// create a pipeline layout
    ls::owned_ptr<VkPipelineLayout> createPipelineLayout(
            const vk::Vulkan& vk,
            VkDescriptorSetLayout descriptorLayout) {
        VkPipelineLayout handle{};

        const VkPipelineLayoutCreateInfo layoutInfo{
            .sType = VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO,
            .setLayoutCount = 1,
            .pSetLayouts = &descriptorLayout
        };
        auto res = vk.df().CreatePipelineLayout(vk.dev(), &layoutInfo, VK_NULL_HANDLE, &handle);
        if (res != VK_SUCCESS)
            throw ls::vulkan_error(res, "vkCreatePipelineLayout() failed");

        return ls::owned_ptr<VkPipelineLayout>(
            new VkPipelineLayout(handle),
            [dev = vk.dev(), defunc = vk.df().DestroyPipelineLayout](VkPipelineLayout& layout) {
                defunc(dev, layout, VK_NULL_HANDLE);
            }
        );
    }
    /// create a compute pipeline
    ls::owned_ptr<VkPipeline> createComputePipeline(
            const vk::Vulkan& vk,
            VkShaderModule shaderModule,
            VkPipelineLayout pipelineLayout) {
        VkPipeline handle{};

        const VkPipelineShaderStageCreateInfo shaderStageInfo{
            .sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO,
            .stage = VK_SHADER_STAGE_COMPUTE_BIT,
            .module = shaderModule,
            .pName = "main"
        };
        const VkComputePipelineCreateInfo pipelineInfo{
            .sType = VK_STRUCTURE_TYPE_COMPUTE_PIPELINE_CREATE_INFO,
            .stage = shaderStageInfo,
            .layout = pipelineLayout
        };
        auto res = vk.df().CreateComputePipelines(vk.dev(),
            vk.cache(), 1, &pipelineInfo, VK_NULL_HANDLE, &handle);
        if (res != VK_SUCCESS)
            throw ls::vulkan_error(res, "vkCreateComputePipelines() failed");

        return ls::owned_ptr<VkPipeline>(
            new VkPipeline(handle),
            [dev = vk.dev(), defunc = vk.df().DestroyPipeline](VkPipeline& pipeline) {
                defunc(dev, pipeline, VK_NULL_HANDLE);
            }
        );
    }
}

Shader::Shader(const vk::Vulkan& vk, const std::vector<uint8_t>& code,
        size_t sampledImages, size_t storageImages,
        size_t buffers, size_t samplers, const std::span<const uint8_t> independentCode) :
    shaderModule(createShaderModule(vk,
        code.data(), code.size()
    )),
    descriptorLayout(createDescriptorSetLayout(vk,
        sampledImages, storageImages,
        buffers, samplers
    )),
    pipelineLayout(createPipelineLayout(vk,
        *this->descriptorLayout
    )),
    pipeline_(createComputePipeline(vk,
        *this->shaderModule,
        *this->pipelineLayout
    )) {
    // Pipelines own the compiled executable; the input module is needed only
    // until pipeline creation returns, including for later context reuse.
    this->shaderModule = {};
    if (!independentCode.empty()) {
        auto module = createShaderModule(vk, independentCode.data(), independentCode.size());
        this->independentPipeline_.emplace(createComputePipeline(vk, *module, *this->pipelineLayout));
    }
}

Shader::Shader(const vk::Vulkan& vk, const std::span<const uint32_t> code,
        const size_t sampledImages, const size_t storageImages,
        const size_t buffers, const size_t samplers) :
    shaderModule(createShaderModule(vk, code)),
    descriptorLayout(createDescriptorSetLayout(vk,
        sampledImages, storageImages,
        buffers, samplers
    )),
    pipelineLayout(createPipelineLayout(vk,
        *this->descriptorLayout
    )),
    pipeline_(createComputePipeline(vk,
        *this->shaderModule,
        *this->pipelineLayout
    )) {
    this->shaderModule = {};
}
