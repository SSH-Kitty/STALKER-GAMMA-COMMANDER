/* SPDX-License-Identifier: GPL-3.0-or-later */

#pragma once

#include "../helpers/managed_shader.hpp"
#include "../helpers/utils.hpp"
#include "mako-common/helpers/pointers.hpp"
#include "mako-common/vulkan/command_buffer.hpp"
#include "mako-common/vulkan/image.hpp"
#include "mako-common/vulkan/vulkan.hpp"

#include <memory>
#include <vector>

#include <vulkan/vulkan_core.h>

namespace ctx { struct Ctx; }

namespace mako::backend {
    /// gamma shaderchain
    class Gamma1 {
    public:
        /// create a gamma shaderchain
        /// @param ctx context
        /// @param idx generated frame index
        /// @param sourceImages source images
        /// @param prepassScratch same-extent Alpha0 outputs, consumed before generation
        /// @param additionalInput0 additional input image
        /// @param additionalInput1 additional input image
        /// @param sharedScratch same-context first-output resources, or null to own them
        Gamma1(const Ctx& ctx, size_t idx,
            const std::vector<vk::Image>& sourceImages,
            const std::vector<vk::Image>& prepassScratch,
            const vk::Image& additionalInput0,
            const vk::Image& additionalInput1,
            const Gamma1* sharedScratch = nullptr);

        /// prepare the shaderchain initially
        /// @param images vector to fill with image handles
        void prepare(std::vector<VkImage>& images) const;

        /// render the gamma shaderchain
        /// @param vk the vulkan instance
        /// @param cmd command buffer
        void render(const vk::Vulkan& vk, const vk::CommandBuffer& cmd) const;

        /// get the generated image
        /// @return image
        [[nodiscard]] const auto& getImage() const { return *this->image; }

        /// get the first same-extent temporary image set
        /// @return temporary images available to the immediately following stage
        [[nodiscard]] const auto& getTempImages0() const { return *this->tempImages0; }

        /// get the second same-extent temporary image set
        /// @return temporary images available to the immediately following stage
        [[nodiscard]] const auto& getTempImages1() const { return this->tempImages1.get(); }
    private:
        std::shared_ptr<std::vector<vk::Image>> tempImages0;
        ls::R<const std::vector<vk::Image>> tempImages1;
        std::shared_ptr<vk::Image> image;

        std::vector<ManagedShader> sets;
        VkExtent2D dispatchExtent{};
    };
}
