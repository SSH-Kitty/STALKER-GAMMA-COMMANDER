/* SPDX-License-Identifier: GPL-3.0-or-later */

#include "gamma1.hpp"
#include "../helpers/utils.hpp"
#include "../helpers/image_prefix.hpp"
#include "mako-common/helpers/pointers.hpp"
#include "mako-common/vulkan/command_buffer.hpp"
#include "mako-common/vulkan/image.hpp"
#include "mako-common/vulkan/vulkan.hpp"

#include <cstddef>
#include <functional>
#include <stdexcept>
#include <vector>

#include <vulkan/vulkan_core.h>

using namespace mako::backend;

Gamma1::Gamma1(const Ctx& ctx, size_t idx,
        const std::vector<vk::Image>& sourceImages,
        const std::vector<vk::Image>& prepassScratch,
        const vk::Image& additionalInput0,
        const vk::Image& additionalInput1, const Gamma1* sharedScratch)
        : tempImages1(std::cref(prepassScratch)) {
    const size_t m = ctx.perf ? 1 : 2; // multiplier
    const VkExtent2D extent = sourceImages.at(0).getExtent();
    const auto scratch = backend::requiredPrefix(prepassScratch, 2 * m, "Gamma1 prepass scratch");
    for (const auto& image : scratch) {
        const auto scratchExtent = image.getExtent();
        if (scratchExtent.width != extent.width || scratchExtent.height != extent.height)
            throw std::invalid_argument("Gamma1 prepass scratch extent does not match");
    }

    // Alpha1 has consumed Alpha0's outputs before the prepass signals. Reuse
    // them across generated passes; the compute dependencies serialize
    // accesses, and prepareWork fences generation before the next prepass.
    this->tempImages0 = sharedScratch ? sharedScratch->tempImages0
        : std::make_shared<std::vector<vk::Image>>();
    if (sharedScratch) {
        this->image = sharedScratch->image;
    } else {
        for (size_t i = 0; i < (2 * m); i++)
            this->tempImages0->emplace_back(ctx.vk, extent, ctx.imageMemoryPool);
        this->image = std::make_shared<vk::Image>(ctx.vk, extent,
            ctx.imageMemoryPool, VK_FORMAT_R16G16B16A16_SFLOAT);
    }

    // create descriptor sets
    const auto& shaders = (ctx.perf ?
        ctx.shaders.get().performance : ctx.shaders.get().quality).gamma;
    this->sets.reserve(4);
    this->sets.emplace_back(ManagedShaderBuilder()
        .sampleds(sourceImages)
        .storages(*this->tempImages0)
        .sampler(ctx.bnbSampler)
        .build(ctx.vk, ctx.pool, shaders.at(1)));
    this->sets.emplace_back(ManagedShaderBuilder()
        .sampleds(*this->tempImages0)
        .storages(scratch)
        .sampler(ctx.bnbSampler)
        .build(ctx.vk, ctx.pool, shaders.at(2)));
    this->sets.emplace_back(ManagedShaderBuilder()
        .sampleds(scratch)
        .storages(*this->tempImages0)
        .sampler(ctx.bnbSampler)
        .build(ctx.vk, ctx.pool, shaders.at(3)));
    this->sets.emplace_back(ManagedShaderBuilder()
        .sampleds(*this->tempImages0)
        .sampled(additionalInput0)
        .sampled(additionalInput1)
        .storage(*this->image)
        .sampler(ctx.bnbSampler)
        .sampler(ctx.eabSampler)
        .buffer(ctx.constantBuffers.at(idx))
        .build(ctx.vk, ctx.pool, shaders.at(4)));

    // store dispatch extents
    this->dispatchExtent = backend::add_shift_extent(extent, 7, 3);
}

void Gamma1::prepare(std::vector<VkImage>& images) const {
    for (size_t i = 0; i < this->tempImages0->size(); i++) {
        images.push_back(this->tempImages0->at(i).handle());
    }
    images.push_back(this->image->handle());
}

void Gamma1::render(const vk::Vulkan& vk, const vk::CommandBuffer& cmd) const {
    for (const auto& set : this->sets)
        set.dispatch(vk, cmd, dispatchExtent);
}
