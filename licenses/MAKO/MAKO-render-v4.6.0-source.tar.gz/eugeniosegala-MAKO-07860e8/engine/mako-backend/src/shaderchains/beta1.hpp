/* SPDX-License-Identifier: GPL-3.0-or-later */

#pragma once

#include "../helpers/managed_shader.hpp"
#include "../helpers/utils.hpp"
#include "mako-common/vulkan/command_buffer.hpp"
#include "mako-common/vulkan/image.hpp"
#include "mako-common/vulkan/vulkan.hpp"

#include <span>
#include <vector>

#include <vulkan/vulkan_core.h>

namespace ctx { struct Ctx; }

namespace mako::backend {
    /// beta shaderchain
    class Beta1 {
    public:
        /// create a beta shaderchain
        /// @param ctx context
        /// @param sourceImages Beta0 outputs, consumed by the first dispatch
        /// @param prepassScratch Alpha0 outputs already consumed by Alpha1
        Beta1(const Ctx& ctx,
            const std::vector<vk::Image>& sourceImages,
            const std::vector<vk::Image>& prepassScratch);

        /// prepare the shaderchain initially
        /// @param images vector to fill with image handles
        void prepare(std::vector<VkImage>& images) const;

        /// render the beta shaderchain
        /// @param vk the vulkan instance
        /// @param cmd command buffer
        void render(const vk::Vulkan& vk, const vk::CommandBuffer& cmd) const;

        /// get the generated images
        /// @return vector of images
        [[nodiscard]] const auto& getImages() const { return this->images; }
    private:
        std::span<const vk::Image> tempImages0;
        std::span<const vk::Image> tempImages1;
        std::vector<vk::Image> images;

        std::vector<ManagedShader> sets;
        VkExtent2D dispatchExtent0{};
        VkExtent2D dispatchExtent1{};
    };
}
