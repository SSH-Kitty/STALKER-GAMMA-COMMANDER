/* SPDX-License-Identifier: GPL-3.0-or-later */

#include "model_resource_validation.hpp"

#include "mako-common/helpers/errors.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <map>
#include <optional>
#include <set>
#include <span>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

namespace {
    constexpr uint32_t spirvMagic = 0x07230203U;
    constexpr uint16_t opCapability = 17U;
    constexpr uint16_t opEntryPoint = 15U;
    constexpr uint16_t opTypeImage = 25U;
    constexpr uint16_t opTypeSampler = 26U;
    constexpr uint16_t opTypeSampledImage = 27U;
    constexpr uint16_t opTypePointer = 32U;
    constexpr uint16_t opVariable = 59U;
    constexpr uint16_t opDecorate = 71U;
    constexpr uint32_t capabilityShader = 1U;
    constexpr uint32_t executionModelCompute = 5U;
    constexpr uint32_t storageUniformConstant = 0U;
    constexpr uint32_t storageUniform = 2U;
    constexpr uint32_t storageStorageBuffer = 12U;
    constexpr uint32_t decorationBinding = 33U;
    constexpr uint32_t decorationDescriptorSet = 34U;
    constexpr uint32_t fourccDxbc = 0x43425844U;
    constexpr uint32_t fourccShdr = 0x52444853U;
    constexpr uint32_t fourccShex = 0x58454853U;

    enum class DescriptorKind : uint8_t {
        SampledImage,
        StorageImage,
        UniformBuffer,
        Sampler,
        Unsupported,
    };

    struct Type {
        enum class Kind : uint8_t {
            Image,
            Sampler,
            SampledImage,
            Pointer,
            Other,
        } kind{Kind::Other};
        uint32_t storageClass{0};
        uint32_t pointee{0};
        uint32_t sampled{0};
    };

    struct Variable {
        uint32_t pointerType{0};
        uint32_t storageClass{0};
    };

    struct Decorations {
        std::optional<uint32_t> descriptorSet;
        std::optional<uint32_t> binding;
    };

    [[nodiscard]] uint32_t readWord(
            const std::span<const uint8_t> data, const size_t index) {
        uint32_t value{};
        std::memcpy(
            &value, data.data() + index * sizeof(uint32_t), sizeof(value)
        );
        return value;
    }

    [[nodiscard]] uint32_t readLittleEndian(
            const std::span<const uint8_t> data, const size_t offset,
            const std::string& sourceName) {
        if (offset > data.size() || sizeof(uint32_t) > data.size() - offset)
            throw ls::error(sourceName + " contains a truncated integer");
        uint32_t value{};
        std::memcpy(&value, data.data() + offset, sizeof(value));
        return value;
    }

    [[nodiscard]] std::string readSpirvString(
            const std::span<const uint8_t> data, const size_t firstWord,
            const size_t endWord, const std::string& sourceName) {
        std::string result;
        for (size_t word = firstWord; word < endWord; ++word) {
            const uint32_t value = readWord(data, word);
            for (uint32_t shift = 0; shift < 32U; shift += 8U) {
                const char character = static_cast<char>(value >> shift);
                if (character == '\0')
                    return result;
                result.push_back(character);
            }
        }
        throw ls::error(sourceName + " contains an unterminated SPIR-V string");
    }

    [[nodiscard]] DescriptorKind descriptorKind(
            const Variable& variable,
            const std::unordered_map<uint32_t, Type>& types) {
        const auto pointer = types.find(variable.pointerType);
        if (pointer == types.end() || pointer->second.kind != Type::Kind::Pointer)
            return DescriptorKind::Unsupported;
        if (variable.storageClass == storageUniform)
            return DescriptorKind::UniformBuffer;
        if (variable.storageClass == storageStorageBuffer)
            return DescriptorKind::Unsupported;
        const auto pointee = types.find(pointer->second.pointee);
        if (pointee == types.end())
            return DescriptorKind::Unsupported;
        if (variable.storageClass != storageUniformConstant)
            return DescriptorKind::Unsupported;
        if (pointee->second.kind == Type::Kind::Sampler)
            return DescriptorKind::Sampler;
        if (pointee->second.kind == Type::Kind::Image) {
            if (pointee->second.sampled == 1U)
                return DescriptorKind::SampledImage;
            if (pointee->second.sampled == 2U)
                return DescriptorKind::StorageImage;
        }
        return DescriptorKind::Unsupported;
    }

    [[nodiscard]] std::map<std::pair<uint32_t, uint32_t>, DescriptorKind>
    requiredBindings(
            const mako::backend::detail::ShaderResourceContract& contract) {
        std::map<std::pair<uint32_t, uint32_t>, DescriptorKind> result;
        for (size_t index = 0; index < contract.uniformBuffers; ++index)
            result.emplace(std::pair{0U, static_cast<uint32_t>(index)},
                DescriptorKind::UniformBuffer);
        for (size_t index = 0; index < contract.samplers; ++index)
            result.emplace(std::pair{0U, static_cast<uint32_t>(16U + index)},
                DescriptorKind::Sampler);
        for (size_t index = 0; index < contract.sampledImages; ++index)
            result.emplace(std::pair{0U, static_cast<uint32_t>(32U + index)},
                DescriptorKind::SampledImage);
        for (size_t index = 0; index < contract.storageImages; ++index)
            result.emplace(std::pair{0U, static_cast<uint32_t>(48U + index)},
                DescriptorKind::StorageImage);
        return result;
    }

    constexpr std::array qualitySpecs{
        mako::backend::detail::LsfgShaderSpec{255, {1, 7, 1, 1}},
        mako::backend::detail::LsfgShaderSpec{256, {5, 1, 1, 2}},
        mako::backend::detail::LsfgShaderSpec{267, {1, 2, 0, 1}},
        mako::backend::detail::LsfgShaderSpec{268, {2, 2, 0, 1}},
        mako::backend::detail::LsfgShaderSpec{269, {2, 4, 0, 1}},
        mako::backend::detail::LsfgShaderSpec{270, {4, 4, 0, 1}},
        mako::backend::detail::LsfgShaderSpec{275, {12, 2, 0, 1}},
        mako::backend::detail::LsfgShaderSpec{276, {2, 2, 0, 1}},
        mako::backend::detail::LsfgShaderSpec{277, {2, 2, 0, 1}},
        mako::backend::detail::LsfgShaderSpec{278, {2, 2, 0, 1}},
        mako::backend::detail::LsfgShaderSpec{279, {2, 6, 1, 1}},
        mako::backend::detail::LsfgShaderSpec{257, {9, 3, 1, 2}},
        mako::backend::detail::LsfgShaderSpec{259, {3, 4, 0, 1}},
        mako::backend::detail::LsfgShaderSpec{260, {4, 4, 0, 1}},
        mako::backend::detail::LsfgShaderSpec{261, {4, 4, 0, 1}},
        mako::backend::detail::LsfgShaderSpec{262, {6, 1, 1, 2}},
        mako::backend::detail::LsfgShaderSpec{263, {3, 4, 0, 1}},
        mako::backend::detail::LsfgShaderSpec{264, {4, 4, 0, 1}},
        mako::backend::detail::LsfgShaderSpec{265, {4, 4, 0, 1}},
        mako::backend::detail::LsfgShaderSpec{266, {6, 1, 1, 2}},
        mako::backend::detail::LsfgShaderSpec{258, {10, 2, 1, 2}},
        mako::backend::detail::LsfgShaderSpec{271, {2, 2, 0, 1}},
        mako::backend::detail::LsfgShaderSpec{272, {2, 2, 0, 1}},
        mako::backend::detail::LsfgShaderSpec{273, {2, 2, 0, 1}},
        mako::backend::detail::LsfgShaderSpec{274, {3, 1, 1, 2}},
    };

    constexpr std::array performanceSpecs{
        mako::backend::detail::LsfgShaderSpec{267, {1, 1, 0, 1}},
        mako::backend::detail::LsfgShaderSpec{268, {1, 1, 0, 1}},
        mako::backend::detail::LsfgShaderSpec{269, {1, 2, 0, 1}},
        mako::backend::detail::LsfgShaderSpec{270, {2, 2, 0, 1}},
        mako::backend::detail::LsfgShaderSpec{275, {6, 2, 0, 1}},
        mako::backend::detail::LsfgShaderSpec{276, {2, 2, 0, 1}},
        mako::backend::detail::LsfgShaderSpec{277, {2, 2, 0, 1}},
        mako::backend::detail::LsfgShaderSpec{278, {2, 2, 0, 1}},
        mako::backend::detail::LsfgShaderSpec{279, {2, 6, 1, 1}},
        mako::backend::detail::LsfgShaderSpec{257, {5, 3, 1, 2}},
        mako::backend::detail::LsfgShaderSpec{259, {3, 2, 0, 1}},
        mako::backend::detail::LsfgShaderSpec{260, {2, 2, 0, 1}},
        mako::backend::detail::LsfgShaderSpec{261, {2, 2, 0, 1}},
        mako::backend::detail::LsfgShaderSpec{262, {4, 1, 1, 2}},
        mako::backend::detail::LsfgShaderSpec{263, {3, 2, 0, 1}},
        mako::backend::detail::LsfgShaderSpec{264, {2, 2, 0, 1}},
        mako::backend::detail::LsfgShaderSpec{265, {2, 2, 0, 1}},
        mako::backend::detail::LsfgShaderSpec{266, {4, 1, 1, 2}},
        mako::backend::detail::LsfgShaderSpec{258, {6, 1, 1, 2}},
        mako::backend::detail::LsfgShaderSpec{271, {1, 1, 0, 1}},
        mako::backend::detail::LsfgShaderSpec{272, {1, 1, 0, 1}},
        mako::backend::detail::LsfgShaderSpec{273, {1, 1, 0, 1}},
        mako::backend::detail::LsfgShaderSpec{274, {2, 1, 1, 2}},
    };
}

void mako::backend::detail::validateDxbcComputeShader(
        const std::span<const uint8_t> data,
        const std::string& sourceName) {
    if (data.size() < 32U || readLittleEndian(data, 0, sourceName) != fourccDxbc)
        throw ls::error(sourceName + " is not a DXBC container");
    const uint32_t declaredSize = readLittleEndian(data, 24U, sourceName);
    const uint32_t chunkCount = readLittleEndian(data, 28U, sourceName);
    if (declaredSize < 32U || declaredSize > data.size())
        throw ls::error(sourceName + " has an invalid DXBC container size");
    if (chunkCount == 0U || chunkCount > (declaredSize - 32U) / 4U)
        throw ls::error(sourceName + " has an invalid DXBC chunk count");

    const size_t headerEnd = 32U + static_cast<size_t>(chunkCount) * 4U;
    std::vector<std::pair<size_t, size_t>> ranges;
    ranges.reserve(chunkCount);
    bool hasComputeBytecode = false;
    for (uint32_t index = 0; index < chunkCount; ++index) {
        const uint32_t offset = readLittleEndian(
            data, 32U + static_cast<size_t>(index) * 4U, sourceName
        );
        if (offset < headerEnd || offset > declaredSize ||
                8U > declaredSize - offset) {
            throw ls::error(sourceName + " has an invalid DXBC chunk offset");
        }
        const uint32_t type = readLittleEndian(data, offset, sourceName);
        const uint32_t size = readLittleEndian(data, offset + 4U, sourceName);
        if (size > declaredSize - offset - 8U)
            throw ls::error(sourceName + " has a truncated DXBC chunk");
        ranges.emplace_back(offset, static_cast<size_t>(offset) + 8U + size);
        hasComputeBytecode = hasComputeBytecode ||
            type == fourccShdr || type == fourccShex;
    }
    std::ranges::sort(ranges);
    for (size_t index = 1; index < ranges.size(); ++index) {
        if (ranges[index].first < ranges[index - 1U].second)
            throw ls::error(sourceName + " has overlapping DXBC chunks");
    }
    if (!hasComputeBytecode)
        throw ls::error(sourceName + " has no DXBC shader bytecode chunk");
}

void mako::backend::detail::validateDxbcResourceBindings(
        const std::span<const uint8_t> data,
        const ShaderResourceContract& required,
        const std::string& sourceName, const bool discovery) {
    validateDxbcComputeShader(data, sourceName);
    std::optional<std::span<const uint8_t>> reflection;
    const uint32_t count = readLittleEndian(data, 28U, sourceName);
    for (uint32_t i = 0; i < count; ++i) {
        const size_t offset = readLittleEndian(data, 32U + i * 4U, sourceName);
        if (readLittleEndian(data, offset, sourceName) != 0x46454452U) // RDEF
            continue;
        if (reflection)
            throw ls::error(sourceName + " has ambiguous DXBC reflection");
        reflection = data.subspan(offset + 8U,
            readLittleEndian(data, offset + 4U, sourceName));
    }
    if (!reflection && !discovery)
        return;
    if (!reflection || reflection->size() < 28U)
        throw ls::error(sourceName + " lacks resource reflection for discovery");
    const auto rdef = *reflection;
    // Shader model 5.0 compute uses eight DWORDs per binding. Other reflection
    // versions need their own reader; never interpret them with this stride.
    if (readLittleEndian(rdef, 16U, sourceName) != 0x43530500U) {
        if (!discovery) return;
        throw ls::error(sourceName + " has unsupported discovery reflection");
    }
    const size_t bindingCount = readLittleEndian(rdef, 8U, sourceName);
    const size_t bindingOffset = readLittleEndian(rdef, 12U, sourceName);
    if (bindingOffset < 28U || bindingOffset > rdef.size() ||
            bindingCount > (rdef.size() - bindingOffset) / 32U)
        throw ls::error(sourceName + " has truncated DXBC reflection bindings");

    std::set<std::pair<uint32_t, uint32_t>> expected;
    const auto add = [&expected](const uint32_t type, const size_t slots) {
        for (size_t i = 0; i < slots; ++i)
            expected.emplace(type, static_cast<uint32_t>(i));
    };
    add(0U, required.uniformBuffers);
    add(2U, required.sampledImages);
    add(3U, required.samplers);
    add(4U, required.storageImages);
    std::set<std::pair<uint32_t, uint32_t>> actual;
    for (size_t i = 0; i < bindingCount; ++i) {
        const size_t offset = bindingOffset + i * 32U;
        const uint32_t type = readLittleEndian(rdef, offset + 4U, sourceName);
        const uint32_t dimension = readLittleEndian(rdef, offset + 12U, sourceName);
        const uint32_t slot = readLittleEndian(rdef, offset + 20U, sourceName);
        const uint32_t slots = readLittleEndian(rdef, offset + 24U, sourceName);
        if (!discovery && !expected.contains({type, slot}))
            continue;
        // D3D_SIT_CBUFFER/TEXTURE/SAMPLER/UAV_RWTYPED; image bindings must be
        // single, non-array Texture2D resources as consumed by the LS1 graph.
        if (slots != 1U ||
                ((type == 2U || type == 4U) ? dimension != 4U
                    : (type != 0U && type != 3U) || dimension != 0U) ||
                !actual.emplace(type, slot).second)
            throw ls::error(sourceName + " has incompatible discovery bindings");
    }
    if (actual != expected)
        throw ls::error(sourceName + " has incompatible discovery bindings");
}

mako::backend::detail::SpirvShaderInfo
mako::backend::detail::validateSpirvComputeShader(
        const std::span<const uint8_t> data,
        const ShaderResourceContract& required,
        const std::string& sourceName) {
    if (data.size() < 5U * sizeof(uint32_t) ||
            data.size() % sizeof(uint32_t) != 0U) {
        throw ls::error(sourceName + " has an invalid SPIR-V size");
    }
    if (readWord(data, 0) != spirvMagic)
        throw ls::error(sourceName + " has invalid SPIR-V magic");
    if (readWord(data, 3) == 0U || readWord(data, 4) != 0U)
        throw ls::error(sourceName + " has an invalid SPIR-V header");

    std::unordered_map<uint32_t, Type> types;
    std::unordered_map<uint32_t, Variable> variables;
    std::unordered_map<uint32_t, Decorations> decorations;
    SpirvShaderInfo info;
    bool hasShaderCapability = false;
    bool hasComputeMain = false;
    const size_t totalWords = data.size() / sizeof(uint32_t);
    for (size_t offset = 5U; offset < totalWords;) {
        const uint32_t instruction = readWord(data, offset);
        const uint16_t count = static_cast<uint16_t>(instruction >> 16U);
        const uint16_t opcode = static_cast<uint16_t>(instruction & 0xffffU);
        if (count == 0U || count > totalWords - offset)
            throw ls::error(sourceName + " contains malformed SPIR-V");
        if (opcode == opCapability && count >= 2U &&
                readWord(data, offset + 1U) == capabilityShader) {
            hasShaderCapability = true;
        } else if (opcode == opEntryPoint && count >= 4U &&
                readWord(data, offset + 1U) == executionModelCompute &&
                readSpirvString(data, offset + 3U, offset + count, sourceName) ==
                    "main") {
            hasComputeMain = true;
        } else if (opcode == opTypeImage && count >= 9U) {
            types.insert_or_assign(readWord(data, offset + 1U), Type{
                .kind = Type::Kind::Image,
                .sampled = readWord(data, offset + 7U),
            });
        } else if (opcode == opTypeSampler && count >= 2U) {
            types.insert_or_assign(
                readWord(data, offset + 1U), Type{.kind = Type::Kind::Sampler}
            );
        } else if (opcode == opTypeSampledImage && count >= 3U) {
            types.insert_or_assign(readWord(data, offset + 1U), Type{
                .kind = Type::Kind::SampledImage,
                .pointee = readWord(data, offset + 2U),
            });
        } else if (opcode == 22U && count == 3U) { // OpTypeFloat
            info.declaresFloat16 = info.declaresFloat16 ||
                readWord(data, offset + 2U) == 16U;
        } else if (opcode == opTypePointer && count >= 4U) {
            types.insert_or_assign(readWord(data, offset + 1U), Type{
                .kind = Type::Kind::Pointer,
                .storageClass = readWord(data, offset + 2U),
                .pointee = readWord(data, offset + 3U),
            });
        } else if (opcode == opVariable && count >= 4U) {
            variables.insert_or_assign(readWord(data, offset + 2U), Variable{
                .pointerType = readWord(data, offset + 1U),
                .storageClass = readWord(data, offset + 3U),
            });
        } else if (opcode == opDecorate && count >= 4U) {
            Decorations& target = decorations[readWord(data, offset + 1U)];
            const uint32_t decoration = readWord(data, offset + 2U);
            if (decoration == decorationBinding)
                target.binding = readWord(data, offset + 3U);
            else if (decoration == decorationDescriptorSet)
                target.descriptorSet = readWord(data, offset + 3U);
        }
        offset += count;
    }
    if (!hasShaderCapability || !hasComputeMain)
        throw ls::error(sourceName + " is not a SPIR-V compute shader with main");

    std::map<std::pair<uint32_t, uint32_t>, DescriptorKind> actual;
    for (const auto& [id, variable] : variables) {
        const auto decorated = decorations.find(id);
        if (decorated == decorations.end() ||
                !decorated->second.descriptorSet || !decorated->second.binding) {
            continue;
        }
        const auto key = std::pair{
            *decorated->second.descriptorSet, *decorated->second.binding
        };
        if (!actual.emplace(key, descriptorKind(variable, types)).second)
            throw ls::error(sourceName + " declares a duplicate descriptor binding");
    }
    const auto expected = requiredBindings(required);
    for (const auto& [binding, kind] : expected) {
        const auto found = actual.find(binding);
        if (found == actual.end())
            throw ls::error(sourceName + " is missing a required descriptor binding");
        if (found->second != kind)
            throw ls::error(sourceName + " has an incompatible descriptor binding");
    }
    info.exactBindings = actual == expected;
    return info;
}

mako::backend::detail::Ls1ModelSpec mako::backend::detail::ls1ModelSpec(
        const Ls1Mode mode, const uint32_t variant) {
    if (variant >= 5U)
        throw ls::error("invalid LS1 model variant");
    constexpr uint32_t rgba8 = 4U;
    constexpr uint32_t r8Snorm = 20U;
    const Ls1ShaderSpec reconstruction{146U, {2, 1, 1, 1}, rgba8};
    if (mode == Ls1Mode::Performance)
        return {reconstruction, {141U + variant, {1, 1, 1, 0}, r8Snorm},
            std::nullopt, std::nullopt};
    const uint32_t first = 147U + variant * 3U;
    return {reconstruction, {first, {1, 1, 1, 0}, rgba8},
        Ls1ShaderSpec{first + 1U, {1, 1, 0, 0}, rgba8},
        Ls1ShaderSpec{first + 2U, {1, 1, 1, 0}, r8Snorm}};
}

uint32_t mako::backend::detail::lsfgResourceId(
        const uint32_t logicalId, const bool fp16,
        const bool performance) {
    constexpr uint32_t baseOffset = 49U;
    constexpr uint32_t fp32Offset = 49U;
    return baseOffset + lsfgDxbcResourceId(logicalId, performance) +
        (fp16 ? 0U : fp32Offset);
}

uint32_t mako::backend::detail::lsfgDxbcResourceId(
        const uint32_t logicalId, const bool performance) {
    return logicalId + (performance ? 23U : 0U);
}

uint32_t mako::backend::detail::lsfgStorageImageFormat(const uint32_t logicalId) {
    // Match the existing shader-chain image owners: scalar mipmaps/masks,
    // floating-point flow outputs, and quantized RGBA intermediates/output.
    if (logicalId == 255U || logicalId == 279U)
        return 15U; // SPIR-V R8
    if (logicalId == 262U || logicalId == 266U || logicalId == 274U)
        return 2U; // SPIR-V Rgba16f
    return 4U; // SPIR-V Rgba8 (generation's HDR copy is patched by the registry)
}

std::span<const mako::backend::detail::LsfgShaderSpec>
mako::backend::detail::lsfgShaderSpecs(const bool performance) {
    return performance
        ? std::span<const LsfgShaderSpec>{performanceSpecs}
        : std::span<const LsfgShaderSpec>{qualitySpecs};
}
