/* SPDX-License-Identifier: GPL-3.0-or-later */

#include "extraction/content_hash.hpp"
#include "extraction/dll_reader.hpp"
#include "extraction/model_resource_validation.hpp"
#include "extraction/model_resources.hpp"
#include "extraction/lsfg_shader_set.hpp"
#include "extraction/spirv_fp16.hpp"
#include "mako-backend/ls1.hpp"
#include "mako-common/helpers/errors.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <cstdlib>
#include <dlfcn.h>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <limits>
#include <span>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <vector>

#include <unistd.h>

namespace {
    void require(const bool condition, const std::string& message) {
        if (!condition)
            throw std::runtime_error(message);
    }

    template<typename Action>
    void requireFailure(Action action, const std::string& message) {
        try {
            action();
            throw std::runtime_error(message);
        } catch (const ls::error&) {
        }
    }

    template<typename Integer>
    void writeInteger(std::vector<uint8_t>& data, const size_t offset,
            const Integer value) {
        if (offset > data.size() || sizeof(value) > data.size() - offset)
            throw std::runtime_error("synthetic fixture write exceeded its buffer");
        std::memcpy(data.data() + offset, &value, sizeof(value));
    }

    struct SyntheticPeOptions {
        bool pe32{false};
        bool extraRootResource{false};
        bool namedRootResource{false};
        bool additionalLanguage{false};
    };

    [[nodiscard]] std::vector<uint8_t> syntheticPe(
            const std::vector<uint8_t>& payload,
            const SyntheticPeOptions options = {}) {
        if (payload.size() > 0x300U)
            throw std::runtime_error("synthetic PE payload is too large");
        std::vector<uint8_t> data(0x600U, 0U);
        constexpr size_t pe = 0x80U;
        constexpr size_t optional = pe + 24U;
        constexpr size_t resources = 0x200U;
        const uint16_t optionalSize = options.pe32 ? 0xe0U : 0xf0U;
        const size_t section = optional + optionalSize;
        const size_t numberOfDirectoriesOffset = options.pe32 ? 92U : 108U;
        const size_t resourceDirectoryOffset = options.pe32 ? 112U : 128U;
        writeInteger<uint16_t>(data, 0U, 0x5a4dU);
        writeInteger<int32_t>(data, 60U, static_cast<int32_t>(pe));
        writeInteger<uint32_t>(data, pe, 0x00004550U);
        writeInteger<uint16_t>(data, pe + 6U, 1U);
        writeInteger<uint16_t>(data, pe + 20U, optionalSize);
        writeInteger<uint16_t>(
            data, optional, options.pe32 ? 0x010bU : 0x020bU
        );
        writeInteger<uint32_t>(data, optional + numberOfDirectoriesOffset, 16U);
        writeInteger<uint32_t>(
            data, optional + resourceDirectoryOffset, 0x1000U
        );
        writeInteger<uint32_t>(
            data, optional + resourceDirectoryOffset + 4U, 0x400U
        );
        writeInteger<uint32_t>(data, section + 8U, 0x400U);
        writeInteger<uint32_t>(data, section + 12U, 0x1000U);
        writeInteger<uint32_t>(data, section + 16U, 0x400U);
        writeInteger<uint32_t>(data, section + 20U, 0x200U);

        writeInteger<uint16_t>(
            data, resources + 12U, options.namedRootResource ? 1U : 0U
        );
        writeInteger<uint16_t>(data, resources + 14U,
            options.extraRootResource ? 2U : 1U);
        size_t rootEntry = resources + 16U;
        if (options.namedRootResource) {
            writeInteger<uint32_t>(data, rootEntry, 0x80000380U);
            writeInteger<uint32_t>(data, rootEntry + 4U, 0U);
            rootEntry += 8U;
        }
        if (options.extraRootResource) {
            writeInteger<uint32_t>(data, rootEntry, 5U);
            writeInteger<uint32_t>(data, rootEntry + 4U, 0U);
            rootEntry += 8U;
        }
        writeInteger<uint32_t>(data, rootEntry, 10U);
        writeInteger<uint32_t>(data, rootEntry + 4U, 0x80000040U);
        writeInteger<uint16_t>(data, resources + 0x40U + 14U, 1U);
        writeInteger<uint32_t>(data, resources + 0x50U, 141U);
        writeInteger<uint32_t>(data, resources + 0x54U, 0x80000060U);
        writeInteger<uint16_t>(
            data, resources + 0x60U + 14U,
            options.additionalLanguage ? 2U : 1U
        );
        writeInteger<uint32_t>(data, resources + 0x70U, 0U);
        writeInteger<uint32_t>(data, resources + 0x74U, 0x90U);
        if (options.additionalLanguage) {
            writeInteger<uint32_t>(data, resources + 0x78U, 1033U);
            writeInteger<uint32_t>(data, resources + 0x7cU, 0xa0U);
        }
        writeInteger<uint32_t>(data, resources + 0x90U, 0x1100U);
        writeInteger<uint32_t>(
            data, resources + 0x94U, static_cast<uint32_t>(payload.size())
        );
        if (options.additionalLanguage) {
            writeInteger<uint32_t>(data, resources + 0xa0U, 0x1100U);
            writeInteger<uint32_t>(
                data, resources + 0xa4U, static_cast<uint32_t>(payload.size())
            );
        }
        std::copy(payload.begin(), payload.end(), data.begin() + 0x300U);
        return data;
    }

    void writeFile(const std::filesystem::path& path,
            const std::vector<uint8_t>& data) {
        std::ofstream output(path, std::ios::binary | std::ios::trunc);
        output.write(
            reinterpret_cast<const char*>(data.data()),
            static_cast<std::streamsize>(data.size())
        );
        if (!output)
            throw std::runtime_error("failed to write synthetic DLL fixture");
    }

    class TemporaryDirectory {
    public:
        TemporaryDirectory() : path(
                std::filesystem::temp_directory_path() /
                ("mako-dll-inspection-tests-" + std::to_string(::getpid()))) {
            std::filesystem::create_directories(this->path);
        }
        ~TemporaryDirectory() {
            std::error_code ignored;
            std::filesystem::remove_all(this->path, ignored);
        }
        std::filesystem::path path;
    };

    [[nodiscard]] uint32_t instruction(
            const uint16_t opcode, const size_t operandCount) {
        return (static_cast<uint32_t>(operandCount + 1U) << 16U) | opcode;
    }

    void appendInstruction(std::vector<uint32_t>& words,
            const uint16_t opcode,
            const std::initializer_list<uint32_t> operands) {
        words.push_back(instruction(opcode, operands.size()));
        words.insert(words.end(), operands.begin(), operands.end());
    }

    [[nodiscard]] std::vector<uint8_t> syntheticSpirv(
            const mako::backend::detail::ShaderResourceContract& contract,
            const bool includeExtraSampler = false,
            const bool fp16 = false) {
        std::vector<uint32_t> words{
            0x07230203U, 0x00010000U, 0U, 256U, 0U,
        };
        appendInstruction(words, 17U, {1U});
        appendInstruction(words, 15U, {5U, 1U, 0x6e69616dU, 0U});
        appendInstruction(words, 22U, {2U, 32U});
        if (fp16)
            appendInstruction(words, 22U, {7U, 16U});
        appendInstruction(words, 26U, {3U});
        appendInstruction(words, 25U, {4U, 2U, 2U, 0U, 0U, 0U, 1U, 0U});
        appendInstruction(words, 25U, {5U, 2U, 2U, 0U, 0U, 0U, 2U, 4U});
        appendInstruction(words, 30U, {6U, 2U});
        appendInstruction(words, 32U, {10U, 0U, 3U});
        appendInstruction(words, 32U, {11U, 0U, 4U});
        appendInstruction(words, 32U, {12U, 0U, 5U});
        appendInstruction(words, 32U, {13U, 2U, 6U});

        uint32_t variable = 20U;
        const auto addDescriptor = [&words, &variable](
                const uint32_t pointer, const uint32_t storage,
                const uint32_t binding) {
            const uint32_t id = variable++;
            appendInstruction(words, 59U, {pointer, id, storage});
            appendInstruction(words, 71U, {id, 34U, 0U});
            appendInstruction(words, 71U, {id, 33U, binding});
        };
        for (size_t index = 0; index < contract.uniformBuffers; ++index)
            addDescriptor(13U, 2U, static_cast<uint32_t>(index));
        for (size_t index = 0; index < contract.samplers; ++index)
            addDescriptor(10U, 0U, static_cast<uint32_t>(16U + index));
        for (size_t index = 0; index < contract.sampledImages; ++index)
            addDescriptor(11U, 0U, static_cast<uint32_t>(32U + index));
        for (size_t index = 0; index < contract.storageImages; ++index)
            addDescriptor(12U, 0U, static_cast<uint32_t>(48U + index));
        if (includeExtraSampler)
            addDescriptor(10U, 0U, 31U);

        std::vector<uint8_t> result(words.size() * sizeof(uint32_t));
        std::memcpy(result.data(), words.data(), result.size());
        return result;
    }

    [[nodiscard]] std::vector<uint8_t> syntheticDxbc(
            const bool shaderChunk = true) {
        std::vector<uint8_t> data(52U, 0U);
        writeInteger<uint32_t>(data, 0U, 0x43425844U);
        writeInteger<uint32_t>(data, 24U, 44U);
        writeInteger<uint32_t>(data, 28U, 1U);
        writeInteger<uint32_t>(data, 32U, 36U);
        writeInteger<uint32_t>(
            data, 36U, shaderChunk ? 0x58454853U : 0x46454452U
        );
        writeInteger<uint32_t>(data, 40U, 0U);
        return data; // Eight trailing vendor bytes are deliberately accepted.
    }

    // A metadata-only SM5.0 fixture, with no proprietary shader instructions.
    [[nodiscard]] std::vector<uint8_t> reflectedDxbc(
            const mako::backend::detail::ShaderResourceContract contract) {
        const size_t count = contract.sampledImages + contract.storageImages +
            contract.uniformBuffers + contract.samplers;
        const size_t reflectionSize = 28U + count * 32U;
        const size_t shader = 48U + reflectionSize;
        std::vector<uint8_t> data(shader + 8U, 0U);
        writeInteger<uint32_t>(data, 0U, 0x43425844U);
        writeInteger<uint32_t>(data, 24U, static_cast<uint32_t>(data.size()));
        writeInteger<uint32_t>(data, 28U, 2U);
        writeInteger<uint32_t>(data, 32U, 40U);
        writeInteger<uint32_t>(data, 36U, static_cast<uint32_t>(shader));
        writeInteger<uint32_t>(data, 40U, 0x46454452U);
        writeInteger<uint32_t>(data, 44U, static_cast<uint32_t>(reflectionSize));
        writeInteger<uint32_t>(data, 56U, static_cast<uint32_t>(count));
        writeInteger<uint32_t>(data, 60U, 28U);
        writeInteger<uint32_t>(data, 64U, 0x43530500U);
        writeInteger<uint32_t>(data, shader, 0x58454853U);
        size_t next = 76U;
        const auto add = [&](const uint32_t type, const uint32_t dimension,
                const size_t slots) {
            for (size_t slot = 0; slot < slots; ++slot, next += 32U) {
                writeInteger<uint32_t>(data, next + 4U, type);
                writeInteger<uint32_t>(data, next + 12U, dimension);
                writeInteger<uint32_t>(data, next + 20U, static_cast<uint32_t>(slot));
                writeInteger<uint32_t>(data, next + 24U, 1U);
            }
        };
        add(0U, 0U, contract.uniformBuffers);
        add(2U, 4U, contract.sampledImages);
        add(3U, 0U, contract.samplers);
        add(4U, 4U, contract.storageImages);
        return data;
    }

    using Resources = std::unordered_map<uint32_t, std::vector<uint8_t>>;

    void addLsfgTable(Resources& resources, const int64_t offset) {
        for (const bool fp16 : {false, true})
            for (const bool performance : {false, true})
                for (const auto& spec : mako::backend::detail::lsfgShaderSpecs(performance)) {
                    const auto canonical = mako::backend::detail::lsfgResourceId(
                        spec.logicalId, fp16, performance);
                    resources.emplace(mako::backend::ModelResourceSelection{offset}.resourceId(canonical),
                        syntheticSpirv(spec.contract, false, fp16));
                }
    }

    void addLsfgDxbcTable(Resources& resources, const int64_t offset) {
        for (const bool performance : {false, true})
            for (const auto& spec : mako::backend::detail::lsfgShaderSpecs(performance)) {
                const auto id = spec.logicalId + (performance ? 23U : 0U);
                resources.emplace(mako::backend::ModelResourceSelection{offset}.resourceId(id),
                    reflectedDxbc(spec.contract));
            }
    }

    void testLsfgDxbcResolutionAndTranslation() {
        using namespace mako::backend;
        Resources resources;
        addLsfgDxbcTable(resources, 0);
        require(resources.size() == 48, "DirectX table must have 48 distinct stages");
        for (const int64_t offset : {-200, 0, 1000}) {
            Resources relocated;
            addLsfgDxbcTable(relocated, offset);
            require(resolveLsfgDxbcModelResources({.resources = relocated}).idOffset == offset,
                "coherent reflected DirectX table was not resolved");
        }
        auto ambiguous = Resources{};
        addLsfgDxbcTable(ambiguous, 1000);
        addLsfgDxbcTable(ambiguous, 2000);
        requireFailure([&] { static_cast<void>(resolveLsfgDxbcModelResources(
            {.resources = ambiguous})); }, "ambiguous DirectX tables accepted");
        for (const uint32_t id : {255U, 267U, 279U, 280U, 302U}) {
            auto partial = resources;
            partial.erase(id);
            requireFailure([&] { static_cast<void>(resolveLsfgDxbcModelResources(
                {.resources = partial})); }, "partial DirectX runtime table accepted");
        }
        auto wrong = resources;
        wrong.at(267) = reflectedDxbc({1, 1, 0, 1});
        requireFailure([&] { static_cast<void>(resolveLsfgDxbcModelResources(
            {.resources = wrong})); }, "wrong mode/stage reflection accepted");
        wrong.at(267) = syntheticDxbc();
        requireFailure([&] { static_cast<void>(resolveLsfgDxbcModelResources(
            {.resources = wrong})); }, "DirectX stage without reflection accepted");

        const char* previous = std::getenv("MAKO_VKD3D_SHADER_PATH");
        const std::string previousPath = previous ? previous : "";
        struct RestoreEnvironment {
            std::string path;
            bool present;
            ~RestoreEnvironment() {
                if (present) ::setenv("MAKO_VKD3D_SHADER_PATH", path.c_str(), 1);
                else ::unsetenv("MAKO_VKD3D_SHADER_PATH");
                ::unsetenv("MAKO_TEST_TRANSLATION_FAILURE");
            }
        } restore{previousPath, previous != nullptr};
        ::setenv("MAKO_VKD3D_SHADER_PATH", MAKO_TEST_TRANSLATOR_PATH, 1);
        void* library = ::dlopen(MAKO_TEST_TRANSLATOR_PATH, RTLD_NOW | RTLD_LOCAL);
        require(library != nullptr, "synthetic translator failed to load");
        struct CloseLibrary { void* value; ~CloseLibrary() { ::dlclose(value); } } close{library};
        const auto calls = reinterpret_cast<size_t (*)()>(
            ::dlsym(library, "mako_test_translation_calls"));
        require(calls != nullptr, "synthetic translator counter unavailable");
        const auto beforeFp16 = calls();
        const DllResourceArchive archive{.resources = resources};
        requireFailure([&] { static_cast<void>(loadLsfgShaderSet(archive, "synthetic.dll", true)); },
            "an FP16 request silently selected a DirectX FP32 fallback");
        require(calls() == beforeFp16 + (detail::experimentalLsfgFp16Available() ? 48U : 0U),
            "FP16 failure did not follow the configured conversion policy");
        // The fixture emits structurally reflected, semantically invalid
        // SPIR-V. Experimental conversion must reject it, without caching a
        // purported FP16 success. Its validated FP32 translation remains cached.
        const DllResourceArchive fp32Archive{.resources = resources};
        const auto begin = calls();
        const auto shaders = loadLsfgShaderSet(fp32Archive, "synthetic.dll", false);
        require(!shaders.fp16 && shaders.translated && shaders.translated->size() == 48,
            "DirectX fallback misreported precision or lost stages");
        require(calls() == begin + 48, "not every DirectX stage was translated once");
        const auto cached = loadLsfgShaderSet(fp32Archive, "synthetic.dll", false);
        require(cached.translated == shaders.translated && calls() == begin + 48,
            "repeated FP32 selection bypassed the process-local translation cache");
        for (const bool mode : {false, true})
            for (const auto& spec : detail::lsfgShaderSpecs(mode)) {
                const auto& bytes = shaders.resource(archive, spec.logicalId, mode);
                const auto info = detail::validateSpirvComputeShader(bytes, spec.contract,
                    "translated synthetic shader");
                require(info.exactBindings && !info.declaresFloat16,
                    "translated stage had wrong bindings or precision");
            }
        // Success belongs to one immutable archive; replaced DLLs must translate.
        const DllResourceArchive replacement{.resources = resources};
        static_cast<void>(loadLsfgShaderSet(replacement, "synthetic.dll", false));
        require(calls() == begin + 96, "replacement archive reused stale translation");

        for (const char* failure : {"compile", "malformed", "binding", "precision"}) {
            ::setenv("MAKO_TEST_TRANSLATION_FAILURE", failure, 1);
            const DllResourceArchive retry{.resources = resources};
            requireFailure([&] { static_cast<void>(loadLsfgShaderSet(
                retry, "synthetic.dll", false)); }, "failed translator output accepted");
            ::unsetenv("MAKO_TEST_TRANSLATION_FAILURE");
            require(loadLsfgShaderSet(retry, "synthetic.dll", false).translated != nullptr,
                "failed translation was permanently cached");
        }
        ::setenv("MAKO_TEST_TRANSLATION_FAILURE", "compile", 1);
        Resources nativeResources = resources;
        addLsfgTable(nativeResources, 0);
        const auto native = loadLsfgShaderSet({.resources = nativeResources}, "synthetic.dll", true);
        require(native.fp16 && !native.translated,
            "native Vulkan model did not take precedence over DirectX translation");
    }

    void addLs1Table(Resources& resources, const int64_t offset) {
        // Independently spell out the supported table to detect mistakes in
        // the production graph, mode, and variant declarations.
        for (uint32_t id = 141U; id <= 161U; ++id) {
            const mako::backend::detail::ShaderResourceContract contract = id == 146U
                ? mako::backend::detail::ShaderResourceContract{2, 1, 1, 1}
                : mako::backend::detail::ShaderResourceContract{
                    1, 1, id >= 148U && (id - 148U) % 3U == 0 ? 0U : 1U, 0};
            resources.emplace(mako::backend::ModelResourceSelection{offset}.resourceId(id),
                reflectedDxbc(contract));
        }
    }

    void testRelocatedTables() {
        using namespace mako::backend;
        for (const int64_t offset : {-140, 1, 700, 9000}) {
            Resources resources;
            addLs1Table(resources, offset);
            addLsfgTable(resources, offset);
            resources.emplace(90000U, std::vector<uint8_t>{1, 2, 3});
            const DllResourceArchive archive{.resources = std::move(resources)};
            for (const bool fp16 : {false, true}) {
                require(resolveLsfgModelResources(archive, fp16).idOffset == offset,
                    "runtime registry disagrees with relocated model inspection");
                for (const bool performance : {false, true})
                    for (int repeat = 0; repeat < 2; ++repeat) {
                        const auto selection = resolveLsfgModelResources(archive, fp16, performance);
                        require(selection.idOffset == offset, "wrong LSFG table selected");
                        const auto spec = detail::lsfgShaderSpecs(performance).front();
                        const auto id = detail::lsfgResourceId(spec.logicalId, fp16, performance);
                        require(&selection.resource(archive, id) ==
                                &archive.resources.at(selection.resourceId(id)),
                            "resolved LSFG bytes do not belong to the selected archive");
                    }
            }
            for (const auto mode : {Ls1Mode::Quality, Ls1Mode::Performance}) {
                require(resolveLs1ModelResources(archive, mode).idOffset == offset,
                    "wrong complete LS1 table selected");
                for (uint32_t variant = 0; variant < 5; ++variant)
                    require(resolveLs1ModelResources(archive, mode, variant).idOffset == offset,
                        "selected LS1 loader disagrees with inspection");
            }
        }
    }

    void testUnsafeDiscoveryAndCanonicalPreference() {
        using namespace mako::backend;
        Resources resources;
        addLs1Table(resources, 1000);
        addLsfgTable(resources, 1000);
        addLs1Table(resources, 2000);
        addLsfgTable(resources, 2000);
        const DllResourceArchive ambiguous{.resources = resources};
        for (int repeat = 0; repeat < 2; ++repeat) {
            requireFailure([&] { static_cast<void>(resolveLs1ModelResources(
                ambiguous, Ls1Mode::Quality)); }, "ambiguous LS1 tables accepted");
            requireFailure([&] { static_cast<void>(resolveLsfgModelResources(
                ambiguous, false, false)); }, "ambiguous LSFG tables accepted");
        }
        addLs1Table(resources, 0);
        addLsfgTable(resources, 0);
        const DllResourceArchive canonical{.resources = resources};
        require(resolveLs1ModelResources(canonical, Ls1Mode::Quality).idOffset == 0 &&
                resolveLsfgModelResources(canonical, false, false).idOffset == 0,
            "canonical models did not take precedence over ambiguous relocated tables");

        Resources mixed;
        addLsfgTable(mixed, 0);
        addLsfgTable(mixed, 1000);
        mixed.erase(detail::lsfgResourceId(257U, true, true));
        const DllResourceArchive mixedArchive{.resources = std::move(mixed)};
        require(resolveLsfgModelResources(mixedArchive, true, false).idOffset == 0 &&
                resolveLsfgModelResources(mixedArchive, true, true).idOffset == 1000 &&
                resolveLsfgModelResources(mixedArchive, true).idOffset == 1000,
            "runtime LSFG registry mixed shared stages from different tables");

        resources.clear();
        addLs1Table(resources, 1000);
        addLsfgTable(resources, 1000);
        for (const uint32_t missing : {1141U, 1161U, 1304U, 1400U}) {
            auto incomplete = resources;
            incomplete.erase(missing);
            const DllResourceArchive archive{.resources = std::move(incomplete)};
            if (missing < 1200U) {
                requireFailure([&] { static_cast<void>(resolveLs1ModelResources(
                    archive, Ls1Mode::Quality, 0)); }, "partial relocated LS1 table accepted");
                require(resolveLsfgModelResources(archive, false, false).idOffset == 1000,
                    "bad LS1 table vetoed LSFG");
            } else {
                requireFailure([&] { static_cast<void>(resolveLsfgModelResources(
                    archive, true, true)); }, "partial relocated LSFG table accepted");
                require(resolveLs1ModelResources(archive, Ls1Mode::Quality).idOffset == 1000,
                    "bad LSFG table vetoed LS1");
            }
        }
        auto noReflection = resources;
        noReflection.at(1141U) = syntheticDxbc();
        requireFailure([&] { static_cast<void>(resolveLs1ModelResources(
            {.resources = noReflection}, Ls1Mode::Quality)); },
            "relocated LS1 accepted a graph without reflection proof");
        auto shuffled = resources;
        std::swap(shuffled.at(1147U), shuffled.at(1148U));
        requireFailure([&] { static_cast<void>(resolveLs1ModelResources(
            {.resources = shuffled}, Ls1Mode::Quality)); }, "shuffled LS1 stages accepted");
        auto swappedPrecision = resources;
        for (const bool performance : {false, true})
            for (const auto& spec : detail::lsfgShaderSpecs(performance))
                std::swap(swappedPrecision.at(1000U + detail::lsfgResourceId(spec.logicalId, true, performance)),
                    swappedPrecision.at(1000U + detail::lsfgResourceId(spec.logicalId, false, performance)));
        requireFailure([&] { static_cast<void>(resolveLsfgModelResources(
            {.resources = swappedPrecision}, false, false)); }, "swapped LSFG precision lanes accepted");
        auto extraBindings = resources;
        extraBindings.at(1304U) = syntheticSpirv(detail::lsfgShaderSpecs(false).front().contract, true, true);
        requireFailure([&] { static_cast<void>(resolveLsfgModelResources(
            {.resources = extraBindings}, true, false)); }, "unproven relocated interface accepted");

        auto oversized = resources;
        for (uint32_t id = 10000U; id < 14100U; ++id)
            oversized.emplace(id, std::vector<uint8_t>{});
        requireFailure([&] { static_cast<void>(resolveLsfgModelResources(
            {.resources = oversized}, true, false)); }, "unbounded discovery accepted");
        addLsfgTable(oversized, 0);
        require(resolveLsfgModelResources({.resources = oversized}, true, false).idOffset == 0,
            "discovery limit incorrectly rejected a canonical table");

        Resources selected;
        selected.emplace(141U, syntheticDxbc());
        selected.emplace(146U, syntheticDxbc());
        const DllResourceArchive oneVariant{.resources = selected};
        require(resolveLs1ModelResources(oneVariant, Ls1Mode::Performance, 0).idOffset == 0,
            "unrelated missing LS1 variants vetoed canonical selected loader");
        requireFailure([&] { static_cast<void>(resolveLs1ModelResources(
            oneVariant, Ls1Mode::Performance)); }, "incomplete canonical family inspection accepted");
        requireFailure([&] { static_cast<void>(resolveLs1ModelResources(
            oneVariant, Ls1Mode::Performance, 5)); }, "invalid variant accepted");
    }

    void testReflectionAndIdBounds() {
        using namespace mako::backend;
        const detail::ShaderResourceContract contract{2, 1, 1, 1};
        const auto original = reflectedDxbc(contract);
        detail::validateDxbcResourceBindings(original, contract, "reflection fixture");
        detail::validateDxbcResourceBindings(syntheticDxbc(), contract, "optional reflection", false);
        auto futureReflection = original;
        writeInteger<uint32_t>(futureReflection, 64U, 0x43530501U);
        detail::validateDxbcResourceBindings(futureReflection, contract, "future reflection", false);
        detail::validateDxbcResourceBindings(reflectedDxbc({2, 1, 1, 2}), contract,
            "additional canonical binding", false);
        // RDEF: unsupported model, count overflow, offset under/overflow,
        // unsupported resource type, wrong dimension, array, duplicate slot.
        for (const auto [offset, value] : std::array<std::pair<size_t, uint32_t>, 9>{
                {{64U, 0x43530501U}, {56U, 0xffffffffU}, {60U, 0U},
                 {60U, 0xffffffffU}, {80U, 99U}, {120U, 5U},
                 {100U, 2U}, {160U, 0U}, {56U, 1U}}}) {
            auto malformed = original;
            writeInteger<uint32_t>(malformed, offset, value);
            requireFailure([&] { detail::validateDxbcResourceBindings(
                malformed, contract, "bad reflection"); }, "invalid reflection accepted");
        }
        for (const int64_t offset : {std::numeric_limits<int64_t>::min(),
                std::numeric_limits<int64_t>::max(), int64_t{-2},
                static_cast<int64_t>(std::numeric_limits<uint32_t>::max())})
            requireFailure([&] { static_cast<void>(ModelResourceSelection{offset}.resourceId(1U)); },
                "out-of-range resource ID accepted");
        require(ModelResourceSelection{-1}.resourceId(1U) == 0U &&
                ModelResourceSelection{1}.resourceId(0xfffffffeU) == 0xffffffffU,
            "valid resource ID boundary rejected");
    }

    void testSha256() {
        const std::array<uint8_t, 3> input{'a', 'b', 'c'};
        require(mako::backend::detail::sha256Hex(input) ==
            "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",
            "SHA-256 implementation returned the wrong known digest");
    }

    void testPeExtractionAndIdentity(const TemporaryDirectory& temporary) {
        const auto firstPath = temporary.path / "first.dll";
        writeFile(firstPath, syntheticPe(
            {1U, 2U, 3U}, {
                .extraRootResource = true,
                .namedRootResource = true,
                .additionalLanguage = true,
            }
        ));
        const auto first = mako::backend::loadDllResourceArchive(firstPath);
        require(first->resources.size() == 1U &&
                first->resources.at(141U) == std::vector<uint8_t>({1U, 2U, 3U}),
            "valid synthetic PE resource was not extracted");
        require(first->fileSha256.size() == 64U &&
                first->resourceLayoutSha256.size() == 64U,
            "DLL fingerprints were not emitted");

        const auto oldTime = std::filesystem::last_write_time(firstPath);
        writeFile(firstPath, syntheticPe(
            {3U, 2U, 1U}, {
                .extraRootResource = true,
                .namedRootResource = true,
                .additionalLanguage = true,
            }
        ));
        std::filesystem::last_write_time(firstPath, oldTime);
        const auto replaced = mako::backend::loadDllResourceArchive(firstPath);
        require(first->fileSha256 != replaced->fileSha256 &&
                first->resourceLayoutSha256 != replaced->resourceLayoutSha256,
            "same-size, restored-mtime DLL replacement reused stale resources");

        require(mako::backend::loadDllResourceArchive(firstPath) == replaced,
            "unchanged DLL should reuse its process-local archive");
        std::filesystem::remove(firstPath);
        requireFailure([&] {
            static_cast<void>(mako::backend::loadDllResourceArchive(firstPath));
        }, "removed DLL reused stale resources");
        writeFile(firstPath, {0U, 1U});
        requireFailure([&] {
            static_cast<void>(mako::backend::loadDllResourceArchive(firstPath));
        }, "truncated replacement reused stale resources");

        const auto pe32Path = temporary.path / "pe32.dll";
        writeFile(pe32Path, syntheticPe(
            {4U, 5U, 6U}, {.pe32 = true, .additionalLanguage = true}
        ));
        const auto pe32 = mako::backend::loadDllResourceArchive(pe32Path);
        require(pe32->resources.at(141U) ==
                std::vector<uint8_t>({4U, 5U, 6U}),
            "valid PE32 resource was not extracted");

        auto negativeOffset = syntheticPe({1U});
        writeInteger<int32_t>(negativeOffset, 60U, -1);
        const auto negativePath = temporary.path / "negative.dll";
        writeFile(negativePath, negativeOffset);
        requireFailure(
            [&] { static_cast<void>(mako::backend::loadDllResourceArchive(
                negativePath)); },
            "negative PE offset was accepted"
        );

        auto outside = syntheticPe({1U});
        writeInteger<uint32_t>(outside, 0x290U, 0x2000U);
        const auto outsidePath = temporary.path / "outside.dll";
        writeFile(outsidePath, outside);
        requireFailure(
            [&] { static_cast<void>(mako::backend::loadDllResourceArchive(
                outsidePath)); },
            "out-of-range PE resource was accepted"
        );

        // Two metadata-only resources are enough for one canonical LS1
        // Performance variant. Replacement must invalidate its resolved model
        // even when size and mtime are restored by an updater.
        auto model = syntheticPe(syntheticDxbc());
        writeInteger<uint16_t>(model, 0x24eU, 2U);
        writeInteger<uint32_t>(model, 0x258U, 146U);
        writeInteger<uint32_t>(model, 0x25cU, 0x800000b0U);
        writeInteger<uint16_t>(model, 0x2beU, 1U);
        writeInteger<uint32_t>(model, 0x2c4U, 0xd0U);
        writeInteger<uint32_t>(model, 0x2d0U, 0x1100U);
        writeInteger<uint32_t>(model, 0x2d4U, static_cast<uint32_t>(syntheticDxbc().size()));
        const auto modelPath = temporary.path / "model.dll";
        writeFile(modelPath, model);
        const auto modelArchive = mako::backend::loadDllResourceArchive(modelPath);
        require(mako::backend::resolveLs1ModelResources(*modelArchive,
                mako::backend::Ls1Mode::Performance, 0).idOffset == 0,
            "synthetic selected model did not resolve");
        {
            const char* previous = std::getenv("MAKO_VKD3D_SHADER_PATH");
            const std::string previousPath = previous ? previous : "";
            struct RestoreTranslator {
                std::string path;
                bool present;
                ~RestoreTranslator() {
                    if (present) ::setenv("MAKO_VKD3D_SHADER_PATH", path.c_str(), 1);
                    else ::unsetenv("MAKO_VKD3D_SHADER_PATH");
                    ::unsetenv("MAKO_TEST_TRANSLATION_FAILURE");
                }
            } restore{previousPath, previous != nullptr};
            ::setenv("MAKO_VKD3D_SHADER_PATH", MAKO_TEST_TRANSLATOR_PATH, 1);
            using namespace mako::backend;
            const auto sdr = loadLs1ShaderSet(modelPath, Ls1Mode::Performance, 0.0F, false);
            const auto hdr = loadLs1ShaderSet(modelPath, Ls1Mode::Performance, 0.0F, true);
            require(sdr.stage1 == hdr.stage1 && sdr.reconstruction != hdr.reconstruction,
                "HDR must preserve model feature precision and replace reconstruction storage");
            const auto storageFormat = [](const std::vector<uint8_t>& bytes) {
                std::vector<uint32_t> words(bytes.size() / sizeof(uint32_t));
                std::memcpy(words.data(), bytes.data(), bytes.size());
                for (size_t i = 5; i < words.size(); i += words.at(i) >> 16U)
                    if ((words.at(i) & 0xffffU) == 25U && words.at(i + 7) == 2U)
                        return words.at(i + 8);
                return UINT32_MAX;
            };
            require(storageFormat(sdr.reconstruction) == 4 && storageFormat(hdr.reconstruction) == 2,
                "LS1 reconstruction must select RGBA8 for SDR and RGBA16F for HDR");
            ::setenv("MAKO_TEST_TRANSLATION_FAILURE", "compile", 1);
            require(loadLs1ShaderSet(modelPath, Ls1Mode::Performance, 0.0F, false).reconstruction == sdr.reconstruction &&
                    loadLs1ShaderSet(modelPath, Ls1Mode::Performance, 0.0F, true).reconstruction == hdr.reconstruction,
                "SDR and HDR cache entries must remain distinct without retranslating");
        }
        const auto modelTime = std::filesystem::last_write_time(modelPath);
        model[0x300U] = 0U;
        writeFile(modelPath, model);
        std::filesystem::last_write_time(modelPath, modelTime);
        const auto replacement = mako::backend::loadDllResourceArchive(modelPath);
        requireFailure([&] { static_cast<void>(mako::backend::resolveLs1ModelResources(
            *replacement, mako::backend::Ls1Mode::Performance, 0)); },
            "DLL replacement reused a stale successful model resolution");
        require(mako::backend::resolveLs1ModelResources(*modelArchive,
                mako::backend::Ls1Mode::Performance, 0).idOffset == 0,
            "DLL replacement invalidated an existing immutable archive");
    }

    void testShaderContainersAndRequiredBindings() {
        const mako::backend::detail::ShaderResourceContract contract{1, 1, 1, 1};
        auto compatible = syntheticSpirv(contract, true);
        mako::backend::detail::validateSpirvComputeShader(
            compatible, contract, "synthetic SPIR-V"
        );
        auto missing = syntheticSpirv({0, 1, 1, 1});
        requireFailure(
            [&] { mako::backend::detail::validateSpirvComputeShader(
                missing, contract, "missing binding"); },
            "missing required SPIR-V binding was accepted"
        );
        compatible[0] = 0U;
        requireFailure(
            [&] { mako::backend::detail::validateSpirvComputeShader(
                compatible, contract, "bad magic"); },
            "invalid SPIR-V magic was accepted"
        );

        mako::backend::detail::validateDxbcComputeShader(
            syntheticDxbc(), "synthetic DXBC"
        );
        // New vendor metadata is harmless; aliasing/truncated chunk tables
        // are not. None of these fixtures contains proprietary bytecode.
        auto extraChunk = syntheticDxbc();
        extraChunk.resize(60U);
        writeInteger<uint32_t>(extraChunk, 24U, 56U);
        writeInteger<uint32_t>(extraChunk, 28U, 2U);
        writeInteger<uint32_t>(extraChunk, 32U, 40U);
        writeInteger<uint32_t>(extraChunk, 36U, 48U);
        writeInteger<uint32_t>(extraChunk, 40U, 0x58454853U);
        writeInteger<uint32_t>(extraChunk, 44U, 0U);
        writeInteger<uint32_t>(extraChunk, 48U, 0x54534554U);
        writeInteger<uint32_t>(extraChunk, 52U, 0U);
        mako::backend::detail::validateDxbcComputeShader(extraChunk, "extra vendor chunk");
        writeInteger<uint32_t>(extraChunk, 36U, 40U);
        requireFailure([&] {
            mako::backend::detail::validateDxbcComputeShader(extraChunk, "aliased chunks");
        }, "aliased DXBC chunks were accepted");
        writeInteger<uint32_t>(extraChunk, 36U, 48U);
        writeInteger<uint32_t>(extraChunk, 52U, 100U);
        requireFailure([&] {
            mako::backend::detail::validateDxbcComputeShader(extraChunk, "truncated chunk");
        }, "out-of-range DXBC chunk was accepted");
        requireFailure(
            [&] { mako::backend::detail::validateDxbcComputeShader(
                syntheticDxbc(false), "missing shader chunk"); },
            "DXBC without shader bytecode was accepted"
        );
    }

    void testCapabilityIsolationAndHarmlessAdditions() {
        for (const bool performance : {false, true}) {
            for (const bool fp16 : {false, true}) {
                std::unordered_map<uint32_t, std::vector<uint8_t>> resources;
                for (const auto& spec :
                        mako::backend::detail::lsfgShaderSpecs(performance)) {
                    resources.emplace(
                        mako::backend::detail::lsfgResourceId(
                            spec.logicalId, fp16, performance
                        ),
                        syntheticSpirv(spec.contract, true)
                    );
                }
                resources.emplace(9999U, std::vector<uint8_t>{1U, 2U, 3U});
                static_cast<void>(mako::backend::resolveLsfgModelResources(
                    {.resources = resources}, fp16, performance
                ));
                resources.erase(mako::backend::detail::lsfgResourceId(
                    mako::backend::detail::lsfgShaderSpecs(performance).front().logicalId,
                    fp16, performance
                ));
                requireFailure(
                    [&] { static_cast<void>(mako::backend::resolveLsfgModelResources(
                        {.resources = resources}, fp16, performance)); },
                    "missing LSFG resource was accepted"
                );
            }
        }

        std::unordered_map<uint32_t, std::vector<uint8_t>> ls1Resources;
        for (uint32_t id = 141U; id <= 161U; ++id)
            ls1Resources.emplace(id, syntheticDxbc());
        ls1Resources.emplace(9999U, std::vector<uint8_t>{1U});
        for (uint32_t removed = 141U; removed <= 161U; ++removed) {
            auto changed = ls1Resources;
            changed.erase(removed);
            for (const auto mode : {mako::backend::Ls1Mode::Quality,
                    mako::backend::Ls1Mode::Performance}) {
                const bool required = removed == 146U ||
                    (mode == mako::backend::Ls1Mode::Quality ? removed >= 147U : removed <= 145U);
                const auto validate = [&] {
                    static_cast<void>(mako::backend::resolveLs1ModelResources(
                        {.resources = changed}, mode));
                };
                if (required) requireFailure(validate, "missing selected LS1 graph resource accepted");
                else validate();
            }
        }
        static_cast<void>(mako::backend::resolveLs1ModelResources(
            {.resources = ls1Resources}, mako::backend::Ls1Mode::Quality
        ));
        static_cast<void>(mako::backend::resolveLs1ModelResources(
            {.resources = ls1Resources}, mako::backend::Ls1Mode::Performance
        ));
        ls1Resources.erase(141U);
        static_cast<void>(mako::backend::resolveLs1ModelResources(
            {.resources = ls1Resources}, mako::backend::Ls1Mode::Quality
        ));
        requireFailure(
            [&] { static_cast<void>(mako::backend::resolveLs1ModelResources(
                {.resources = ls1Resources}, mako::backend::Ls1Mode::Performance)); },
            "LS1 Performance did not fail independently of Quality"
        );
    }
}

int main() {
    try {
        const TemporaryDirectory temporary;
        testSha256();
        testLsfgDxbcResolutionAndTranslation();
        testPeExtractionAndIdentity(temporary);
        testShaderContainersAndRequiredBindings();
        testCapabilityIsolationAndHarmlessAdditions();
        testRelocatedTables();
        testUnsafeDiscoveryAndCanonicalPreference();
        testReflectionAndIdBounds();
    } catch (const std::exception& error) {
        std::cerr << "DLL inspection test failed: " << error.what() << '\n';
        return 1;
    }
    return 0;
}
