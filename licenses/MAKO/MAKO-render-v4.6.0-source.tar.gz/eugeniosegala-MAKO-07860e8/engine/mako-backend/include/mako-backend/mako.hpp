/* SPDX-License-Identifier: GPL-3.0-or-later */

#pragma once

#include <cstdint>
#include <exception>
#include <filesystem>
#include <functional>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <utility>
#include <vector>

namespace vk { class DeviceMemoryAccounting; }

namespace mako::backend {

    /// Encoding of the images exchanged with the frame-generation backend.
    enum class FrameEncoding : uint8_t {
        Sdr8,
        SdrHighPrecision,
        ScRgbLinear,
        Hdr10Pq,
        Hdr10PqPacked,
    };

    /// Shared colour-conversion shaders for Renderer-owned HDR image stages.
    /// The returned bytes are copied only during private-resource construction.
    [[nodiscard]] std::vector<uint8_t> hdrColorConversionShader(bool linearToPq);

    class [[gnu::visibility("default")]] ContextImpl;
    class [[gnu::visibility("default")]] InstanceImpl;

    using Context = ContextImpl;

    /// Diagnostic timings for the most recent completed generated-frame batch.
    /// GPU spans include commands/barriers; CPU submit times can overlap GPU work.
    struct FrameProfile {
        double cpuPreviousWaitUs{};
        double cpuPrepassSubmitUs{}; // Separate prepass; zero for a combined single-output submission.
        double cpuGenerationSubmitUs{}; // Includes preprocessing for a combined single-output submission.
        double gpuPrepassUs{};
        double gpuInputConversionUs{};
        double gpuMotionEstimationUs{};
        std::vector<double> gpuGeneratedUs;
        std::vector<double> gpuSynthesisUs;
        std::vector<double> gpuOutputConversionUs;
        double gpuSpanUs{};
        uint32_t timestampValidBits{};
        float timestampPeriodNs{};
    };

    ///
    /// Primitive exception class that deliveres a detailed error message
    ///
    class [[gnu::visibility("default")]] error : public std::runtime_error {
    public:
        ///
        /// Construct an error
        ///
        /// @param msg Error message.
        /// @param inner Inner exception.
        ///
        explicit error(const std::string &msg, const std::exception &inner);

        ///
        /// Construct an error
        ///
        /// @param msg Error message.
        ///
        explicit error(const std::string &msg);

        error(const error &) = default;
        error &operator=(const error &) = default;
        error(error &&) = default;
        error &operator=(error &&) = default;
        ~error() override;
    };

    /// Function type for picking a device based on its name and IDs
    using DevicePicker = std::function<bool(
        const std::string& deviceName,
        std::pair<const std::string&, const std::string&> ids, // (vendor ID, device ID) 0xXXXX format
        const std::optional<std::string>& pci // (bus:slot.func) if available, no padded zeros
    )>;

    ///
    /// Main entry point of the library
    ///
    class [[gnu::visibility("default")]] Instance {
    public:
        ///
        /// Create a mako instance
        ///
        /// @param devicePicker Function that picks a physical device based on some identifiers.
        /// @param shaderDllPath Path to the Lossless.dll file to load shaders from.
        /// @param allowLowPrecision Request supported FP16 model shaders; false requires FP32.
        ///
        /// @throws backend::error on failure
        ///
        Instance(
            const DevicePicker& devicePicker,
            const std::filesystem::path& shaderDllPath,
            bool allowLowPrecision
        );

        ///
        /// Open a frame generation context.
        ///
        /// The VkFormat of the exchanged images is inferred from encoding:
        /// - Sdr8: VK_FORMAT_R8G8B8A8_UNORM
        /// - Hdr10PqPacked: VK_FORMAT_A2B10G10R10_UNORM_PACK32
        /// - all other encodings: VK_FORMAT_R16G16B16A16_SFLOAT
        ///
        /// The application and library must keep track of the frame index. When the next frame
        /// is ready, signal the syncFd with one increment (with the first trigger being 1).
        /// Each generated frame will increment the semaphore by one:
        /// - Application signals 1 -> Start generating with (curr, next) source images
        /// - Library signals 2 -> First frame between (curr, next) is ready
        /// - Library signals N+1 -> N-th frame between (curr, next) is ready
        /// - Application signals N+2 -> Start generating with (next, curr) source images
        ///
        /// Context creation initializes image layouts; upload sources afterwards.
        /// Before signalling the input timeline, release uploaded sources to
        /// VK_QUEUE_FAMILY_EXTERNAL in GENERAL. The backend acquires both sources
        /// and releases them in GENERAL at batch completion (also for history).
        /// Acquire each generated output from EXTERNAL in GENERAL after its
        /// timeline wait, then perform any caller-owned layout transition.
        /// Source uploads and generated outputs fully overwrite their images:
        /// UNDEFINED transitions discard prior contents/ownership on reuse.
        /// Complete all previous reads before permitting that overwrite.
        ///
        /// Takes ownership of every supplied descriptor on entry, including when
        /// construction fails before an import. Pass distinct owned descriptors;
        /// the caller must neither close nor reuse them after this call.
        ///
        /// @param sourceFds Pair of file descriptors for the source images alternated between.
        /// @param destFds Vector with file descriptors to import output images from.
        /// @param syncFd File descriptor for the timeline semaphore used for synchronization.
        /// @param width Width of the images.
        /// @param height Height of the images.
        /// @param encoding Colour encoding of the exchanged images.
        /// @param flow Inverse motion Flow Scale after profile presets (1..4).
        /// @param perf Whether to enable performance mode.
        /// @param reducedHdrPrecision Approximate HDR10 interpolation in PQ code values
        ///        with half-size motion analysis, bounded at quarter Flow Scale.
        ///        Source/output extents and the selected model/arithmetic stay unchanged.
        ///        scRGB and SDR retain their existing model path.
        ///
        /// @throws backend::error on failure
        ///
        Context& openContext(
            std::pair<int, int> sourceFds,
            const std::vector<int>& destFds,
            int syncFd,
            uint32_t width, uint32_t height,
            FrameEncoding encoding, float flow, bool perf,
            bool reducedHdrPrecision = false
        );

        /// Return whether the backend device can import and write the packed
        /// RGB10A2 images used by the low-bandwidth HDR10 transport path.
        [[nodiscard]] bool supportsPackedHdr10Transport() const;

        /// Retain read-only atomic memory accounting without retaining or
        /// calling the private Vulkan device from a diagnostic worker.
        [[nodiscard]] std::shared_ptr<const vk::DeviceMemoryAccounting>
        deviceMemoryAccounting() const;

        ///
        /// Schedule a new set of generated frames.
        ///
        /// @param context Context to use.
        /// @throws backend::error on failure
        ///
        void scheduleFrames(Context& context);

        /// Enable diagnostic CPU clocks and GPU timestamps on a fresh context.
        /// Must precede its first schedule; ordinary contexts allocate no queries.
        void enableFrameProfiling(Context& context);

        /// Read the latest batch after the caller establishes GPU completion with
        /// its normal output wait. No extra fence wait or blocking query-result
        /// flag is added; unavailable queries fail. Readback is measurement overhead.
        [[nodiscard]] FrameProfile readFrameProfile(const Context& context) const;

        ///
        /// Schedule generated frames at explicit interpolation timestamps.
        ///
        /// Timestamps must be strictly increasing values between 0 and 1. The
        /// number of timestamps may not exceed the destination-image capacity
        /// supplied when the context was opened.
        ///
        /// @param context Context to use.
        /// @param timestamps Normalized positions between the previous and current real frame.
        /// @throws backend::error on failure
        ///
        void scheduleFrames(Context& context, std::span<const float> timestamps);

        ///
        /// Update temporal model history without generating output frames.
        ///
        /// The caller must submit the source frame and signal its shared timeline
        /// value first. The shared pre-pass is then run so temporal feature maps,
        /// source-image parity, and synchronization remain aligned while the
        /// expensive per-output generation passes are skipped.
        ///
        /// @param context Context to advance.
        ///
        void scheduleFrameHistory(Context& context);

        /// Check whether the context's previously submitted work has completed
        /// without blocking.
        [[nodiscard]] bool contextReady(const Context& context) const;

        ///
        /// Close a frame generation context
        ///
        /// @param context Context to close.
        ///
        void closeContext(const Context& context);

        // Non-copyable and non-movable
        Instance(const Instance&) = delete;
        Instance& operator=(const Instance&) = delete;
        Instance(Instance&&) = delete;
        Instance& operator=(Instance&&) = delete;
        virtual ~Instance();
    private:
        void collectRetiredContexts();

        std::unique_ptr<InstanceImpl> m_impl;

        std::vector<std::unique_ptr<Context>> m_contexts;
        std::vector<std::unique_ptr<Context>> m_retiredContexts;
    };

    ///
    /// Retain private Vulkan objects for the remaining process lifetime.
    /// This works around Vulkan loader configurations where destroying a
    /// nested instance and device during layer unload is unsafe.
    /// The retained device submits no new work, but its driver resources remain
    /// allocated until the host process exits. Do not enable this before a
    /// backend context has successfully been attached to an application layer.
    ///
    void makeLeaking();

}
