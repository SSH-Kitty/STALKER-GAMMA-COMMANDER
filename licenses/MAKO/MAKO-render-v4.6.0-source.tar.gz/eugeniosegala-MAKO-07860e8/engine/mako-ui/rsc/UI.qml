import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Window
import QtQuick.Dialogs
import "dialogs"
import "panes"
import "widgets"

ApplicationWindow {
    id: mainWindow
    property var t: localization.strings
    property string profileErrorText: {
        switch (backend.profile_operation_error) {
            case "invalid_name": return t.profileNameInvalid;
            case "duplicate_name": return t.profileNameExists;
            case "default_protected": return t.defaultProfileProtected;
            case "save_failed": return t.profileSaveFailed;
            default: return "";
        }
    }

    title: t.makoRendererConfig
    width: 900
    height: 550
    minimumWidth: 700
    minimumHeight: 400
    visible: true
    onActiveChanged: if (active) backend.refreshLosslessScaling()
    Component.onCompleted: backend.refreshRemotePlay()
    onClosing: function(close) { if (backend.remote_play_busy) close.accepted = false }

    component ShaderActionButton: Button {
        id: action
        Layout.fillWidth: true
        Layout.minimumWidth: 0
        contentItem: Label {
            text: action.text
            font: action.font
            color: action.palette.buttonText
            horizontalAlignment: Text.AlignHCenter
            verticalAlignment: Text.AlignVCenter
            wrapMode: Text.WordWrap
        }
    }

    ShaderParametersWindow {
        id: shaderEditor
        strings: t
        owner: mainWindow
    }

    RunningGamesDialog {
        id: running_games_dialog
        strings: t
        onCaptured: launch_setup_dialog.open()
    }

    CenteredDialog {
        id: launch_setup_dialog
        objectName: "launch_setup_dialog"
        name: t.gameProfileReady
        width: parent.width * 0.8

        Label {
            Layout.fillWidth: true
            text: t.gameLaunchSetup
            wrapMode: Text.WordWrap
        }
        TextField {
            Layout.fillWidth: true
            text: backend.launch_option
            readOnly: true
            selectByMouse: true
        }
        Label {
            Layout.fillWidth: true
            text: t.gameLaunchFlatpak
            wrapMode: Text.WordWrap
        }
        Button {
            Layout.fillWidth: true
            text: t.openLaunchGuide
            onClicked: Qt.openUrlExternally("https://github.com/eugeniosegala/MAKO/blob/main/engine/README.md#2-launch-the-game-with-mako")
        }
    }

    CenteredDialog {
        id: create_dialog
        objectName: "create_profile_dialog"
        name: t.createNewProfile
        acceptOnConfirm: false
        onConfirm: if (backend.createProfile(create_name.text)) close()

        Label {
            Layout.fillWidth: true
            text: t.createProfileDesc
            wrapMode: Text.WordWrap
        }

        TextField {
            id: create_name
            Layout.fillWidth: true
            placeholderText: t.chooseProfileName
            focus: true
        }
        Label {
            Layout.fillWidth: true
            text: profileErrorText
            visible: text.length > 0
            wrapMode: Text.WordWrap
        }
    }

    CenteredDialog {
        id: rename_dialog
        name: t.renameProfile
        acceptOnConfirm: false
        onConfirm: if (backend.renameProfile(rename_name.text)) close()

        TextField {
            id: rename_name
            Layout.fillWidth: true
            placeholderText: t.chooseProfileName
            focus: true
        }
        Label {
            Layout.fillWidth: true
            text: profileErrorText
            visible: text.length > 0
            wrapMode: Text.WordWrap
        }
    }

    CenteredDialog {
        id: delete_dialog
        name: t.confirmDeletion
        acceptOnConfirm: false
        onConfirm: if (backend.deleteProfile()) close()

        Label {
            Layout.fillWidth: true
            text: t.confirmDeleteMsg
            horizontalAlignment: Text.AlignHCenter
        }
        Label {
            Layout.fillWidth: true
            text: profileErrorText
            visible: text.length > 0
            wrapMode: Text.WordWrap
        }
    }

    LargeDialog {
        id: active_in_dialog
        name: t.activeIn

        List {
            Layout.fillWidth: true
            Layout.fillHeight: true

            model: backend.active_in
            selected: backend.active_in_index
            onSelect: index => {
                backend.active_in_index = index;
                var idx = backend.active_in.index(index, 0);
                active_in_name.text = backend.active_in.data(idx);
            }
        }

        RowLayout {
            spacing: 8

            TextField {
                id: active_in_name
                Layout.fillWidth: true
                placeholderText: t.activeInPlaceholder
                focus: true
            }
            Button {
                icon.name: "list-add"
                onClicked: backend.addActiveIn(active_in_name.text)
            }
            Button {
                icon.name: "list-remove"
                onClicked: backend.removeActiveIn()
            }
        }
    }

    SplitView {
        anchors.fill: parent
        orientation: Qt.Horizontal

        Pane {
            SplitView.minimumWidth: 200
            SplitView.preferredWidth: 250
            SplitView.maximumWidth: 300

            Label {
                text: t.profiles
                Layout.fillWidth: true
                font.bold: true
                horizontalAlignment: Text.AlignHCenter
            }

            List {
                model: backend.profiles
                selected: backend.profile_index
                onSelect: index => backend.profile_index = index
            }

            Button {
                Layout.fillWidth: true
                text: t.detectRunningGame
                onClicked: running_games_dialog.open()
            }
            Button {
                Layout.fillWidth: true
                text: t.createNewProfile
                onClicked: {
                    backend.clearProfileOperationError();
                    create_name.text = "";
                    create_dialog.open();
                }
            }
            Button {
                Layout.fillWidth: true
                text: t.renameProfile
                enabled: backend.can_manage_profile
                onClicked: {
                    backend.clearProfileOperationError();
                    var idx = backend.profiles.index(backend.profile_index, 0);
                    rename_name.text = backend.profiles.data(idx);
                    rename_dialog.open();
                }
            }
            Button {
                Layout.fillWidth: true
                text: t.deleteProfile
                enabled: backend.can_manage_profile
                onClicked: {
                    backend.clearProfileOperationError();
                    delete_dialog.open();
                }
            }
            Label {
                Layout.fillWidth: true
                text: profileErrorText
                visible: text.length > 0 && !create_dialog.visible && !rename_dialog.visible && !delete_dialog.visible
                wrapMode: Text.WordWrap
            }
        }

        ScrollView {
            id: settings_scroll
            SplitView.fillWidth: true
            clip: true
            contentWidth: availableWidth
            leftPadding: 12
            rightPadding: 12
            topPadding: 12
            bottomPadding: 12
            ScrollBar.vertical.policy: ScrollBar.AsNeeded

            ColumnLayout {
                width: settings_scroll.availableWidth
                spacing: 12

                Group {
                    objectName: "lossless_scaling_warning"
                    name: t.losslessWarningTitle
                    visible: backend.lossless_scaling_missing

                    RowLayout {
                        Layout.fillWidth: true
                        Label {
                            Layout.fillWidth: true
                            text: "• " + t.losslessWarningRequired
                            textFormat: Text.PlainText
                            wrapMode: Text.WordWrap
                        }
                        Button {
                            text: t.losslessWarningInstallAction
                            Accessible.name: t.losslessWarningOpenSteam
                            onClicked: Qt.openUrlExternally("https://store.steampowered.com/app/993090/Lossless_Scaling/")
                        }
                    }
                }

                Group {
                    name: t.globalSettings

                    GroupEntry {
                        title: t.losslessDllPath
                        description: t.losslessDllDesc
                        compactRestartMarker: true

                        FileEdit {
                            Layout.fillWidth: true

                            title: t.selectLosslessDll
                            filter: t.dllFilter
                            allFilesFilter: t.allFilesFilter

                            text: backend.dll
                            onUpdate: text => backend.dll = text
                        }
                    }

                    GroupEntry {
                        title: t.allowFp16
                        description: t.allowFp16Desc
                        compactRestartMarker: true

                        CheckBox {
                            Layout.alignment: Qt.AlignRight

                            checked: backend.allow_fp16
                            onToggled: backend.allow_fp16 = checked
                        }
                    }
                }

                Group {
                    name: t.powerProfiles
                    enabled: backend.available

                    GroupEntry {
                        title: t.separatePowerModes
                        description: t.powerProfilesDesc
                        CheckBox {
                            checked: backend.separate_power_modes
                            onToggled: backend.separate_power_modes = checked
                        }
                    }
                    GroupEntry {
                        title: t.editPowerMode
                        visible: backend.separate_power_modes
                        ComboBox {
                            model: [t.powerShared, t.powerHandheld, t.powerDocked]
                            currentIndex: backend.power_mode
                            onActivated: backend.power_mode = currentIndex
                        }
                    }
                }

                Group {
                    name: t.profileMatching
                    enabled: backend.available

                    GroupEntry {
                        title: t.activeIn
                        description: t.activeInDesc

                        RowLayout {
                            Layout.fillWidth: true
                            spacing: 8

                            Label {
                                Layout.fillWidth: true
                                Layout.minimumWidth: 0
                                text: backend.matched_processes.length > 0
                                    ? backend.matched_processes
                                    : t.noMatchedProcesses
                                elide: Text.ElideMiddle
                            }

                            Button {
                                text: t.editEllipsis
                                onClicked: active_in_dialog.open()
                            }
                        }
                    }
                }

                Group {
                    name: t.frameGeneration
                    enabled: backend.available

                    GroupEntry {
                        title: t.frameGenerationProvisioned
                        description: t.frameGenerationProvisionedDesc
                        compactRestartMarker: true

                        CheckBox {
                            Layout.alignment: Qt.AlignRight

                            checked: backend.frame_generation_provisioned
                            onToggled: backend.frame_generation_provisioned = checked
                        }
                    }

                    GroupEntry {
                        title: t.baseFpsCap
                        description: t.baseFpsCapDesc
                        visible: backend.frame_generation_provisioned
                        enabled: !(backend.adaptive && backend.adaptive_auto_base_fps_cap)
                            && !(backend.fractional_adaptive
                                && backend.adaptive_fractional_real_frame_priority !== "auto")

                        SpinBox {
                            Layout.alignment: Qt.AlignRight

                            from: backend.minimum_base_fps_cap
                            to: backend.maximum_base_fps_cap
                            editable: true

                            value: backend.base_fps_cap
                            textFromValue: function (value) {
                                return value === 0 ? t.off : value + t.fps;
                            }
                            valueFromText: function (text) {
                                var parsed = parseInt(text);
                                return isNaN(parsed)
                                    ? backend.minimum_base_fps_cap
                                    : Math.max(
                                        backend.minimum_base_fps_cap,
                                        Math.min(backend.maximum_base_fps_cap, parsed)
                                    );
                            }
                            onValueModified: backend.base_fps_cap = value
                        }
                    }

                    GroupEntry {
                        title: t.adaptiveFrameGen
                        description: t.adaptiveFrameGenDesc
                        visible: backend.frame_generation_provisioned

                        CheckBox {
                            Layout.alignment: Qt.AlignRight

                            checked: backend.adaptive
                            onToggled: backend.adaptive = checked
                        }
                    }

                    GroupEntry {
                        title: t.fractionalAdaptive
                        description: t.fractionalAdaptiveDesc
                        visible: backend.frame_generation_provisioned
                        enabled: backend.adaptive

                        CheckBox {
                            Layout.alignment: Qt.AlignRight

                            checked: backend.fractional_adaptive
                            onToggled: backend.fractional_adaptive = checked
                        }
                    }

                    GroupEntry {
                        title: backend.adaptive_target_refresh_rate
                            ? t.fallbackTargetFps : t.targetFps
                        description: backend.adaptive_target_refresh_rate
                            ? t.fallbackTargetFpsDesc : t.targetFpsDesc
                        visible: backend.frame_generation_provisioned
                        enabled: backend.adaptive

                        SpinBox {
                            Layout.alignment: Qt.AlignRight

                            enabled: !backend.adaptive_target_refresh_rate

                            from: backend.minimum_target_fps
                            to: backend.maximum_target_fps

                            value: backend.target_fps
                            onValueModified: backend.target_fps = value
                        }
                    }

                    GroupEntry {
                        title: t.adaptiveTargetRefreshRate
                        description: t.adaptiveTargetRefreshRateDesc
                        visible: backend.frame_generation_provisioned
                        enabled: backend.adaptive

                        CheckBox {
                            Layout.alignment: Qt.AlignRight

                            checked: backend.adaptive_target_refresh_rate
                            onToggled: backend.adaptive_target_refresh_rate = checked
                        }
                    }

                    GroupEntry {
                        title: t.realFramePriority
                        description: backend.adaptive_fractional_real_frame_priority === "auto"
                            ? t.realFramePriorityDesc + " " + t.realFramePriorityAutoDesc
                            : t.realFramePriorityDesc + " "
                                + t.realFramePriorityActivePrefix
                                + Number(backend.adaptive_fractional_real_frame_priority_cap.toFixed(1))
                                + t.realFramePriorityActiveSuffix
                        visible: backend.frame_generation_provisioned
                            && backend.fractional_adaptive

                        ComboBox {
                            Layout.fillWidth: true
                            function priorityOption(label, id, target) {
                                const cap = backend.fractionalRealFramePriorityCapFor(id)
                                return t.realFramePriorityOption
                                    .replace("{priority}", label)
                                    .replace("{cap}", Number(cap.toFixed(1)))
                                    .replace("{percent}", Math.round(cap / target * 100))
                            }
                            model: [
                                t.automatic,
                                priorityOption(t.low, "low", backend.target_fps),
                                priorityOption(t.medium, "medium", backend.target_fps),
                                priorityOption(t.high, "high", backend.target_fps),
                                priorityOption(t.veryHigh, "very-high", backend.target_fps)
                            ]
                            currentIndex: ["auto", "low", "medium", "high", "very-high"]
                                .indexOf(backend.adaptive_fractional_real_frame_priority)
                            onActivated: index => backend.adaptive_fractional_real_frame_priority =
                                ["auto", "low", "medium", "high", "very-high"][index]
                        }
                    }

                    GroupEntry {
                        title: t.adaptiveFpsCapPrefix + (backend.target_fps / 2) + t.adaptiveFpsCapSuffix
                        description: t.adaptiveFpsCapDesc
                        visible: backend.frame_generation_provisioned
                        enabled: backend.adaptive

                        CheckBox {
                            Layout.alignment: Qt.AlignRight

                            checked: backend.adaptive_auto_base_fps_cap
                            onToggled: backend.adaptive_auto_base_fps_cap = checked
                        }
                    }

                    GroupEntry {
                        title: t.maxAdaptiveMultiplier
                        description: t.maxAdaptiveMultiplierDesc
                        visible: backend.frame_generation_provisioned && backend.adaptive

                        ComboBox {
                            Layout.fillWidth: true
                            model: ["0" + t.multiplierX, "2" + t.multiplierX, "3" + t.multiplierX, "4" + t.multiplierX, "5" + t.multiplierX]
                            currentIndex: backend.frame_generation_factor_index
                            onActivated: index => backend.frame_generation_factor_index = index
                        }
                    }

                    GroupEntry {
                        title: t.multiplier
                        description: t.multiplierDesc
                        visible: backend.frame_generation_provisioned && !backend.adaptive

                        ComboBox {
                            Layout.fillWidth: true
                            model: ["0" + t.multiplierX, "2" + t.multiplierX, "3" + t.multiplierX, "4" + t.multiplierX, "5" + t.multiplierX]
                            currentIndex: backend.frame_generation_factor_index
                            onActivated: index => backend.frame_generation_factor_index = index
                        }
                    }

                    GroupEntry {
                        title: t.smoothCadence
                        description: t.smoothCadenceDesc
                        visible: backend.frame_generation_provisioned

                        CheckBox {
                            Layout.alignment: Qt.AlignRight

                            checked: backend.adaptive_stable_cadence
                            onToggled: backend.adaptive_stable_cadence = checked
                        }
                    }

                    GroupEntry {
                        title: t.gamescopeVrrMode
                        description: t.gamescopeVrrModeDesc
                        visible: backend.frame_generation_provisioned

                        ComboBox {
                            Layout.fillWidth: true
                            model: [t.gamescopeVrrFollowSteam, t.gamescopeVrrOn, t.gamescopeVrrOff]
                            currentIndex: ["follow-steam", "on", "off"].indexOf(backend.gamescope_vrr_mode)
                            onActivated: index => backend.gamescope_vrr_mode = ["follow-steam", "on", "off"][index]
                        }
                    }

                    GroupEntry {
                        title: t.performanceMode
                        description: t.performanceModeDesc
                        visible: backend.frame_generation_provisioned
                        enabled: !backend.ultra_performance

                        CheckBox {
                            Layout.alignment: Qt.AlignRight

                            checked: backend.performance_mode
                            onToggled: backend.performance_mode = checked
                        }
                    }

                    GroupEntry {
                        title: t.gpu
                        description: t.gpuDesc
                        visible: backend.frame_generation_provisioned
                        compactRestartMarker: true

                        ComboBox {
                            Layout.fillWidth: true

                            model: backend.gpus
                            currentIndex: backend.gpu
                            onActivated: index => backend.gpu = index
                        }
                    }
                }

                Group {
                    name: t.scalingSettings
                    enabled: backend.available

                    GroupEntry {
                        title: t.scalingEnabled
                        description: t.scalingEnabledDesc + "\n\n" + t.scalingEnabledWarning
                        experimentalLabel: t.experimentalLabel
                        compactRestartMarker: true

                        CheckBox {
                            Layout.alignment: Qt.AlignRight

                            checked: backend.scaling_enabled
                            onToggled: backend.scaling_enabled = checked
                        }
                    }

                    GroupEntry {
                        title: t.scalingMethod
                        description: t.scalingMethodDesc
                        visible: backend.scaling_enabled
                        enabled: backend.scaling_enabled && !backend.ultra_performance

                        ComboBox {
                            Layout.fillWidth: true
                            model: [t.scalingMethodNative, t.scalingMethodMako, t.scalingMethodLs1, t.scalingMethodLs1Performance]
                            currentIndex: backend.ultra_performance ? 3 : backend.scaling_method === "native" ? 0 : backend.scaling_method === "ls1" ? 2 : backend.scaling_method === "ls1-performance" ? 3 : 1
                            onActivated: index => backend.scaling_method = index === 0 ? "native" : index === 2 ? "ls1" : index === 3 ? "ls1-performance" : "mako"
                        }
                    }

                    GroupEntry {
                        title: t.scalingSupersampling
                        description: t.scalingSupersamplingDesc + (backend.scaling_supersampling ? "\n\n" + t.scalingSupersamplingWarning : "")
                        visible: backend.scaling_enabled
                        enabled: backend.scaling_enabled

                        CheckBox {
                            Layout.alignment: Qt.AlignRight

                            checked: backend.scaling_supersampling
                            onToggled: backend.scaling_supersampling = checked
                        }
                    }

                    GroupEntry {
                        title: t.scalingFactor
                        description: t.scalingFactorDesc
                        visible: backend.scaling_enabled
                        enabled: backend.scaling_enabled

                        FlowSlider {
                            Layout.fillWidth: true

                            from: backend.minimum_scaling_factor
                            to: backend.maximum_scaling_factor

                            value: backend.scaling_factor
                            onUpdate: value => backend.scaling_factor = value
                        }
                    }

                    GroupEntry {
                        title: t.scalingSharpness
                        description: t.scalingSharpnessDesc
                        visible: backend.scaling_enabled && backend.scaling_method !== "native"
                        enabled: backend.scaling_enabled && backend.scaling_method !== "native"

                        FlowSlider {
                            Layout.fillWidth: true

                            from: backend.minimum_scaling_sharpness
                            to: backend.maximum_scaling_sharpness

                            value: backend.scaling_sharpness
                            onUpdate: value => backend.scaling_sharpness = value
                        }
                    }
                }

                Group {
                    name: t.shaderSettings
                    enabled: backend.available

                    Label {
                        Layout.fillWidth: true
                        wrapMode: Text.Wrap
                        text: t.shaderSettingsDesc
                        color: Qt.rgba(palette.text.r, palette.text.g, palette.text.b, 0.7)
                    }

                    GroupEntry {
                        title: t.enableShaders
                        description: t.enableShadersDesc
                        compactRestartMarker: true

                        CheckBox {
                            Layout.alignment: Qt.AlignRight
                            checked: backend.enable_vkbasalt
                            onToggled: backend.enable_vkbasalt = checked
                        }
                    }

                    GroupEntry {
                        title: t.shaderEffects
                        description: t.shaderEffectsDesc
                        visible: backend.enable_vkbasalt

                        ColumnLayout {
                            id: effectStack
                            Layout.fillWidth: true
                            property var bundledEffectIds: ["none", "hdr_look", "clarity", "levels_plus", "vibrance", "colourfulness", "curves", "deband", "technicolor2", "dpx", "bleach_bypass", "noir", "technicolor", "monochrome", "sepia", "film_grain", "vignette", "cartoon", "nostalgia", "chromatic_aberration", "crop_stretch"]
                            property var bundledEffectLabels: [t.off, t.shaderEffectHdrLook, t.shaderEffectClarity, t.shaderEffectLevelsPlus, t.shaderEffectVibrance, t.shaderEffectColourfulness, t.shaderEffectCurves, t.shaderEffectDeband, t.shaderEffectTechnicolor2, t.shaderEffectDpx, t.shaderEffectBleachBypass, t.shaderEffectNoir, t.shaderEffectTechnicolor, t.shaderEffectMonochrome, t.shaderEffectSepia, t.shaderEffectFilmGrain, t.shaderEffectVignette, t.shaderEffectCartoon, t.shaderEffectNostalgia, t.shaderEffectChromaticAberration, t.shaderEffectCropStretch]

                            property var customEffects: backend.custom_shader_effects
                            property var missingIds: backend.vkbasalt_shader.split(":").filter(function(id) {
                                return id.indexOf("custom/") === 0 && !customEffects.some(function(effect) { return effect.id === id; });
                            })
                            property var effectIds: bundledEffectIds.concat(customEffects.map(function(effect) { return effect.id; }), missingIds)
                            property var effectLabels: bundledEffectLabels.concat(customEffects.map(function(effect) { return t.customShader + ": " + effect.name; }), missingIds.map(function(id) { return t.customShader + ": " + id.slice(7) + " (" + t.shaderDefinitionMissing + ")"; }))

                            Button {
                                Layout.fillWidth: true
                                text: t.shaderEffects + " (" + (backend.vkbasalt_shader === "none" ? 0 : backend.vkbasalt_shader.split(":").length) + ")"
                                onClicked: effectsDialog.open()
                            }

                            FileDialog {
                                id: customShaderPicker
                                title: t.addCustomShader
                                nameFilters: ["ReShade (*.fx)"]
                                onAccepted: backend.addCustomShader(selectedFile.toString())
                            }

                            Dialog {
                                id: effectsDialog
                                parent: Overlay.overlay
                                modal: true
                                focus: true
                                title: t.shaderEffects
                                width: Math.min(520, parent.width - 32)
                                height: Math.min(effectChoices.implicitHeight + effectDescription.implicitHeight + effectActions.implicitHeight + 124, parent.height - 32)
                                x: (parent.width - width) / 2
                                y: (parent.height - height) / 2

                                contentItem: ColumnLayout {
                                    spacing: 8

                                    Label {
                                        id: effectDescription
                                        Layout.fillWidth: true
                                        text: t.shaderEffectsDesc
                                        wrapMode: Text.WordWrap
                                    }

                                    ScrollView {
                                        id: effectsScroll
                                        Layout.fillWidth: true
                                        Layout.fillHeight: true
                                        contentWidth: availableWidth
                                        contentHeight: effectChoices.implicitHeight
                                        clip: true
                                        ScrollBar.vertical.policy: ScrollBar.AsNeeded

                                        GridLayout {
                                            id: effectChoices
                                            width: effectsScroll.availableWidth
                                            height: implicitHeight
                                            columns: width >= 460 ? 2 : 1
                                            columnSpacing: 12
                                            rowSpacing: 0

                                            Repeater {
                                                model: effectStack.effectIds.slice(1)
                                                delegate: CheckBox {
                                                    required property string modelData
                                                    Layout.fillWidth: true
                                                    text: (backend.vkbasalt_shader !== "none" && backend.vkbasalt_shader.split(":").indexOf(modelData) >= 0
                                                        ? (backend.vkbasalt_shader.split(":").indexOf(modelData) + 1) + ". " : "")
                                                        + effectStack.effectLabels[effectStack.effectIds.indexOf(modelData)]
                                                    checked: backend.vkbasalt_shader !== "none" && backend.vkbasalt_shader.split(":").indexOf(modelData) >= 0
                                                    onToggled: {
                                                        const current = backend.vkbasalt_shader === "none" ? [] : backend.vkbasalt_shader.split(":")
                                                        const next = checked ? current.concat(modelData) : current.filter(effect => effect !== modelData)
                                                        backend.vkbasalt_shader = next.length ? next.join(":") : "none"
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    RowLayout {
                                        id: effectActions
                                        Layout.fillWidth: true
                                        Layout.topMargin: 4

                                        Button {
                                            text: t.off
                                            onClicked: backend.vkbasalt_shader = "none"
                                        }
                                        Item { Layout.fillWidth: true }
                                        Button {
                                            text: t.close
                                            onClicked: effectsDialog.close()
                                        }
                                    }
                                }
                            }
                        }
                    }

                    ColumnLayout {
                        Layout.fillWidth: true
                        visible: backend.enable_vkbasalt
                        spacing: 8

                        ShaderActionButton {
                            text: t.shaderEditorTitle
                            enabled: backend.vkbasalt_shader !== "none"
                            onClicked: { shaderEditor.profileName = backend.shader_profile_name; shaderEditor.openEditor() }
                        }
                        RowLayout {
                            Layout.fillWidth: true
                            spacing: 8
                            ShaderActionButton {
                                Layout.preferredWidth: 1
                                Layout.fillHeight: true
                                text: t.addCustomShader
                                onClicked: customShaderPicker.open()
                            }
                            ShaderActionButton {
                                Layout.preferredWidth: 1
                                Layout.fillHeight: true
                                text: t.refreshCustomShaders
                                onClicked: backend.refreshCustomShaders()
                            }
                        }
                        ShaderActionButton {
                            text: t.deleteSelectedCustomShaders
                            enabled: backend.vkbasalt_shader.split(":").some(function(id) { return id.indexOf("custom/") === 0; })
                            opacity: enabled ? 1.0 : 0.45
                            palette.button: "#64253a"
                            palette.buttonText: "#fff0f5"
                            onClicked: backend.deleteSelectedCustomShaders()
                        }
                        Label {
                            Layout.fillWidth: true
                            text: t.customShaderHelp
                            wrapMode: Text.WordWrap
                            font.pixelSize: 10
                            color: Qt.rgba(palette.text.r, palette.text.g, palette.text.b, 0.7)
                        }
                        Label {
                            Layout.fillWidth: true
                            visible: backend.shader_load_error.length > 0
                            text: backend.shader_load_error
                            wrapMode: Text.WordWrap
                        }
                    }

                    GroupEntry {
                        title: t.shaderSharpening
                        description: t.shaderSharpeningDesc
                        visible: backend.enable_vkbasalt

                        ComboBox {
                            Layout.fillWidth: true
                            model: [t.off, "CAS", "DLS"]
                            currentIndex: ["none", "cas", "dls"].indexOf(backend.vkbasalt_sharpening)
                            onActivated: index => backend.vkbasalt_sharpening = ["none", "cas", "dls"][index]
                        }
                    }

                    GroupEntry {
                        title: t.shaderSharpness
                        description: t.shaderSharpnessDesc
                        visible: backend.enable_vkbasalt && backend.vkbasalt_sharpening !== "none"

                        FlowSlider {
                            Layout.fillWidth: true
                            from: backend.minimum_vkbasalt_strength
                            to: backend.maximum_vkbasalt_strength
                            value: backend.vkbasalt_sharpness
                            onUpdate: value => backend.vkbasalt_sharpness = value
                        }
                    }

                    GroupEntry {
                        title: t.shaderDlsDenoise
                        description: t.shaderDlsDenoiseDesc
                        visible: backend.enable_vkbasalt && backend.vkbasalt_sharpening === "dls"

                        FlowSlider {
                            Layout.fillWidth: true
                            from: backend.minimum_vkbasalt_strength
                            to: backend.maximum_vkbasalt_strength
                            value: backend.vkbasalt_dls_denoise
                            onUpdate: value => backend.vkbasalt_dls_denoise = value
                        }
                    }

                    GroupEntry {
                        title: t.shaderAntialiasing
                        description: t.shaderAntialiasingDesc
                        visible: backend.enable_vkbasalt

                        ComboBox {
                            Layout.fillWidth: true
                            model: [t.off, "FXAA", "SMAA"]
                            currentIndex: ["none", "fxaa", "smaa"].indexOf(backend.vkbasalt_antialiasing)
                            onActivated: index => backend.vkbasalt_antialiasing = ["none", "fxaa", "smaa"][index]
                        }
                    }

                    Label {
                        Layout.fillWidth: true
                        visible: backend.enable_vkbasalt
                        wrapMode: Text.Wrap
                        text: t.shaderAdvancedNote
                        color: Qt.rgba(palette.text.r, palette.text.g, palette.text.b, 0.7)
                    }

                    Button {
                        Layout.fillWidth: true
                        visible: backend.enable_vkbasalt
                        flat: true
                        onClicked: backend.openVkBasaltConfig()

                        contentItem: Label {
                            text: backend.vkbasalt_config_path
                            color: palette.link
                            font.underline: true
                            wrapMode: Text.WrapAnywhere
                            horizontalAlignment: Text.AlignLeft
                            verticalAlignment: Text.AlignVCenter
                        }
                    }
                }

                Group {
                    name: t.performanceSettings
                    enabled: backend.available

                    GroupEntry {
                        title: t.disableSteamOverlay
                        description: t.disableSteamOverlayDesc
                        compactRestartMarker: true

                        CheckBox {
                            Layout.alignment: Qt.AlignRight
                            checked: backend.disable_steam_overlay
                            onToggled: backend.disable_steam_overlay = checked
                        }
                    }

                    GroupEntry {
                        title: t.ultraPerformance
                        description: t.ultraPerformanceDesc
                        compactRestartMarker: true

                        CheckBox {
                            Layout.alignment: Qt.AlignRight

                            checked: backend.ultra_performance
                            onToggled: backend.ultra_performance = checked
                        }
                    }

                    GroupEntry {
                        title: t.flowScale
                        description: t.flowScaleDesc
                        visible: backend.frame_generation_provisioned
                        enabled: !backend.ultra_performance

                        FlowSlider {
                            Layout.fillWidth: true

                            from: backend.minimum_flow_scale
                            to: backend.maximum_flow_scale

                            value: backend.flow_scale
                            onUpdate: value => backend.flow_scale = value
                        }
                    }

                    GroupEntry {
                        title: t.gpuHeadroom
                        description: t.gpuHeadroomDesc
                        CheckBox {
                            Layout.alignment: Qt.AlignRight
                            checked: backend.gpu_headroom_percent > 0
                            onToggled: backend.gpu_headroom_percent = checked ? 10 : 0
                        }
                    }
                    GroupEntry {
                        title: t.gpuHeadroomReserve
                        description: t.gpuHeadroomTradeoff
                        visible: backend.gpu_headroom_percent > 0
                        ComboBox {
                            Layout.fillWidth: true
                            property var values: backend.gpu_headroom_presets.slice(1)
                            model: values.map(value => value + "%")
                            currentIndex: values.indexOf(backend.gpu_headroom_percent)
                            onActivated: index => backend.gpu_headroom_percent = values[index]
                        }
                    }

                }

                Group {
                    name: t.compatibilitySettings
                    enabled: backend.available

                    GroupEntry {
                        title: t.gameSwapchainImages
                        description: t.gameSwapchainImagesDesc + "\n\n" + t.gameSwapchainImagesWarning
                        compactRestartMarker: true

                        CheckBox {
                            Layout.alignment: Qt.AlignRight

                            checked: backend.swapchain_image_count_compatibility
                            onToggled: backend.swapchain_image_count_compatibility = checked
                        }
                    }

                    GroupEntry {
                        title: t.refreshRateGuard
                        description: t.refreshRateGuardDesc

                        CheckBox {
                            Layout.alignment: Qt.AlignRight

                            checked: backend.frame_generation_refresh_threshold > 0
                            onToggled: backend.frame_generation_refresh_threshold = checked
                                ? backend.frame_generation_refresh_threshold_preset
                                : 0
                        }
                    }

                    GroupEntry {
                        visible: backend.frame_generation_refresh_threshold > 0
                        title: t.refreshRateThreshold
                        description: t.refreshRateThresholdDesc

                        SpinBox {
                            Layout.alignment: Qt.AlignRight
                            from: 1
                            to: backend.maximum_frame_generation_refresh_threshold
                            editable: true

                            value: backend.frame_generation_refresh_threshold
                            textFromValue: function (value) {
                                return value + " Hz";
                            }
                            valueFromText: function (text) {
                                var parsed = parseInt(text);
                                return isNaN(parsed) ? 1 : Math.max(
                                    1,
                                    Math.min(
                                        backend.maximum_frame_generation_refresh_threshold,
                                        parsed
                                    )
                                );
                            }
                            onValueModified: backend.frame_generation_refresh_threshold = value
                        }
                    }

                    GroupEntry {
                        title: t.dynamicCadence
                        description: t.dynamicCadenceDesc

                        CheckBox {
                            Layout.alignment: Qt.AlignRight

                            checked: backend.dynamic_cadence_recovery
                            onToggled: backend.dynamic_cadence_recovery = checked
                        }
                    }

                    GroupEntry {
                        visible: backend.dynamic_cadence_recovery
                        title: t.dynamicCadenceProbeInterval
                        description: t.dynamicCadenceProbeIntervalDesc

                        ComboBox {
                            id: dynamic_cadence_probe_interval
                            Layout.fillWidth: true
                            model: backend.dynamic_cadence_probe_interval_presets_seconds
                            currentIndex: {
                                for (let index = 0; index < model.length; ++index) {
                                    if (Math.abs(Number(model[index]) - backend.dynamic_cadence_probe_interval_seconds) < 0.001)
                                        return index
                                }
                                return -1
                            }
                            displayText: currentIndex >= 0 ? Number(Number(model[currentIndex]).toFixed(2)) + t.secondsSuffix : Number(backend.dynamic_cadence_probe_interval_seconds.toFixed(2)) + t.secondsSuffix
                            onActivated: backend.dynamic_cadence_probe_interval_seconds = Number(model[index])
                        }
                    }
                }

                Group {
                    name: t.externalTools
                    objectName: "externalToolsGroup"

                    GroupEntry {
                        title: t.enableMangoHud
                        description: t.enableMangoHudDesc
                        compactRestartMarker: true

                        CheckBox {
                            objectName: "enableMangoHud"
                            Layout.alignment: Qt.AlignRight
                            enabled: backend.available && !backend.mangohud_checking &&
                                     (backend.mangohud_available || backend.enable_mangohud)
                            checked: backend.enable_mangohud
                            onToggled: backend.enable_mangohud = checked
                        }
                    }
                    Label {
                        Layout.fillWidth: true
                        wrapMode: Text.Wrap
                        text: t.mangoHudLaunchHelp
                        color: Qt.rgba(palette.text.r, palette.text.g, palette.text.b, 0.7)
                    }
                    Label {
                        visible: !backend.mangohud_available
                        Layout.fillWidth: true
                        wrapMode: Text.Wrap
                        text: backend.mangohud_checking ? t.mangoHudChecking : t.mangoHudUnavailable
                    }
                    ShaderActionButton {
                        text: t.refreshMangoHud
                        enabled: !backend.mangohud_checking
                        onClicked: backend.refreshMangoHud()
                    }
                }

                Group {
                    name: t.standaloneLaunchSettings

                    GroupEntry {
                        title: t.enableHdr
                        description: t.enableHdrDesc
                        experimentalLabel: t.experimentalLabel
                        compactRestartMarker: true

                        CheckBox {
                            Layout.alignment: Qt.AlignRight
                            checked: backend.enable_hdr
                            onToggled: backend.enable_hdr = checked
                        }
                    }

                    GroupEntry {
                        visible: backend.enable_hdr
                        title: t.hdrQuality
                        description: t.hdrQualityDesc

                        ComboBox {
                            Layout.alignment: Qt.AlignRight
                            model: [t.hdrQualityQuality, t.hdrQualityBalanced, t.hdrQualityPerformance]
                            property var values: ["quality", "balanced", "performance"]
                            currentIndex: values.indexOf(backend.hdr_quality)
                            onActivated: backend.hdr_quality = values[index]
                        }
                    }

                    Label {
                        Layout.fillWidth: true
                        wrapMode: Text.Wrap
                        text: t.standaloneLaunchDesc
                        color: Qt.rgba(palette.text.r, palette.text.g, palette.text.b, 0.7)
                    }

                    GroupEntry {
                        title: t.enableZink
                        description: t.enableZinkDesc
                        compactRestartMarker: true

                        CheckBox {
                            Layout.alignment: Qt.AlignRight
                            checked: backend.enable_zink
                            onToggled: backend.enable_zink = checked
                        }
                    }

                    GroupEntry {
                        title: t.forceAlsaAudio
                        description: t.forceAlsaAudioDesc
                        compactRestartMarker: true

                        CheckBox {
                            Layout.alignment: Qt.AlignRight
                            checked: backend.force_alsa_audio
                            onToggled: backend.force_alsa_audio = checked
                        }
                    }
                }

                Group {
                    name: t.remotePlay
                    objectName: "remotePlayGroup"
                    RowLayout {
                        Layout.fillWidth: true
                        spacing: 8
                        ShaderActionButton {
                            Layout.preferredWidth: 1
                            text: backend.remote_play_managed ? t.restoreSteamClient : t.overrideRemotePlay
                            Layout.fillHeight: true
                            enabled: !backend.remote_play_busy && !backend.remote_play_running &&
                                     (backend.remote_play_managed || backend.remote_play_available)
                            onClicked: backend.setRemotePlayOverride(!backend.remote_play_managed)
                        }
                        ShaderActionButton {
                            Layout.preferredWidth: 1
                            text: t.refreshRemotePlay
                            Layout.fillHeight: true
                            enabled: !backend.remote_play_busy
                            onClicked: backend.refreshRemotePlay()
                        }
                    }
                    Label {
                        Layout.fillWidth: true
                        wrapMode: Text.WordWrap
                        text: t.remotePlayDesc
                        font.pixelSize: 12
                        color: Qt.rgba(palette.text.r, palette.text.g, palette.text.b, 0.7)
                    }
                    Rectangle {
                        id: remoteStatus
                        objectName: "remotePlayStatus"
                        property bool attention: !backend.remote_play_busy && backend.remote_play_message.length > 0
                        property string stateText: backend.remote_play_busy ? t.remotePlayWorking :
                            attention ? t.remotePlayAttention :
                            backend.remote_play_running ? t.remotePlayRunning :
                            backend.remote_play_installed ? t.remotePlayEnabled :
                            !backend.remote_play_available ? t.remotePlayUnavailable : t.remotePlayDisabled
                        property color indicatorColor: attention || (!backend.remote_play_busy && !backend.remote_play_available) ? "#f4a259" :
                            backend.remote_play_busy || backend.remote_play_running || backend.remote_play_installed ? "#83bff0" : "#738891"
                        Layout.fillWidth: true
                        implicitHeight: remoteStatusContent.implicitHeight + 20
                        color: palette.base
                        border.color: palette.mid
                        radius: 4

                        ColumnLayout {
                            id: remoteStatusContent
                            anchors.fill: parent
                            anchors.margins: 10
                            spacing: 8
                            RowLayout {
                                Layout.fillWidth: true
                                spacing: 8
                                Rectangle {
                                    width: 7
                                    height: 7
                                    radius: 3.5
                                    color: remoteStatus.indicatorColor
                                }
                                ColumnLayout {
                                    Layout.fillWidth: true
                                    spacing: 3
                                    Label {
                                        text: t.remotePlayStatus
                                        font.pixelSize: 11
                                        color: Qt.rgba(palette.text.r, palette.text.g, palette.text.b, 0.6)
                                    }
                                    Label {
                                        Layout.fillWidth: true
                                        text: remoteStatus.stateText
                                        font.pixelSize: 12
                                        wrapMode: Text.WordWrap
                                    }
                                }
                            }
                            Rectangle {
                                Layout.fillWidth: true
                                implicitHeight: 1
                                color: palette.mid
                                visible: remoteStatus.attention
                            }
                            Label {
                                Layout.fillWidth: true
                                text: backend.remote_play_message
                                textFormat: Text.PlainText
                                font.pixelSize: 12
                                wrapMode: Text.Wrap
                                color: "#f4a259"
                                visible: remoteStatus.attention
                            }
                        }
                    }
                }

                Group {
                    name: t.deckyIntegration

                    Label {
                        Layout.fillWidth: true
                        wrapMode: Text.WordWrap
                        text: t.deckyDesc
                        color: Qt.rgba(palette.text.r, palette.text.g, palette.text.b, 0.7)
                    }
                }

                Group {
                    name: t.interfaceSettings

                    GroupEntry {
                        title: t.language
                        description: t.languageDesc

                        ComboBox {
                            Layout.fillWidth: true

                            model: localization.language_names
                            currentIndex: localization.language_index
                            onActivated: index => localization.language_index = index
                        }
                    }
                }
            }
        }
    }
}
