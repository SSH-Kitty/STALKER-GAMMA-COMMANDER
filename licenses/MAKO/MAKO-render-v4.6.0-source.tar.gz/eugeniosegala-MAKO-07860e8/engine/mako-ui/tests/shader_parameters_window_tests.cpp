/* SPDX-License-Identifier: GPL-3.0-or-later */
#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QQuickWindow>
#include <QQuickItem>
#include <QJsonDocument>
#include <QJsonArray>
#include <QTimer>
#include <QPointer>
#include <iostream>
#include <stdexcept>

class ShaderBackendFixture : public QObject {
    Q_OBJECT
    Q_PROPERTY(bool shader_parameters_loading READ loading NOTIFY shaderParametersChanged)
    Q_PROPERTY(QString shader_parameter_error READ error NOTIFY shaderParametersChanged)
    Q_PROPERTY(QVariantList shader_parameter_effects READ effects NOTIFY shaderParametersChanged)
public:
    bool fail = false;
    bool noParameters = false;
    bool palette = false;
    int saves = 0;
    QVariantMap last;
    bool loading() const { return false; }
    QString error() const { return fail ? QStringLiteral("disk full") : QString(); }
    QVariantList effects() const {
        if (noParameters) return {};
        auto result = QJsonDocument::fromJson(R"JSON([{"id":"Tone","name":"Tone","error":null,"parameters":[
        {"key":"strength","label":"Strength","description":"Effect intensity","category":"Colour","type":"float","min":0,"max":1,"step":0.01,"value":0.5,"default":0.25,"items":[]},
        {"key":"gamma","label":"Gamma","description":"Midtones","category":"Colour","type":"float","min":0.5,"max":2,"step":null,"value":1.05499995,"default":1,"items":[]},
        {"key":"mode","label":"Mode","description":"","category":"","type":"int","min":null,"max":null,"step":null,"value":0,"default":0,"items":["Soft","Strong"]},
        {"key":"dither","label":"Dithering","description":"Reduce colour banding","category":"","type":"bool","min":null,"max":null,"step":null,"value":1,"default":1,"items":[]}
        ]}])JSON").array().toVariantList();
        auto effect = result[0].toMap();
        auto parameters = effect["parameters"].toList();
        for (int component = 0; component < 4; ++component) {
            const QString base = QStringLiteral("makoShader_41_436f6c6f7572_");
            parameters.append(QVariantMap{{"key", base + QString::number(component)}, {"label", QStringLiteral("Border colour [%1]").arg(component + 1)}, {"description", "Authored colour help"}, {"category", "Colour"}, {"type", "float"}, {"value", component == 2 ? 1.5 : .123456789}, {"default", 0.0}, {"resettable", component != 3}, {"min", QVariant()}, {"max", QVariant()}, {"step", QVariant()}, {"items", QVariantList()}, {"presentation", QVariantMap{{"widget", "color"}, {"group", base + "0"}, {"label", "Border colour"}, {"count", 4}, {"component", component}}}});
        }
        if (palette) for (int color = 0; color < 16; ++color) {
            const auto name = QStringLiteral("Color %1").arg(color);
            const auto base = QStringLiteral("makoShader_41_") + QString::fromLatin1(name.toUtf8().toHex()) + "_";
            for (int component = 0; component < 3; ++component)
                parameters.append(QVariantMap{{"key", base + QString::number(component)}, {"label", name + QStringLiteral(" [%1]").arg(component + 1)}, {"description", ""}, {"category", "Custom palette"}, {"type", "float"}, {"value", component == 2 ? 1.5 : .123456789}, {"default", 0.0}, {"resettable", color != 15 || component != 2}, {"min", QVariant()}, {"max", QVariant()}, {"step", QVariant()}, {"items", QVariantList()}, {"presentation", QVariantMap{{"widget", "color"}, {"group", base + "0"}, {"label", name}, {"count", 3}, {"component", component}}}});
        }
        effect["parameters"] = parameters;
        result[0] = effect;
        return result;
    }
    Q_INVOKABLE void loadShaderParameters() { emit shaderParametersChanged(); }
    Q_INVOKABLE bool setShaderParameters(const QVariantMap& changes) { ++saves; last = changes; emit shaderParametersChanged(); return !fail; }
signals:
    void shaderParametersChanged();
};
static void require(bool value, const char* message) { if (!value) throw std::runtime_error(message); }
int main(int argc, char** argv) {
    QGuiApplication application(argc, argv);
    ShaderBackendFixture backend;
    QQmlApplicationEngine engine;
    engine.rootContext()->setContextProperty(QStringLiteral("backend"), &backend);
    const auto directory = QUrl::fromLocalFile(QString::fromUtf8(MAKO_UI_DIALOGS_DIRECTORY)).toString();
    try {
        engine.loadData((QStringLiteral(R"QML(
import QtQuick
import QtQuick.Controls
import ")QML") + directory + QStringLiteral(R"QML("
ApplicationWindow {
    id: main
    width: 700; height: 400; visible: true
    ShaderParametersWindow {
        id: editor
        objectName: "editor"
        owner: main
        strings: ({shaderEditorTitle:"Customize shaders",shaderEditorLive:"Saved to this profile and applied live.",shaderEditorHide:"Hide controls",shaderEditorShow:"Show controls",shaderEditorClose:"Close",shaderEditorLoading:"Reading shader options...",shaderEditorEmpty:"No editable parameters",shaderEditorReset:"Reset shader to defaults",shaderEditorRetry:"Retry save",shaderEditorDiscard:"Discard unsaved changes",shaderEditorRed:"Red",shaderEditorGreen:"Green",shaderEditorBlue:"Blue",shaderEditorAlpha:"Alpha",shaderEditorColorPreview:"Colour preview",shaderEditorColorRange:"Preview is limited to 0–1. Exact values are preserved."})
    }
    Component.onCompleted: editor.openEditor()
})QML")).toUtf8());
        require(!engine.rootObjects().empty(), "cannot load shader editor");
        auto* owner = engine.rootObjects().front();
        auto* editor = owner->findChild<QQuickWindow*>(QStringLiteral("editor"));
        require(editor && editor->isVisible(), "editor did not open");
        require(!owner->property("visible").toBool(), "configuration window still obscures the game");
        require(editor->width() <= 360, "shader editor is too wide");
        QVariantMap values{{QStringLiteral("strength"), 0.8}};
        require(QMetaObject::invokeMethod(editor,"setValues",Q_ARG(QVariant,QVariant(values))), "cannot adjust shader value");
        backend.fail = true;
        editor->close();
        require(editor->isVisible() && backend.saves == 1, "failed save incorrectly closed editor");
        backend.fail = false;
        editor->close();
        require(!editor->isVisible() && owner->property("visible").toBool() && backend.saves == 2 && backend.last == values, "close did not retry pending values and restore main window");
        QMetaObject::invokeMethod(editor,"openEditor");
        const auto findNamed = [](auto&& find, QQuickItem* item, const QString& name) -> QQuickItem* {
            if (item->objectName() == name) return item;
            for (auto* child : item->childItems())
                if (auto* result = find(find, child, name)) return result;
            return nullptr;
        };
        const auto findInput = [&](auto&&, QQuickItem* item) { return findNamed(findNamed, item, QStringLiteral("shader-parameter-strength")); };
        auto* gamma = findNamed(findNamed, editor->contentItem(), QStringLiteral("shader-parameter-gamma"));
        auto* gammaSlider = findNamed(findNamed, editor->contentItem(), QStringLiteral("shader-slider-gamma"));
        require(gamma && gammaSlider && gamma->property("text").toString() == "1.055", "Gamma exposes FP32 readback noise");
        require(gammaSlider->property("stepSize").toDouble() == .01 && gammaSlider->property("snapMode").toInt() == 1, "Gamma slider does not snap to hundredths");
        require(QMetaObject::invokeMethod(gamma, "commitValue"), "cannot commit unchanged Gamma");
        require(editor->property("pending").toMap().empty(), "normalized display saved an untouched value");
        gammaSlider->setProperty("value", 1.0499999999999998);
        require(QMetaObject::invokeMethod(gammaSlider, "moved"), "cannot adjust Gamma slider");
        require(editor->property("pending").toMap().value("gamma").toDouble() == 1.05, "Gamma slider saved an arithmetic tail");
        gamma->setProperty("text", QStringLiteral("1.05789"));
        QMetaObject::invokeMethod(gamma, "commitValue");
        require(editor->property("pending").toMap().value("gamma").toDouble() == 1.05789, "exact Gamma input snapped to the slider step");
        editor->close();
        const auto savesAfterGamma = backend.saves;
        QMetaObject::invokeMethod(editor,"openEditor");
        gamma = findNamed(findNamed, editor->contentItem(), QStringLiteral("shader-parameter-gamma"));
        gamma->forceActiveFocus();
        editor->close();
        require(backend.saves == savesAfterGamma, "closing an untouched normalized field saved a change");
        QMetaObject::invokeMethod(editor,"openEditor");
        auto* red = findNamed(findNamed, editor->contentItem(), QStringLiteral("shader-parameter-makoShader_41_436f6c6f7572_0"));
        auto* blue = findNamed(findNamed, editor->contentItem(), QStringLiteral("shader-parameter-makoShader_41_436f6c6f7572_2"));
        auto* swatch = findNamed(findNamed, editor->contentItem(), QStringLiteral("shader-color-preview-makoShader_41_436f6c6f7572_0"));
        require(red && blue && swatch && swatch->isVisible(), "declared colour did not create channel controls and a preview");
        require(red->parentItem()->property("label").toString() == "Red" && blue->parentItem()->property("label").toString() == "Blue", "colour channel labels are incorrect");
        require(red->property("text").toString() == "0.123456789" && blue->property("text").toString() == "1.5", "colour presentation rounded or clamped exact values");
        const auto savesBeforeColour = backend.saves;
        require(editor->property("pending").toMap().empty(), "opening colour controls changed saved values");
        red->forceActiveFocus();
        red->setProperty("text", QStringLiteral("0.456789123"));
        editor->close();
        require(backend.saves == savesBeforeColour + 1 && backend.last.size() == 1 && backend.last.value("makoShader_41_436f6c6f7572_0").toDouble() == .456789123, "colour edit did not preserve the exact value or changed another channel");
        QMetaObject::invokeMethod(editor,"openEditor");
        red = findNamed(findNamed, editor->contentItem(), QStringLiteral("shader-parameter-makoShader_41_436f6c6f7572_0"));
        red->forceActiveFocus(); red->setProperty("text", QStringLiteral("0.8"));
        QMetaObject::invokeMethod(editor, "resetEffect");
        const auto reset = editor->property("pending").toMap();
        require(reset.value("makoShader_41_436f6c6f7572_0").isNull() && !reset.contains("makoShader_41_436f6c6f7572_3"), "Qt reset lost to the focused draft or reset a protected parameter");
        editor->close();
        QMetaObject::invokeMethod(editor,"openEditor");
        auto* input = findInput(findInput, editor->contentItem());
        require(input != nullptr, "numeric shader control was not created");
        input->forceActiveFocus();
        input->setProperty("text", QStringLiteral("0.65"));
        QPointer<QQuickItem> draftControl(input);
        QMetaObject::invokeMethod(editor,"setValues",Q_ARG(QVariant,QVariant(QVariantMap{{QStringLiteral("mode"), 1}})));
        QMetaObject::invokeMethod(editor,"flush");
        require(draftControl && draftControl->property("text").toString() == QStringLiteral("0.65"), "saving another option replaced the focused draft");
        editor->close();
        require(backend.last.value(QStringLiteral("strength")).toDouble() == 0.65, "closing lost the focused numeric draft");
        QMetaObject::invokeMethod(editor,"openEditor");
        input = findInput(findInput, editor->contentItem());
        input->forceActiveFocus();
        input->setProperty("text", QStringLiteral("0.7"));
        const auto expanded = editor->height();
        editor->setProperty("preview", true);
        QCoreApplication::processEvents();
        require(editor->height() < expanded, "preview did not collapse the editor");
        require(editor->property("pending").toMap().value(QStringLiteral("strength")).toDouble() == 0.7, "hiding controls lost the focused draft");
        editor->setProperty("preview", false);
        QCoreApplication::processEvents();
        require(editor->height() == expanded, "controls did not restore the editor size");
        editor->close();
        QMetaObject::invokeMethod(editor,"openEditor");
        input = findInput(findInput, editor->contentItem());
        input->forceActiveFocus();
        input->setProperty("text", QStringLiteral("0.8"));
        backend.fail = true;
        editor->close();
        const auto savesBeforeDiscard = backend.saves;
        require(editor->isVisible(), "failed save closed the editor before discard");
        input->setProperty("text", QStringLiteral("0.9"));
        QMetaObject::invokeMethod(editor,"discardAndClose");
        require(!editor->isVisible() && backend.saves == savesBeforeDiscard, "discard retried the focused unsaved draft");
        backend.noParameters = true;
        QMetaObject::invokeMethod(editor,"openEditor");
        QCoreApplication::processEvents();
        auto* empty = findNamed(findNamed, editor->contentItem(), QStringLiteral("shader-editor-empty"));
        require(empty && !empty->isVisible(), "discovery failure incorrectly claimed there were no editable parameters");
        editor->close();
        backend.fail = false;
        QMetaObject::invokeMethod(editor,"openEditor");
        QCoreApplication::processEvents();
        require(empty->isVisible(), "successful empty discovery lost its message");
        editor->close();
        backend.noParameters = false;
        QMetaObject::invokeMethod(editor,"openEditor");
        auto* scrollView = findNamed(findNamed, editor->contentItem(), QStringLiteral("shader-editor-scroll"));
        auto* controls = findNamed(findNamed, editor->contentItem(), QStringLiteral("shader-editor-controls"));
        auto* scrollBar = findNamed(findNamed, editor->contentItem(), QStringLiteral("shader-editor-scrollbar"));
        auto* resetButton = findNamed(findNamed, editor->contentItem(), QStringLiteral("shader-editor-reset"));
        require(scrollView && controls && scrollBar && resetButton, "shader scroll layout is missing");
        for (const auto size : {QSize(280, 360), QSize(360, 650)}) {
            editor->resize(size);
            QCoreApplication::processEvents();
            // Layout polish can schedule another pass after a wrapped label changes height.
            QCoreApplication::processEvents();
            const auto contentOrigin = controls->mapToItem(scrollView, QPointF());
            const auto barOrigin = scrollBar->mapToItem(scrollView, QPointF());
            require(contentOrigin.x() >= 12, "shader controls lost their left inset");
            require(barOrigin.x() - (contentOrigin.x() + controls->width()) >= 8, "shader controls overlap the scrollbar lane");
            require(scrollView->width() - (barOrigin.x() + scrollBar->width()) >= 12, "shader scrollbar touches the outer border");
            require(barOrigin.y() >= 12 && scrollView->height() - barOrigin.y() - scrollBar->height() >= 12, "shader scrollbar lost its vertical insets");
            require(controls->width() <= scrollView->property("availableWidth").toReal(), "shader controls overflow horizontally");
            const auto barSize = scrollBar->property("size").toReal();
            require(barSize > 0 && barSize < 1, "long shader controls are not scrollable");
            scrollBar->setProperty("position", 1 - barSize);
            QCoreApplication::processEvents();
            const auto resetOrigin = resetButton->mapToItem(scrollView, QPointF());
            require(resetOrigin.y() >= 12 && resetOrigin.y() + resetButton->height() <= scrollView->height() - 11.5, "scrolling cannot reveal Reset inside the frame");
            scrollBar->setProperty("position", 0);
        }
        editor->close();
        backend.palette = true;
        QMetaObject::invokeMethod(editor, "openEditor");
        QCoreApplication::processEvents();
        const auto paletteKey = [](int color, int component) {
            return QStringLiteral("makoShader_41_") + QString::fromLatin1(QStringLiteral("Color %1").arg(color).toUtf8().toHex()) + "_" + QString::number(component);
        };
        const auto paletteInput = [&](int color, int component) {
            return findNamed(findNamed, editor->contentItem(), "shader-parameter-" + paletteKey(color, component));
        };
        const auto paletteButton = [&](int color) {
            return findNamed(findNamed, editor->contentItem(), "shader-color-swatch-" + paletteKey(color, 0));
        };
        for (int color = 0; color < 16; ++color)
            require(paletteButton(color), "palette is missing a colour swatch");
        require(paletteInput(0, 0) && !paletteInput(15, 0), "palette did not limit controls to the selected colour");
        auto* lastSwatch = paletteButton(15);
        const auto savesBeforePalette = backend.saves;
        lastSwatch->forceActiveFocus();
        require(paletteInput(0, 0) && !paletteInput(15, 0) && backend.saves == savesBeforePalette, "focusing a swatch selected or saved a colour");
        auto* paletteRed = paletteInput(0, 0);
        paletteRed->forceActiveFocus();
        paletteRed->setProperty("text", QStringLiteral("0.345678912"));
        require(QMetaObject::invokeMethod(lastSwatch, "clicked"), "cannot select a palette colour");
        QCoreApplication::processEvents();
        require(!paletteInput(0, 0) && paletteInput(15, 0), "palette selection did not replace channel controls");
        require(lastSwatch->property("checked").toBool() && !paletteButton(0)->property("checked").toBool(), "palette selection marker is stale");
        require(editor->property("pending").toMap().value(paletteKey(0, 0)).toDouble() == .345678912, "switching palette colours lost the focused exact draft");
        require(paletteInput(15, 2)->property("text").toString() == "1.5", "palette clamped an out-of-range colour value");
        QMetaObject::invokeMethod(paletteButton(0), "clicked");
        QCoreApplication::processEvents();
        require(paletteInput(0, 0)->property("text").toString() == "0.345678912", "returning to a palette colour lost its exact value");
        QMetaObject::invokeMethod(editor, "flush");
        require(backend.saves == savesBeforePalette + 1 && backend.last.size() == 1, "selecting palette colours changed unrelated values");
        QMetaObject::invokeMethod(editor, "resetEffect");
        const auto paletteReset = editor->property("pending").toMap();
        require(paletteReset.contains(paletteKey(14, 2)) && paletteReset.value(paletteKey(14, 2)).isNull() && !paletteReset.contains(paletteKey(15, 2)), "palette reset missed hidden colours or changed a protected channel");
        for (const auto size : {QSize(280, 360), QSize(360, 650)}) {
            editor->resize(size);
            QCoreApplication::processEvents();
            QCoreApplication::processEvents();
            for (int color = 0; color < 16; ++color) {
                auto* button = paletteButton(color);
                const auto origin = button->mapToItem(controls, QPointF());
                require(button->width() > 24 && origin.x() >= 0 && origin.x() + button->width() <= controls->width() + .5, "palette swatches overflow the narrow controls frame");
            }
        }
        editor->close();
        if (argc > 1) {
            QMetaObject::invokeMethod(editor,"openEditor");
            QTimer::singleShot(150, &application, [&] {
                const auto paletteTop = paletteButton(0)->mapToItem(controls, QPointF()).y();
                scrollBar->setProperty("position", paletteTop / controls->height());
            });
            QTimer::singleShot(250, &application, [&] { editor->grabWindow().save(QString::fromLocal8Bit(argv[1])); application.quit(); });
            return application.exec();
        }
    } catch (const std::exception& error) {
        std::cerr << "MAKO Renderer: shader editor test failed: " << error.what() << '\n'; return 1;
    }
    return 0;
}
#include "shader_parameters_window_tests.moc"
