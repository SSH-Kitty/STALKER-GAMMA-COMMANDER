/* SPDX-License-Identifier: GPL-3.0-or-later */

#pragma once

#include "generated_frame_delivery.hpp"
#include "generated_frame_plan.hpp"
#include "mako-common/configuration/config.hpp"

#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <string>
#include <string_view>

namespace mako::layer {

    struct AdaptiveGenerationLoadBaseline {
        size_t fallbackGenerationLimit{0};
        double baseFps{0.0};
    };

    /// Cadence recovery follows the presentation transport selected when the
    /// swapchain was created; it is not selected from live HDR feedback.
    ///
    /// Ordered SDR has FIFO ordering/backpressure under MAKO's control, so a
    /// discontinuity only needs a short temporal-history refresh and can keep
    /// the last multiplier that was proven stable. The Gamescope HDR bridge
    /// preserves Gamescope's lower transport and admits synthetic images
    /// opportunistically. A discontinuity there can also mean compositor or
    /// colour-pipeline pressure, so it deliberately remeasures more cautiously.
    enum class AdaptiveRecoveryPolicy : uint8_t {
        OrderedSdr,
        ConservativeHdr,
    };

    struct AdaptiveSchedulerConfig {
        uint32_t targetFps{ls::GameConfDefaults::targetFps};
        size_t maximumMultiplier{ls::GameConfDefaults::adaptiveMaxMultiplier};
        size_t generatedFrameCapacity{0};
        bool stableCadence{ls::GameConfDefaults::adaptiveStableCadence};
        bool automaticBaseFpsCap{
            ls::GameConfDefaults::adaptiveAutoBaseFpsCap
        };
        bool nearTargetNativePreference{false};
        // Fractional Automatic may qualify native output at/above target.
        // Other modes retain their existing near-target and recovery rules.
        bool qualifyTargetNativeCadence{false};
        // Derived by the presentation owner; never a persisted setting.
        bool validateIntegerPacing{false};
        bool dynamicCadenceRecovery{
            ls::GameConfDefaults::dynamicCadenceRecovery
        };
        std::chrono::milliseconds dynamicCadenceProbeInterval{
            ls::dynamicCadenceProbeIntervalDuration(
                ls::GameConfDefaults::dynamicCadenceProbeIntervalSeconds
            )
        };
        std::optional<uint32_t> displayRefreshFps;
        AdaptiveRecoveryPolicy recoveryPolicy{
            AdaptiveRecoveryPolicy::ConservativeHdr
        };
    };

    using AdaptiveFramePlan = GeneratedFramePlan;

    enum class AdaptiveSchedulerPhase : uint8_t {
        Uninitialized,
        HistoryWarmup,
        Stabilizing,
        DiscontinuityRecovery,
        RescueMeasurement,
        RearmCooldown,
        RampEvaluation,
        StableCadence,
        Active,
        NativeCadenceProbe,
        NearTargetNative,
    };

    struct AdaptiveSchedulerSnapshot {
        AdaptiveSchedulerPhase phase{AdaptiveSchedulerPhase::Uninitialized};
        size_t generationLimit{0};
        size_t validatedGenerationLimit{0};
        std::optional<size_t> stableCadenceLimit;
        bool stableCadenceEvaluationActive{false};
        size_t historyWarmupRemaining{0};
        double smoothedBaseFps{0.0};
        bool rampEvaluationActive{false};
        bool pacedLoadValidationPending{false};
        std::optional<size_t> pacedLoadRollbackGenerationLimit;
        std::optional<size_t> efficiencyProbeGenerationLimit;
        bool rearmRequired{false};
        bool discontinuityRecoveryActive{false};
        bool nativeCadenceProbeActive{false};
        bool nearTargetNativePreference{false};
        bool automaticBaseCapSuppressed{false};
        bool targetOutputClockActive{false};
        double targetOutputBudgetCreditOutputs{0.0};
        double targetOutputPhaseErrorOutputs{0.0};
        bool targetOutputDeferredBudgetOutput{false};
    };

    struct AdaptivePlanDiagnostic {
        double baseFps{0.0};
        uint32_t targetFps{0};
        size_t generatedFrames{0};
        size_t maximumGeneratedFrames{0};
        size_t configuredMaximumGeneratedFrames{0};
        bool stableCadence{false};
        bool nearTargetNativePreference{false};
        double predictedNativeIntervalRmsMilliseconds{0.0};
        double predictedFractionalIntervalRmsMilliseconds{0.0};
        std::string_view phase;
        size_t recoveryGenerationLimit{0};
        size_t consecutiveFailures{0};
        std::string_view rearmReason;
        std::chrono::steady_clock::duration rearmCooldownRemaining{};
        double rearmBaselineBaseFps{0.0};
        bool targetOutputClockActive{false};
        double targetOutputBudgetCreditOutputs{0.0};
        double targetOutputPhaseErrorMilliseconds{0.0};
        bool targetOutputDeferredBudgetOutput{false};
        size_t pacingSourceSamples{0};
        double sourceIntervalMeanMilliseconds{0.0};
        double sourceIntervalStdDevMilliseconds{0.0};
        double sourceIntervalP95Milliseconds{0.0};
        double sourceIntervalP99Milliseconds{0.0};
        size_t generatedCountChanges{0};
        size_t requestedIntervalSamples{0};
        double requestedIntervalMeanMilliseconds{0.0};
        double requestedIntervalStdDevMilliseconds{0.0};
        double requestedIntervalP95Milliseconds{0.0};
        double requestedIntervalP99Milliseconds{0.0};
        size_t targetPhaseErrorSamples{0};
        double targetPhaseErrorRmsMilliseconds{0.0};
        double targetPhaseErrorMaximumMilliseconds{0.0};
    };

    class AdaptiveSchedulerDiagnostics {
    public:
        virtual ~AdaptiveSchedulerDiagnostics() = default;

        [[nodiscard]] virtual bool enabled() const { return false; }
        virtual void plan(const AdaptivePlanDiagnostic&) {}
        virtual void stabilization(std::string_view,
            std::chrono::steady_clock::duration) {}
        virtual void ramp(size_t, size_t, double) {}
        virtual void rampResult(bool, size_t, size_t, double, double,
            double, double, std::string_view = {}) {}
        virtual void probeAborted(std::string_view, size_t) {}
        virtual void rearm(std::string_view, std::string_view, size_t, size_t,
            std::chrono::steady_clock::duration, double, double = 0.0,
            std::string_view = {}) {}
        virtual void fastCadenceBurst(double, double, double, size_t, size_t,
            std::chrono::steady_clock::duration) {}
        virtual void fastCadenceBurstComplete(size_t,
            std::chrono::steady_clock::duration) {}
        virtual void rampBackoff(size_t, size_t, double,
            std::chrono::steady_clock::duration) {}
        virtual void targetConstrained(uint32_t, size_t, double, double) {}
        virtual void recoveryResume(size_t,
            std::chrono::steady_clock::duration, std::string_view) {}
        virtual void stableCadence(std::string_view, size_t, double, double,
            std::string_view = {}) {}
        virtual void rescueStart(size_t, double, double, double,
            std::string_view = "stable-cadence-collapse") {}
        virtual void rescueComplete(size_t, size_t, size_t, size_t, double,
            double, std::string_view) {}
        virtual void discontinuityRecoveryStart(size_t, double,
            std::string_view, std::chrono::steady_clock::duration) {}
        virtual void discontinuityRecoveryComplete(size_t, double, double,
            std::string_view) {}
        virtual void cadenceRefresh(std::string_view, size_t, size_t) {}
        virtual void automaticBaseCapSuppressed(size_t, double, double,
            std::string_view) {}
        virtual void automaticBaseCapRestored(size_t, double, double,
            std::string_view) {}
        virtual void nativeCadenceProbe(std::string_view, size_t, double,
            double, size_t) {}
        virtual void nearTargetNativePreference(std::string_view, uint32_t,
            double, double, double, std::chrono::steady_clock::duration,
            std::string_view) {}
    };

    /// Pure adaptive frame-generation policy.
    ///
    /// All time enters through method arguments. The scheduler owns no Vulkan
    /// resources and performs no wall-clock reads, which makes a recorded frame
    /// cadence exactly replayable in unit tests.
    class AdaptiveScheduler {
    public:
        using Clock = std::chrono::steady_clock;
        using TimePoint = Clock::time_point;

        explicit AdaptiveScheduler(AdaptiveSchedulerConfig config,
            AdaptiveSchedulerDiagnostics* diagnostics = nullptr);

        // The presentation owner supplies its existing queue horizon. Native
        // probes capture it once; the scheduler never queries the transport.
        // An active Headroom source cap bounds reachable lower-load output;
        // zero leaves ordinary workload qualification unchanged.
        [[nodiscard]] AdaptiveFramePlan planFrame(TimePoint now,
            bool generatedImageAcquireBackoff,
            std::optional<size_t> orderedFifoGenerationLimit = std::nullopt,
            std::optional<size_t> integerBaseCapGenerationLimit = std::nullopt,
            std::optional<TimePoint> queuedPresentationDeadline = std::nullopt,
            double headroomSourceCapFps = 0.0);

        void resetTiming(TimePoint now);
        // A released Headroom cap is fresh evidence that the old paced source
        // rate may be self-limiting. Request one existing lower-load trial;
        // acceptance still requires sustained target-rate delivery.
        void requestHeadroomRecovery(TimePoint now, double restoredSourceFps);
        void updateDynamicCadenceProbeInterval(
            TimePoint now, std::chrono::milliseconds interval);
        void beginStabilization(TimePoint now, std::string_view reason);
        void beginTransportRecovery(
            TimePoint now, bool classifyGeneratedLoadFailure = false);
        [[nodiscard]] bool rejectActiveRampForTransportMiss(TimePoint now);
        void resumeAfterExternalInterruption(TimePoint now, bool confirmedReturn);
        // The presentation owner calls only for a confirmed policy change.
        // Preserve the qualified rung and remeasure before another trial.
        [[nodiscard]] bool refreshHigherLoadRetry(TimePoint now);
        void restoreGenerationLimit(TimePoint now, size_t generationLimit,
            std::string_view reason,
            std::optional<size_t> monitoredFallbackLimit = std::nullopt,
            double monitoredBaselineBaseFps = 0.0,
            bool preserveRampBackoff = false);
        void beginDiscontinuityRecovery(TimePoint now, size_t generationLimit,
            size_t fallbackGenerationLimit, double baselineBaseFps,
            std::optional<TimePoint> deadline,
            bool softRecoveryAttempted, std::string_view reason);

        [[nodiscard]] size_t validatedGenerationLimit() const;
        [[nodiscard]] AdaptiveSchedulerSnapshot snapshot() const;

        [[nodiscard]] bool historyWarmupActive() const {
            return this->state.historyWarmup.remaining > 0;
        }
        [[nodiscard]] size_t historyWarmupRemaining() const {
            return this->state.historyWarmup.remaining;
        }
        [[nodiscard]] bool historyWarmupIsRecovery() const {
            return this->state.historyWarmup.recovery;
        }
        void beginHistoryWarmup(size_t frames, bool recovery);
        void ensureHistoryWarmup(size_t frames, bool recovery);
        void cancelHistoryWarmup();
        // Use the same application-present start boundary as planFrame(),
        // never a clock sampled after history scheduling or GPU waits.
        void consumeHistoryWarmupFrame(TimePoint frameStarted);
        void reportGeneratedFrameDelivery(GeneratedFrameDelivery delivery);

        [[nodiscard]] bool discontinuityRecoveryActive() const {
            return this->state.discontinuityRecovery.deadline.has_value();
        }
        [[nodiscard]] size_t discontinuityGenerationLimit() const {
            return this->state.discontinuityRecovery.generationLimit;
        }
        [[nodiscard]] double discontinuityBaselineBaseFps() const {
            return this->state.discontinuityRecovery.baselineBaseFps;
        }
        [[nodiscard]] size_t discontinuityFallbackGenerationLimit() const {
            return this->state.discontinuityRecovery.fallbackGenerationLimit;
        }
        [[nodiscard]] AdaptiveGenerationLoadBaseline generationLoadBaseline()
                const {
            if (this->state.acceptedLoadBaseline.baseFps <= 0.0 ||
                    this->validatedGenerationLimit() <=
                        this->state.acceptedLoadBaseline.generationLimit) {
                return {};
            }
            return {
                .fallbackGenerationLimit =
                    this->state.acceptedLoadBaseline.generationLimit,
                .baseFps = this->state.acceptedLoadBaseline.baseFps,
            };
        }
        [[nodiscard]] std::optional<TimePoint> discontinuityDeadline() const {
            return this->state.discontinuityRecovery.deadline;
        }
        [[nodiscard]] bool discontinuitySoftRecoveryAttempted() const {
            return this->state.discontinuityRecovery.softRecoveryAttempted;
        }
        void markDiscontinuitySoftRecoveryAttempted() {
            this->state.discontinuityRecovery.softRecoveryAttempted = true;
        }

        static size_t historyWarmupFrameCount();
        static Clock::duration rescueMeasurementDuration();
        static Clock::duration rescueCooldown();
        static Clock::duration stableRearmDuration();

    private:
        void beginStabilization(TimePoint now, std::string_view reason,
            Clock::duration stabilizationDuration);

        struct CadenceObservation {
            bool planningReady{false};
            AdaptiveFramePlan terminalPlan;
            double baseFps{0.0};
            double instantaneousBaseFps{0.0};
            double rawIntervalSeconds{0.0};
        };

        struct PlanningStageResult {
            bool planningReady{false};
            AdaptiveFramePlan terminalPlan;
        };

        // These named stages are still one per-present hot path. Their
        // definitions remain inline in adaptive_scheduler.cpp so optimized
        // flattening does not retain duplicate out-of-line implementations.
        [[nodiscard]] inline CadenceObservation observeCadence(
            TimePoint now, bool generatedImageAcquireBackoff);
        [[nodiscard]] inline PlanningStageResult advanceDiscontinuityRecovery(
            TimePoint now, double baseFps);
        [[nodiscard]] inline PlanningStageResult advanceRescueMeasurement(
            TimePoint now, double baseFps, double rawIntervalSeconds);
        void startRescueMeasurement(TimePoint now, size_t generationLimit,
            double baselineBaseFps, double currentBaseFps);
        void restoreRescueAutomaticBaseCap(std::string_view reason);
        void cancelRescueMeasurement(std::string_view reason);
        [[nodiscard]] inline PlanningStageResult advanceStableCadence(
            TimePoint now, double baseFps,
            double desiredOutputsPerRealFrame,
            size_t maximumGeneratedFrameCount);
        inline void advanceEfficiencyProbe(TimePoint now, double baseFps,
            double rawIntervalSeconds, double headroomSourceCapFps);
        [[nodiscard]] inline size_t selectGeneratedFrameCount(
            double desiredOutputsPerRealFrame,
            double rawIntervalSeconds,
            size_t maximumGeneratedFrameCount);
        [[nodiscard]] inline PlanningStageResult advanceNativeCadenceProbe(
            TimePoint now, double baseFps, double instantaneousBaseFps,
            double desiredOutputsPerRealFrame,
            size_t maximumGeneratedFrameCount,
            size_t& generatedFrameCount,
            std::optional<TimePoint> queuedPresentationDeadline);
        [[nodiscard]] inline bool advanceNearTargetNativePreference(
            TimePoint now, double baseFps, size_t configuredGenerationLimit);
        void suppressAutomaticBaseCap(size_t generationLimit,
            double baselineBaseFps, double currentBaseFps,
            std::string_view reason);
        void beginCadenceRefresh(TimePoint now, std::string_view reason);
        void scheduleRearm(TimePoint now, std::string_view reason,
            size_t fallbackLimit = 0, double baselineBaseFps = 0.0);
        // This larger multiplier-validation stage follows the same inline
        // contract as the per-present stages above.
        inline void updateGenerationLimit(TimePoint now, double baseFps,
            double rawIntervalSeconds);
        inline void advancePacedLoadValidation(TimePoint now,
            double rawIntervalSeconds,
            std::optional<size_t> orderedFifoGenerationLimit,
            std::optional<size_t> integerBaseCapGenerationLimit);
        void cancelPacedLoadValidation(std::string_view reason);
        [[nodiscard]] size_t configuredGenerationLimit() const;

        struct SchedulerState {
            struct HistoryWarmup {
                size_t remaining{0};
                bool recovery{false};
            } historyWarmup;

            struct Cadence {
                std::optional<TimePoint> lastRealFrame;
                double smoothedIntervalSeconds{0.0};
                size_t dropFrames{0};
                // Shadow estimate while a sustained drop is unconfirmed.
                // Read only when dropFrames is nonzero; a rejected candidate
                // must not discard the slower half of a bursty source stream.
                double pendingDropIntervalSeconds{0.0};
                // Ordered SDR keeps updating temporal history while native
                // frames are presented. Once a hard cadence stall has already
                // requested that refresh, do not restart the same warm-up on
                // every sub-10-FPS frame. Resume normal policy only after
                // several clearly viable intervals.
                bool sdrStallBypass{false};
                size_t sdrResumeFrames{0};
            } cadence;

            struct DiagnosticThrottle {
                std::optional<TimePoint> lastPlanAt;
            } diagnosticThrottle;

            struct PacingWindow {
                struct Distribution {
                    static constexpr size_t histogramBinCount = 101;
                    static constexpr double histogramBinWidthMilliseconds = 1.0;

                    std::array<uint32_t, histogramBinCount> histogram{};
                    size_t samples{0};
                    double mean{0.0};
                    double squaredDeviation{0.0};

                    void record(const double milliseconds) {
                        const double bounded = std::max(0.0, milliseconds);
                        const size_t bin = std::min(
                            histogramBinCount - 1,
                            static_cast<size_t>(
                                bounded / histogramBinWidthMilliseconds
                            )
                        );
                        this->histogram[bin]++;
                        this->samples++;
                        const double delta = bounded - this->mean;
                        this->mean += delta / static_cast<double>(this->samples);
                        this->squaredDeviation +=
                            delta * (bounded - this->mean);
                    }

                    [[nodiscard]] double standardDeviation() const {
                        return this->samples > 1
                            ? std::sqrt(
                                std::max(0.0, this->squaredDeviation) /
                                static_cast<double>(this->samples)
                            )
                            : 0.0;
                    }

                    [[nodiscard]] double percentile(
                            const double quantile) const {
                        if (this->samples == 0)
                            return 0.0;
                        const size_t rank = static_cast<size_t>(std::ceil(
                            std::clamp(quantile, 0.0, 1.0) *
                            static_cast<double>(this->samples)
                        ));
                        size_t cumulative = 0;
                        for (size_t bin = 0;
                                bin < this->histogram.size(); ++bin) {
                            cumulative += this->histogram[bin];
                            if (cumulative >= std::max<size_t>(rank, 1)) {
                                return (static_cast<double>(bin) + 0.5) *
                                    histogramBinWidthMilliseconds;
                            }
                        }
                        return static_cast<double>(histogramBinCount) *
                            histogramBinWidthMilliseconds;
                    }

                    void reset() {
                        this->histogram.fill(0);
                        this->samples = 0;
                        this->mean = 0.0;
                        this->squaredDeviation = 0.0;
                    }
                } sourceIntervals, requestedIntervals;

                std::optional<size_t> previousGeneratedFrameCount;
                size_t generatedCountChanges{0};
                size_t phaseErrorSamples{0};
                double phaseErrorSquaredMilliseconds{0.0};
                double maximumAbsolutePhaseErrorMilliseconds{0.0};
                size_t frameSequence{0};
                std::optional<size_t> lastRecordedFrameSequence;
                std::optional<bool> recordedTargetClockActive;
                std::optional<bool> recordedStableCadence;
                std::optional<size_t> recordedGenerationLimit;
                std::optional<size_t> recordedTargetClockEpoch;

                void beginFrame() {
                    this->frameSequence++;
                }

                void record(const double rawIntervalSeconds,
                        const size_t generatedFrameCount,
                        const bool targetClockActive,
                        const double targetPhaseErrorOutputs,
                        const uint32_t targetFps,
                        const bool stableCadence,
                        const size_t generationLimit,
                        const size_t targetClockEpoch) {
                    const bool skippedPolicyFrame =
                        this->lastRecordedFrameSequence &&
                        this->frameSequence !=
                            *this->lastRecordedFrameSequence + 1;
                    const bool policyChanged =
                        (this->recordedTargetClockActive &&
                         *this->recordedTargetClockActive !=
                            targetClockActive) ||
                        (this->recordedStableCadence &&
                         *this->recordedStableCadence != stableCadence) ||
                        (this->recordedGenerationLimit &&
                         *this->recordedGenerationLimit != generationLimit) ||
                        (this->recordedTargetClockEpoch &&
                         *this->recordedTargetClockEpoch != targetClockEpoch);
                    if (skippedPolicyFrame || policyChanged) {
                        this->resetWindow();
                        this->previousGeneratedFrameCount.reset();
                    }
                    this->lastRecordedFrameSequence = this->frameSequence;
                    this->recordedTargetClockActive = targetClockActive;
                    this->recordedStableCadence = stableCadence;
                    this->recordedGenerationLimit = generationLimit;
                    this->recordedTargetClockEpoch = targetClockEpoch;

                    const double sourceIntervalMilliseconds =
                        rawIntervalSeconds * 1000.0;
                    this->sourceIntervals.record(sourceIntervalMilliseconds);
                    const size_t outputCount = generatedFrameCount + 1;
                    const double requestedIntervalMilliseconds =
                        sourceIntervalMilliseconds /
                        static_cast<double>(outputCount);
                    for (size_t output = 0; output < outputCount; ++output)
                        this->requestedIntervals.record(
                            requestedIntervalMilliseconds
                        );
                    if (this->previousGeneratedFrameCount &&
                            *this->previousGeneratedFrameCount !=
                                generatedFrameCount) {
                        this->generatedCountChanges++;
                    }
                    this->previousGeneratedFrameCount = generatedFrameCount;

                    if (!targetClockActive || targetFps == 0)
                        return;
                    const double phaseErrorMilliseconds =
                        targetPhaseErrorOutputs * 1000.0 /
                        static_cast<double>(targetFps);
                    this->phaseErrorSamples++;
                    this->phaseErrorSquaredMilliseconds +=
                        phaseErrorMilliseconds * phaseErrorMilliseconds;
                    this->maximumAbsolutePhaseErrorMilliseconds = std::max(
                        this->maximumAbsolutePhaseErrorMilliseconds,
                        std::abs(phaseErrorMilliseconds)
                    );
                }

                void resetWindow() {
                    this->sourceIntervals.reset();
                    this->requestedIntervals.reset();
                    this->generatedCountChanges = 0;
                    this->phaseErrorSamples = 0;
                    this->phaseErrorSquaredMilliseconds = 0.0;
                    this->maximumAbsolutePhaseErrorMilliseconds = 0.0;
                }

                void reset() {
                    this->resetWindow();
                    this->previousGeneratedFrameCount.reset();
                    this->frameSequence = 0;
                    this->lastRecordedFrameSequence.reset();
                    this->recordedTargetClockActive.reset();
                    this->recordedStableCadence.reset();
                    this->recordedGenerationLimit.reset();
                    this->recordedTargetClockEpoch.reset();
                }
            } pacingWindow;

            struct FastBurst {
                std::optional<TimePoint> startedAt;
                std::optional<TimePoint> lastDiagnosticAt;
                size_t frames{0};
                size_t framesSinceDiagnostic{0};
            } fastBurst;

            struct OutputPlanner {
                // Smoothed cadence owns the generated-work budget, preserving
                // the established long-term load envelope. Its one-time
                // half-output phase seed rounds prefix demand to the nearest
                // output instead of always trailing it. Raw cadence owns only
                // the bounded placement phase and may defer one
                // already-budgeted output from a clearly short interval.
                double budgetCreditOutputs{0.0};
                double targetPhaseErrorOutputs{0.0};
                bool deferredBudgetOutput{false};
                double deferredPlacementBenefit{0.0};
                double maximumBaselineSpacingOutputs{0.0};
                bool targetClockActive{false};
                size_t targetClockEpoch{0};
                size_t generationLimit{0};

                void resetTargetClock() {
                    if (this->budgetCreditOutputs != 0.0 ||
                            this->targetPhaseErrorOutputs != 0.0 ||
                            this->deferredBudgetOutput ||
                            this->deferredPlacementBenefit != 0.0 ||
                            this->maximumBaselineSpacingOutputs != 0.0 ||
                            this->targetClockActive) {
                        this->targetClockEpoch++;
                    }
                    this->budgetCreditOutputs = 0.0;
                    this->targetPhaseErrorOutputs = 0.0;
                    this->deferredBudgetOutput = false;
                    this->deferredPlacementBenefit = 0.0;
                    this->maximumBaselineSpacingOutputs = 0.0;
                    this->targetClockActive = false;
                }
            } outputPlanner;

            struct NativeCadenceProbe {
                std::optional<TimePoint> nextAt;
                std::optional<TimePoint> drainUntil;
                bool active{false};
                bool qualifyingNearTarget{false};
                double baselineBaseFps{0.0};
                double minimumMeasuredBaseFps{0.0};
                size_t confirmedSamples{0};

                void reset() {
                    this->nextAt.reset();
                    this->drainUntil.reset();
                    this->active = false;
                    this->qualifyingNearTarget = false;
                    this->baselineBaseFps = 0.0;
                    this->minimumMeasuredBaseFps = 0.0;
                    this->confirmedSamples = 0;
                }
            } nativeCadenceProbe;

            struct NearTargetNativePreference {
                bool active{false};
                std::optional<bool> candidateActive;
                Clock::duration candidateEvidence{};
                std::optional<TimePoint> lastEvaluationAt;
                // Only confirmed Dynamic Cadence Recovery owns this native
                // measurement. Count every source interval, including bursts,
                // so queue turnover cannot bias it toward the slower frames.
                double nativeSampleSeconds{0.0};
                size_t nativeSampleFrames{0};
                std::optional<double> nativeBaseFps;

                void resetNativeSample() {
                    this->nativeSampleSeconds = 0.0;
                    this->nativeSampleFrames = 0;
                    this->nativeBaseFps.reset();
                }

                void resetCandidate() {
                    this->candidateActive.reset();
                    this->candidateEvidence = Clock::duration{};
                    this->lastEvaluationAt.reset();
                }

                void reset() {
                    this->active = false;
                    this->resetCandidate();
                    this->resetNativeSample();
                }
            } nearTargetNativePreference;

            struct Stabilization {
                std::optional<TimePoint> until;
            } stabilization;

            struct Ramp {
                // Recent trials use their adjacent baseline. A later applied
                // pacing owner obtains a fresh baseline through EfficiencyProbe.
                struct PacedLoad {
                    std::optional<TimePoint> until;
                    std::optional<TimePoint> settlingUntil;
                    size_t testedLimit{0};
                    size_t previousLimit{0};
                    double baselineBaseFps{0.0};
                    size_t previousFailures{0};
                    bool fifo{false};
                    bool refreshBaseline{false};
                    bool lowerLoadProbe{false};
                    bool discardTurnoverInterval{false};
                    double pacedBaseFps{0.0};
                    double pacedOutputFps{0.0};
                    bool deliveryObserved{false};
                    size_t deliveredOutputs{0};
                    double sampleSeconds{0.0};
                    size_t sampleFrames{0};
                    size_t sampleOutputs{0};
                    double windowSeconds{0.0};
                    size_t windowFrames{0};
                    double minimumWindowFps{0.0};
                    double maximumWindowFps{0.0};

                    void reset() { *this = {}; }
                    void resetSamples() {
                        this->discardTurnoverInterval = false;
                        this->deliveryObserved = false;
                        this->deliveredOutputs = 0;
                        this->sampleSeconds = 0.0;
                        this->sampleFrames = 0;
                        this->sampleOutputs = 0;
                        this->windowSeconds = 0.0;
                        this->windowFrames = 0;
                        this->minimumWindowFps = 0.0;
                        this->maximumWindowFps = 0.0;
                    }
                } pacedLoad;
                std::optional<size_t> observedPacingLimit;
                bool observedPacingFifo{false};
                // A planned probe return belongs to the observed pacing
                // lifetime until its workload/owner changes, not a timeout.
                bool pacingResumePending{false};
                void resetPacingObservation() {
                    this->observedPacingLimit.reset();
                    this->pacingResumePending = false;
                }
                std::optional<size_t> pacedLoadRollbackLimit;
                // Higher promotions and stale-baseline replacement require
                // a continuous, delivered sample of the current lower load.
                struct LowerLoadSample {
                    std::optional<TimePoint> since;
                    double minimumBaseFps{0.0};
                    double maximumBaseFps{0.0};
                    double intervalSecondsSum{0.0};
                    size_t frames{0};
                    bool deliveryObserved{false};

                    void reset() { *this = {}; }
                } lowerLoadSample;
                std::optional<TimePoint> nextAt;
                std::optional<TimePoint> evaluationAt;
                std::optional<TimePoint> targetDeficitSince;
                std::optional<TimePoint> targetConstraintSince;
                bool targetConstraintReported{false};
                GeneratedDeliveryWindow delivery;
                size_t previousLimit{0};
                double targetSampleSeconds{0.0};
                TimePoint targetSampleStartsAt{};
                size_t targetSampleFrames{0};
                size_t targetDeliveryReports{0};
                size_t targetTrialFrames{0};
                size_t targetGeneratedBeforeSample{0};
                bool targetSampleComplete{false};
                double baselineBaseFps{0.0};
                size_t lastFailedLimit{0};
                size_t consecutiveFailures{0};
                double failedBaselineBaseFps{0.0};
            } ramp;

            struct Rearm {
                bool required{false};
                std::optional<TimePoint> notBefore;
                std::optional<TimePoint> stableSince;
                std::string reason;
                double baselineBaseFps{0.0};
                size_t fallbackLimit{0};
                size_t consecutiveProbeFailures{0};
            } rearm;

            struct StableCadence {
                struct Candidate {
                    std::optional<size_t> limit;
                    std::optional<TimePoint> since;
                    double minimumBaseFps{0.0};
                    double maximumBaseFps{0.0};
                    bool convergenceProbe{false};

                    void reset() {
                        this->limit.reset();
                        this->since.reset();
                        this->minimumBaseFps = 0.0;
                        this->maximumBaseFps = 0.0;
                        this->convergenceProbe = false;
                    }
                } candidate;

                std::optional<size_t> limit;
                std::optional<TimePoint> evaluationAt;
                std::optional<TimePoint> outsideRangeSince;
                std::optional<TimePoint> retryAt;
                double baselineBaseFps{0.0};
                GeneratedDeliveryWindow delivery;
                bool convergenceProbe{false};
                bool convergedTwoX{false};
            } stableCadence;

            struct EfficiencyProbe {
                std::optional<TimePoint> headroomRequestUntil;
                size_t headroomTestLimit{};
                std::optional<TimePoint> eligibleSince;
                std::optional<TimePoint> evaluationAt;
                // A rejected lower load remains rejected through cadence
                // interruptions, independently of experiments at other rungs.
                std::array<std::optional<TimePoint>,
                    GeneratedFramePlan::capacity> retryAt{};
                GeneratedDeliveryWindow delivery;
                size_t testedLimit{0};
                double baselineBaseFps{0.0};
                bool settlingGraceUsed{false};
                // A promising endpoint must survive a continuous delivered
                // sample before replacing the retained higher workload.
                bool sampling{false};
                bool sampleComplete{true};
                bool deliveryObserved{false};
                double sampleSeconds{0.0};
                size_t sampleFrames{0};

                void resetEvaluation() {
                    this->eligibleSince.reset();
                    this->evaluationAt.reset();
                    this->delivery.reset();
                    this->testedLimit = 0;
                    this->baselineBaseFps = 0.0;
                    this->settlingGraceUsed = false;
                    this->sampling = false;
                    this->sampleComplete = true;
                    this->deliveryObserved = false;
                    this->sampleSeconds = 0.0;
                    this->sampleFrames = 0;
                }

                void reset() {
                    this->resetEvaluation();
                    this->headroomRequestUntil.reset();
                    this->retryAt.fill(std::nullopt);
                }
            } efficiencyProbe;

            struct Rescue {
                // A stable-cadence exit can precede the actual collapse.
                // Retain its proof briefly, without probing every heavy scene.
                std::optional<TimePoint> watchUntil;
                std::optional<TimePoint> until;
                std::optional<TimePoint> verificationUntil;
                std::optional<TimePoint> cooldownUntil;
                size_t previousLimit{0};
                double baselineBaseFps{0.0};
                double collapsedBaseFps{0.0};
                size_t pendingGeneratedFrames{0};
                size_t deliveredGeneratedFrames{0};
                bool deliveryHealthy{true};
                double sampleSeconds{0.0};
                size_t sampleFrames{0};
                bool skipNextSample{true};

                void resetSamples(const bool skipFirst = true) {
                    this->sampleSeconds = 0.0;
                    this->sampleFrames = 0;
                    this->skipNextSample = skipFirst;
                }

                void observe(const double intervalSeconds) {
                    if (this->skipNextSample) {
                        this->skipNextSample = false;
                        return;
                    }
                    this->sampleSeconds += intervalSeconds;
                    this->sampleFrames++;
                }

                [[nodiscard]] double measuredBaseFps() const {
                    return this->sampleSeconds > 0.0
                        ? static_cast<double>(this->sampleFrames) /
                            this->sampleSeconds
                        : 0.0;
                }

                void resetAttempt() {
                    this->watchUntil.reset();
                    this->until.reset();
                    this->verificationUntil.reset();
                    this->previousLimit = 0;
                    this->baselineBaseFps = 0.0;
                    this->collapsedBaseFps = 0.0;
                    this->pendingGeneratedFrames = 0;
                    this->deliveredGeneratedFrames = 0;
                    this->deliveryHealthy = true;
                    this->resetSamples();
                }
            } rescue;

            struct AutomaticBaseCap {
                bool suppressed{false};
            } automaticBaseCap;

            struct AcceptedLoadBaseline {
                size_t generationLimit{0};
                double baseFps{0.0};
            } acceptedLoadBaseline;

            struct DiscontinuityRecovery {
                std::optional<TimePoint> deadline;
                std::optional<TimePoint> stableSince;
                size_t generationLimit{0};
                size_t fallbackGenerationLimit{0};
                double baselineBaseFps{0.0};
                bool softRecoveryAttempted{false};

                void reset() {
                    this->deadline.reset();
                    this->stableSince.reset();
                    this->generationLimit = 0;
                    this->fallbackGenerationLimit = 0;
                    this->baselineBaseFps = 0.0;
                    this->softRecoveryAttempted = false;
                }
            } discontinuityRecovery;

            struct MenuReturnLoadGuard {
                bool active{false};
                size_t provenGenerationLimit{0};
                double baselineBaseFps{0.0};

                void reset() {
                    this->active = false;
                    this->provenGenerationLimit = 0;
                    this->baselineBaseFps = 0.0;
                }
            } menuReturnLoadGuard;
        };

        AdaptiveSchedulerConfig config;
        AdaptiveSchedulerDiagnostics* diagnostics;
        bool diagnosticsActive;
        SchedulerState state;
    };

}
