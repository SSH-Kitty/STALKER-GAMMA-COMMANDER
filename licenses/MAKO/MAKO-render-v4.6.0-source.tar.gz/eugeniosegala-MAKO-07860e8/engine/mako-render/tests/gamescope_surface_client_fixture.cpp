/* SPDX-License-Identifier: GPL-3.0-or-later */

// A local protocol peer fixture. The production adapter loads these ordinary
// runtime symbols through its real dlopen path, with no test branch in MAKO.
#include <algorithm>
#include <array>
#include <cerrno>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <mutex>
#include <string>
#include <string_view>
#include <thread>
#include <vector>
#include <unordered_map>
#include <sys/socket.h>
#include <unistd.h>
#include <X11/Xlib.h>
#include <xcb/xcb.h>

struct wl_display;
struct wl_event_queue;
struct wl_message;
struct wl_interface {
    const char* name;
    int version;
    int method_count;
    const wl_message* methods;
    int event_count;
    const wl_message* events;
};
struct wl_message { const char* name; const char* signature; const wl_interface** types; };
union wl_argument { int32_t i; uint32_t u; const char* s; void* o; };
struct wl_proxy {
    std::string_view kind;
    void (**listener)(void){};
    void* data{};
    bool pending{};
    wl_proxy* surface{};
    uint32_t version{1};
    bool staged{};
};

namespace {
    std::recursive_mutex fixtureMutex;
    std::thread::id applicationThread;
    std::vector<wl_proxy*> objects;
    int mode{};
    uint32_t advertisedVersion{1};
    int associations{};
    int feedbacks{};
    uint32_t hdrOutput{};
    bool hdrOutputPresent{true};
    int hdrPropertyFault{};
    uint32_t serverId{9};
    bool externalOutput{};
    int hdrQueries{};
    uint32_t feedbackColorSpace{};
    int hdrMetadataCalls{};
    uint32_t hdrMetadata[12]{};
    int presentModes{};
    int presentTimes{};
    uint64_t presentId{};
    wl_proxy* lastTimedProxy{};
    uint64_t presentTime{};
    uint32_t presentMode{};
    uint32_t feedbackImageCount{};
    std::string feedbackEngine;
    int queues{};
    int reads{};
    int geometryQueries{};
    uint16_t windowWidth{1920};
    uint16_t windowHeight{1080};
    int sockets[2]{-1, -1};
    uint32_t associatedServer{};
    uint32_t associatedWindow{};
    struct Override { wl_proxy* surface{}; wl_proxy* content{}; };
    std::unordered_map<uint64_t, Override> overrides;
    bool ownershipModel{};
    bool delayedEvents{};
    struct WireEvent { wl_proxy* proxy; uint64_t id; uint64_t time; bool retired; };
    std::deque<WireEvent> unreadEvents;
    std::deque<WireEvent> readEvents;
    int deliveredEvents{};
    int preparedReads{};
    int readerFlushes{};
    int readError{};

    void enqueueEvent(bool retired) {
        if (!lastTimedProxy)
            std::abort();
        unreadEvents.push_back({lastTimedProxy, presentId, presentTime, retired});
        const char byte = 1;
        if (write(sockets[1], &byte, 1) != 1)
            std::abort();
    }

    uint64_t windowKey(uint32_t server, uint32_t window) {
        return (uint64_t{server} << 32) | window;
    }

    void associate(wl_proxy* proxy, uint32_t server, uint32_t window) {
        auto& current = overrides[windowKey(server, window)];
        if (current.content == proxy)
            return;
        if (current.content)
            current.content->pending = true;
        current = {proxy->surface, proxy};
    }

    wl_proxy* make(std::string_view kind) {
        auto* proxy = new wl_proxy{kind};
        objects.push_back(proxy);
        return proxy;
    }
    void drop(wl_proxy* proxy) {
        std::erase_if(unreadEvents, [proxy](const auto& event) { return event.proxy == proxy;
    });
        std::erase_if(readEvents, [proxy](const auto& event) { return event.proxy == proxy;
    });
        // Gamescope clears the override attached to the resource's wl_surface,
        // including when an older protocol resource shares a replacement's
        // surface. A later present must reassert the surviving association.
        std::erase_if(overrides, [proxy](const auto& entry) {
            return entry.second.surface == proxy ||
                (proxy->surface && entry.second.surface == proxy->surface);
        });
        if (lastTimedProxy == proxy)
            lastTimedProxy = nullptr;
        std::erase(objects, proxy);
        delete proxy;
    }
}

extern "C" {
    // Keep peer identity deterministic in PID-isolated test sandboxes too.
    int getsockopt(int, int level, int option, void* value, socklen_t* size) noexcept {
        const std::lock_guard fixtureLock(fixtureMutex);
        if (mode == 16 || level != SOL_SOCKET || option != SO_PEERCRED || *size < sizeof(ucred))
            return -1;
        const ucred peer{mode == 18 ? 0 : getpid(), getuid(), getgid()};
        std::memcpy(value, &peer, sizeof(peer));
        *size = mode == 17 ? sizeof(peer) - 1 : sizeof(peer);
        return 0;
    }
    extern const wl_interface wl_registry_interface{"wl_registry", 1, 0, nullptr, 0, nullptr};
    extern const wl_interface wl_compositor_interface{"wl_compositor", 1, 0, nullptr, 0, nullptr};
    extern const wl_interface wl_surface_interface{"wl_surface", 1, 0, nullptr, 0, nullptr};
    extern const wl_interface wl_callback_interface{"wl_callback", 1, 0, nullptr, 0, nullptr};

    void mako_test_surface_mode(int value) {
        const std::lock_guard fixtureLock(fixtureMutex);
        mode = value;
    }
    void mako_test_surface_protocol(uint32_t version) {
        const std::lock_guard fixtureLock(fixtureMutex);
        advertisedVersion = version;
    }
    uint64_t mako_test_surface_present_serial() {
        const std::lock_guard fixtureLock(fixtureMutex);
        return presentId;
    }
    void mako_test_surface_staged_timing(uint64_t serial, uint64_t ready,
            uint64_t latch, uint64_t predicted) {
        const std::lock_guard fixtureLock(fixtureMutex);
        auto* proxy = lastTimedProxy;
        if (!proxy || !proxy->staged || !proxy->listener)
            std::abort();
        using Timing = void (*)(void*, wl_proxy*, uint32_t, uint32_t, uint32_t,
            uint32_t, uint32_t, uint32_t, uint32_t, uint32_t);
        reinterpret_cast<Timing>(proxy->listener[3])(proxy->data, proxy,
            static_cast<uint32_t>(serial >> 32), static_cast<uint32_t>(serial),
            static_cast<uint32_t>(ready >> 32), static_cast<uint32_t>(ready),
            static_cast<uint32_t>(latch >> 32), static_cast<uint32_t>(latch),
            static_cast<uint32_t>(predicted >> 32), static_cast<uint32_t>(predicted));
    }
    void mako_test_surface_timing_properties(uint64_t duration, uint64_t interval) {
        const std::lock_guard fixtureLock(fixtureMutex);
        auto* proxy = lastTimedProxy;
        if (!proxy || !proxy->staged || !proxy->listener)
            std::abort();
        using Properties = void (*)(void*, wl_proxy*, uint32_t, uint32_t, uint32_t, uint32_t);
        reinterpret_cast<Properties>(proxy->listener[4])(proxy->data, proxy,
            static_cast<uint32_t>(duration >> 32), static_cast<uint32_t>(duration),
            static_cast<uint32_t>(interval >> 32), static_cast<uint32_t>(interval));
    }
    void mako_test_surface_wire_event(bool retired) {
        const std::lock_guard fixtureLock(fixtureMutex);
        enqueueEvent(retired);
    }
    int mako_test_surface_delivered_events() {
        const std::lock_guard fixtureLock(fixtureMutex);
        return deliveredEvents;
    }
    int mako_test_surface_prepared_reads() {
        const std::lock_guard fixtureLock(fixtureMutex);
        return preparedReads;
    }
    int mako_test_surface_reader_flushes() {
        const std::lock_guard fixtureLock(fixtureMutex);
        return readerFlushes;
    }
    void mako_test_surface_break_connection(bool hangup) {
        const std::lock_guard fixtureLock(fixtureMutex);
        if (hangup) {
            close(sockets[1]);
            sockets[1] = -1;
        } else {
            readError = EIO;
            enqueueEvent(false);
        }
    }
    void mako_test_surface_ownership(bool value) {
        const std::lock_guard fixtureLock(fixtureMutex);
        ownershipModel = value;
    }
    void mako_test_surface_delay_events(bool value) {
        const std::lock_guard fixtureLock(fixtureMutex);
        delayedEvents = value;
    }
    int mako_test_surface_overrides() {
        const std::lock_guard fixtureLock(fixtureMutex);
        return static_cast<int>(overrides.size());
    }
    void mako_test_surface_competing_override(uint32_t server, uint32_t window) {
        const std::lock_guard fixtureLock(fixtureMutex);
        const auto found = overrides.find(windowKey(server, window));
        if (found != overrides.end()) {
            if (found->second.content)
                found->second.content->pending = true;
            overrides.erase(found);
        }
    }
    int mako_test_surface_objects() {
        const std::lock_guard fixtureLock(fixtureMutex);
        return static_cast<int>(objects.size()) + queues;
    }
    int mako_test_surface_associations() {
        const std::lock_guard fixtureLock(fixtureMutex);
        return associations;
    }
    int mako_test_surface_feedbacks() {
        const std::lock_guard fixtureLock(fixtureMutex);
        return feedbacks;
    }
    void mako_test_surface_hdr_output(uint32_t value) {
        const std::lock_guard fixtureLock(fixtureMutex);
        hdrOutput = value;
    }
    void mako_test_surface_hdr_output_present(bool value) {
        const std::lock_guard fixtureLock(fixtureMutex);
        hdrOutputPresent = value;
    }
    void mako_test_surface_hdr_property_fault(int value) {
        const std::lock_guard fixtureLock(fixtureMutex);
        hdrPropertyFault = value;
    }
    void mako_test_surface_server_id(uint32_t value) {
        const std::lock_guard fixtureLock(fixtureMutex);
        serverId = value;
    }
    void mako_test_surface_external_output(bool value) {
        const std::lock_guard fixtureLock(fixtureMutex);
        externalOutput = value;
    }
    int mako_test_surface_hdr_queries() {
        const std::lock_guard fixtureLock(fixtureMutex);
        return hdrQueries;
    }
    uint32_t mako_test_surface_feedback_color() {
        const std::lock_guard fixtureLock(fixtureMutex);
        return feedbackColorSpace;
    }
    int mako_test_surface_hdr_metadata_calls() {
        const std::lock_guard fixtureLock(fixtureMutex);
        return hdrMetadataCalls;
    }
    uint32_t mako_test_surface_hdr_metadata(unsigned index) {
        const std::lock_guard fixtureLock(fixtureMutex);
        return hdrMetadata[index];
    }

    int mako_test_surface_present_times() {
        const std::lock_guard fixtureLock(fixtureMutex);
        return presentTimes;
    }
    uint32_t mako_test_surface_present_id() {
        const std::lock_guard fixtureLock(fixtureMutex);
        return static_cast<uint32_t>(presentId);
    }
    uint64_t mako_test_surface_present_time() {
        const std::lock_guard fixtureLock(fixtureMutex);
        return presentTime;
    }
    void mako_test_surface_ready_timing(uint64_t earliest, uint64_t margin = 0) {
        const std::lock_guard fixtureLock(fixtureMutex);
        auto* proxy = lastTimedProxy;
        if (!proxy || !proxy->listener)
            std::abort();
        using Timing = void (*)(void*, wl_proxy*, uint32_t, uint32_t, uint32_t,
            uint32_t, uint32_t, uint32_t, uint32_t, uint32_t, uint32_t);
        using Refresh = void (*)(void*, wl_proxy*, uint32_t, uint32_t);
        const uint64_t actual = presentTime + 100000;
        reinterpret_cast<Timing>(proxy->listener[0])(proxy->data, proxy, static_cast<uint32_t>(presentId),
            static_cast<uint32_t>(presentTime >> 32), static_cast<uint32_t>(presentTime),
            static_cast<uint32_t>(actual >> 32), static_cast<uint32_t>(actual),
            static_cast<uint32_t>(earliest >> 32), static_cast<uint32_t>(earliest),
            static_cast<uint32_t>(margin >> 32), static_cast<uint32_t>(margin));
        reinterpret_cast<Refresh>(proxy->listener[1])(proxy->data, proxy, 0, 8333333);
    }
    void mako_test_surface_timing() {
        const std::lock_guard fixtureLock(fixtureMutex);
        mako_test_surface_ready_timing(0);
    }
    int mako_test_surface_present_modes() {
        const std::lock_guard fixtureLock(fixtureMutex);
        return presentModes;
    }
    uint32_t mako_test_surface_present_mode() {
        const std::lock_guard fixtureLock(fixtureMutex);
        return presentMode;
    }
    uint32_t mako_test_surface_feedback_image_count() {
        const std::lock_guard fixtureLock(fixtureMutex);
        return feedbackImageCount;
    }
    const char* mako_test_surface_feedback_engine() {
        const std::lock_guard fixtureLock(fixtureMutex);
        return feedbackEngine.c_str();
    }
    int mako_test_surface_reads() {
        const std::lock_guard fixtureLock(fixtureMutex);
        return reads;
    }
    int mako_test_surface_geometry_queries() {
        const std::lock_guard fixtureLock(fixtureMutex);
        return geometryQueries;
    }
    void mako_test_surface_resize(uint16_t width, uint16_t height) {
        const std::lock_guard fixtureLock(fixtureMutex);
        windowWidth = width;
        windowHeight = height;
    }
    uint32_t mako_test_surface_window() {
        const std::lock_guard fixtureLock(fixtureMutex);
        return associatedWindow;
    }
    uint32_t mako_test_surface_server() {
        const std::lock_guard fixtureLock(fixtureMutex);
        return associatedServer;
    }
    void mako_test_surface_retire() {
        const std::lock_guard fixtureLock(fixtureMutex);
        for (auto* proxy : objects) {
            if (proxy->kind == "gamescope_swapchain") {
                proxy->pending = true;
                break;
            }
        }
    }

    wl_display* wl_display_connect(const char*) {
        const std::lock_guard fixtureLock(fixtureMutex);
        applicationThread = std::this_thread::get_id();
        readError = 0;
        if (mode == 1)
            return nullptr;
        if (socketpair(AF_UNIX, SOCK_STREAM, 0, sockets) != 0)
            std::abort();
        return reinterpret_cast<wl_display*>(make("wl_display"));
    }
    void wl_display_disconnect(wl_display* display) {
        const std::lock_guard fixtureLock(fixtureMutex);
        if (preparedReads != 0)
            std::abort();
        drop(reinterpret_cast<wl_proxy*>(display));
        close(sockets[0]);
        close(sockets[1]);
    }
    // Match the public opaque pointer signatures even though the fixture uses
    // proxies/counters as storage. dlopen callers retain the real API types.
    int wl_display_get_fd(wl_display*) {
        const std::lock_guard fixtureLock(fixtureMutex);
        return sockets[0];
    }
    int wl_display_flush(wl_display*) {
        const std::lock_guard fixtureLock(fixtureMutex);
        const bool applicationCall = std::this_thread::get_id() == applicationThread;
        if (!applicationCall)
            ++readerFlushes;
        // Legacy one-call fault injection is scoped to its caller. A real
        // reader failure is injected separately through the socket below.
        if (applicationCall && (mode == 12 || mode == 13)) {
            errno = mode == 12 ? EAGAIN : EPIPE;
            return -1;
        }
        return 0;
    }
    int wl_display_get_error(wl_display*) {
        const std::lock_guard fixtureLock(fixtureMutex);
        return mode == 5 && std::this_thread::get_id() == applicationThread ? 32 : 0;
    }
    wl_event_queue* wl_display_create_queue(wl_display*) {
        const std::lock_guard fixtureLock(fixtureMutex);
        ++queues;
        return reinterpret_cast<wl_event_queue*>(&queues);
    }
    void wl_event_queue_destroy(wl_event_queue*) {
        const std::lock_guard fixtureLock(fixtureMutex);
        --queues;
    }
    int wl_display_prepare_read_queue(wl_display*, wl_event_queue*) {
        const std::lock_guard fixtureLock(fixtureMutex);
        if (std::this_thread::get_id() == applicationThread)
            ++reads;
        if (!readEvents.empty()) {
            errno = EAGAIN;
            return -1;
        }
        ++preparedReads;
        return 0;
    }
    int wl_display_read_events(wl_display*) {
        const std::lock_guard fixtureLock(fixtureMutex);
        if (--preparedReads < 0)
            std::abort();
        if (readError) {
            errno = readError;
            return -1;
        }
        char bytes[4096];
        if (recv(sockets[0], bytes, sizeof(bytes), MSG_DONTWAIT) < 0 && errno != EAGAIN)
            return -1;
        readEvents.insert(readEvents.end(), unreadEvents.begin(), unreadEvents.end());
        unreadEvents.clear();
        return 0;
    }
    void wl_display_cancel_read(wl_display*) {
        const std::lock_guard fixtureLock(fixtureMutex);
        if (--preparedReads < 0)
            std::abort();
    }
    void wl_proxy_set_queue(wl_proxy*, wl_event_queue*) {
        const std::lock_guard fixtureLock(fixtureMutex);}
    void wl_proxy_destroy(wl_proxy* proxy) {
        const std::lock_guard fixtureLock(fixtureMutex);
        drop(proxy);
    }
    int wl_proxy_add_listener(wl_proxy* proxy, void (**listener)(void), void* data) {
        const std::lock_guard fixtureLock(fixtureMutex);
        if (mode == 8 && proxy->kind == "gamescope_swapchain")
            return -1;
        proxy->listener = listener;
        proxy->data = data;
        return 0;
    }
    wl_proxy* wl_proxy_marshal_array_flags(wl_proxy* proxy, uint32_t opcode,
            const wl_interface* interface, uint32_t version, uint32_t flags, wl_argument* args) {
        const std::lock_guard fixtureLock(fixtureMutex);
        if (flags & 1) {
            drop(proxy);
            return nullptr;
        }
        if (proxy->kind == "gamescope_swapchain") {
            if (opcode == 1) {
                ++associations;
                associatedServer = args[0].u;
                associatedWindow = args[1].u;
                if (ownershipModel)
                    associate(proxy, args[0].u, args[1].u);
            } else if (opcode == 2) {
                ++feedbacks;
                feedbackImageCount = args[0].u;
                feedbackColorSpace = args[2].u;
                feedbackEngine = args[6].s;
            } else if (opcode == 3) {
                ++presentModes;
                presentMode = args[0].u;
            } else if (opcode == 4) {
                ++hdrMetadataCalls;
                for (unsigned index = 0; index < 12; ++index)
                    hdrMetadata[index] = args[index].u;
            } else if (opcode == 5) {
                if (proxy->staged)
                    std::abort();
                lastTimedProxy = proxy;
                ++presentTimes;
                presentId = args[0].u;
                presentTime = (uint64_t{args[1].u} << 32) | args[2].u;
            } else if (opcode == 6) {
                if (!proxy->staged || proxy->version != 2 || args[4].u != 0)
                    std::abort();
                lastTimedProxy = proxy;
                ++presentTimes;
                presentId = (uint64_t{args[0].u} << 32) | args[1].u;
                presentTime = (uint64_t{args[2].u} << 32) | args[3].u;
            } else {
                std::abort(); // No limiter control requests.
            }
            return nullptr;
        }
        if (!interface)
            std::abort();
        if (mode == 7 && std::string_view(interface->name) == "gamescope_swapchain")
            return nullptr;
        auto* created = make(interface->name);
        created->version = version;
        if (created->kind == "gamescope_swapchain_factory_v2" &&
                (version != std::min(advertisedVersion, uint32_t{2}) || args[2].u != version ||
                interface->method_count != 3 ||
                std::string_view(interface->methods[2].signature) != "2on"))
            std::abort();
        if (created->kind == "gamescope_swapchain") {
            if (version != proxy->version || opcode != (version == 2 ? 2U : 1U) ||
                    interface->method_count != 7 || interface->event_count != 5 ||
                    std::string_view(interface->methods[6].signature) != "2uuuuu" ||
                    std::string_view(interface->events[3].signature) != "2uuuuuuuu" ||
                    std::string_view(interface->events[4].signature) != "2uuuu")
                std::abort();
            created->staged = version == 2;
            created->surface = static_cast<wl_proxy*>(args[0].o);
        }
        if (created->kind == "wl_registry" || created->kind == "wl_callback")
            created->pending = true;
        return created;
    }
    int wl_display_dispatch_queue_pending(wl_display*, wl_event_queue*) {
        const std::lock_guard fixtureLock(fixtureMutex);
        if (mode == 14 && std::this_thread::get_id() == applicationThread) {
            errno = EPROTO;
            return -1;
        }
        if (mode == 3)
            return 0; // A silent peer must hit the bounded discovery deadline.
        while (!readEvents.empty()) {
            const auto event = readEvents.front();
            readEvents.pop_front();
            auto* proxy = event.proxy;
            if (event.retired) {
                reinterpret_cast<void (*)(void*, wl_proxy*)>(proxy->listener[2])(proxy->data, proxy);
            } else if (proxy->staged) {
                using Timing = void (*)(void*, wl_proxy*, uint32_t, uint32_t, uint32_t,
                    uint32_t, uint32_t, uint32_t, uint32_t, uint32_t);
                reinterpret_cast<Timing>(proxy->listener[3])(proxy->data, proxy,
                    static_cast<uint32_t>(event.id >> 32), static_cast<uint32_t>(event.id),
                    0, 0, 0, 0,
                    static_cast<uint32_t>(event.time >> 32), static_cast<uint32_t>(event.time));
            } else {
                using Timing = void (*)(void*, wl_proxy*, uint32_t, uint32_t, uint32_t,
                    uint32_t, uint32_t, uint32_t, uint32_t, uint32_t, uint32_t);
                reinterpret_cast<Timing>(proxy->listener[0])(proxy->data, proxy, static_cast<uint32_t>(event.id),
                    static_cast<uint32_t>(event.time >> 32), static_cast<uint32_t>(event.time),
                    static_cast<uint32_t>(event.time >> 32), static_cast<uint32_t>(event.time),
                    0, 0, 0, 0);
            }
            ++deliveredEvents;
        }
        const auto pending = objects;
        for (auto* proxy : pending) {
            if (!proxy->pending || !proxy->listener)
                continue;
            if (delayedEvents && proxy->kind == "gamescope_swapchain")
                continue;
            proxy->pending = false;
            if (proxy->kind == "wl_registry") {
                auto callback = reinterpret_cast<void (*)(void*, wl_proxy*, uint32_t, const char*, uint32_t)>(proxy->listener[0]);
                callback(proxy->data, proxy, 1, "wl_compositor", 4);
                if (mode != 2)
                    callback(proxy->data, proxy, 2, "gamescope_swapchain_factory_v2", advertisedVersion);
            } else if (proxy->kind == "wl_callback") {
                reinterpret_cast<void (*)(void*, wl_proxy*, uint32_t)>(proxy->listener[0])(proxy->data, proxy, 0);
            } else if (proxy->kind == "gamescope_swapchain") {
                reinterpret_cast<void (*)(void*, wl_proxy*)>(proxy->listener[2])(proxy->data, proxy);
            }
        }
        return 0;
    }

    wl_proxy* wl_proxy_marshal_array_constructor_versioned(wl_proxy* proxy,
            uint32_t opcode, wl_argument* args, const wl_interface* interface,
            uint32_t version) {
        const std::lock_guard fixtureLock(fixtureMutex);
        return wl_proxy_marshal_array_flags(proxy, opcode, interface, version, 0, args);
    }
    void wl_proxy_marshal_array(wl_proxy* proxy, uint32_t opcode, wl_argument* args) {
        const std::lock_guard fixtureLock(fixtureMutex);
        if (opcode == 0)
            return; // Destructor request; the following proxy destroy owns cleanup.
        wl_proxy_marshal_array_flags(proxy, opcode, nullptr, 1, 0, args);
    }

    xcb_get_geometry_cookie_t xcb_get_geometry(xcb_connection_t*, xcb_drawable_t) {
        const std::lock_guard fixtureLock(fixtureMutex);
        ++geometryQueries;
        return {1};
    }
    xcb_get_geometry_reply_t* xcb_get_geometry_reply(xcb_connection_t*, xcb_get_geometry_cookie_t, xcb_generic_error_t**) {
        const std::lock_guard fixtureLock(fixtureMutex);
        if (mode == 4)
            return nullptr;
        auto* reply = static_cast<xcb_get_geometry_reply_t*>(std::calloc(1, sizeof(xcb_get_geometry_reply_t)));
        reply->root = 42;
        reply->width = windowWidth;
        reply->height = windowHeight;
        return reply;
    }
    xcb_intern_atom_cookie_t xcb_intern_atom(xcb_connection_t*, uint8_t, uint16_t size, const char* name) {
        const std::lock_guard fixtureLock(fixtureMutex);
        if (std::string_view(name, size) == "GAMESCOPE_HDR_OUTPUT_FEEDBACK") {
            ++hdrQueries;
            return {102};
        }
        if (std::string_view(name, size) == "GAMESCOPE_DISPLAY_IS_EXTERNAL")
            return {103};
        return {std::string_view(name, size) == "GAMESCOPE_PID" ? 100u : 101u};
    }
    xcb_intern_atom_reply_t* xcb_intern_atom_reply(xcb_connection_t*, xcb_intern_atom_cookie_t cookie, xcb_generic_error_t**) {
        const std::lock_guard fixtureLock(fixtureMutex);
        if (cookie.sequence == 102 && hdrPropertyFault == 6)
            return nullptr;
        auto* reply = static_cast<xcb_intern_atom_reply_t*>(std::calloc(1, sizeof(xcb_intern_atom_reply_t)));
        reply->atom = mode == 6 || (cookie.sequence == 102 && hdrPropertyFault == 7)
            ? XCB_ATOM_NONE : cookie.sequence;
        return reply;
    }
    xcb_get_property_cookie_t xcb_get_property(xcb_connection_t*, uint8_t, xcb_window_t, xcb_atom_t atom, xcb_atom_t, uint32_t, uint32_t) {
        const std::lock_guard fixtureLock(fixtureMutex);
        return {atom};
    }
    xcb_get_property_reply_t* xcb_get_property_reply(xcb_connection_t*, xcb_get_property_cookie_t cookie, xcb_generic_error_t**) {
        const std::lock_guard fixtureLock(fixtureMutex);
        if (cookie.sequence == 102 && hdrPropertyFault == 5)
            return nullptr;
        auto* reply = static_cast<xcb_get_property_reply_t*>(std::calloc(1, sizeof(xcb_get_property_reply_t) + 4));
        if (cookie.sequence == 102 && !hdrOutputPresent)
            return reply; // A missing property has None type and no value.
        reply->type = XCB_ATOM_CARDINAL;
        reply->format = mode == 9 ? 8 : 32;
        reply->value_len = 1;
        if (cookie.sequence == 102) {
            if (hdrPropertyFault == 1) reply->type = XCB_ATOM_STRING;
            if (hdrPropertyFault == 2) reply->format = 8;
            if (hdrPropertyFault == 3) reply->value_len = 0;
            if (hdrPropertyFault == 4) reply->bytes_after = 4;
        }
        const uint32_t value = cookie.sequence == 100
            ? static_cast<uint32_t>(getpid()) + (mode == 10 ? 1 : 0)
            : cookie.sequence == 102 ? hdrOutput : cookie.sequence == 103 ? externalOutput : serverId;
        std::memcpy(reply + 1, &value, 4);
        return reply;
    }
    void* xcb_get_property_value(const xcb_get_property_reply_t* reply) {
        const std::lock_guard fixtureLock(fixtureMutex);
        return const_cast<xcb_get_property_reply_t*>(reply) + 1;
    }
    xcb_connection_t* XGetXCBConnection(Display*) {
        const std::lock_guard fixtureLock(fixtureMutex);
        return reinterpret_cast<xcb_connection_t*>(1);
    }
}
