/* SPDX-License-Identifier: GPL-3.0-or-later */

#include "adaptive_scheduler.hpp"
#include "generated_frame_delivery.hpp"
#include "presentation_policy.hpp"
#include "profile_update.hpp"

#include <algorithm>
#include <array>
#include <bit>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <exception>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

using namespace mako::layer;
using namespace std::chrono_literals;

namespace {
    using TimePoint = AdaptiveScheduler::TimePoint;

    struct TestFailure {
        std::string message;
    };

    void require(const bool condition, std::string message) {
        if (!condition)
            throw TestFailure{std::move(message)};
    }

    void requireNear(const float actual, const float expected,
            const float tolerance, std::string message) {
        if (std::abs(actual - expected) > tolerance) {
            message += ": expected " + std::to_string(expected) +
                ", got " + std::to_string(actual);
            throw TestFailure{std::move(message)};
        }
    }

    struct RecordingDiagnostics final : AdaptiveSchedulerDiagnostics {
        struct Event {
            std::string operation;
            std::string reason;
            bool accepted{false};
            size_t previousLimit{0};
            size_t testedLimit{0};
            double previousBaseFps{0.0};
            double currentBaseFps{0.0};
            std::chrono::milliseconds duration{0};
        };

        std::vector<Event> events;
        std::vector<AdaptivePlanDiagnostic> plans;
        std::optional<AdaptivePlanDiagnostic> latestPlan;

        [[nodiscard]] bool enabled() const override { return true; }

        void plan(const AdaptivePlanDiagnostic& plan) override {
            this->plans.push_back(plan);
            this->latestPlan = plan;
        }

        void stabilization(const std::string_view reason,
                const std::chrono::steady_clock::duration duration) override {
            this->events.push_back({
                .operation = "stabilization",
                .reason = std::string(reason),
                .duration = std::chrono::duration_cast<
                    std::chrono::milliseconds>(duration),
            });
        }

        void ramp(const size_t previousLimit, const size_t testedLimit,
                double) override {
            this->events.push_back({
                .operation = "ramp",
                .reason = {},
                .previousLimit = previousLimit,
                .testedLimit = testedLimit,
            });
        }

        void rampResult(const bool accepted, const size_t previousLimit,
                const size_t testedLimit, const double previousBaseFps,
                const double currentBaseFps, double,
                double, const std::string_view reason) override {
            this->events.push_back({
                .operation = "ramp-result",
                .reason = std::string(reason),
                .accepted = accepted,
                .previousLimit = previousLimit,
                .testedLimit = testedLimit,
                .previousBaseFps = previousBaseFps,
                .currentBaseFps = currentBaseFps,
            });
        }

        void probeAborted(std::string_view reason, size_t testedLimit) override {
            this->events.push_back({
                .operation = "probe-aborted",
                .reason = std::string(reason),
                .testedLimit = testedLimit,
            });
        }

        void rearm(std::string_view operation, std::string_view reason,
                size_t failures, size_t, std::chrono::steady_clock::duration retry,
                double, double, std::string_view) override {
            this->events.push_back({
                .operation = std::string(operation),
                .reason = std::string(reason),
                .previousLimit = failures,
                .duration = std::chrono::duration_cast<std::chrono::milliseconds>(retry),
            });
        }

        void rampBackoff(size_t testedLimit, size_t failures, double,
                std::chrono::steady_clock::duration retry) override {
            this->events.push_back({
                .operation = "ramp-backoff",
                .reason = {},
                .previousLimit = failures,
                .testedLimit = testedLimit,
                .duration = std::chrono::duration_cast<std::chrono::milliseconds>(retry),
            });
        }

        void targetConstrained(uint32_t, size_t maximumMultiplier,
                double, double) override {
            this->events.push_back({
                .operation = "target-constrained",
                .testedLimit = maximumMultiplier,
            });
        }

        void fastCadenceBurst(double, double, double, size_t, size_t,
                std::chrono::steady_clock::duration) override {
            this->events.push_back({
                .operation = "fast-burst",
                .reason = {},
            });
        }

        void fastCadenceBurstComplete(size_t,
                std::chrono::steady_clock::duration) override {
            this->events.push_back({
                .operation = "fast-burst-complete",
                .reason = {},
            });
        }

        void cadenceRefresh(std::string_view reason, size_t retainedLimit,
                size_t historyFrames) override {
            this->events.push_back({
                .operation = "cadence-refresh",
                .reason = std::string(reason),
                .previousLimit = retainedLimit,
                .testedLimit = historyFrames,
            });
        }

        void recoveryResume(size_t generationLimit,
                std::chrono::steady_clock::duration higherProbeDelay,
                std::string_view reason) override {
            this->events.push_back({
                .operation = "adaptive-recovery-resume-scheduled",
                .reason = std::string(reason),
                .testedLimit = generationLimit,
                .duration = std::chrono::duration_cast<
                    std::chrono::milliseconds>(higherProbeDelay),
            });
        }

        void automaticBaseCapSuppressed(size_t generationLimit, double,
                double, std::string_view reason) override {
            this->events.push_back({
                .operation = "automatic-base-cap-suppressed",
                .reason = std::string(reason),
                .testedLimit = generationLimit,
            });
        }

        void nativeCadenceProbe(std::string_view operation, size_t,
                double, double, size_t) override {
            this->events.push_back({
                .operation = std::string(operation),
            });
        }

        void nearTargetNativePreference(std::string_view operation, uint32_t,
                double, double, double,
                std::chrono::steady_clock::duration,
                std::string_view reason) override {
            this->events.push_back({
                .operation = std::string(operation),
                .reason = std::string(reason),
            });
        }

        void stableCadence(const std::string_view operation,
                const size_t generatedLimit, const double baselineBaseFps,
                const double currentBaseFps, const std::string_view reason) override {
            this->events.push_back({
                .operation = std::string(operation),
                .reason = std::string(reason),
                .testedLimit = operation.starts_with(
                    "adaptive-efficiency-probe"
                ) || operation.starts_with("adaptive-paced-load")
                    ? generatedLimit : 0,
                .previousBaseFps = baselineBaseFps,
                .currentBaseFps = currentBaseFps,
            });
        }

        void rescueStart(size_t previousLimit, double, double, double,
                std::string_view reason) override {
            this->events.push_back({
                .operation = "rescue-start",
                .reason = std::string(reason),
                .previousLimit = previousLimit,
            });
        }

        void rescueComplete(size_t previousLimit, size_t resumedLimit,
                size_t, size_t, double, double,
                std::string_view decision) override {
            this->events.push_back({
                .operation = "rescue-complete",
                .reason = std::string(decision),
                .previousLimit = previousLimit,
                .testedLimit = resumedLimit,
            });
        }

        void automaticBaseCapRestored(size_t previousLimit,
                double baselineBaseFps, double measuredBaseFps,
                std::string_view reason) override {
            this->events.push_back({
                .operation = "automatic-base-cap-restored",
                .reason = std::string(reason),
                .previousLimit = previousLimit,
                .previousBaseFps = baselineBaseFps,
                .currentBaseFps = measuredBaseFps,
            });
        }

        void discontinuityRecoveryComplete(size_t previousLimit, double,
                double, std::string_view decision) override {
            this->events.push_back({
                .operation = "discontinuity-complete",
                .reason = std::string(decision),
                .previousLimit = previousLimit,
            });
        }

        [[nodiscard]] bool contains(const std::string_view operation) const {
            for (const auto& event : this->events) {
                if (event.operation == operation)
                    return true;
            }
            return false;
        }

        [[nodiscard]] const Event* last(const std::string_view operation) const {
            for (auto event = this->events.rbegin();
                    event != this->events.rend(); ++event) {
                if (event->operation == operation)
                    return &*event;
            }
            return nullptr;
        }

        [[nodiscard]] size_t count(const std::string_view operation) const {
            size_t result = 0;
            for (const auto& event : this->events) {
                if (event.operation == operation)
                    result++;
            }
            return result;
        }
    };

    struct Harness {
        RecordingDiagnostics diagnostics;
        AdaptiveScheduler scheduler;
        TimePoint now{};
        std::optional<TimePoint> queuedPresentationDeadline;
        double headroomSourceCapFps{};

        Harness(const uint32_t targetFps, const size_t maximumMultiplier,
                const bool stableCadence = false,
                const AdaptiveRecoveryPolicy recoveryPolicy =
                    AdaptiveRecoveryPolicy::ConservativeHdr,
                const bool dynamicCadenceRecovery = false,
                const std::chrono::milliseconds dynamicCadenceProbeInterval =
                    ls::dynamicCadenceProbeIntervalDuration(
                        ls::GameConfDefaults::
                            dynamicCadenceProbeIntervalSeconds
                    ),
                const std::optional<uint32_t> displayRefreshFps =
                    std::nullopt,
                const bool nearTargetNativePreference = true,
                const bool automaticBaseFpsCap = false,
                const bool validateIntegerPacing = false,
                const bool qualifyTargetNativeCadence = false) :
            scheduler(
                AdaptiveSchedulerConfig{
                    .targetFps = targetFps,
                    .maximumMultiplier = maximumMultiplier,
                    .generatedFrameCapacity = GeneratedFramePlan::capacity,
                    .stableCadence = stableCadence,
                    .automaticBaseFpsCap = automaticBaseFpsCap,
                    .nearTargetNativePreference =
                        nearTargetNativePreference,
                    .qualifyTargetNativeCadence = qualifyTargetNativeCadence,
                    .validateIntegerPacing = validateIntegerPacing,
                    .dynamicCadenceRecovery = dynamicCadenceRecovery,
                    .dynamicCadenceProbeInterval =
                        dynamicCadenceProbeInterval,
                    .displayRefreshFps = displayRefreshFps,
                    .recoveryPolicy = recoveryPolicy,
                },
                &this->diagnostics
            ) {}

        void start() {
            this->scheduler.beginStabilization(this->now, "startup");
            for (size_t i = 0;
                    i < AdaptiveScheduler::historyWarmupFrameCount(); ++i) {
                this->now += 16ms;
                this->scheduler.consumeHistoryWarmupFrame(this->now);
            }
        }

        AdaptiveFramePlan frame(const std::chrono::nanoseconds interval,
                const bool acquireBackoff = false,
                const bool reportDelivery = true) {
            this->now += interval;
            const auto plan = this->scheduler.planFrame(this->now, acquireBackoff,
                std::nullopt, std::nullopt, this->queuedPresentationDeadline,
                this->headroomSourceCapFps);
            // Ordinary workload simulations deliver their plan. Fault tests
            // opt out before supplying their own missing/partial observation.
            if (reportDelivery)
                this->scheduler.reportGeneratedFrameDelivery({
                    plan.size(), plan.size(),
                });
            return plan;
        }

        AdaptiveFramePlan frameAtFps(const double fps,
                const bool acquireBackoff = false,
                const bool reportDelivery = true) {
            return this->frame(std::chrono::duration_cast<std::chrono::nanoseconds>(
                std::chrono::duration<double>(1.0 / fps)
            ), acquireBackoff, reportDelivery);
        }

        AdaptiveFramePlan deliveredFrameAtFps(const double fps,
                const std::optional<bool> delivered = true) {
            this->now += std::chrono::duration_cast<std::chrono::nanoseconds>(
                std::chrono::duration<double>(1.0 / fps)
            );
            if (this->scheduler.historyWarmupActive()) {
                this->scheduler.consumeHistoryWarmupFrame(this->now);
                return {};
            }
            auto plan = this->scheduler.planFrame(this->now, false,
                std::nullopt, std::nullopt, this->queuedPresentationDeadline,
                this->headroomSourceCapFps);
            if (delivered)
                this->scheduler.reportGeneratedFrameDelivery({
                    plan.size(), *delivered ? plan.size() : 0,
                });
            return plan;
        }

        AdaptiveFramePlan runAtFps(const double fps,
                const std::chrono::nanoseconds duration,
                const bool reportDelivery = true) {
            AdaptiveFramePlan result;
            const size_t frames = static_cast<size_t>(
                std::ceil(fps * std::chrono::duration<double>(duration).count())
            );
            for (size_t i = 0; i < frames; ++i)
                result = this->frameAtFps(fps, false, reportDelivery);
            return result;
        }
    };

    void requireValidTimestamps(const AdaptiveFramePlan& timestamps,
            const size_t capacity) {
        require(timestamps.size() <= capacity,
            "generated timestamps exceeded destination capacity");
        float previous = 0.0F;
        for (const float timestamp : timestamps) {
            require(timestamp > previous,
                "generated timestamps were not strictly increasing");
            require(timestamp < 1.0F,
                "generated timestamp reached or exceeded the real frame");
            previous = timestamp;
        }
    }

    class TraceFingerprint {
    public:
        void mix(const uint64_t value) {
            this->value ^= value;
            this->value *= 1099511628211ULL;
        }

        void mix(const std::string_view text) {
            for (const char character : text)
                this->mix(static_cast<unsigned char>(character));
            this->mix(0xffU);
        }

        [[nodiscard]] uint64_t get() const { return this->value; }

    private:
        uint64_t value{1469598103934665603ULL};
    };

    uint64_t characterizeTrace(const uint32_t targetFps,
            const size_t maximumMultiplier, const bool stableCadence,
            const AdaptiveRecoveryPolicy recoveryPolicy,
            const std::vector<std::chrono::nanoseconds>& intervals) {
        Harness harness(
            targetFps, maximumMultiplier, stableCadence, recoveryPolicy
        );
        harness.start();
        TraceFingerprint fingerprint;
        for (const auto interval : intervals) {
            const auto plan = harness.frame(interval, false, false);
            harness.scheduler.reportGeneratedFrameDelivery({
                .requested = plan.size(),
                .acceptedForPresentation = plan.size(),
            });
            fingerprint.mix(plan.size());
            for (const float timestamp : plan)
                fingerprint.mix(std::bit_cast<uint32_t>(timestamp));

            const auto snapshot = harness.scheduler.snapshot();
            fingerprint.mix(static_cast<uint8_t>(snapshot.phase));
            fingerprint.mix(snapshot.generationLimit);
            fingerprint.mix(snapshot.validatedGenerationLimit);
            fingerprint.mix(snapshot.stableCadenceLimit.has_value());
            fingerprint.mix(snapshot.stableCadenceLimit.value_or(0));
            fingerprint.mix(snapshot.historyWarmupRemaining);
            fingerprint.mix(snapshot.rampEvaluationActive);
            fingerprint.mix(snapshot.rearmRequired);
            fingerprint.mix(snapshot.discontinuityRecoveryActive);
            fingerprint.mix(snapshot.automaticBaseCapSuppressed);
        }
        for (const auto& event : harness.diagnostics.events) {
            fingerprint.mix(event.operation);
            fingerprint.mix(event.reason);
            fingerprint.mix(event.accepted);
            fingerprint.mix(event.previousLimit);
            fingerprint.mix(event.testedLimit);
        }
        return fingerprint.get();
    }

    std::vector<std::chrono::nanoseconds> constantTrace(
            const std::chrono::nanoseconds interval, const size_t frames) {
        return std::vector<std::chrono::nanoseconds>(frames, interval);
    }

    void testCharacterizationTraceCorpus() {
        const auto steady45 = characterizeTrace(
            90, 3, true, AdaptiveRecoveryPolicy::OrderedSdr,
            constantTrace(22'222'222ns, 540)
        );
        const auto boundary425 = characterizeTrace(
            90, 3, true, AdaptiveRecoveryPolicy::OrderedSdr,
            constantTrace(23'529'411ns, 510)
        );
        const auto boundary4275 = characterizeTrace(
            90, 3, true, AdaptiveRecoveryPolicy::OrderedSdr,
            constantTrace(23'391'812ns, 513)
        );
        const auto boundary43 = characterizeTrace(
            90, 3, true, AdaptiveRecoveryPolicy::OrderedSdr,
            constantTrace(23'255'813ns, 516)
        );

        std::vector<std::chrono::nanoseconds> disruptionTrace;
        disruptionTrace.reserve(640);
        constexpr std::array cadence{
            17ms, 16ms, 17ms, 16ms, 50ms, 16ms, 17ms, 200ms,
            16ms, 16ms, 17ms, 1ms, 1ms, 16ms, 33ms, 34ms,
        };
        for (size_t replay = 0; replay < 40; ++replay) {
            disruptionTrace.insert(
                disruptionTrace.end(), cadence.begin(), cadence.end()
            );
        }
        const auto disruptions = characterizeTrace(
            120, 4, true, AdaptiveRecoveryPolicy::ConservativeHdr,
            disruptionTrace
        );

        require(steady45 == 2958441852441804317ULL,
            "45-to-90 characterization changed: " +
                std::to_string(steady45));
        // Higher-rung traces include the delivered lower-load qualification;
        // the target-satisfied 2x and disruption traces retain their identities.
        require(boundary425 == 10506803357898072879ULL,
            "42.5-to-90 characterization changed: " +
                std::to_string(boundary425));
        require(boundary4275 == 15426359556047636635ULL,
            "42.75-to-90 characterization changed: " +
                std::to_string(boundary4275));
        require(boundary43 == 17608479708632752434ULL,
            "43-to-90 characterization changed: " +
                std::to_string(boundary43));
        require(disruptions == 3251577126843654263ULL,
            "disruption characterization changed: " +
                std::to_string(disruptions));
    }

    void testStartupWarmupIsExplicit() {
        Harness harness(120, 3);
        require(harness.scheduler.historyWarmupRemaining() == 3,
            "Adaptive must start with three temporal-history frames");
        require(harness.scheduler.snapshot().phase ==
                AdaptiveSchedulerPhase::HistoryWarmup,
            "startup history warm-up was not exposed as scheduler state");
        harness.start();
        require(!harness.scheduler.historyWarmupActive(),
            "startup history warm-up did not complete deterministically");
        require(harness.scheduler.snapshot().phase ==
                AdaptiveSchedulerPhase::Stabilizing,
            "scheduler left startup stabilization too early");
    }

    void testSwapchainRecreationUsesBoundedSettlingGuard() {
        Harness harness(60, 2);
        harness.scheduler.beginStabilization(
            harness.now, "swapchain-recreation"
        );
        const auto* recreation = harness.diagnostics.last("stabilization");
        require(recreation && recreation->reason == "swapchain-recreation" &&
                recreation->duration == 1s,
            "known swapchain replacement did not use the one-second recovery guard");

        Harness startup(60, 2);
        startup.scheduler.beginStabilization(startup.now, "startup");
        const auto* coldStart = startup.diagnostics.last("stabilization");
        require(coldStart && coldStart->duration == 3s,
            "cold startup lost its three-second splash-screen guard");
    }

    void testTransportRecoveryInvalidatesStableCadence() {
        Harness harness(
            120, 3, true, AdaptiveRecoveryPolicy::OrderedSdr
        );
        harness.start();
        harness.runAtFps(60.0, 12s);
        const auto before = harness.scheduler.snapshot();
        require(before.phase == AdaptiveSchedulerPhase::StableCadence &&
                before.stableCadenceLimit == 1,
            "precondition failed: ordered Smooth Cadence was not accepted");

        harness.scheduler.beginTransportRecovery(harness.now);
        const auto after = harness.scheduler.snapshot();
        require(after.phase == AdaptiveSchedulerPhase::Stabilizing &&
                !after.stableCadenceLimit &&
                after.generationLimit == 0 &&
                after.validatedGenerationLimit == 0,
            "transport recovery retained stale stable-cadence or pacing state");
        const auto* stabilization = harness.diagnostics.last("stabilization");
        require(stabilization &&
                stabilization->reason == "generated-image-recovery" &&
                stabilization->duration == 1s,
            "transport recovery did not request one fresh cadence qualification");
    }

    void testExplicitAcquireTimeoutPreservesValidatedCadence() {
        for (const size_t maximumMultiplier : {2U, 4U}) {
            for (const double baseFps : {45.0, 60.0}) {
                Harness harness(
                    90, maximumMultiplier, false,
                    AdaptiveRecoveryPolicy::OrderedSdr
                );
                OrderedAcquireRecovery recovery;
                harness.start();
                harness.runAtFps(baseFps, 12s);
                const auto validated = harness.scheduler.snapshot();
                require(validated.validatedGenerationLimit == 1,
                    "precondition failed: 90 FPS delivery was not validated");

                const auto miss = recovery.observe(harness.now, true);
                require(miss.quarantined && recovery.active(),
                    "explicit acquire timeout did not enter transport backoff");
                require(harness.scheduler.snapshot().validatedGenerationLimit ==
                        validated.validatedGenerationLimit,
                    "transport timeout itself demoted accepted Adaptive state");
                const auto retryAt = harness.now + miss.retryDelay;
                const auto retry = recovery.beforePresent(retryAt);
                require(retry.boundedAcquireProbe,
                    "transport timeout did not reach its bounded retry");
                const auto ready = recovery.observe(
                    retryAt, false, false, true
                );
                require(ready.recovered && !recovery.active(),
                    "successful bounded retry did not end transport recovery");
                require(harness.scheduler.snapshot().validatedGenerationLimit ==
                        validated.validatedGenerationLimit,
                    "ordinary direct recovery changed the validated multiplier");
            }
        }
    }

    void testBusyWarmupNotificationIsIdempotent() {
        Harness harness(120, 3);
        harness.scheduler.consumeHistoryWarmupFrame(harness.now + 16ms);
        require(harness.scheduler.historyWarmupRemaining() == 2,
            "precondition failed: initial warm-up did not advance");
        harness.scheduler.ensureHistoryWarmup(3, true);
        require(harness.scheduler.historyWarmupRemaining() == 2,
            "a repeated busy notification restarted active warm-up");
        harness.scheduler.consumeHistoryWarmupFrame(harness.now + 32ms);
        require(harness.scheduler.historyWarmupRemaining() == 1,
            "warm-up did not continue after an intermittent busy frame");
    }

    void testTransientBusyFrameDoesNotRearmCompletedWarmup() {
        Harness harness(120, 3);
        PipelineBusyRecovery pipelineBusy;

        for (size_t frame = 0;
                frame < AdaptiveScheduler::historyWarmupFrameCount(); ++frame) {
            harness.now += 16ms;
            harness.scheduler.consumeHistoryWarmupFrame(harness.now);

            const auto busy = pipelineBusy.reportBusy(harness.now + 8ms);
            if (busy.requestHistoryWarmup) {
                harness.scheduler.ensureHistoryWarmup(
                    AdaptiveScheduler::historyWarmupFrameCount(), true
                );
            }
            static_cast<void>(pipelineBusy.reportReady(harness.now + 16ms));
        }

        require(!harness.scheduler.historyWarmupActive(),
            "normal GPU overlap rearmed a completed Adaptive warm-up");
        require(harness.scheduler.historyWarmupRemaining() == 0,
            "Adaptive warm-up did not reach a generation-eligible state");
    }

    void testInvalidConfigurationIsRejectedAtBoundary() {
        bool invalidTargetRejected = false;
        try {
            AdaptiveScheduler scheduler({
                .targetFps = 0,
                .maximumMultiplier = 3,
                .generatedFrameCapacity = 3,
            });
            static_cast<void>(scheduler);
        } catch (const std::invalid_argument&) {
            invalidTargetRejected = true;
        }
        require(invalidTargetRejected,
            "scheduler accepted an invalid target FPS");

        bool invalidMultiplierRejected = false;
        try {
            AdaptiveScheduler scheduler({
                .targetFps = 120,
                .maximumMultiplier = 6,
                .generatedFrameCapacity = 3,
            });
            static_cast<void>(scheduler);
        } catch (const std::invalid_argument&) {
            invalidMultiplierRejected = true;
        }
        require(invalidMultiplierRejected,
            "scheduler accepted an invalid maximum multiplier");

        bool invalidCapacityRejected = false;
        try {
            AdaptiveScheduler scheduler({
                .targetFps = 120,
                .maximumMultiplier = 5,
                .generatedFrameCapacity = 5,
            });
            static_cast<void>(scheduler);
        } catch (const std::invalid_argument&) {
            invalidCapacityRejected = true;
        }
        require(invalidCapacityRejected,
            "scheduler accepted more than four generated-frame slots");
    }

    void testGeneratedDeliveryWindowContract() {
        GeneratedDeliveryWindow window;
        require(window.healthy(),
            "an empty delivery window should be healthy");

        window.record({.requested = 1, .acceptedForPresentation = 0});
        require(!window.healthy(),
            "complete loss in a short window was incorrectly tolerated");

        window.reset();
        window.record({.requested = 19, .acceptedForPresentation = 18});
        require(!window.healthy(),
            "short evaluation windows must require complete delivery");

        window.reset();
        window.record({.requested = 20, .acceptedForPresentation = 19});
        require(window.healthy(),
            "one isolated miss in a full window should be tolerated");
        window.record({.requested = 0, .acceptedForPresentation = 20});
        require(window.healthy(),
            "accepted-frame clamping changed delivery health");

        window.reset();
        window.record({.requested = 1, .acceptedForPresentation = 2});
        window.record({.requested = 1, .acceptedForPresentation = 0});
        require(window.acceptedForPresentation() == 1 && !window.healthy(),
            "surplus acceptance from one sample hid a later miss");

        window.reset();
        window.record({.requested = 20, .acceptedForPresentation = 18});
        require(!window.healthy(),
            "persistent delivery pressure was incorrectly tolerated");
    }

    void testReplacementBackendStabilizationIsBounded() {
        using Clock = ReplacementBackendStabilization::Clock;
        const auto start = Clock::time_point{};

        ReplacementBackendStabilization coldStart;
        coldStart.begin(false, true, start);
        const auto coldDecision = coldStart.beforeFrame(start);
        require(!coldStart.active() && !coldDecision.bypassBackend &&
                !coldDecision.resumed,
            "A cold swapchain was incorrectly given replacement-only backend stabilization");

        ReplacementBackendStabilization disabledReplacement;
        disabledReplacement.begin(true, false, start);
        const auto disabledDecision = disabledReplacement.beforeFrame(
            start + ReplacementBackendStabilization::duration * 2
        );
        require(!disabledReplacement.active() &&
                !disabledDecision.bypassBackend && !disabledDecision.resumed,
            "A replacement armed private-backend stabilization while Frame Generation was disabled");

        ReplacementBackendStabilization replacement;
        replacement.begin(true, true, start);
        const auto first = replacement.beforeFrame(start);
        const auto repeated = replacement.beforeFrame(
            start + ReplacementBackendStabilization::duration / 2
        );
        const auto resumed = replacement.beforeFrame(
            start + ReplacementBackendStabilization::duration
        );
        const auto completed = replacement.beforeFrame(
            start + ReplacementBackendStabilization::duration * 2
        );
        require(first.bypassBackend && first.diagnostic &&
                repeated.bypassBackend && !repeated.diagnostic &&
                !resumed.bypassBackend && resumed.resumed &&
                !replacement.active() && !completed.bypassBackend &&
                !completed.resumed,
            "Replacement backend stabilization did not bypass once, resume once, and retire at its fixed deadline");
    }

    void testSteadySixtyRampsToTwoXFor120Target() {
        Harness harness(120, 3);
        harness.start();
        const auto timestamps = harness.runAtFps(60.0, 7s);
        requireValidTimestamps(timestamps, 3);
        require(timestamps.size() == 1,
            "60 FPS toward 120 FPS should settle at one generated frame");
        requireNear(timestamps.front(), 0.5F, 0.0001F,
            "2x interpolation timestamp changed");
        const auto snapshot = harness.scheduler.snapshot();
        require(snapshot.validatedGenerationLimit == 1,
            "2x level was not validated after its evaluation window");
        require(!snapshot.rampEvaluationActive,
            "steady 2x policy remained in a transient probe");
        require(snapshot.targetOutputClockActive &&
                std::abs(snapshot.targetOutputPhaseErrorOutputs) <= 0.5,
            "steady 2x output was not phase-bounded by the target clock");
    }

    void testFractionalTargetClockAssignsWorkToLongIntervals() {
        Harness harness(90, 2);
        harness.start();
        harness.runAtFps(60.0, 7s);
        require(harness.scheduler.snapshot().validatedGenerationLimit == 1,
            "precondition failed: fractional clock had no generated capacity");

        harness.scheduler.resetTiming(harness.now);
        constexpr auto shortInterval = 13ms;
        constexpr auto longInterval = 20'333'333ns;
        for (size_t pair = 0; pair < 20; ++pair) {
            harness.frame(shortInterval);
            harness.frame(longInterval);
        }
        size_t scheduledOutputs = 0;
        double elapsedSeconds = 0.0;
        std::vector<double> plannedIntervalsMilliseconds;
        std::vector<double> legacyPlannedIntervalsMilliseconds;
        plannedIntervalsMilliseconds.reserve(540);
        legacyPlannedIntervalsMilliseconds.reserve(540);

        for (size_t pair = 0; pair < 180; ++pair) {
            const auto shortPlan = harness.frame(shortInterval);
            const auto longPlan = harness.frame(longInterval);
            require(shortPlan.empty(),
                "fractional clock assigned the extra output to a short interval");
            require(longPlan.size() == 1,
                "fractional clock did not subdivide the longer interval");
            requireNear(longPlan.front(), 0.5F, 0.0001F,
                "fractional target clock changed the minimum-variance timestamp");

            scheduledOutputs += shortPlan.size() + longPlan.size() + 2;
            elapsedSeconds += std::chrono::duration<double>(
                shortInterval + longInterval
            ).count();
            plannedIntervalsMilliseconds.push_back(13.0);
            plannedIntervalsMilliseconds.push_back(20.333333 / 2.0);
            plannedIntervalsMilliseconds.push_back(20.333333 / 2.0);
            legacyPlannedIntervalsMilliseconds.push_back(13.0 / 2.0);
            legacyPlannedIntervalsMilliseconds.push_back(13.0 / 2.0);
            legacyPlannedIntervalsMilliseconds.push_back(20.333333);

            const auto snapshot = harness.scheduler.snapshot();
            require(snapshot.targetOutputClockActive &&
                    std::abs(snapshot.targetOutputPhaseErrorOutputs) <=
                        0.5 + 1e-9,
                "fractional target-clock phase escaped its half-output bound");
        }

        const double outputFps = static_cast<double>(scheduledOutputs) /
            elapsedSeconds;
        require(std::abs(outputFps - 90.0) < 0.001,
            "fractional target clock lost the requested long-term output rate");

        const auto populationStandardDeviation = [](const auto& samples) {
            double mean = 0.0;
            for (const double sample : samples)
                mean += sample;
            mean /= static_cast<double>(samples.size());
            double squaredDeviation = 0.0;
            for (const double sample : samples) {
                const double delta = sample - mean;
                squaredDeviation += delta * delta;
            }
            return std::sqrt(
                squaredDeviation / static_cast<double>(samples.size())
            );
        };
        const double standardDeviation = populationStandardDeviation(
            plannedIntervalsMilliseconds
        );
        const double legacyStandardDeviation = populationStandardDeviation(
            legacyPlannedIntervalsMilliseconds
        );
        require(standardDeviation < 1.5 &&
                standardDeviation < legacyStandardDeviation * 0.25,
            "noisy fractional plan retained excessive temporal-spacing variance");

        require(harness.diagnostics.latestPlan.has_value(),
            "fractional pacing aggregate was not reported");
        const auto& pacing = *harness.diagnostics.latestPlan;
        require(pacing.targetOutputClockActive &&
                pacing.pacingSourceSamples > 0 &&
                pacing.generatedCountChanges > 0,
            "fractional pacing aggregate omitted target-clock activity");
        require(pacing.requestedIntervalStdDevMilliseconds < 1.5 &&
                std::abs(pacing.requestedIntervalP99Milliseconds - 13.5) <
                    1e-6,
            "fractional pacing aggregate did not expose the improved outliers");
        require(pacing.targetPhaseErrorSamples == pacing.pacingSourceSamples,
            "fractional pacing aggregate omitted phase-error sample coverage");
        require(pacing.targetPhaseErrorMaximumMilliseconds <=
                1000.0 / 90.0 / 2.0 + 1e-6,
            "reported target-clock error exceeded half an output interval");
    }

    void testFractionalTargetClockStartsCenterAligned() {
        Harness harness(
            120, 2, false, AdaptiveRecoveryPolicy::OrderedSdr
        );
        harness.start();
        harness.runAtFps(90.0, 7s);
        require(harness.scheduler.snapshot().validatedGenerationLimit == 1,
            "precondition failed: centered clock had no generated capacity");

        harness.scheduler.resetTiming(harness.now);
        constexpr auto sourceInterval = 11'111'111ns;
        constexpr size_t sourceFrames = 600;
        size_t scheduledOutputs = 0;
        double elapsedSeconds = 0.0;
        double maximumAbsolutePrefixError = 0.0;
        bool sawRealOnly = false;
        bool sawGenerated = false;

        for (size_t frame = 0; frame < sourceFrames; ++frame) {
            const auto plan = harness.frame(sourceInterval);
            requireValidTimestamps(plan, 1);
            scheduledOutputs += plan.size() + 1;
            elapsedSeconds +=
                std::chrono::duration<double>(sourceInterval).count();
            const double requestedOutputs =
                elapsedSeconds * 120.0;
            maximumAbsolutePrefixError = std::max(
                maximumAbsolutePrefixError,
                std::abs(
                    static_cast<double>(scheduledOutputs) -
                    requestedOutputs
                )
            );
            sawRealOnly |= plan.empty();
            sawGenerated |= !plan.empty();
        }

        require(sawRealOnly && sawGenerated,
            "centered Fractional clock did not retain its 0/1 cadence");
        require(maximumAbsolutePrefixError <= 0.5 + 1e-6,
            "Fractional output demand lagged by more than half an output");
        require(std::abs(
                static_cast<double>(scheduledOutputs) / elapsedSeconds - 120.0
            ) < 0.2,
            "centered Fractional clock changed the long-term target rate");
    }

    void testOrderedFractionalClockDoesNotDeferFifoWork() {
        Harness harness(
            120, 2, false, AdaptiveRecoveryPolicy::OrderedSdr
        );
        harness.start();
        harness.runAtFps(90.0, 7s);
        require(harness.scheduler.snapshot().validatedGenerationLimit == 1,
            "precondition failed: ordered clock had no generated capacity");

        harness.scheduler.resetTiming(harness.now);
        constexpr std::array<std::chrono::nanoseconds, 4> sourceTrace{
            9ms, 12ms, 10ms, 13ms,
        };
        size_t scheduledOutputs = 0;
        double requestedOutputs = 0.0;
        double maximumAbsolutePrefixError = 0.0;
        for (size_t cycle = 0; cycle < 300; ++cycle) {
            for (const auto interval : sourceTrace) {
                const auto plan = harness.frame(interval);
                requireValidTimestamps(plan, 1);
                scheduledOutputs += plan.size() + 1;
                const auto snapshot = harness.scheduler.snapshot();
                require(snapshot.targetOutputClockActive &&
                        snapshot.smoothedBaseFps > 0.0,
                    "ordered noisy trace left Fractional scheduling");
                require(!snapshot.targetOutputDeferredBudgetOutput,
                    "ordered FIFO moved earned work behind its target queue");
                requestedOutputs += 120.0 / snapshot.smoothedBaseFps;
                maximumAbsolutePrefixError = std::max(
                    maximumAbsolutePrefixError,
                    std::abs(
                        static_cast<double>(scheduledOutputs) -
                        requestedOutputs
                    )
                );
            }
        }
        require(maximumAbsolutePrefixError <= 0.5 + 1e-6,
            "ordered Fractional workload escaped its half-output prefix bound");
    }

    void testFractionalTargetClockIgnoresMarginalPlacementBenefit() {
        Harness harness(120, 2);
        harness.start();
        harness.runAtFps(90.5, 7s);
        require(harness.scheduler.snapshot().validatedGenerationLimit == 1,
            "precondition failed: marginal-placement clock had no capacity");

        harness.scheduler.resetTiming(harness.now);
        bool sawRealOnly = false;
        bool sawGenerated = false;
        for (size_t frame = 0; frame < 600; ++frame) {
            const auto plan = harness.frameAtFps(90.5);
            requireValidTimestamps(plan, 1);
            sawRealOnly |= plan.empty();
            sawGenerated |= !plan.empty();
            require(!harness.scheduler.snapshot().
                    targetOutputDeferredBudgetOutput,
                "marginal high-base spacing noise relocated earned work");
        }
        require(sawRealOnly && sawGenerated,
            "marginal-placement guard changed Fractional target delivery");
    }

    void testTargetClockCoversSteadyAndNoisyCadenceMatrix() {
        struct PacingCase {
            double baseFps;
            uint32_t targetFps;
        };
        constexpr std::array cases{
            PacingCase{45.0, 90},
            PacingCase{60.0, 90},
            PacingCase{60.0, 120},
            PacingCase{80.0, 120},
            PacingCase{89.0, 120},
        };

        for (const auto pacingCase : cases) {
            Harness harness(pacingCase.targetFps, 2);
            harness.start();
            harness.runAtFps(pacingCase.baseFps, 7s);
            require(harness.scheduler.snapshot().validatedGenerationLimit == 1,
                "pacing matrix did not validate 2x capacity");

            size_t steadyOutputs = 0;
            bool steadySawRealOnly = false;
            bool steadySawGenerated = false;
            constexpr size_t steadyFrames = 240;
            for (size_t frame = 0; frame < steadyFrames; ++frame) {
                const auto plan = harness.frameAtFps(pacingCase.baseFps);
                requireValidTimestamps(plan, 1);
                steadyOutputs += plan.size() + 1;
                steadySawRealOnly |= plan.empty();
                steadySawGenerated |= !plan.empty();
            }
            const double steadyOutputFps =
                static_cast<double>(steadyOutputs) /
                (static_cast<double>(steadyFrames) / pacingCase.baseFps);
            require(std::abs(
                    steadyOutputFps -
                        static_cast<double>(pacingCase.targetFps)
                ) < 0.3,
                "steady pacing matrix lost its requested target average at " +
                    std::to_string(pacingCase.baseFps) + " to " +
                    std::to_string(pacingCase.targetFps) + ": " +
                    std::to_string(steadyOutputFps));
            const bool integerRelationship =
                (pacingCase.baseFps == 45.0 &&
                 pacingCase.targetFps == 90) ||
                (pacingCase.baseFps == 60.0 &&
                 pacingCase.targetFps == 120);
            if (integerRelationship) {
                require(!steadySawRealOnly && steadySawGenerated,
                    "integer pacing matrix did not retain constant 2x");
            } else {
                require(steadySawRealOnly && steadySawGenerated,
                    "fractional steady pacing did not exercise both counts");
            }

            harness.scheduler.resetTiming(harness.now);
            const auto meanInterval = std::chrono::duration<double>(
                1.0 / pacingCase.baseFps
            );
            const auto shortInterval =
                std::chrono::duration_cast<std::chrono::nanoseconds>(
                    meanInterval * 0.9
                );
            const auto longInterval =
                std::chrono::duration_cast<std::chrono::nanoseconds>(
                    meanInterval * 1.1
                );
            size_t scheduledOutputs = 0;
            double elapsedSeconds = 0.0;

            for (size_t pair = 0; pair < 240; ++pair) {
                for (const auto interval : {shortInterval, longInterval}) {
                    const auto plan = harness.frame(interval);
                    requireValidTimestamps(plan, 1);
                    scheduledOutputs += plan.size() + 1;
                    elapsedSeconds += std::chrono::duration<double>(
                        interval
                    ).count();
                    const auto snapshot = harness.scheduler.snapshot();
                    require(snapshot.targetOutputClockActive &&
                            std::abs(snapshot.targetOutputPhaseErrorOutputs) <=
                                0.5 + 1e-9,
                        "noisy pacing matrix escaped the target-clock phase bound");
                }
            }

            const double outputFps =
                static_cast<double>(scheduledOutputs) / elapsedSeconds;
            require(std::abs(
                    outputFps - static_cast<double>(pacingCase.targetFps)
                ) < 0.3,
                "noisy pacing matrix lost its requested target average at " +
                    std::to_string(pacingCase.baseFps) + " to " +
                    std::to_string(pacingCase.targetFps) + ": " +
                    std::to_string(outputFps));
        }
    }

    void testAdaptiveNativePresentationAboveTarget() {
        // Join the scheduler, applied policy and production output timeline.
        // Submission backpressure feeds the next source interval, reproducing
        // a native source held at target despite having no generated output.
        struct Scenario {
            uint32_t targetFps;
            uint32_t refreshHz;
            double nativeFps;
            size_t maximumMultiplier;
            uint32_t baseFpsCap{0};
        };
        constexpr std::array scenarios{
            Scenario{60, 90, 60., 2},
            Scenario{60, 90, 75., 2},
            Scenario{60, 90, 90., 2},
            Scenario{60, 90, 150., 2},
            Scenario{90, 120, 110., 3},
            Scenario{120, 144, 144., 4},
            Scenario{30, 60, 45., 5},
            Scenario{60, 90, 75., 2, 90},
            Scenario{60, 120, 150., 2, 90},
            Scenario{60, 90, 75., 2, 60},
            Scenario{60, 90, 150., 2, 120},
            Scenario{100, 144, 110., 3, 120},
        };
        for (const bool bridge : {false, true}) {
            for (const bool smooth : {false, true}) {
                for (const auto& [targetFps, refreshHz, nativeFps, maximumMultiplier,
                        baseFpsCap] : scenarios) {
                    for (const bool recovery : {false, true}) {
                        // Dynamic Cadence Recovery is disabled by an effective cap.
                        if (recovery && baseFpsCap > 0)
                            continue;
                        ls::GameConf profile;
                        profile.frame_generation_provisioned = true;
                        profile.frame_generation_enabled = true;
                        profile.adaptive = true;
                        profile.target_fps = targetFps;
                        profile.adaptive_max_multiplier = maximumMultiplier;
                        profile.adaptive_auto_base_fps_cap = false;
                        profile.adaptive_fractional_real_frame_priority =
                            ls::AdaptiveFractionalRealFramePriority::Auto;
                        profile.base_fps_cap = baseFpsCap;
                        profile.dynamic_cadence_recovery = recovery;
                        const auto schedulerPolicy = generationSchedulerPolicy(profile, refreshHz);
                        require(schedulerPolicy.has_value(), "Adaptive scheduler policy is absent");
                        Harness harness(targetFps, maximumMultiplier, smooth,
                            AdaptiveRecoveryPolicy::OrderedSdr, recovery, 2s, refreshHz,
                            schedulerPolicy->nearTargetNativePreference, false, false,
                            schedulerPolicy->qualifyTargetNativeCadence);
                        harness.start();
                        RealFramePacer sourcePacer;
                        OrderedPresentTimeline timeline;
                        TimePoint lastOutput{};
                        uint64_t serial = 0;
                        // Clang 14 needs an init-capture for a structured binding.
                        auto present = [&, refreshHz = refreshHz](const double sourceFps) {
                            const auto renderInterval =
                                std::chrono::duration_cast<TimePoint::duration>(
                                    std::chrono::duration<double>(1.0 / sourceFps));
                            const auto arrival = harness.now + renderInterval;
                            const auto deadline = sourcePacer.schedule(arrival,
                                effectiveBaseFpsCap(profile,
                                    harness.scheduler.snapshot(), refreshHz));
                            // Feed the production source-cap wait into the
                            // same clock as rendering and presentation waits.
                            harness.now += deadline - arrival;
                            const auto plan = harness.deliveredFrameAtFps(sourceFps);
                            const auto policy = gamescopeBridgeOutputPolicy(
                                profile, refreshHz, harness.scheduler.snapshot());
                            if (bridge)
                                timeline.observeSourceBatch(harness.now, ++serial);
                            for (size_t i = 0; i <= plan.size(); ++i) {
                                const auto slot = timeline.schedule(harness.now,
                                    policy.outputFps, refreshHz, plan.size() + 1,
                                    policy.generatedTimeline);
                                require(slot && slot->presentAt > lastOutput,
                                    "Adaptive transition overtook queued output");
                                harness.now = slot->submitAt;
                                lastOutput = slot->presentAt;
                            }
                            harness.queuedPresentationDeadline = lastOutput;
                            return plan;
                        };
                        const auto settledAt = harness.now + 8s;
                        while (harness.now < settledAt)
                            present(nativeFps);
                        require(harness.scheduler.snapshot().nearTargetNativePreference,
                            "at/above-target source never qualified native presentation");
                        const auto firstOutput = lastOutput;
                        constexpr size_t measuredFrames = 450;
                        for (size_t frame = 0; frame < measuredFrames; ++frame)
                            require(present(nativeFps).empty(),
                                "target-capable native source generated an unnecessary frame");
                        const double outputFps = measuredFrames /
                            std::chrono::duration<double>(lastOutput - firstOutput).count();
                        const double expectedFps = std::min({nativeFps, double(refreshHz),
                            baseFpsCap > 0 ? double(baseFpsCap) : nativeFps});
                        require(std::abs(outputFps - expectedFps) < 0.1,
                            "Automatic presentation lost native FPS or its source cap: " +
                                std::to_string(outputFps) + " expected=" + std::to_string(expectedFps));

                        // A completion-paced caller must not retain a generated
                        // readiness lead after qualification, in either transport.
                        const auto nativePolicy = gamescopeBridgeOutputPolicy(
                            profile, refreshHz, harness.scheduler.snapshot());
                        const auto afterWait = lastOutput +
                            std::chrono::duration_cast<TimePoint::duration>(
                                std::chrono::duration<double>(2.0 / refreshHz));
                        const auto nativeSlot = timeline.schedule(afterWait,
                            nativePolicy.outputFps, refreshHz, 1, nativePolicy.generatedTimeline);
                        require(nativeSlot && nativeSlot->presentAt == afterWait,
                            "native Automatic retained generated-work readiness delay");
                        lastOutput = nativeSlot->presentAt;
                        harness.now = afterWait;

                        bool resumedGeneration = false;
                        const auto lowEnd = harness.now + 8s;
                        while (harness.now < lowEnd) {
                            const auto plan = present(double(targetFps) / 2.0);
                            if (!plan.empty()) {
                                const auto policy = gamescopeBridgeOutputPolicy(
                                    profile, refreshHz, harness.scheduler.snapshot());
                                require(policy.outputFps == targetFps && policy.generatedTimeline,
                                    "resumed generation lost its target or readiness lead");
                                resumedGeneration = true;
                            }
                        }
                        require(resumedGeneration,
                            "sustained native deficit did not resume generated output");
                        // A faster source hidden by generated backpressure needs
                        // the existing opt-in native probe before it is observable.
                        if (!recovery)
                            continue;
                        const auto recoveredAt = harness.now + 10s;
                        while (harness.now < recoveredAt)
                            present(nativeFps);
                        require(!gamescopeBridgeOutputPolicy(profile, refreshHz,
                                harness.scheduler.snapshot()).generatedTimeline,
                            "recovered native source retained the generated output ceiling: native=" +
                                std::to_string(nativeFps) + " bridge=" + std::to_string(bridge) +
                                " smooth=" + std::to_string(smooth) + " measured=" +
                                std::to_string(harness.scheduler.snapshot().smoothedBaseFps) +
                                " phase=" + std::to_string(static_cast<int>(
                                    harness.scheduler.snapshot().phase)));
                    }
                }
            }
        }
    }

    void testTargetNativeQualificationIsFractionalOnly() {
        using Priority = ls::AdaptiveFractionalRealFramePriority;
        struct Scenario {
            bool adaptive;
            bool steady;
            Priority priority;
            uint32_t cap;
            bool qualifies;
        };
        constexpr std::array scenarios{
            Scenario{true, false, Priority::Auto, 0, true},
            Scenario{true, false, Priority::Auto, 60, true},
            Scenario{true, false, Priority::Auto, 90, true},
            Scenario{true, false, Priority::Auto, 59, false},
            Scenario{true, false, Priority::Auto, 30, false},
            Scenario{true, false, Priority::Low, 90, false},
            Scenario{true, false, Priority::Medium, 90, false},
            Scenario{true, false, Priority::High, 90, false},
            Scenario{true, false, Priority::VeryHigh, 90, false},
            Scenario{true, true, Priority::Auto, 0, false},
            Scenario{true, true, Priority::Auto, 90, false},
            Scenario{false, false, Priority::Auto, 0, false},
        };
        for (const auto& scenario : scenarios) {
            for (const bool smooth : {false, true}) {
                ls::GameConf profile;
                profile.frame_generation_provisioned = true;
                profile.frame_generation_enabled = true;
                profile.adaptive = scenario.adaptive;
                profile.adaptive_auto_base_fps_cap = scenario.steady;
                profile.adaptive_fractional_real_frame_priority = scenario.priority;
                profile.base_fps_cap = scenario.cap;
                profile.target_fps = 60;
                profile.adaptive_max_multiplier = 2;
                profile.multiplier = 2;
                profile.adaptive_stable_cadence = smooth;
                // Fixed only creates a scheduler for opt-in cadence recovery.
                profile.dynamic_cadence_recovery = !scenario.adaptive;
                const auto policy = generationSchedulerPolicy(profile, 90);
                require(policy && policy->qualifyTargetNativeCadence == scenario.qualifies,
                    "native qualification escaped its Fractional Automatic profile boundary");
                for (const double ratio : {1.0, 1.25}) {
                    Harness harness(policy->targetFps, policy->maximumMultiplier,
                        policy->stableCadence, AdaptiveRecoveryPolicy::OrderedSdr,
                        policy->dynamicCadenceRecovery, 2s, 90,
                        policy->nearTargetNativePreference, scenario.steady, false,
                        policy->qualifyTargetNativeCadence);
                    harness.start();
                    // Deliberately bypass the source cap: unusual fast samples
                    // must not activate the new state in an ineligible mode.
                    harness.runAtFps(policy->targetFps * ratio, 8s);
                    const auto snapshot = harness.scheduler.snapshot();
                    require(snapshot.nearTargetNativePreference == scenario.qualifies,
                        "at/above-target samples changed another mode's native preference");
                    const auto output = gamescopeBridgeOutputPolicy(profile, 90, snapshot);
                    require(output.generatedTimeline == !scenario.qualifies &&
                            output.outputFps == (scenario.qualifies || !scenario.adaptive ? 90 : 60),
                        "native qualification changed another mode's output timing");
                }
            }
        }
    }

    void testNearTargetNativePreferenceCoversSteadySweep() {
        constexpr uint32_t targetFps = 120;
        for (size_t baseFps = 60; baseFps < targetFps; ++baseFps) {
            Harness harness(targetFps, 2);
            harness.start();
            harness.runAtFps(static_cast<double>(baseFps), 8s);
            const auto snapshot = harness.scheduler.snapshot();

            if (baseFps >= 114) {
                require(snapshot.nearTargetNativePreference,
                    "steady near-target cadence did not prefer native at " +
                        std::to_string(baseFps) + " FPS");
                require(snapshot.validatedGenerationLimit == 0,
                    "near-target native preference retained generated work");
                require(harness.diagnostics.count(
                        "adaptive-near-target-native-enabled") == 1,
                    "steady near-target cadence did not enter exactly once");
                require(harness.frameAtFps(
                        static_cast<double>(baseFps)).empty(),
                    "near-target native preference generated a frame");
                require(harness.diagnostics.latestPlan.has_value() &&
                        harness.diagnostics.latestPlan->
                            nearTargetNativePreference &&
                        harness.diagnostics.latestPlan->
                            predictedNativeIntervalRmsMilliseconds <=
                        harness.diagnostics.latestPlan->
                            predictedFractionalIntervalRmsMilliseconds + 1e-6,
                    "near-target diagnostic omitted its derived quality basis");
                continue;
            }

            require(!snapshot.nearTargetNativePreference,
                "below-boundary cadence incorrectly preferred native at " +
                    std::to_string(baseFps) + " FPS");
            size_t outputs = 0;
            constexpr size_t sampleFrames = 600;
            for (size_t frame = 0; frame < sampleFrames; ++frame) {
                const auto plan = harness.frameAtFps(
                    static_cast<double>(baseFps)
                );
                requireValidTimestamps(plan, 1);
                outputs += plan.size() + 1;
            }
            const double outputFps = static_cast<double>(outputs) /
                (static_cast<double>(sampleFrames) /
                    static_cast<double>(baseFps));
            require(std::abs(outputFps - static_cast<double>(targetFps)) < 0.21,
                "below-boundary Fractional cadence lost target average at " +
                    std::to_string(baseFps) + " FPS: " +
                    std::to_string(outputFps));
        }
    }

    void testNearTargetNativePreferenceScalesAcrossTargets() {
        struct RatioCase {
            uint32_t targetFps;
            double nativePreferredBaseFps;
            double fractionalPreferredBaseFps;
        };
        constexpr std::array cases{
            RatioCase{60, 57.0, 56.0},
            RatioCase{90, 86.0, 84.0},
            RatioCase{100, 95.0, 94.0},
            RatioCase{120, 114.0, 113.0},
            RatioCase{144, 137.0, 136.0},
        };

        for (const auto& ratioCase : cases) {
            Harness nativeHarness(ratioCase.targetFps, 2);
            nativeHarness.start();
            nativeHarness.runAtFps(ratioCase.nativePreferredBaseFps, 8s);
            require(nativeHarness.scheduler.snapshot().
                    nearTargetNativePreference &&
                    nativeHarness.scheduler.snapshot().
                        validatedGenerationLimit == 0,
                "native-preference output floor did not scale at target " +
                    std::to_string(ratioCase.targetFps));

            Harness fractionalHarness(ratioCase.targetFps, 2);
            fractionalHarness.start();
            fractionalHarness.runAtFps(
                ratioCase.fractionalPreferredBaseFps, 8s
            );
            require(!fractionalHarness.scheduler.snapshot().
                    nearTargetNativePreference &&
                    fractionalHarness.scheduler.snapshot().
                        validatedGenerationLimit == 1,
                "Fractional side of output floor did not scale at target " +
                    std::to_string(ratioCase.targetFps));
        }
    }

    void testNearTargetNativePreferenceToleratesBoundaryMeasurementNoise() {
        Harness nominalBoundary(120, 2);
        nominalBoundary.start();
        nominalBoundary.runAtFps(114.0, 8s);
        require(nominalBoundary.scheduler.snapshot().
                    nearTargetNativePreference &&
                nominalBoundary.scheduler.snapshot().
                    validatedGenerationLimit == 0,
            "native-retention boundary did not prefer a target-near real cadence");

        Harness usefulFractional(120, 2);
        usefulFractional.start();
        usefulFractional.runAtFps(113.0, 8s);
        require(!usefulFractional.scheduler.snapshot().
                    nearTargetNativePreference &&
                usefulFractional.scheduler.snapshot().
                    validatedGenerationLimit == 1,
            "boundary tolerance suppressed a materially useful Fractional cadence");
    }

    void testNearTargetNativePreferenceCoversNoisySweep() {
        constexpr uint32_t targetFps = 120;
        for (size_t baseFps = 60; baseFps < targetFps; ++baseFps) {
            Harness harness(targetFps, 2);
            harness.start();
            const auto meanInterval = std::chrono::duration<double>(
                1.0 / static_cast<double>(baseFps)
            );
            const std::array intervals{
                std::chrono::duration_cast<std::chrono::nanoseconds>(
                    meanInterval * 0.9
                ),
                std::chrono::duration_cast<std::chrono::nanoseconds>(
                    meanInterval * 1.1
                ),
            };
            const size_t frames = baseFps * 12;
            for (size_t frame = 0; frame < frames; ++frame) {
                const auto plan = harness.frame(intervals[frame & 1U]);
                requireValidTimestamps(plan, 1);
            }

            const size_t enabled = harness.diagnostics.count(
                "adaptive-near-target-native-enabled"
            );
            const size_t disabled = harness.diagnostics.count(
                "adaptive-near-target-native-disabled"
            );
            require(enabled + disabled <= 1,
                "noisy sweep caused near-target preference chatter at " +
                    std::to_string(baseFps) + " FPS");
            if (baseFps <= 110) {
                require(!harness.scheduler.snapshot().
                        nearTargetNativePreference &&
                        harness.scheduler.snapshot().
                            validatedGenerationLimit == 1,
                    "clearly Fractional-favourable noisy cadence chose native at " +
                        std::to_string(baseFps) + " FPS");
            } else if (baseFps >= 116) {
                require(harness.scheduler.snapshot().
                        nearTargetNativePreference &&
                        harness.scheduler.snapshot().
                            validatedGenerationLimit == 0,
                    "clearly native-favourable noisy cadence retained Fractional at " +
                        std::to_string(baseFps) + " FPS");
            }
        }
    }

    void testNearTargetNativePreferenceHasHysteresisAndNoChatter() {
        for (const double nativeFps : {119.0, 125.0}) {
            Harness harness(120, 2);
            harness.start();
            harness.runAtFps(80.0, 8s);
            require(harness.scheduler.snapshot().validatedGenerationLimit == 1 &&
                    !harness.scheduler.snapshot().nearTargetNativePreference,
                "precondition failed: 80 FPS did not settle on Fractional");

            bool generatedDuringEntryHold = false;
            for (size_t frame = 0; frame < 50; ++frame) {
                const auto plan = harness.frameAtFps(nativeFps);
                requireValidTimestamps(plan, 1);
                generatedDuringEntryHold = generatedDuringEntryHold ||
                    !plan.empty();
            }
            require(!harness.scheduler.snapshot().nearTargetNativePreference &&
                    harness.scheduler.snapshot().validatedGenerationLimit == 1 &&
                    generatedDuringEntryHold &&
                    harness.diagnostics.count(
                        "adaptive-near-target-native-enabled") == 0,
                "cadence rise changed Fractional policy before the native-preference hold completed");
            harness.runAtFps(nativeFps, 2500ms);
            require(harness.scheduler.snapshot().nearTargetNativePreference &&
                    harness.scheduler.snapshot().validatedGenerationLimit == 0,
                "cadence rise did not enter near-target native preference");

            constexpr std::array boundaryCadence{116.0, 120.0};
            for (size_t frame = 0; frame < 1200; ++frame)
                harness.frameAtFps(boundaryCadence[frame & 1U]);
            require(harness.scheduler.snapshot().nearTargetNativePreference &&
                    harness.diagnostics.count(
                        "adaptive-near-target-native-enabled") == 1 &&
                    harness.diagnostics.count(
                        "adaptive-near-target-native-disabled") == 0,
                "boundary oscillation caused native-preference chatter");

            harness.runAtFps(80.0, 500ms);
            require(harness.scheduler.snapshot().nearTargetNativePreference,
                "brief cadence drop bypassed native-preference hysteresis");
            harness.runAtFps(80.0, 2500ms);
            require(!harness.scheduler.snapshot().nearTargetNativePreference &&
                    harness.scheduler.snapshot().validatedGenerationLimit == 1 &&
                    harness.diagnostics.count(
                        "adaptive-near-target-native-disabled") == 1,
                "sustained Fractional advantage did not resume generation");

            harness.runAtFps(nativeFps, 3s);
            require(harness.scheduler.snapshot().nearTargetNativePreference &&
                harness.scheduler.snapshot().validatedGenerationLimit == 0 &&
                    harness.diagnostics.count(
                        "adaptive-near-target-native-enabled") == 2,
                "second sustained cadence rise did not re-enter native preference");

            const auto interruptionPlan = harness.frame(400ms);
            require(interruptionPlan.empty() &&
                    harness.scheduler.snapshot().phase ==
                        AdaptiveSchedulerPhase::Stabilizing &&
                    !harness.scheduler.snapshot().nearTargetNativePreference,
                "native preference took ownership from cadence stabilization");
        }
    }

    void testNearTargetNativePreferenceResumesAcrossNoisyHighExcursions() {
        Harness harness(120, 2);
        harness.start();
        harness.runAtFps(119.0, 8s);
        require(harness.scheduler.snapshot().nearTargetNativePreference &&
                harness.scheduler.snapshot().validatedGenerationLimit == 0,
            "precondition failed: high-base cadence did not prefer native");

        // Reproduce the RE4 resolution-change failure shape: native cadence
        // previously remained latched while the game fluctuated around
        // 95-110 FPS against a 120 FPS target. That policy made Adaptive look
        // inactive even though Fixed 2x continued to generate successfully.
        constexpr std::array noisyCadence{96.0, 105.0, 100.0, 110.0};
        bool resumed = false;
        size_t resumedAt = 0;
        for (size_t frame = 0; frame < 420; ++frame) {
            const auto plan = harness.frameAtFps(
                noisyCadence[frame % noisyCadence.size()]
            );
            if (!plan.empty() && !resumed) {
                resumed = true;
                resumedAt = frame;
            }
        }

        require(resumed && resumedAt < 320 &&
                !harness.scheduler.snapshot().nearTargetNativePreference &&
                harness.scheduler.snapshot().validatedGenerationLimit == 1 &&
                harness.diagnostics.count(
                    "adaptive-near-target-native-disabled") == 1,
            "noisy sustained cadence drop did not resume Fractional FG within its bounded evidence window");
        const auto transition = std::find_if(
            harness.diagnostics.events.cbegin(),
            harness.diagnostics.events.cend(),
            [](const RecordingDiagnostics::Event& event) {
                return event.operation ==
                    "adaptive-near-target-native-disabled";
            }
        );
        require(transition != harness.diagnostics.events.cend() &&
                transition->reason ==
                    "native-output-below-retention-floor",
            "resolution-change recovery did not identify its target-output deficit");
    }

    void testNearTargetNativePreferenceBypassesOnlyMarginalRamp() {
        Harness nearTarget(120, 2);
        nearTarget.start();
        nearTarget.runAtFps(119.0, 8s);
        require(nearTarget.scheduler.snapshot().nearTargetNativePreference &&
                nearTarget.diagnostics.count("ramp") == 0 &&
                nearTarget.diagnostics.count("ramp-result") == 0,
            "near-target policy measured a marginal generated ramp");

        Harness fractional(120, 2);
        fractional.start();
        fractional.runAtFps(100.0, 8s);
        require(!fractional.scheduler.snapshot().nearTargetNativePreference &&
                fractional.scheduler.snapshot().validatedGenerationLimit == 1 &&
                fractional.diagnostics.count("ramp") == 1 &&
                fractional.diagnostics.count("ramp-result") == 1,
            "useful below-boundary Fractional ramp was not retained");
    }

    void testNearTargetNativePreferenceDoesNotChangeFixedRecoveryPolicy() {
        Harness fixedRecovery(
            120,
            2,
            false,
            AdaptiveRecoveryPolicy::OrderedSdr,
            true,
            2s,
            120,
            false
        );
        fixedRecovery.start();
        fixedRecovery.runAtFps(100.0, 8s);

        require(!fixedRecovery.scheduler.snapshot().
                    nearTargetNativePreference &&
                fixedRecovery.scheduler.snapshot().
                    validatedGenerationLimit == 1,
            "Adaptive-only native preference changed Fixed recovery policy");
        require(fixedRecovery.diagnostics.count(
                "adaptive-near-target-native-enabled") == 0,
            "Fixed recovery emitted an Adaptive-only preference transition");
        bool observedGeneratedFrame = false;
        for (size_t frame = 0; frame < 120; ++frame) {
            const auto plan = fixedRecovery.frameAtFps(100.0);
            requireValidTimestamps(plan, 1);
            observedGeneratedFrame = observedGeneratedFrame || !plan.empty();
        }
        require(observedGeneratedFrame,
            "Fixed recovery lost its established fractional ceiling policy");
    }

    void testTargetClockHandlesMultiLevelFractionalCadence() {
        Harness harness(120, 3);
        harness.start();
        harness.runAtFps(45.0, 10s);
        require(harness.scheduler.snapshot().validatedGenerationLimit == 2,
            "precondition failed: multi-level test had no 3x capacity");

        constexpr std::chrono::nanoseconds shortInterval = 18'888'889ns;
        constexpr std::chrono::nanoseconds longInterval = 25'555'555ns;
        size_t scheduledOutputs = 0;
        double elapsedSeconds = 0.0;
        bool sawOneGeneratedFrame = false;
        bool sawTwoGeneratedFrames = false;
        bool sawDeferredOutput = false;
        for (size_t pair = 0; pair < 600; ++pair) {
            for (const auto interval : {shortInterval, longInterval}) {
                const auto plan = harness.frame(interval);
                requireValidTimestamps(plan, 2);
                sawOneGeneratedFrame |= plan.size() == 1;
                sawTwoGeneratedFrames |= plan.size() == 2;
                scheduledOutputs += plan.size() + 1;
                elapsedSeconds +=
                    std::chrono::duration<double>(interval).count();
                const auto snapshot = harness.scheduler.snapshot();
                sawDeferredOutput |=
                    snapshot.targetOutputDeferredBudgetOutput;
                require(snapshot.targetOutputClockActive &&
                        std::abs(snapshot.targetOutputPhaseErrorOutputs) <=
                            0.5 + 1e-9,
                    "multi-level fractional phase escaped its bound");
            }
        }

        require(sawOneGeneratedFrame && sawTwoGeneratedFrames,
            "multi-level fractional cadence did not exercise both counts");
        require(sawDeferredOutput,
            "multi-level fractional cadence did not exercise placement");
        require(std::abs(
                static_cast<double>(scheduledOutputs) / elapsedSeconds - 120.0
            ) < 0.2,
            "multi-level fractional cadence lost its target average");

        constexpr std::array<std::chrono::nanoseconds, 4> tailTrace{
            11ms, 18'333'333ns, 20'833'333ns, 20'833'334ns,
        };
        const auto tailTraceDuration =
            tailTrace[0] + tailTrace[1] + tailTrace[2] + tailTrace[3];
        const double tailBaseFps = 4.0 /
            std::chrono::duration<double>(tailTraceDuration).count();
        Harness tailHarness(120, 3);
        tailHarness.start();
        tailHarness.runAtFps(tailBaseFps, 10s);
        for (size_t frame = 0;
                frame < 120 && tailHarness.scheduler.snapshot().
                    targetOutputDeferredBudgetOutput;
                ++frame) {
            tailHarness.frameAtFps(tailBaseFps);
        }
        const auto initial = tailHarness.scheduler.snapshot();
        require(initial.validatedGenerationLimit == 2 &&
                !initial.targetOutputDeferredBudgetOutput,
            "precondition failed: tail guard had no 3x capacity");

        double legacyCredit = initial.targetOutputBudgetCreditOutputs;
        size_t actualOutputCount = 0;
        size_t legacyOutputCount = 0;
        double actualMaximumInterval = 0.0;
        double legacyMaximumInterval = 0.0;
        std::vector<double> actualIntervals;
        std::vector<double> legacyIntervals;
        actualIntervals.reserve(7'200);
        legacyIntervals.reserve(7'200);

        for (size_t cycle = 0; cycle < 600; ++cycle) {
            for (const auto interval : tailTrace) {
                const auto plan = tailHarness.frame(interval);
                requireValidTimestamps(plan, 2);
                const auto snapshot = tailHarness.scheduler.snapshot();
                legacyCredit += 120.0 / snapshot.smoothedBaseFps;
                const size_t requestedOutputs = std::max<size_t>(
                    1,
                    static_cast<size_t>(std::floor(legacyCredit + 1e-9))
                );
                const size_t baselineOutputs = std::min<size_t>(
                    requestedOutputs, 3
                );
                legacyCredit -= static_cast<double>(baselineOutputs);
                if (legacyCredit < 0.0)
                    legacyCredit = 0.0;
                if (baselineOutputs == 3 && legacyCredit >= 1.0)
                    legacyCredit = std::fmod(legacyCredit, 1.0);

                const size_t actualOutputs = plan.size() + 1;
                actualOutputCount += actualOutputs;
                legacyOutputCount += baselineOutputs;
                require(actualOutputCount <= legacyOutputCount &&
                        legacyOutputCount - actualOutputCount <= 1,
                    "multi-level placement changed the workload envelope");

                const double intervalMilliseconds =
                    std::chrono::duration<double, std::milli>(interval).count();
                const double actualSpacing = intervalMilliseconds /
                    static_cast<double>(actualOutputs);
                const double legacySpacing = intervalMilliseconds /
                    static_cast<double>(baselineOutputs);
                actualMaximumInterval = std::max(
                    actualMaximumInterval, actualSpacing
                );
                legacyMaximumInterval = std::max(
                    legacyMaximumInterval, legacySpacing
                );
                require(actualMaximumInterval <=
                        legacyMaximumInterval + 1e-9,
                    "multi-level placement worsened the requested maximum");
                for (size_t output = 0; output < actualOutputs; ++output)
                    actualIntervals.push_back(actualSpacing);
                for (size_t output = 0; output < baselineOutputs; ++output)
                    legacyIntervals.push_back(legacySpacing);
            }
        }

        std::sort(actualIntervals.begin(), actualIntervals.end());
        std::sort(legacyIntervals.begin(), legacyIntervals.end());
        const auto percentile = [](const std::vector<double>& samples,
                const double quantile) {
            const size_t rank = std::max<size_t>(
                1,
                static_cast<size_t>(std::ceil(
                    quantile * static_cast<double>(samples.size())
                ))
            );
            return samples[rank - 1];
        };
        require(percentile(actualIntervals, 0.95) <=
                percentile(legacyIntervals, 0.95) + 1e-9 &&
                percentile(actualIntervals, 0.99) <=
                    percentile(legacyIntervals, 0.99) + 1e-9,
            "multi-level placement worsened requested tail intervals");
    }

    void testTargetClockPreservesNoisyIntegerCeiling() {
        Harness harness(120, 2);
        harness.start();
        harness.runAtFps(60.0, 7s);
        require(harness.scheduler.snapshot().validatedGenerationLimit == 1,
            "precondition failed: noisy integer test had no 2x capacity");

        constexpr std::chrono::nanoseconds shortInterval = 10ms;
        constexpr std::chrono::nanoseconds longInterval = 23'333'333ns;
        for (size_t pair = 0; pair < 20; ++pair) {
            harness.frame(shortInterval);
            harness.frame(longInterval);
        }

        size_t scheduledOutputs = 0;
        double elapsedSeconds = 0.0;
        for (size_t pair = 0; pair < 240; ++pair) {
            for (const auto interval : {shortInterval, longInterval}) {
                const auto plan = harness.frame(interval);
                require(plan.size() == 1,
                    "raw placement reduced an achievable noisy 2x cadence");
                scheduledOutputs += plan.size() + 1;
                elapsedSeconds +=
                    std::chrono::duration<double>(interval).count();
                require(std::abs(
                        harness.scheduler.snapshot().
                            targetOutputPhaseErrorOutputs
                    ) <= 0.5 + 1e-9,
                    "noisy integer target phase escaped its bounded residual");
            }
        }
        require(std::abs(
                static_cast<double>(scheduledOutputs) / elapsedSeconds - 120.0
            ) < 0.001,
            "noisy achievable 2x cadence lost the target average");
    }

    void testTargetClockRecoversNoisyThreeXCeilingAfterThrottle() {
        Harness harness(120, 3, false,
            AdaptiveRecoveryPolicy::OrderedSdr);
        harness.start();
        harness.runAtFps(40.0, 10s);
        require(harness.scheduler.snapshot().validatedGenerationLimit == 2,
            "precondition failed: throttle recovery had no 3x capacity");

        harness.runAtFps(30.0, 15s);
        require(harness.scheduler.snapshot().validatedGenerationLimit == 2,
            "external throttle discarded the validated 3x ceiling");

        size_t phaseFrames = 0;
        while (harness.scheduler.snapshot().
                    targetOutputBudgetCreditOutputs < 0.98 &&
                phaseFrames < 400) {
            harness.frameAtFps(39.9);
            phaseFrames++;
        }
        require(phaseFrames < 400,
            "precondition failed: noisy ceiling did not reach its rollover phase");

        const auto slowPlan = harness.frame(26ms);
        requireValidTimestamps(slowPlan, 2);
        require(slowPlan.size() == 2 &&
                harness.scheduler.snapshot().
                    targetOutputBudgetCreditOutputs >= 0.95,
            "ceiling saturation discarded recoverable output credit");
        const auto fastPlan = harness.frame(22ms);
        requireValidTimestamps(fastPlan, 2);
        require(fastPlan.size() == 2,
            "ceiling-credit rollover dropped a generated output");

        std::array<std::chrono::nanoseconds, 200> intervals{};
        uint32_t jitterState = 10;
        for (auto& interval : intervals) {
            jitterState ^= jitterState << 13;
            jitterState ^= jitterState >> 17;
            jitterState ^= jitterState << 5;
            const int64_t jitter = static_cast<int64_t>(
                jitterState % 1'000'001U
            ) - 500'000;
            interval = std::chrono::nanoseconds{25'000'000 + jitter};
        }
        constexpr size_t windowFrames = 40;
        constexpr size_t windows = intervals.size() / windowFrames;
        for (size_t window = 0; window < windows; ++window) {
            std::chrono::nanoseconds elapsed{};
            for (size_t frame = 0; frame < windowFrames; ++frame)
                elapsed += intervals[window * windowFrames + frame];
            const auto correction =
                (elapsed - 1s) / static_cast<int64_t>(windowFrames);
            for (size_t frame = 0; frame < windowFrames; ++frame)
                intervals[window * windowFrames + frame] -= correction;
        }

        for (size_t frame = 0; frame < 80; ++frame) {
            const auto plan = harness.frame(intervals[frame]);
            requireValidTimestamps(plan, 2);
        }

        size_t targetWindows = 0;
        size_t longestTargetStreak = 0;
        for (size_t window = 0; window < windows; ++window) {
            size_t scheduledOutputs = 0;
            std::chrono::nanoseconds elapsed{};
            for (size_t frame = 0; frame < windowFrames; ++frame) {
                const auto interval =
                    intervals[window * windowFrames + frame];
                const auto plan = harness.frame(interval);
                requireValidTimestamps(plan, 2);
                require(plan.size() == 2,
                    "near-integer 3x recovery dropped a generated output");
                const auto snapshot = harness.scheduler.snapshot();
                require(snapshot.targetOutputClockActive &&
                        snapshot.targetOutputBudgetCreditOutputs >= 0.0 &&
                        snapshot.targetOutputBudgetCreditOutputs < 1.0 &&
                        std::abs(snapshot.targetOutputPhaseErrorOutputs) <=
                            0.5 + 1e-9,
                    "near-integer 3x recovery escaped bounded clock state");
                scheduledOutputs += plan.size() + 1;
                elapsed += interval;
            }
            const double outputFps =
                static_cast<double>(scheduledOutputs) /
                std::chrono::duration<double>(elapsed).count();
            if (outputFps >= 117.6 && outputFps <= 122.4) {
                targetWindows++;
                longestTargetStreak = std::max(
                    longestTargetStreak, targetWindows
                );
            } else {
                targetWindows = 0;
            }
        }
        require(longestTargetStreak >= 3,
            "noisy 3x ceiling did not sustain three 120 FPS windows");
    }

    void testDeferredOutputRepaymentPreservesPacingBenefit() {
        constexpr std::array traces{
            std::array<std::chrono::nanoseconds, 3>{
                27'777'778ns, 13'333'333ns, 8'888'889ns,
            },
            std::array<std::chrono::nanoseconds, 3>{
                23'333'333ns, 23'333'333ns, 8'888'889ns,
            },
        };

        for (const auto& trace : traces) {
            const auto traceDuration = trace[0] + trace[1] + trace[2];
            const double baseFps = 3.0 /
                std::chrono::duration<double>(traceDuration).count();
            Harness harness(90, 2);
            harness.start();
            harness.runAtFps(baseFps, 7s);
            const auto initial = harness.scheduler.snapshot();
            require(initial.validatedGenerationLimit == 1 &&
                    !initial.targetOutputDeferredBudgetOutput,
                "precondition failed: irregular trace had stale placement debt");

            double legacyCredit = initial.targetOutputBudgetCreditOutputs;
            double actualSquaredError = 0.0;
            double legacySquaredError = 0.0;
            size_t actualOutputs = 0;
            size_t legacyOutputs = 0;
            bool sawDeferredOutput = false;
            bool sawRepaidOutput = false;
            bool deferredOutputPending = false;
            constexpr double targetIntervalMilliseconds = 1000.0 / 90.0;

            for (size_t cycle = 0; cycle < 600; ++cycle) {
                for (const auto interval : trace) {
                    const auto plan = harness.frame(interval);
                    const auto snapshot = harness.scheduler.snapshot();
                    require(snapshot.targetOutputClockActive &&
                            snapshot.smoothedBaseFps > 0.0,
                        "irregular trace left active fractional scheduling");

                    legacyCredit += 90.0 / snapshot.smoothedBaseFps;
                    const size_t requestedOutputs = std::max<size_t>(
                        1,
                        static_cast<size_t>(std::floor(
                            legacyCredit + 1e-9
                        ))
                    );
                    const size_t baselineOutputs = std::min<size_t>(
                        requestedOutputs, 2
                    );
                    legacyCredit -= static_cast<double>(baselineOutputs);
                    if (legacyCredit < 0.0)
                        legacyCredit = 0.0;
                    if (baselineOutputs == 2 && legacyCredit >= 1.0)
                        legacyCredit = std::fmod(legacyCredit, 1.0);

                    const size_t scheduledOutputs = plan.size() + 1;
                    actualOutputs += scheduledOutputs;
                    legacyOutputs += baselineOutputs;
                    require(actualOutputs <= legacyOutputs &&
                            legacyOutputs - actualOutputs <= 1,
                        "raw placement changed the smoothed workload envelope");
                    sawDeferredOutput |=
                        snapshot.targetOutputDeferredBudgetOutput;
                    const bool repaidOutput = deferredOutputPending &&
                        !snapshot.targetOutputDeferredBudgetOutput;
                    sawRepaidOutput |= repaidOutput;
                    if (repaidOutput) {
                        require(actualOutputs == legacyOutputs,
                            "deferred repayment did not restore baseline work");
                    }
                    deferredOutputPending =
                        snapshot.targetOutputDeferredBudgetOutput;

                    const double intervalMilliseconds =
                        std::chrono::duration<double, std::milli>(
                            interval
                        ).count();
                    const auto squaredError = [intervalMilliseconds](
                            const size_t outputCount) {
                        const double error = intervalMilliseconds /
                            static_cast<double>(outputCount) -
                            targetIntervalMilliseconds;
                        return static_cast<double>(outputCount) *
                            error * error;
                    };
                    actualSquaredError += squaredError(scheduledOutputs);
                    legacySquaredError += squaredError(baselineOutputs);
                    require(actualSquaredError <=
                            legacySquaredError + 1e-6,
                        "placement worsened a prefix of requested pacing");
                }
            }

            require(sawDeferredOutput,
                "irregular trace did not exercise deferred placement");
            require(sawRepaidOutput,
                "irregular trace never repaid a deferred output");
            require(legacyOutputs - actualOutputs <= 1,
                "deferred placement lost more than one bounded output");
            require(actualSquaredError <= legacySquaredError + 1e-6,
                "deferred repayment made requested pacing worse than baseline");
        }
    }

    void testTargetClockResetClearsDeferredOutput() {
        Harness harness(90, 2);
        harness.start();
        harness.runAtFps(60.0, 7s);

        constexpr std::array<std::chrono::nanoseconds, 3> trace{
            27'777'778ns, 13'333'333ns, 8'888'889ns,
        };
        bool createdDeferredOutput = false;
        for (size_t cycle = 0;
                cycle < 120 && !createdDeferredOutput; ++cycle) {
            for (const auto interval : trace) {
                harness.frame(interval);
                if (harness.scheduler.snapshot().
                        targetOutputDeferredBudgetOutput) {
                    createdDeferredOutput = true;
                    break;
                }
            }
        }
        require(createdDeferredOutput,
            "precondition failed: reset test created no deferred output");

        harness.scheduler.resetTiming(harness.now);
        const auto reset = harness.scheduler.snapshot();
        require(!reset.targetOutputClockActive &&
                reset.targetOutputBudgetCreditOutputs == 0.0 &&
                reset.targetOutputPhaseErrorOutputs == 0.0 &&
                !reset.targetOutputDeferredBudgetOutput,
            "timing reset retained fractional placement state");
    }

    void testRawPlacementCannotMintGeneratedWork() {
        Harness harness(90, 2);
        harness.start();
        harness.runAtFps(60.0, 7s);
        require(harness.scheduler.snapshot().validatedGenerationLimit == 1,
            "precondition failed: placement guard had no generated capacity");

        harness.scheduler.resetTiming(harness.now);
        require(harness.frame(10ms).empty(),
            "above-target source interval unexpectedly generated a frame");
        const auto delayedIntervalPlan = harness.frame(19ms);
        require(delayedIntervalPlan.empty(),
            "raw interval minted work before the smoothed budget earned it");
        const auto snapshot = harness.scheduler.snapshot();
        require(snapshot.targetOutputClockActive &&
                snapshot.targetOutputBudgetCreditOutputs > 0.0 &&
                snapshot.targetOutputBudgetCreditOutputs < 1.0,
            "fractional placement clock did not activate for the delayed interval");
    }

    void testTargetClockDiscardsUnreachableCeilingDebt() {
        Harness harness(240, 3);
        harness.start();
        const auto saturatedPlan = harness.runAtFps(60.0, 10s);
        require(saturatedPlan.size() == 2 &&
                harness.scheduler.snapshot().validatedGenerationLimit == 2,
            "precondition failed: target clock did not reach its 3x ceiling");
        require(harness.scheduler.snapshot().
                    targetOutputBudgetCreditOutputs < 1.0,
            "unreachable ceiling accumulated whole-output budget debt");

        harness.scheduler.resetTiming(harness.now);
        for (size_t frame = 0; frame < 120; ++frame) {
            const auto recoveredPlan = harness.frameAtFps(120.0);
            require(recoveredPlan.size() <= 1,
                "unreachable target debt produced a catch-up output after recovery");
            require(std::abs(
                    harness.scheduler.snapshot().targetOutputPhaseErrorOutputs
                ) <= 0.5 + 1e-9,
                "ceiling saturation retained whole-output target debt");
        }
    }

    void testPacingDiagnosticsRestartAfterPolicyGap() {
        Harness harness(90, 2);
        harness.start();
        harness.runAtFps(60.0, 7s);

        const size_t initialPlanCount = harness.diagnostics.plans.size();
        for (size_t frame = 0;
                frame < 120 &&
                    harness.diagnostics.plans.size() == initialPlanCount;
                ++frame) {
            harness.frameAtFps(60.0);
        }
        require(harness.diagnostics.plans.size() > initialPlanCount,
            "precondition failed: no baseline pacing aggregate was emitted");

        for (size_t frame = 0; frame < 30; ++frame)
            harness.frameAtFps(60.0);
        harness.diagnostics.plans.clear();
        harness.frameAtFps(60.0, true);

        size_t postGapFrames = 0;
        while (harness.diagnostics.plans.empty() && postGapFrames < 120) {
            harness.frameAtFps(60.0);
            postGapFrames++;
        }
        require(!harness.diagnostics.plans.empty(),
            "no pacing aggregate was emitted after acquisition bypass");
        const auto& postGap = harness.diagnostics.plans.front();
        require(postGap.pacingSourceSamples > 0 &&
                postGap.pacingSourceSamples <= postGapFrames,
            "post-bypass aggregate retained pre-bypass pacing samples");
        require(postGap.targetPhaseErrorSamples ==
                postGap.pacingSourceSamples,
            "post-bypass phase RMS mixed a different policy window");
    }

    void testIsolatedGeneratedFrameMissDoesNotRejectRamp() {
        Harness harness(120, 2);
        harness.start();
        bool reportedMiss = false;
        for (size_t frame = 0; frame < 600; ++frame) {
            const auto plan = harness.frameAtFps(60.0, false, false);
            if (harness.scheduler.snapshot().rampEvaluationActive &&
                    !reportedMiss && !plan.empty()) {
                harness.scheduler.reportGeneratedFrameDelivery({
                    .requested = plan.size(),
                    .acceptedForPresentation = plan.size() - 1,
                });
                reportedMiss = true;
            } else {
                harness.scheduler.reportGeneratedFrameDelivery({
                    .requested = plan.size(),
                    .acceptedForPresentation = plan.size(),
                });
            }
            if (reportedMiss && harness.diagnostics.contains("ramp-result"))
                break;
        }
        const auto* result = harness.diagnostics.last("ramp-result");
        require(reportedMiss && result && result->accepted,
            "one isolated compositor admission miss rejected a healthy ramp");
        require(harness.scheduler.snapshot().validatedGenerationLimit == 1,
            "healthy delivery with one isolated miss was not validated");
    }

    void testPersistentGeneratedFrameMissesRejectRamp() {
        Harness harness(120, 2);
        harness.start();
        bool reportedPressure = false;
        for (size_t frame = 0; frame < 600; ++frame) {
            const auto plan = harness.frameAtFps(60.0, false, false);
            if (harness.scheduler.snapshot().rampEvaluationActive &&
                    !plan.empty()) {
                harness.scheduler.reportGeneratedFrameDelivery({
                    .requested = plan.size(),
                    .acceptedForPresentation = 0,
                });
                reportedPressure = true;
            } else {
                harness.scheduler.reportGeneratedFrameDelivery({
                    .requested = plan.size(),
                    .acceptedForPresentation = plan.size(),
                });
            }
            if (reportedPressure && harness.diagnostics.contains("ramp-result"))
                break;
        }
        const auto* result = harness.diagnostics.last("ramp-result");
        require(reportedPressure && result && !result->accepted,
            "persistent compositor admission loss did not reject the ramp");
        require(harness.scheduler.snapshot().validatedGenerationLimit == 0,
            "persistent delivery loss was retained as a validated multiplier");
    }

    void testEscalationClosesNinetyFivePercentTargetGap() {
        Harness harness(120, 3, false,
            AdaptiveRecoveryPolicy::OrderedSdr);
        harness.start();
        harness.runAtFps(58.0, 10s);
        require(harness.scheduler.snapshot().validatedGenerationLimit == 2,
            "a 116 FPS 2x ceiling was incorrectly accepted for a 120 FPS target");
        const auto* higherProbe = harness.diagnostics.last("ramp-result");
        require(higherProbe && higherProbe->testedLimit == 2 &&
                higherProbe->accepted,
            "the scheduler did not validate available 3x headroom near target");
    }

    void testNearTargetRungDoesNotProbeHigherMultiplier() {
        constexpr uint32_t targetFps = 120;
        for (size_t higherMultiplier = 2; higherMultiplier <= 5;
                ++higherMultiplier) {
            const double lowerRungBaseFps =
                static_cast<double>(targetFps) /
                static_cast<double>(higherMultiplier - 1);
            Harness nearTarget(targetFps, higherMultiplier, false,
                AdaptiveRecoveryPolicy::OrderedSdr, false, 2s, targetFps,
                false);
            nearTarget.start();
            nearTarget.runAtFps(lowerRungBaseFps * 0.995, 12s);
            require(nearTarget.scheduler.snapshot().validatedGenerationLimit ==
                    higherMultiplier - 2 &&
                    !nearTarget.scheduler.snapshot().rampEvaluationActive,
                "near-target Adaptive rung probed a higher multiplier at " +
                    std::to_string(higherMultiplier) + "x");

            Harness meaningfulDeficit(targetFps, higherMultiplier, false,
                AdaptiveRecoveryPolicy::OrderedSdr, false, 2s, targetFps,
                false);
            meaningfulDeficit.start();
            meaningfulDeficit.runAtFps(lowerRungBaseFps * 0.97, 20s);
            require(meaningfulDeficit.scheduler.snapshot().
                    validatedGenerationLimit == higherMultiplier - 1,
                "meaningful target deficit could not validate " +
                    std::to_string(higherMultiplier) + "x");
        }
    }

    void testMultiplierCeilingDeficitIsReportedOnce() {
        Harness harness(120, 2, false,
            AdaptiveRecoveryPolicy::OrderedSdr);
        harness.start();
        harness.runAtFps(55.0, 12s);
        require(harness.scheduler.snapshot().validatedGenerationLimit == 1,
            "the maximum configured 2x policy was not retained");
        require(harness.diagnostics.count("target-constrained") == 1,
            "a sustained multiplier-ceiling deficit was not reported exactly once");
        const auto* constrained =
            harness.diagnostics.last("target-constrained");
        require(constrained && constrained->testedLimit == 2,
            "the target-constrained diagnostic lost the configured multiplier");
    }

    void testFourXPlanUsesEvenInterpolationTimestamps() {
        Harness harness(120, 4);
        harness.start();
        const auto timestamps = harness.runAtFps(30.0, 15s);
        requireValidTimestamps(timestamps, 3);
        require(timestamps.size() == 3,
            "30 FPS toward 120 FPS did not settle at the 4x ceiling");
        requireNear(timestamps[0], 0.25F, 0.0001F,
            "first 4x interpolation timestamp changed");
        requireNear(timestamps[1], 0.50F, 0.0001F,
            "second 4x interpolation timestamp changed");
        requireNear(timestamps[2], 0.75F, 0.0001F,
            "third 4x interpolation timestamp changed");
    }

    void testFiveXPlanUsesEvenInterpolationTimestamps() {
        Harness harness(120, 5);
        harness.start();
        harness.runAtFps(24.0, 20s);
        require(harness.scheduler.snapshot().validatedGenerationLimit == 4,
            "24 FPS toward 120 FPS did not validate the 5x ceiling");
        AdaptiveFramePlan fullPlan;
        for (size_t frame = 0; frame < 120; ++frame) {
            const auto timestamps = harness.frameAtFps(24.0);
            if (timestamps.size() == 4) {
                fullPlan = timestamps;
                break;
            }
        }
        requireValidTimestamps(fullPlan, 4);
        require(fullPlan.size() == 4,
            "24 FPS toward 120 FPS did not schedule a 5x frame plan");
        requireNear(fullPlan[0], 0.20F, 0.0001F,
            "first 5x interpolation timestamp changed");
        requireNear(fullPlan[1], 0.40F, 0.0001F,
            "second 5x interpolation timestamp changed");
        requireNear(fullPlan[2], 0.60F, 0.0001F,
            "third 5x interpolation timestamp changed");
        requireNear(fullPlan[3], 0.80F, 0.0001F,
            "fourth 5x interpolation timestamp changed");
    }

    void testSchedulerCannotReduceAboveTargetCadence() {
        Harness harness(120, 4);
        harness.start();
        const auto timestamps = harness.runAtFps(144.0, 6s);
        require(timestamps.empty(),
            "scheduler generated frames when real cadence exceeded target");
        require(harness.scheduler.snapshot().validatedGenerationLimit == 0,
            "above-target cadence raised the validated generation level");
        require(!harness.scheduler.snapshot().targetOutputClockActive,
            "above-target cadence retained fractional target-clock debt");
    }

    void testAcquireBackoffDoesNotAdvancePolicy() {
        Harness harness(120, 3);
        harness.start();
        harness.runAtFps(60.0, 7s);
        const auto before = harness.scheduler.snapshot();
        for (size_t i = 0; i < 120; ++i) {
            const auto timestamps = harness.frameAtFps(60.0, true);
            require(timestamps.size() == 1,
                "acquire backoff must perform exactly one availability probe");
            requireNear(timestamps.front(), 0.5F, 0.0001F,
                "acquire-backoff probe timestamp changed");
        }
        const auto after = harness.scheduler.snapshot();
        require(after.generationLimit == before.generationLimit,
            "acquire backoff advanced generation policy");
        require(after.validatedGenerationLimit ==
                before.validatedGenerationLimit,
            "acquire backoff changed the validated level");
        require(!after.targetOutputClockActive,
            "acquire backoff retained a stale fractional target phase");
    }

    void testValidatedTwoXUsesCommonCadenceStallPolicy() {
        Harness harness(90, 2);
        harness.start();
        harness.runAtFps(45.0, 7s);
        require(harness.scheduler.snapshot().validatedGenerationLimit == 1,
            "precondition failed: 2x was not validated");

        const auto hitchPlan = harness.frame(200ms);
        require(hitchPlan.empty(),
            "2x cadence stall generated from stale temporal history");
        const auto snapshot = harness.scheduler.snapshot();
        require(snapshot.discontinuityRecoveryActive &&
                snapshot.generationLimit == 0,
            "2x cadence stall bypassed the common recovery policy");
    }

    // On the Gamescope HDR transport a long gap is ambiguous: it can be a
    // menu/focus transition, a colour-pipeline transition, or compositor
    // admission pressure. Do not resume generated work until cadence is proven.
    void testHdrLongHitchUsesConservativeDiscontinuityRecovery() {
        Harness harness(90, 2);
        harness.start();
        harness.runAtFps(45.0, 7s);
        const auto hitchPlan = harness.frame(400ms);
        require(hitchPlan.empty(),
            "long hitch unexpectedly generated a frame");
        const auto snapshot = harness.scheduler.snapshot();
        require(snapshot.discontinuityRecoveryActive,
            "long hitch bypassed menu/focus discontinuity recovery");
        require(snapshot.generationLimit == 0,
            "long hitch retained generated load during stabilization");
    }

    void testRecoveredCadenceRestoresValidatedLevel() {
        Harness harness(90, 2);
        harness.start();
        harness.runAtFps(45.0, 7s);
        require(harness.scheduler.snapshot().validatedGenerationLimit == 1,
            "precondition failed: 2x was not validated");
        harness.frame(400ms);
        require(harness.scheduler.discontinuityRecoveryActive(),
            "precondition failed: long hitch did not start recovery");

        harness.runAtFps(45.0, 3s);
        const auto snapshot = harness.scheduler.snapshot();
        require(!snapshot.discontinuityRecoveryActive,
            "healthy cadence did not complete discontinuity recovery");
        require(snapshot.validatedGenerationLimit == 1,
            "healthy cadence did not restore the proven 2x level");
        require(harness.frameAtFps(45.0).size() == 1,
            "restored 2x policy did not resume generation");
    }

    void testDiscontinuityRecoveryTimesOutToFreshRamp() {
        Harness harness(90, 2);
        harness.start();
        harness.runAtFps(45.0, 7s);
        harness.frame(400ms);
        require(harness.scheduler.discontinuityRecoveryActive(),
            "precondition failed: long hitch did not start recovery");

        for (size_t frame = 0;
                frame < 160 &&
                    !harness.diagnostics.contains("discontinuity-complete");
                ++frame) {
            harness.frameAtFps(20.0);
        }
        const auto* completion = harness.diagnostics.last(
            "discontinuity-complete"
        );
        require(completion && completion->reason == "timeout-ramp-from-zero",
            "unrecovered cadence did not take the bounded timeout path");
        const auto snapshot = harness.scheduler.snapshot();
        require(!snapshot.discontinuityRecoveryActive,
            "expired discontinuity recovery remained active");
        require(snapshot.generationLimit == 0,
            "expired discontinuity recovery retained stale generated load");
    }

    void testSustainedCadenceDropRebasesWithoutMenuRecovery() {
        Harness harness(120, 3);
        harness.start();
        harness.runAtFps(60.0, 7s);
        require(harness.scheduler.snapshot().validatedGenerationLimit == 1,
            "precondition failed: 2x was not validated");

        harness.frameAtFps(30.0);
        harness.frameAtFps(30.0);
        harness.frameAtFps(30.0);
        const auto snapshot = harness.scheduler.snapshot();
        require(snapshot.phase == AdaptiveSchedulerPhase::Stabilizing,
            "sustained gameplay cadence drop did not rebase through stabilization");
        require(!snapshot.discontinuityRecoveryActive,
            "ordinary gameplay cadence drop was mistaken for a menu discontinuity");
        require(snapshot.generationLimit == 0,
            "cadence rebase retained load before measuring the new scene");
    }

    void testSdrLongHitchRefreshesHistoryWithoutDroppingValidatedLevel() {
        // Ordered FIFO delivery makes an SDR hitch a temporal-history problem,
        // not evidence that the previously validated multiplier is unsafe.
        Harness harness(90, 2, false, AdaptiveRecoveryPolicy::OrderedSdr);
        harness.start();
        harness.runAtFps(45.0, 7s);
        require(harness.scheduler.snapshot().validatedGenerationLimit == 1,
            "precondition failed: SDR 2x was not validated");

        require(harness.frame(400ms).empty(),
            "SDR cadence refresh generated from stale history");
        auto snapshot = harness.scheduler.snapshot();
        require(!snapshot.discontinuityRecoveryActive,
            "ordinary SDR hitch entered HDR-style discontinuity recovery");
        require(snapshot.validatedGenerationLimit == 1,
            "ordinary SDR hitch discarded the validated 2x level");
        require(snapshot.historyWarmupRemaining == 2,
            "ordinary SDR hitch did not request the short history refresh");
        const auto* refresh = harness.diagnostics.last("cadence-refresh");
        require(refresh && refresh->reason == "cadence-stall" &&
                refresh->previousLimit == 1 && refresh->testedLimit == 2,
            "SDR cadence refresh was not reported accurately");

        harness.now += 22ms;
        harness.scheduler.consumeHistoryWarmupFrame(harness.now);
        harness.now += 22ms;
        harness.scheduler.consumeHistoryWarmupFrame(harness.now);
        require(harness.frameAtFps(45.0).empty(),
            "SDR resumed before recovered cadence was confirmed");
        require(harness.frameAtFps(45.0).empty(),
            "SDR resumed before three healthy cadence samples");
        const auto thirdResumedPlan = harness.frameAtFps(45.0);
        const auto fourthResumedPlan = harness.frameAtFps(45.0);
        require(thirdResumedPlan.size() == 1 || fourthResumedPlan.size() == 1,
            "SDR did not resume its validated 2x level after confirmed recovery");
    }

    void testUnconfirmedCadenceDropRetainsSlowSamples() {
        for (const auto recovery : {AdaptiveRecoveryPolicy::OrderedSdr,
                AdaptiveRecoveryPolicy::ConservativeHdr}) {
            Harness harness(150, 3, false, recovery);
            harness.start();
            harness.runAtFps(75.0, 7s);
            require(harness.scheduler.snapshot().validatedGenerationLimit == 1,
                "precondition failed: 75-to-150 generation was not validated");

            // Hold the old baseline while two slow samples could still become
            // a three-frame discontinuity. Once that candidate is rejected,
            // those samples remain part of the real source cadence.
            harness.frame(40ms);
            harness.frame(40ms);
            requireNear(harness.scheduler.snapshot().smoothedBaseFps,
                75.0F, 0.01F, "unconfirmed drop changed its comparison baseline");
            harness.frameAtFps(75.0);
            const auto measured = harness.scheduler.snapshot().smoothedBaseFps;
            require(measured > 40.0 && measured < 55.0,
                "rejected cadence drop discarded its slow source samples");
            require(!harness.scheduler.historyWarmupActive(),
                "two slow frames triggered discontinuity recovery");

            // Pending observations cannot cross a timing reset.
            harness.frame(60ms);
            harness.scheduler.resetTiming(harness.now);
            harness.frame(20ms);
            requireNear(harness.scheduler.snapshot().smoothedBaseFps,
                50.0F, 0.01F, "timing reset inherited pending slow samples");

            harness.frame(60ms);
            harness.frame(20ms, true);
            harness.frame(20ms);
            requireNear(harness.scheduler.snapshot().smoothedBaseFps,
                50.0F, 0.01F, "acquire backoff inherited pending slow samples");
        }
    }

    void testBurstySourceCadenceDoesNotLockOntoFastSamples() {
        for (const auto recovery : {AdaptiveRecoveryPolicy::OrderedSdr,
                AdaptiveRecoveryPolicy::ConservativeHdr}) {
            for (const bool automaticCap : {false, true}) {
                for (const bool stableCadence : {false, true}) {
                    Harness harness(150, 3, stableCadence, recovery, false, 2s,
                        240, true, automaticCap);
                    harness.start();
                    harness.runAtFps(75.0, 12s);
                    require(harness.scheduler.snapshot().validatedGenerationLimit == 1,
                        "precondition failed: burst trace had no proven generation");

                    // A 50 FPS source alternates 8/32 ms. The slow half alone is
                    // not a sustained drop. Previously it was discarded forever,
                    // reporting 125 FPS and suppressing most generated work. The
                    // capped variant uses 14/30 ms: both intervals respect the
                    // reporter's automatic 75 FPS cap, but previously only the
                    // 14 ms half contributed to the estimate.
                    size_t outputs = 0;
                    for (size_t frame = 0; frame < 1200; ++frame) {
                        const auto shortInterval = automaticCap ? 14ms : 8ms;
                        const auto longInterval = automaticCap ? 30ms : 32ms;
                        const auto plan = harness.frame(
                            frame % 2 ? longInterval : shortInterval, false, false);
                        requireValidTimestamps(plan, 2);
                        require(!harness.scheduler.historyWarmupActive(),
                            "alternating sub-stall intervals restarted history");
                        harness.scheduler.reportGeneratedFrameDelivery(
                            {plan.size(), plan.size()});
                        if (frame >= 1000)
                            outputs += 1 + plan.size();
                    }
                    const auto snapshot = harness.scheduler.snapshot();
                    require(snapshot.smoothedBaseFps > 40.0 &&
                            snapshot.smoothedBaseFps < 60.0,
                        "bursty source cadence locked onto only the fast samples");
                    require(outputs >= 540 && outputs <= 600,
                        "bursty source lost useful generation or exceeded its ceiling: outputs=" +
                            std::to_string(outputs) + ", limit=" +
                            std::to_string(snapshot.validatedGenerationLimit) +
                            ", recovery=" + std::to_string(static_cast<int>(recovery)) +
                            ", cap=" + std::to_string(automaticCap) +
                            ", smooth=" + std::to_string(stableCadence));
                    require(harness.diagnostics.count("cadence-refresh") == 0,
                        "bursty source was mistaken for a sustained cadence drop");
                }
            }
        }
    }

    void testHistoryWarmupUsesPresentStartDespitePrivateWork() {
        for (const bool smooth : {false, true}) {
            Harness harness(120, 3, smooth, AdaptiveRecoveryPolicy::OrderedSdr);
            harness.start();
            harness.runAtFps(60.0, 12s);
            require(harness.scheduler.snapshot().validatedGenerationLimit == 1,
                "precondition failed: recovery needs a validated 2x baseline");
            const auto refreshes = harness.diagnostics.count("cadence-refresh");
            harness.scheduler.ensureHistoryWarmup(3, true);
            const auto period = std::chrono::nanoseconds{16'666'667};
            auto nextPresent = harness.now;
            size_t generated = 0;
            for (size_t frame = 0; frame < 300; ++frame) {
                nextPresent += period;
                const auto presentStarted = nextPresent;
                harness.now = presentStarted;
                AdaptiveFramePlan plan;
                if (!harness.scheduler.historyWarmupActive())
                    plan = harness.scheduler.planFrame(presentStarted, false);
                harness.scheduler.reportGeneratedFrameDelivery({
                    .requested = plan.size(),
                    .acceptedForPresentation = plan.size(),
                });
                // Completion would seed ~214 FPS from a steady 60-FPS source
                // and restart history every five frames. Keep the entry clock.
                harness.now += 12ms;
                if (harness.scheduler.historyWarmupActive())
                    harness.scheduler.consumeHistoryWarmupFrame(presentStarted);
                generated += plan.size();
            }
            require(harness.diagnostics.count("cadence-refresh") == refreshes,
                "private history work caused a false cadence-drop loop");
            require(generated >= 295 && generated <= 300,
                "steady source did not promptly resume full 2x delivery");
            require(std::abs(harness.scheduler.snapshot().smoothedBaseFps - 60.0) < 0.01,
                "post-warmup cadence included a partial application frame");
        }
    }

    void testSdrCadenceDropRefreshesHistoryWithoutFullStabilization() {
        Harness harness(120, 3, false, AdaptiveRecoveryPolicy::OrderedSdr);
        harness.start();
        harness.runAtFps(60.0, 7s);
        require(harness.scheduler.snapshot().validatedGenerationLimit == 1,
            "precondition failed: SDR 2x was not validated");

        harness.frameAtFps(30.0);
        harness.frameAtFps(30.0);
        harness.frameAtFps(30.0);
        const auto snapshot = harness.scheduler.snapshot();
        require(snapshot.phase == AdaptiveSchedulerPhase::HistoryWarmup,
            "SDR cadence drop did not use a short history refresh");
        require(snapshot.validatedGenerationLimit == 1,
            "SDR cadence drop discarded the validated multiplier");
        require(!snapshot.discontinuityRecoveryActive,
            "SDR cadence drop entered discontinuity recovery");
        const auto* refresh = harness.diagnostics.last("cadence-refresh");
        require(refresh && refresh->reason == "cadence-drop",
            "SDR cadence-drop refresh was not observable");
    }

    void testSdrSustainedHardStallDoesNotRestartHistoryRefresh() {
        Harness harness(120, 2, true, AdaptiveRecoveryPolicy::OrderedSdr);
        harness.start();
        harness.runAtFps(60.0, 12s);
        require(harness.scheduler.snapshot().phase ==
                    AdaptiveSchedulerPhase::StableCadence &&
                harness.scheduler.snapshot().validatedGenerationLimit == 1,
            "precondition failed: SDR Smooth Cadence 2x was not accepted");

        // A hard interval starts the short SDR refresh, then the following real
        // frames remain too slow for generation. They must remain
        // native/history-only rather than scheduling another two-frame refresh
        // indefinitely.
        require(harness.frame(150ms).empty(),
            "first SDR stall generated from stale temporal history");
        require(harness.frame(150ms).empty(),
            "consecutive SDR stall bypassed history recovery");
        for (size_t frame = 0; frame < 2; ++frame) {
            harness.now += 150ms;
            harness.scheduler.consumeHistoryWarmupFrame(harness.now);
        }
        for (size_t frame = 0; frame < 8; ++frame) {
            require(harness.frame(150ms).empty(),
                "sustained hard SDR stall generated output");
        }
        require(harness.diagnostics.count("cadence-refresh") == 1,
            "sustained hard SDR stall restarted the history refresh");
        require(!harness.scheduler.historyWarmupActive(),
            "sustained hard SDR stall left history warm-up active");

        // Hovering around the old 10-FPS boundary must neither restart the
        // refresh nor count as a confirmed recovery. This is the remaining
        // boundary chatter that remains after the refresh-loop fix.
        for (size_t frame = 0; frame < 4; ++frame) {
            require(harness.frame(90ms).empty(),
                "near-boundary SDR cadence resumed generation");
            require(harness.frame(110ms).empty(),
                "near-boundary SDR cadence generated output");
        }
        require(harness.diagnostics.count("cadence-refresh") == 1,
            "near-boundary SDR cadence restarted the history refresh");

        require(harness.frameAtFps(60.0).empty(),
            "SDR resumed on the first healthy recovery sample");
        require(harness.frameAtFps(60.0).empty(),
            "SDR resumed before recovery hysteresis completed");
        const auto thirdRecoveredPlan = harness.frameAtFps(60.0);
        const auto fourthRecoveredPlan = harness.frameAtFps(60.0);
        require(thirdRecoveredPlan.size() == 1 ||
                fourthRecoveredPlan.size() == 1,
            "SDR did not resume its retained 2x level after confirmed recovery");
    }

    void testImpossibleFastBurstDoesNotCorruptCadence() {
        Harness harness(120, 3);
        harness.start();
        harness.runAtFps(60.0, 7s);
        const auto before = harness.scheduler.snapshot();
        for (size_t i = 0; i < 30; ++i)
            require(harness.frame(1ms).empty(),
                "impossible fast-present burst generated interpolation work");
        harness.frameAtFps(60.0);
        const auto after = harness.scheduler.snapshot();
        require(after.validatedGenerationLimit ==
                before.validatedGenerationLimit,
            "fast-present burst corrupted the proven generation level");
        require(after.smoothedBaseFps < 80.0,
            "fast-present burst polluted the gameplay cadence estimate");
        require(harness.diagnostics.contains("fast-burst-complete"),
            "fast-present burst completion was not observable");
    }

    void testRejectedFirstProbeEntersBoundedRearm() {
        Harness harness(180, 2);
        harness.start();
        for (size_t frame = 0;
                frame < 600 &&
                    !harness.scheduler.snapshot().rampEvaluationActive;
                ++frame) {
            harness.frameAtFps(60.0);
        }
        require(harness.scheduler.snapshot().rampEvaluationActive,
            "precondition failed: initial multiplier probe did not begin");
        // 34 FPS is slow enough to make 2x counterproductive against the
        // 60 FPS baseline, but not slow enough to trip the separate 2x raw
        // cadence-discontinuity detector before the one-second probe ends.
        harness.runAtFps(34.0, 2s);
        const auto snapshot = harness.scheduler.snapshot();
        require(snapshot.rearmRequired,
            "harmful first multiplier probe did not enter rearm cooldown");
        require(snapshot.validatedGenerationLimit == 0,
            "rejected first probe was incorrectly treated as validated");
        const auto* result = harness.diagnostics.last("ramp-result");
        require(result && !result->accepted,
            "rejected probe result was not emitted deterministically");
    }

    void testRejectedFirstProbeBackoffSurvivesFocusReturns() {
        for (const bool confirmedReturn : {false, true}) {
            Harness harness(180, 2);
            harness.start();
            const auto reachProbe = [&] {
                for (size_t frame = 0; frame < 6000; ++frame) {
                    harness.deliveredFrameAtFps(60.0);
                    if (harness.scheduler.snapshot().rampEvaluationActive)
                        return true;
                }
                return false;
            };
            const auto rejectProbe = [&] {
                require(reachProbe(), "first-rung retry did not become eligible");
                while (harness.scheduler.snapshot().rampEvaluationActive)
                    harness.deliveredFrameAtFps(34.0);
                require(harness.scheduler.snapshot().rearmRequired &&
                        harness.scheduler.validatedGenerationLimit() == 0,
                    "harmful first-rung trial was not rejected");
            };

            rejectProbe();
            require(!harness.scheduler.refreshHigherLoadRetry(harness.now),
                "VRR change discarded the rejected native-to-2x safety cooldown");
            const auto ramps = harness.diagnostics.count("ramp");
            harness.now += 500ms;
            harness.scheduler.resumeAfterExternalInterruption(
                harness.now, confirmedReturn
            );
            for (size_t frame = 0; frame < 360; ++frame) {
                harness.deliveredFrameAtFps(60.0);
                require(harness.scheduler.snapshot().rearmRequired &&
                        harness.diagnostics.count("ramp") == ramps,
                    "menu return bypassed a rejected first-rung cooldown");
            }
            rejectProbe();
            const auto* second = harness.diagnostics.last("adaptive-rearm-scheduled");
            require(second && second->previousLimit == 2 && second->duration == 30s,
                "menu return reset first-rung failure escalation");

            harness.now += 120s;
            harness.scheduler.resumeAfterExternalInterruption(
                harness.now, confirmedReturn
            );
            rejectProbe();
            const auto* third = harness.diagnostics.last("adaptive-rearm-scheduled");
            require(third && third->previousLimit == 3 && third->duration == 60s,
                "elapsed menu cooldown erased first-rung failure history");

            require(reachProbe(), "failed first rung never retried after its cooldown");
            while (harness.scheduler.snapshot().rampEvaluationActive)
                harness.deliveredFrameAtFps(58.0);
            require(harness.scheduler.validatedGenerationLimit() == 1,
                "first-rung backoff prevented a newly beneficial workload");
        }
    }

    void testInterruptedProbeRearmsWithoutFailurePenalty() {
        Harness harness(180, 3);
        harness.start();
        for (size_t frame = 0;
                frame < 600 &&
                    !harness.scheduler.snapshot().rampEvaluationActive;
                ++frame) {
            harness.frameAtFps(60.0);
        }
        require(harness.scheduler.snapshot().rampEvaluationActive,
            "precondition failed: multiplier probe did not begin");

        harness.frame(400ms);
        auto snapshot = harness.scheduler.snapshot();
        require(snapshot.rearmRequired,
            "interrupted probe did not enter bounded rearm");
        const auto* scheduled = harness.diagnostics.last(
            "adaptive-rearm-scheduled"
        );
        require(scheduled && scheduled->reason == "probe-interrupted",
            "interrupted probe was recorded as a throughput rejection");

        harness.runAtFps(60.0, 4s);
        snapshot = harness.scheduler.snapshot();
        require(!snapshot.rearmRequired,
            "stable cadence did not rearm an interrupted probe promptly");
        const auto* ready = harness.diagnostics.last("adaptive-rearm-ready");
        require(ready && ready->reason == "probe-interrupted",
            "interrupted probe rearm decision was not observable");
    }

    void testRejectedFirstProbeRebasesAfterPersistentNativeDeficit() {
        Harness harness(120, 3);
        harness.start();
        for (size_t frame = 0;
                frame < 600 &&
                    !harness.scheduler.snapshot().rampEvaluationActive;
                ++frame) {
            harness.frameAtFps(100.0);
        }
        require(harness.scheduler.snapshot().rampEvaluationActive,
            "precondition failed: initial multiplier probe did not begin");

        harness.runAtFps(60.0, 2s);
        require(harness.scheduler.snapshot().rearmRequired,
            "harmful first probe did not enter rearm cooldown");

        harness.runAtFps(75.0, 20s);
        const auto snapshot = harness.scheduler.snapshot();
        require(!snapshot.rearmRequired,
            "stable lower gameplay cadence remained permanently native-only");
        require(snapshot.validatedGenerationLimit >= 1,
            "stable lower gameplay cadence did not retry useful generation");
        require(harness.diagnostics.contains("adaptive-rearm-ready"),
            "lower gameplay baseline rearm was not observable");
    }

    void testCounterproductiveFirstStepNeverEscalates() {
        Harness harness(180, 3);
        harness.start();
        for (size_t frame = 0;
                frame < 600 &&
                    !harness.scheduler.snapshot().rampEvaluationActive;
                ++frame) {
            harness.frameAtFps(60.0);
        }
        require(harness.scheduler.snapshot().rampEvaluationActive,
            "precondition failed: initial multiplier probe did not begin");

        harness.runAtFps(31.0, 3s);
        const auto* result = harness.diagnostics.last("ramp-result");
        require(result && !result->accepted &&
                result->reason == "unpaid-real-frame-cost",
            "counterproductive first workload was not rejected by the common rule");
        require(harness.scheduler.snapshot().validatedGenerationLimit == 0 &&
                harness.scheduler.snapshot().rearmRequired,
            "rejected first workload escalated past the proven native level");
    }

    void testRejectedHigherLevelRetainsProvenLoadAndBacksOff() {
        Harness harness(180, 3);
        harness.start();
        for (size_t frame = 0;
                frame < 900;
                ++frame) {
            harness.frameAtFps(60.0);
            const auto snapshot = harness.scheduler.snapshot();
            if (snapshot.rampEvaluationActive &&
                    snapshot.generationLimit == 2 &&
                    snapshot.validatedGenerationLimit == 1) {
                break;
            }
        }
        auto snapshot = harness.scheduler.snapshot();
        require(snapshot.rampEvaluationActive &&
                snapshot.generationLimit == 2 &&
                snapshot.validatedGenerationLimit == 1,
            "precondition failed: higher-level probe did not begin from proven 2x");

        harness.runAtFps(35.0, 2s);
        snapshot = harness.scheduler.snapshot();
        require(!snapshot.rampEvaluationActive,
            "counterproductive higher-level probe did not finish");
        require(snapshot.validatedGenerationLimit == 1,
            "rejected higher-level probe discarded the proven 2x load");
        const auto* backoff = harness.diagnostics.last("ramp-backoff");
        require(backoff && backoff->testedLimit == 2 &&
                backoff->previousLimit == 1,
            "higher-level rejection did not schedule first bounded retry delay");
    }

    void testOrderedSdrRejectsUnpaidHigherLevelBelowTarget() {
        Harness harness(
            120, 3, false, AdaptiveRecoveryPolicy::OrderedSdr
        );
        harness.start();

        while (!harness.scheduler.snapshot().rampEvaluationActive)
            harness.frameAtFps(60.0);
        while (harness.scheduler.snapshot().rampEvaluationActive)
            harness.frameAtFps(40.0);
        require(harness.scheduler.snapshot().validatedGenerationLimit == 1,
            "precondition failed: useful ordered-SDR 2x level was not accepted");

        while (!harness.scheduler.snapshot().rampEvaluationActive)
            harness.frameAtFps(31.2726);
        require(harness.scheduler.snapshot().generationLimit == 2 &&
                harness.scheduler.snapshot().validatedGenerationLimit == 1,
            "precondition failed: ordered-SDR 3x probe did not begin");

        while (harness.scheduler.snapshot().rampEvaluationActive)
            harness.frameAtFps(22.5732);

        const auto snapshot = harness.scheduler.snapshot();
        const auto* result = harness.diagnostics.last("ramp-result");
        require(result && !result->accepted &&
                result->previousLimit == 1 && result->testedLimit == 2,
            "ordered SDR accepted displayed gain smaller than its real-frame cost");
        require(result->reason == "unpaid-real-frame-cost" &&
                snapshot.validatedGenerationLimit == 1,
            "rejected 3x workload did not retain the proven 2x level");
    }

    void testHigherPromotionPrefersMeasuredTarget() {
        for (const uint32_t target : {60U, 120U, 144U, 240U}) {
            for (const size_t multiplier : {3U, 4U, 5U}) {
                for (const bool smooth : {false, true}) {
                    for (const auto policy : {AdaptiveRecoveryPolicy::OrderedSdr,
                            AdaptiveRecoveryPolicy::ConservativeHdr}) {
                        Harness harness(target, multiplier, smooth, policy,
                            false, 2s, target, false);
                        harness.start();
                        const double baseline = static_cast<double>(target) * 0.96 /
                            static_cast<double>(multiplier - 1);
                        harness.runAtFps(baseline, 4s);
                        harness.scheduler.restoreGenerationLimit(harness.now,
                            multiplier - 2, "target-test-lower-rung");
                        for (size_t frame = 0; frame < 1500 &&
                                !harness.scheduler.snapshot().rampEvaluationActive; ++frame)
                            harness.frameAtFps(baseline);
                        require(harness.scheduler.snapshot().rampEvaluationActive &&
                                harness.scheduler.snapshot().generationLimit == multiplier - 1,
                            "target fixture did not begin its adjacent higher trial");
                        const double pacedFps = static_cast<double>(target) /
                            static_cast<double>(multiplier);
                        for (size_t frame = 0; frame < 300 &&
                                harness.scheduler.snapshot().rampEvaluationActive; ++frame)
                            harness.frameAtFps(pacedFps);
                        require(harness.scheduler.validatedGenerationLimit() == multiplier - 1,
                            "delivered target was rejected: target=" + std::to_string(target) +
                                " multiplier=" + std::to_string(multiplier) +
                                " smooth=" + std::to_string(smooth) +
                                " policy=" + std::to_string(static_cast<int>(policy)));
                        const auto ramps = harness.diagnostics.count("ramp");
                        harness.runAtFps(pacedFps, 4s);
                        require(harness.scheduler.validatedGenerationLimit() == multiplier - 1 &&
                                harness.diagnostics.count("ramp") == ramps,
                            "target delivery failed to retain its lowest sufficient workload");
                    }
                }
            }
        }
    }

    void testTargetPreferenceRequiresWholeTrialDelivery() {
        for (const size_t failure : {0U, 1U, 2U, 3U, 4U, 5U, 6U, 7U}) {
            Harness harness(120, 3, false, AdaptiveRecoveryPolicy::OrderedSdr,
                false, 2s, 120, false);
            harness.start();
            const double baseline = failure == 4 ? 58.0 : 56.0;
            harness.runAtFps(baseline, 4s);
            harness.scheduler.restoreGenerationLimit(harness.now, 1,
                "target-evidence-lower-rung");
            for (size_t frame = 0; frame < 1200 &&
                    !harness.scheduler.snapshot().rampEvaluationActive; ++frame)
                harness.frameAtFps(baseline);
            require(harness.scheduler.snapshot().rampEvaluationActive,
                "target evidence fixture never started its 3x trial");
            const auto started = harness.now;
            for (size_t frame = 0; frame < 150 &&
                    harness.scheduler.snapshot().rampEvaluationActive; ++frame) {
                if (frame == 20 && failure == 5)
                    harness.frame(1ms, false, false); // Production omits empty-plan delivery reports.
                if (frame == 20 && failure == 6)
                    harness.scheduler.resetTiming(harness.now);
                if (frame == 20 && failure == 7)
                    harness.frameAtFps(40.0, true, false); // Bypassed generated acquisition.
                const double fps = failure == 2
                    ? (harness.now - started < 800ms ? 35.0 : 42.0)
                    : failure == 3 ? 38.0
                    : failure == 4 ? (harness.now - started < 900ms ? 39.0 : 40.0)
                    : 40.0;
                const auto plan = harness.frameAtFps(fps, false, false);
                if (failure == 0 && frame == 3)
                    continue; // Missing observation, even though the projection reaches 120.
                harness.scheduler.reportGeneratedFrameDelivery({plan.size(),
                    failure == 1 && frame == 3 && !plan.empty()
                        ? plan.size() - 1 : plan.size()});
            }
            const auto* result = harness.diagnostics.last("ramp-result");
            require(result && !result->accepted &&
                    result->reason == "unpaid-real-frame-cost" &&
                    harness.scheduler.validatedGenerationLimit() == 1,
                "incomplete delivery, a fast tail, a target deficit, or an unpaid measured margin bypassed the cost guard");
        }
    }

    void testAdaptiveHigherLoadNeedsMeaningfulNetGain() {
        for (const auto [probeFps, shouldAccept] : {
                std::pair{30.0, false}, std::pair{32.0, true}}) {
            Harness harness(
                120, 3, false, AdaptiveRecoveryPolicy::OrderedSdr,
                false, 2s, 120, false
            );
            harness.start();
            for (size_t frame = 0; frame < 900 &&
                    !harness.scheduler.snapshot().rampEvaluationActive;
                    ++frame)
                harness.frameAtFps(60.0);
            require(harness.scheduler.snapshot().rampEvaluationActive,
                "precondition failed: 2x probe did not begin");
            while (harness.scheduler.snapshot().rampEvaluationActive)
                harness.frameAtFps(40.0);
            require(harness.scheduler.snapshot().validatedGenerationLimit == 1,
                "precondition failed: 40 FPS 2x load was not validated");

            for (size_t frame = 0; frame < 900 &&
                    !harness.scheduler.snapshot().rampEvaluationActive;
                    ++frame)
                harness.frameAtFps(40.0);
            require(harness.scheduler.snapshot().rampEvaluationActive &&
                    harness.scheduler.snapshot().generationLimit == 2,
                "precondition failed: 3x probe did not begin");
            while (harness.scheduler.snapshot().rampEvaluationActive)
                harness.frameAtFps(probeFps);

            const auto* result = harness.diagnostics.last("ramp-result");
            require(result && result->accepted == shouldAccept &&
                    harness.scheduler.snapshot().validatedGenerationLimit ==
                        (shouldAccept ? 2u : 1u),
                "3x workload decision did not distinguish a marginal "
                "40-to-30 FPS trade from a useful 40-to-32 FPS trade");
        }
    }

    void testConfirmedFocusReturnRetainsProvenLevel() {
        for (const bool smooth : {false, true}) {
            Harness harness(120, 3, smooth, AdaptiveRecoveryPolicy::OrderedSdr);
            harness.start();
            harness.runAtFps(40.0, 15s);
            require(harness.scheduler.snapshot().validatedGenerationLimit == 2,
                "precondition failed: gameplay had no proven 3x level");
            const auto stalls = harness.diagnostics.count("cadence-refresh");
            // No planFrame calls during confirmed menu focus, even if it
            // lasts minutes. Recovery observes fresh frames only on return.
            harness.now += 120s;
            harness.scheduler.resumeAfterExternalInterruption(harness.now, true);
            require(harness.scheduler.snapshot().validatedGenerationLimit == 2 &&
                    harness.scheduler.historyWarmupActive(),
                "focus return lost proven capacity or retained stale history");
            const auto plan = harness.runAtFps(40.0, 4s);
            require(harness.scheduler.snapshot().validatedGenerationLimit == 2 &&
                    plan.size() == 2 &&
                    harness.diagnostics.count("cadence-refresh") == stalls,
                "menu time polluted cadence or prevented ordinary 3x recovery");
        }
    }

    void testMenuReturnHoldsTargetProvenLowerMultiplier() {
        for (const bool smooth : {false, true}) {
            for (const bool automaticBaseCap : {false, true}) {
                for (const uint32_t maximumMultiplier : {3u, 4u, 5u}) {
                    Harness harness(
                        120, maximumMultiplier, smooth,
                        AdaptiveRecoveryPolicy::OrderedSdr, false,
                        ls::dynamicCadenceProbeIntervalDuration(
                            ls::GameConfDefaults::dynamicCadenceProbeIntervalSeconds
                        ),
                        120, true, automaticBaseCap
                    );
                    harness.start();
                    harness.runAtFps(60.0, 12s);
                    auto snapshot = harness.scheduler.snapshot();
                    require(snapshot.validatedGenerationLimit == 1 &&
                            (!smooth || snapshot.stableCadenceLimit == 1),
                        "precondition failed: menu return had no target-proven 2x cadence");
                    const auto ramps = harness.diagnostics.count("ramp");

                    harness.now += 2s;
                    harness.scheduler.resumeAfterExternalInterruption(
                        harness.now, true
                    );
                    for (size_t frame = 0; frame < 3; ++frame) {
                        harness.now += 22ms;
                        harness.scheduler.consumeHistoryWarmupFrame(harness.now);
                    }

                    // Time below target without delivery observations cannot
                    // release the pre-menu baseline; fresh proof is required.
                    const auto degradedPlan = harness.runAtFps(45.0, 12s, false);
                    snapshot = harness.scheduler.snapshot();
                    require(!snapshot.rampEvaluationActive &&
                            snapshot.generationLimit == 1 &&
                            snapshot.validatedGenerationLimit == 1 &&
                            degradedPlan.size() == 1 &&
                            harness.diagnostics.count("ramp") == ramps,
                        "post-menu deficit increased work before the target-proven 2x level recovered");

                    harness.runAtFps(60.0, 4s);
                    snapshot = harness.scheduler.snapshot();
                    require(snapshot.validatedGenerationLimit == 1 &&
                            harness.diagnostics.count("ramp") == ramps,
                        "recovered 2x cadence unnecessarily returned to the higher load");

                    for (size_t frame = 0;
                            frame < 1200 &&
                                !harness.scheduler.snapshot().rampEvaluationActive;
                            ++frame) {
                        harness.frameAtFps(45.0);
                    }
                    snapshot = harness.scheduler.snapshot();
                    require(snapshot.rampEvaluationActive &&
                            snapshot.generationLimit == 2 &&
                            snapshot.validatedGenerationLimit == 1 &&
                            harness.diagnostics.count("ramp") == ramps + 1,
                        "a recovered menu return permanently disabled ordinary Adaptive promotion");
                }
            }
        }
    }

    void testMenuReturnRequalifiesChangedSceneAcrossModes() {
        for (const uint32_t target : {60u, 90u, 120u}) {
            for (const size_t priorMultiplier : {2u, 3u, 4u}) {
                for (const bool steady : {false, true}) {
                    for (const bool smooth : {false, true}) {
                        Harness harness(target, 5, smooth,
                            AdaptiveRecoveryPolicy::OrderedSdr, false,
                            2s, target, true, steady);
                        const double sourceFps = double(target) / priorMultiplier;
                        harness.start();
                        harness.runAtFps(sourceFps, 15s);
                        require(harness.scheduler.validatedGenerationLimit() ==
                                priorMultiplier - 1,
                            "precondition failed: menu test has wrong validated load");
                        const auto ramps = harness.diagnostics.count("ramp");
                        harness.now += 2s;
                        harness.scheduler.resumeAfterExternalInterruption(
                            harness.now, true
                        );
                        const auto returnedAt = harness.now;
                        while (harness.now - returnedAt < 4s)
                            harness.deliveredFrameAtFps(sourceFps * 0.8);
                        require(harness.diagnostics.count("ramp") == ramps,
                            "changed menu scene skipped recovery promotion delay");
                        while (harness.now - returnedAt < 15s)
                            harness.deliveredFrameAtFps(sourceFps * 0.8);
                        require(harness.scheduler.validatedGenerationLimit() >
                                priorMultiplier - 1,
                            "healthy changed scene was stranded at pre-menu multiplier");
                        require(harness.diagnostics.contains("adaptive-rearm-ready"),
                            "fresh lower-load requalification was not observable");
                    }
                }
            }
        }
    }

    void testMenuReturnDoesNotInventTargetProof() {
        Harness harness(120, 3, false, AdaptiveRecoveryPolicy::OrderedSdr);
        harness.start();
        for (size_t frame = 0; frame < 1000 &&
                harness.scheduler.validatedGenerationLimit() == 0; ++frame)
            harness.deliveredFrameAtFps(45.0);
        require(harness.scheduler.validatedGenerationLimit() == 1,
            "precondition failed: below-target menu needs validated 2x");
        harness.now += 2s;
        harness.scheduler.resumeAfterExternalInterruption(harness.now, true);
        for (size_t frame = 0; frame < 45 * 12; ++frame)
            harness.deliveredFrameAtFps(45.0);
        require(harness.scheduler.validatedGenerationLimit() == 2,
            "a workload that never met target was treated as target-proven");
        require(!harness.diagnostics.contains("adaptive-rearm-ready"),
            "below-target menu unnecessarily required stale-baseline requalification");
    }

    void testLowerLoadRequalificationCoexistsWithNativeProbes() {
        for (const auto interval : {100ms, 500ms, 1000ms, 1500ms, 2000ms, 3000ms}) {
            Harness harness(120, 3, false, AdaptiveRecoveryPolicy::OrderedSdr,
                true, interval, 120, false);
            harness.start();
            for (size_t frame = 0; frame < 60 * 15; ++frame)
                harness.deliveredFrameAtFps(60.0);
            require(harness.scheduler.validatedGenerationLimit() == 1,
                "precondition failed: native-probe menu test needs proven 2x");
            harness.now += 2s;
            harness.scheduler.resumeAfterExternalInterruption(harness.now, true);
            const auto returnedAt = harness.now;
            auto deliveredEvidence = AdaptiveScheduler::Clock::duration{};
            bool checkedEvidence = false;
            for (size_t frame = 0; frame < 45 * 20; ++frame) {
                const auto previousAt = harness.now;
                const auto plan = harness.deliveredFrameAtFps(45.0);
                const auto frameDuration = harness.now - previousAt;
                // Only delivered 2x work after the existing five-second
                // higher-trial delay may pay for the requalification window.
                if (harness.now >= returnedAt + 5s && plan.size() == 1)
                    deliveredEvidence += frameDuration;
                if (!checkedEvidence &&
                        harness.diagnostics.contains("adaptive-rearm-ready")) {
                    require(deliveredEvidence + 2 * frameDuration >=
                            AdaptiveScheduler::stableRearmDuration(),
                        "intentional native probes counted as delivered lower-load evidence");
                    checkedEvidence = true;
                }
            }
            require(checkedEvidence,
                "native sampling never completed lower-load requalification");
            require(harness.scheduler.validatedGenerationLimit() == 2,
                "periodic native sampling prevented fresh lower-load qualification");
        }
    }

    void testLowerLoadRequalificationNeedsContinuousEvidence() {
        for (const auto delivered : {std::optional<bool>{false},
                std::optional<bool>{}}) {
            Harness harness(120, 3, false, AdaptiveRecoveryPolicy::OrderedSdr);
            harness.start();
            harness.runAtFps(60.0, 12s);
            const auto ramps = harness.diagnostics.count("ramp");
            harness.now += 2s;
            harness.scheduler.resumeAfterExternalInterruption(harness.now, true);
            for (size_t frame = 0; frame < 45 * 15; ++frame)
                harness.deliveredFrameAtFps(45.0,
                    frame % 30 == 0 ? delivered : std::optional<bool>{true});
            require(harness.diagnostics.count("ramp") == ramps,
                "missing or failed delivery qualified a stale lower-load baseline");
            // Continually changing load cannot be mistaken for settled evidence.
            const auto changingAt = harness.now;
            while (harness.now - changingAt < 10s) {
                const auto seconds = std::chrono::duration_cast<
                    std::chrono::seconds>(harness.now - changingAt).count();
                harness.deliveredFrameAtFps(seconds % 2 ? 45.0 : 30.0);
            }
            require(harness.diagnostics.count("ramp") == ramps,
                "moving source qualified a stable lower-load baseline");
            for (size_t frame = 0; frame < 45 * 12; ++frame)
                harness.deliveredFrameAtFps(frame % 2 ? 44.0 : 46.0);
            require(harness.scheduler.validatedGenerationLimit() == 2,
                "delivery recovery with normal source jitter remained stuck");
        }
    }

    void testHigherPromotionWaitsForSettledDemandAcrossModes() {
        for (const auto recovery : {AdaptiveRecoveryPolicy::OrderedSdr,
                AdaptiveRecoveryPolicy::ConservativeHdr}) {
            for (const bool steady : {false, true}) {
                for (const bool smooth : {false, true}) {
                    for (const size_t multiplier : {3u, 4u, 5u}) {
                        Harness harness(120, multiplier, smooth, recovery,
                            false, 2s, 120, false, steady);
                        const double sourceFps = 120.0 / (multiplier - 1);
                        harness.start();
                        harness.runAtFps(sourceFps, 20s);
                        require(harness.scheduler.validatedGenerationLimit() ==
                                multiplier - 2,
                            "precondition failed: lower target-proven rung did not settle");
                        const auto ramps = harness.diagnostics.count("ramp");

                        // Each dip exceeds the old one-second deficit guard,
                        // but recovers before proving settled higher demand.
                        for (size_t cycle = 0; cycle < 5; ++cycle) {
                            harness.runAtFps(sourceFps * 0.90, 1500ms);
                            harness.runAtFps(sourceFps, 2s);
                        }
                        require(harness.diagnostics.count("ramp") == ramps &&
                                harness.scheduler.validatedGenerationLimit() ==
                                    multiplier - 2,
                            "transient demand repeatedly promoted the higher workload");

                        // Real sustained demand, including ordinary frame-time
                        // jitter, must still reach every configured higher rung.
                        const auto deficitAt = harness.now;
                        for (size_t frame = 0;
                                harness.now - deficitAt < 10s; ++frame)
                            harness.deliveredFrameAtFps(sourceFps *
                                (frame % 2 ? 0.79 : 0.81));
                        require(harness.scheduler.validatedGenerationLimit() ==
                                multiplier - 1 &&
                                harness.diagnostics.count("ramp") == ramps + 1,
                            "settled noisy demand could not promote the higher workload");
                    }
                }
            }
        }
    }

    void testHigherPromotionNeedsContinuousDeliveredEvidence() {
        for (const bool steady : {false, true}) {
            for (const auto delivered : {std::optional<bool>{false},
                    std::optional<bool>{}}) {
                Harness harness(120, 3, false,
                    AdaptiveRecoveryPolicy::OrderedSdr, false,
                    2s, 120, false, steady);
                harness.start();
                harness.runAtFps(60.0, 12s);
                const auto ramps = harness.diagnostics.count("ramp");
                for (size_t frame = 0; frame < 45 * 15; ++frame)
                    harness.deliveredFrameAtFps(45.0,
                        frame % 30 == 0 ? delivered : std::optional<bool>{true});
                require(harness.diagnostics.count("ramp") == ramps,
                    "missing or failed delivery authorized an ordinary promotion");

                const auto changingAt = harness.now;
                while (harness.now - changingAt < 10s) {
                    const auto seconds = std::chrono::duration_cast<
                        std::chrono::seconds>(harness.now - changingAt).count();
                    harness.deliveredFrameAtFps(seconds % 2 ? 45.0 : 30.0);
                }
                require(harness.diagnostics.count("ramp") == ramps,
                    "a continuously moving source authorized an ordinary promotion");
                for (size_t frame = 0; frame < 45 * 10; ++frame)
                    harness.deliveredFrameAtFps(frame % 2 ? 44.0 : 46.0);
                require(harness.scheduler.validatedGenerationLimit() == 2,
                    "healthy settled demand remained stuck after delivery recovery");
            }
        }
    }

    void testOrdinaryPromotionCoexistsWithNativeProbes() {
        for (const auto interval : {100ms, 500ms, 1000ms, 3000ms}) {
            for (const bool steady : {false, true}) {
                Harness harness(120, 3, false,
                    AdaptiveRecoveryPolicy::OrderedSdr, true,
                    interval, 120, false, steady);
                harness.start();
                harness.runAtFps(45.0, 20s);
                require(harness.scheduler.validatedGenerationLimit() == 2 &&
                        harness.diagnostics.contains("dynamic-cadence-probe-rejected"),
                    "periodic native sampling stranded ordinary higher promotion");
            }
        }
    }

    void testHigherPromotionUsesStrongestQualifiedLowerLoad() {
        Harness harness(120, 3, false, AdaptiveRecoveryPolicy::OrderedSdr,
            false, 2s, 120, false);
        harness.start();
        harness.runAtFps(60.0, 12s);
        harness.runAtFps(45.0, 1500ms);
        for (size_t frame = 0; frame < 500 &&
                !harness.scheduler.snapshot().rampEvaluationActive; ++frame)
            harness.deliveredFrameAtFps(44.0);
        require(harness.scheduler.snapshot().rampEvaluationActive,
            "a small settled source variation prevented the higher trial");
        while (harness.scheduler.snapshot().rampEvaluationActive)
            harness.deliveredFrameAtFps(34.0);
        const auto* result = harness.diagnostics.last("ramp-result");
        require(result && !result->accepted &&
                result->previousBaseFps > 44.0 &&
                result->reason == "unpaid-real-frame-cost" &&
                harness.scheduler.validatedGenerationLimit() == 1,
            "the higher trial compared its cost only with the lower-load dip");
    }

    void testFailedHigherLoadRequalifiesChangedScene() {
        for (const uint32_t multiplier : {3u, 4u, 5u}) {
            for (const bool steady : {false, true}) {
                for (const bool smooth : {false, true}) {
                    for (const bool usefulRetry : {false, true}) {
                        Harness harness(120, multiplier, smooth,
                            AdaptiveRecoveryPolicy::OrderedSdr, false,
                            2s, 120, true, steady);
                        const double originalFps = 120.0 / (multiplier - 0.5);
                        harness.start();
                        for (size_t frame = 0; frame < 5000; ++frame) {
                            const auto snapshot = harness.scheduler.snapshot();
                            if (snapshot.rampEvaluationActive &&
                                    snapshot.generationLimit == multiplier - 1)
                                break;
                            harness.deliveredFrameAtFps(originalFps);
                        }
                        require(harness.scheduler.snapshot().rampEvaluationActive &&
                                harness.scheduler.snapshot().generationLimit == multiplier - 1,
                            "precondition failed: final higher-load trial did not start");
                        for (size_t frame = 0; frame < 500 &&
                                harness.scheduler.snapshot().rampEvaluationActive; ++frame)
                            harness.deliveredFrameAtFps(originalFps * 0.65);
                        require(harness.scheduler.validatedGenerationLimit() == multiplier - 2,
                            "precondition failed: harmful higher load was accepted");
                        const auto failedAt = harness.now;
                        const double changedFps = originalFps * 0.8;
                        while (harness.now - failedAt < 4s)
                            harness.deliveredFrameAtFps(changedFps);
                        require(!harness.scheduler.snapshot().rampEvaluationActive,
                            "new scene bypassed failed-probe cooldown");
                        for (size_t frame = 0; frame < 2000 &&
                                !harness.scheduler.snapshot().rampEvaluationActive; ++frame)
                            harness.deliveredFrameAtFps(changedFps);
                        require(harness.scheduler.snapshot().rampEvaluationActive,
                            "new delivered baseline could not retry the higher multiplier");
                        for (size_t frame = 0; frame < 500 &&
                                harness.scheduler.snapshot().rampEvaluationActive; ++frame)
                            harness.deliveredFrameAtFps(
                                changedFps * (usefulRetry ? 1.0 : 0.65));
                        const auto* result = harness.diagnostics.last("ramp-result");
                        require(result && result->accepted == usefulRetry,
                            "rebased retry bypassed adjacent workload comparison");
                        if (!usefulRetry) {
                            const auto* backoff = harness.diagnostics.last("ramp-backoff");
                            require(backoff && backoff->previousLimit == 2,
                                "requalification erased failed-probe backoff history");
                            const auto ramps = harness.diagnostics.count("ramp");
                            const auto retryFailedAt = harness.now;
                            while (harness.now - retryFailedAt < 14s)
                                harness.deliveredFrameAtFps(changedFps);
                            require(harness.diagnostics.count("ramp") == ramps,
                                "rejected fresh trial ignored its longer retry delay");
                        }
                    }
                }
            }
        }
    }

    AdaptiveFramePlan frameAfterFocusReturn(Harness& harness,
            const std::chrono::milliseconds interval) {
        harness.now += interval;
        // Match prepareFramePlan/presentHistoryOnly: warm-up never plans
        // synthetic work and consumes history at the present start boundary.
        if (harness.scheduler.historyWarmupActive()) {
            harness.scheduler.consumeHistoryWarmupFrame(harness.now);
            return {};
        }
        return harness.scheduler.planFrame(harness.now, false);
    }

    void testConfirmedFocusReturnBoundedFastResume() {
        for (const bool smooth : {false, true}) {
            Harness harness(120, 3, smooth, AdaptiveRecoveryPolicy::OrderedSdr);
            harness.start();
            harness.runAtFps(40.0, 15s);
            require(harness.scheduler.validatedGenerationLimit() == 2,
                "precondition failed: fast menu return needs proven 3x");
            const auto ramps = harness.diagnostics.count("ramp");
            for (const auto menuDuration : {500ms, 750ms, 30'000ms, 120'000ms,
                    500ms, 500ms, 500ms}) {
                harness.now += menuDuration;
                harness.scheduler.resumeAfterExternalInterruption(harness.now, true);
                const auto returnedAt = harness.now;
                require(harness.scheduler.historyWarmupRemaining() == 3,
                    "fast return skipped three fresh history frames");
                const auto* settling = harness.diagnostics.last("stabilization");
                require(settling && settling->duration == 0ms,
                    "confirmed return invented a time-based settling delay");
                AdaptiveFramePlan plan;
                for (size_t frame = 0; frame < 12; ++frame) {
                    plan = frameAfterFocusReturn(harness, 25ms);
                    if (frame < 3)
                        require(plan.empty(), "menu resume bypassed fresh history");
                    if (!plan.empty())
                        break;
                }
                require(plan.size() == 2 && harness.now - returnedAt <= 100ms,
                    "proven 3x did not return after three fresh history frames");
                harness.runAtFps(40.0, 1s);
                require(harness.scheduler.validatedGenerationLimit() == 2 &&
                        harness.diagnostics.count("ramp") == ramps,
                    "repeated menu returns restarted ordinary 3x qualification");
            }
        }
    }

    void testFocusReturnRetainsConservativeFallbacks() {
        for (const auto policy : {AdaptiveRecoveryPolicy::OrderedSdr,
                AdaptiveRecoveryPolicy::ConservativeHdr}) {
            Harness harness(120, 3, false, policy);
            harness.start();
            harness.runAtFps(40.0, 15s);
            harness.now += 2s;
            // Ordered SDR with uncertain focus and unsupported HDR with a
            // claimed return must both retain the ordinary stabilization.
            harness.scheduler.resumeAfterExternalInterruption(harness.now,
                policy == AdaptiveRecoveryPolicy::ConservativeHdr);
            const auto* settling = harness.diagnostics.last("stabilization");
            require(settling && settling->duration == 1s,
                "unconfirmed/unsupported return enabled fast settling");
            for (size_t frame = 0; frame < 39; ++frame)
                require(frameAfterFocusReturn(harness, 25ms).empty(),
                    "conservative return generated before one second");
        }

        // Live target/ceiling/cap changes and FG re-enable reconstruct the
        // scheduler. A confirmed menu return cannot validate its new policy.
        Harness changed(90, 2, false, AdaptiveRecoveryPolicy::OrderedSdr);
        changed.scheduler.beginStabilization(changed.now, "configuration-update");
        changed.now += 2s;
        changed.scheduler.resumeAfterExternalInterruption(changed.now, true);
        require(changed.scheduler.validatedGenerationLimit() == 0,
            "menu return invented a proven multiplier for a live policy reset");
        const auto* settling = changed.diagnostics.last("stabilization");
        require(settling && settling->duration == 1s,
            "unproven live policy used the short menu delay");
        for (size_t frame = 0; frame < 39; ++frame)
            require(frameAfterFocusReturn(changed, 25ms).empty(),
                "live policy reset bypassed ordinary qualification");
    }

    void testFastFocusReturnCannotBypassHistoryOrTransportSettling() {
        Harness harness(120, 3, false, AdaptiveRecoveryPolicy::OrderedSdr);
        harness.start();
        harness.runAtFps(40.0, 15s);
        harness.now += 2s;
        harness.scheduler.resumeAfterExternalInterruption(harness.now, true);
        for (size_t frame = 0; frame < 3; ++frame)
            require(frameAfterFocusReturn(harness, 100ms).empty(),
                "elapsed menu settling bypassed fresh history at low source FPS");
        require(!harness.scheduler.historyWarmupActive(),
            "three slow real frames failed to complete history warm-up");
        harness.scheduler.beginTransportRecovery(harness.now);
        const auto* settling = harness.diagnostics.last("stabilization");
        require(settling && settling->duration == 1s,
            "fast menu return shortened real transport recovery");
        for (size_t frame = 0; frame < 39; ++frame)
            require(frameAfterFocusReturn(harness, 25ms).empty(),
                "fast menu return bypassed transport recovery settling");

        harness.runAtFps(40.0, 15s);
        harness.scheduler.beginTransportRecovery(harness.now);
        const auto transportStarted = harness.now;
        harness.now += 100ms;
        harness.scheduler.resumeAfterExternalInterruption(harness.now, true);
        while (harness.now - transportStarted < 950ms)
            require(frameAfterFocusReturn(harness, 25ms).empty(),
                "menu return shortened an already active transport deadline");

        harness.runAtFps(40.0, 15s);
        harness.scheduler.resumeAfterExternalInterruption(harness.now, true);
        static_cast<void>(frameAfterFocusReturn(harness, 25ms));
        require(harness.scheduler.historyWarmupRemaining() == 2,
            "precondition failed: interrupted warm-up did not retain two frames");
        // The game presents once, then stops immediately for another menu.
        // Reusing the unfinished warm-up could interpolate across that gap.
        harness.now += 2s;
        harness.scheduler.resumeAfterExternalInterruption(harness.now, true);
        require(harness.scheduler.historyWarmupRemaining() == 3,
            "a second menu return reused history from before its interruption");
    }

    void testSmoothCadenceSettlesNearIntegerDemand() {
        Harness harness(90, 2, true);
        harness.start();
        const auto timestamps = harness.runAtFps(47.0, 12s);
        require(timestamps.size() == 1,
            "Smooth Cadence did not settle on constant 2x output");
        require(harness.scheduler.snapshot().phase ==
                AdaptiveSchedulerPhase::StableCadence,
            "accepted Smooth Cadence was not exposed as scheduler state");
        require(harness.diagnostics.contains(
                "adaptive-stable-cadence-accepted"),
            "Smooth Cadence acceptance was not observable");
    }

    void testSmoothCadenceConvergesFractionalTwoXOnMatchingRefresh() {
        Harness harness(
            120, 2, true, AdaptiveRecoveryPolicy::OrderedSdr, false,
            ls::dynamicCadenceProbeIntervalDuration(
                ls::GameConfDefaults::dynamicCadenceProbeIntervalSeconds
            ),
            120
        );
        harness.start();

        AdaptiveFramePlan plan;
        for (size_t frame = 0; frame < 1200; ++frame) {
            plan = harness.frameAtFps(68.0, false, false);
            harness.scheduler.reportGeneratedFrameDelivery({
                .requested = plan.size(),
                .acceptedForPresentation = plan.size(),
            });
            const auto* probe = harness.diagnostics.last(
                "adaptive-stable-cadence-probe"
            );
            if (probe && probe->reason == "ordered-2x-convergence")
                break;
        }
        const auto* probe = harness.diagnostics.last(
            "adaptive-stable-cadence-probe"
        );
        require(probe && probe->reason == "ordered-2x-convergence" &&
                harness.scheduler.snapshot().stableCadenceEvaluationActive &&
                plan.size() == 1,
            "target-matched Fractional cadence did not test constant 2x");

        for (size_t frame = 0; frame < 180; ++frame) {
            plan = harness.frameAtFps(60.0, false, false);
            harness.scheduler.reportGeneratedFrameDelivery({
                .requested = plan.size(),
                .acceptedForPresentation = plan.size(),
            });
            if (harness.diagnostics.contains(
                    "adaptive-stable-cadence-accepted")) {
                break;
            }
        }
        const auto* accepted = harness.diagnostics.last(
            "adaptive-stable-cadence-accepted"
        );
        const auto snapshot = harness.scheduler.snapshot();
        require(accepted && accepted->reason == "ordered-2x-convergence" &&
                snapshot.phase == AdaptiveSchedulerPhase::StableCadence &&
                snapshot.stableCadenceLimit == 1 &&
                !snapshot.stableCadenceEvaluationActive &&
                plan.size() == 1,
            "target-preserving 2x convergence did not become Smooth Cadence");
    }

    void testSmoothCadenceRejectsTwoXThatDoesNotConverge() {
        Harness harness(
            120, 2, true, AdaptiveRecoveryPolicy::OrderedSdr, false,
            ls::dynamicCadenceProbeIntervalDuration(
                ls::GameConfDefaults::dynamicCadenceProbeIntervalSeconds
            ),
            120
        );
        harness.start();

        AdaptiveFramePlan plan;
        for (size_t frame = 0; frame < 1200; ++frame) {
            plan = harness.frameAtFps(68.0, false, false);
            harness.scheduler.reportGeneratedFrameDelivery({
                .requested = plan.size(),
                .acceptedForPresentation = plan.size(),
            });
            const auto* probe = harness.diagnostics.last(
                "adaptive-stable-cadence-probe"
            );
            if (probe && probe->reason == "ordered-2x-convergence")
                break;
        }
        require(harness.scheduler.snapshot().stableCadenceEvaluationActive,
            "precondition failed: 2x convergence probe did not begin");

        for (size_t frame = 0; frame < 180; ++frame) {
            plan = harness.frameAtFps(68.0, false, false);
            harness.scheduler.reportGeneratedFrameDelivery({
                .requested = plan.size(),
                .acceptedForPresentation = plan.size(),
            });
            if (harness.diagnostics.contains(
                    "adaptive-stable-cadence-rejected")) {
                break;
            }
        }
        const auto* rejected = harness.diagnostics.last(
            "adaptive-stable-cadence-rejected"
        );
        require(rejected && rejected->reason == "ordered-2x-convergence" &&
                !harness.scheduler.snapshot().stableCadenceLimit,
            "2x cadence that remained above target was not rolled back");

        const size_t probes = harness.diagnostics.count(
            "adaptive-stable-cadence-probe"
        );
        harness.runAtFps(68.0, 10s);
        require(harness.diagnostics.count(
                    "adaptive-stable-cadence-probe") == probes,
            "failed 2x convergence retried before its bounded cooldown");
    }

    void testSmoothCadenceConvergenceRequiresTargetMatchedOrderedFifo() {
        Harness mismatchedRefresh(
            120, 2, true, AdaptiveRecoveryPolicy::OrderedSdr, false,
            ls::dynamicCadenceProbeIntervalDuration(
                ls::GameConfDefaults::dynamicCadenceProbeIntervalSeconds
            ),
            90
        );
        mismatchedRefresh.start();
        mismatchedRefresh.runAtFps(68.0, 12s);
        require(!mismatchedRefresh.diagnostics.contains(
                "adaptive-stable-cadence-probe"),
            "mismatched display refresh allowed a 2x convergence probe");

        Harness hdr(
            120, 2, true, AdaptiveRecoveryPolicy::ConservativeHdr, false,
            ls::dynamicCadenceProbeIntervalDuration(
                ls::GameConfDefaults::dynamicCadenceProbeIntervalSeconds
            ),
            120
        );
        hdr.start();
        hdr.runAtFps(68.0, 12s);
        require(!hdr.diagnostics.contains("adaptive-stable-cadence-probe"),
            "nonblocking HDR transport allowed a 2x convergence probe");
    }

    void testVrrFullFifoUsesOnlyValidatedHigherRung() {
        Harness harness(
            120, 3, true, AdaptiveRecoveryPolicy::OrderedSdr,
            false, 2s, 120, false, true
        );
        harness.start();
        harness.runAtFps(60.0, 12s);
        require(harness.scheduler.snapshot().validatedGenerationLimit == 1,
            "3x FIFO precondition unexpectedly skipped its lower rung");
        harness.runAtFps(50.0, 12s);
        const auto snapshot = harness.scheduler.snapshot();
        require(snapshot.validatedGenerationLimit == 2 &&
                snapshot.phase == AdaptiveSchedulerPhase::Active,
            "3x FIFO precondition did not validate a variable higher rung");

        harness.now += 20ms;
        const auto fifoPlan = harness.scheduler.planFrame(
            harness.now, false, 2
        );
        require(fifoPlan.size() == 2 &&
                harness.scheduler.snapshot().targetOutputClockActive == false,
            "VRR FIFO did not request its complete validated 3x batch");
        requireNear(fifoPlan[0], 1.0F / 3.0F, 0.0001F,
            "VRR FIFO 3x did not evenly space its first generated frame");
        requireNear(fifoPlan[1], 2.0F / 3.0F, 0.0001F,
            "VRR FIFO 3x did not evenly space its second generated frame");

        harness.now += 20ms;
        static_cast<void>(harness.scheduler.planFrame(harness.now, false));
        require(harness.scheduler.snapshot().targetOutputClockActive,
            "leaving VRR FIFO did not resume the Adaptive target clock");

        Harness fractional(
            120, 3, true, AdaptiveRecoveryPolicy::OrderedSdr,
            false, 2s, 120, false, false
        );
        fractional.start();
        fractional.runAtFps(50.0, 12s);
        require(fractional.scheduler.snapshot().validatedGenerationLimit == 2,
            "fractional control did not validate its higher rung");
        bool fractionalCountObserved = false;
        for (size_t frame = 0; frame < 20; ++frame) {
            fractional.now += 20ms;
            if (fractional.scheduler.planFrame(
                    fractional.now, false, 2).size() == 1) {
                fractionalCountObserved = true;
                break;
            }
        }
        require(fractionalCountObserved,
            "Fractional policy accepted the Steady VRR FIFO override");
    }

    void promoteForPacedLoadTest(Harness& harness, const size_t multiplier,
            const double lowerOutputFps) {
        harness.start();
        const double baseline = lowerOutputFps /
            static_cast<double>(multiplier - 1);
        harness.runAtFps(baseline, 4s);
        harness.scheduler.restoreGenerationLimit(harness.now, multiplier - 2,
            "paced-test-lower-rung");
        for (size_t frame = 0; frame < 1200; ++frame) {
            harness.frameAtFps(baseline);
            if (harness.scheduler.snapshot().rampEvaluationActive)
                break;
        }
        require(harness.scheduler.snapshot().rampEvaluationActive &&
                harness.scheduler.snapshot().generationLimit == multiplier - 1,
            "paced test did not start its adjacent higher-load trial");
        const double trialFps = 144.0 / static_cast<double>(multiplier);
        for (size_t frame = 0; frame < 300; ++frame) {
            harness.frameAtFps(trialFps);
            if (!harness.scheduler.snapshot().rampEvaluationActive)
                break;
        }
        require(harness.scheduler.snapshot().validatedGenerationLimit ==
                multiplier - 1,
            "paced test's ordinary load trial was not accepted");
    }

    AdaptiveFramePlan pacedLoadFrame(Harness& harness, const double fps,
            const size_t generationLimit, const bool fifo,
            const bool completeDelivery = true) {
        harness.now += std::chrono::duration_cast<std::chrono::nanoseconds>(
            std::chrono::duration<double>{1.0 / fps});
        const auto plan = harness.scheduler.planFrame(harness.now, false,
            fifo ? std::optional{generationLimit} : std::nullopt,
            fifo ? std::nullopt : std::optional{generationLimit});
        harness.scheduler.reportGeneratedFrameDelivery({
            plan.size(), completeDelivery ? plan.size() : 0,
        });
        return plan;
    }

    void testIntegerPacingPrefersDeliveredTargetAcrossMultipliers() {
        for (const bool fifo : {false, true}) {
            for (const size_t multiplier : {3U, 4U, 5U}) {
                for (const bool paid : {false, true}) {
                    Harness harness(120, multiplier, true,
                        AdaptiveRecoveryPolicy::OrderedSdr, false, 2s,
                        120, false, true, true);
                    const double lowerOutputFps = multiplier == 3 ? 108.0 : 114.0;
                    promoteForPacedLoadTest(harness, multiplier, lowerOutputFps);
                    require(harness.scheduler.snapshot().pacedLoadValidationPending,
                        "integer pacing lost its recent accepted baseline");
                    const auto initialRamps = harness.diagnostics.count("ramp");
                    const double settledFps = (paid ? 120.0 : lowerOutputFps) /
                        static_cast<double>(multiplier);
                    for (size_t frame = 0; frame < 100; ++frame) {
                        pacedLoadFrame(harness, settledFps, multiplier - 1, fifo);
                        if (!harness.scheduler.snapshot().pacedLoadValidationPending)
                            break;
                    }
                    const auto snapshot = harness.scheduler.snapshot();
                    require(!snapshot.pacedLoadValidationPending,
                        "settled integer pacing did not complete its bounded check");
                    require(snapshot.validatedGenerationLimit ==
                            (paid ? multiplier - 1 : multiplier - 2),
                        "settled pacing did not prefer the delivered target or reject overload");
                    require(snapshot.historyWarmupRemaining == 0 &&
                            !snapshot.automaticBaseCapSuppressed &&
                            !snapshot.discontinuityRecoveryActive,
                        "pacing validation changed history, cap ownership, or recovery");
                    if (paid) {
                        require(harness.diagnostics.contains("adaptive-paced-load-accepted"),
                            "useful settled pacing was not accepted");
                    } else {
                        const auto* result = harness.diagnostics.last("ramp-result");
                        require(result && !result->accepted &&
                                result->reason == "paced-unpaid-real-frame-cost",
                            "unpaid settled pacing lacked a measured rejection");
                        require(snapshot.pacedLoadRollbackGenerationLimit == multiplier - 1,
                            "pacing rollback did not mark its planned FIFO exit");
                        requireNear(static_cast<float>(result->currentBaseFps),
                            static_cast<float>(settledFps), 0.01F,
                            "pacing check used the smoothed pre-handoff FPS");
                        const auto* backoff = harness.diagnostics.last("ramp-backoff");
                        require(backoff && backoff->previousLimit == 1 && backoff->duration == 5s,
                            "pacing rejection did not use the adjacent-rung retry ladder");
                        harness.runAtFps(lowerOutputFps /
                            static_cast<double>(multiplier - 1), 4s);
                        require(harness.diagnostics.count("ramp") == initialRamps,
                            "pacing rejection retried before its cooldown");
                        require(!harness.scheduler.snapshot().pacedLoadRollbackGenerationLimit,
                            "planned rollback marker survived beyond one frame");
                        for (size_t frame = 0; frame < 600; ++frame) {
                            harness.frameAtFps(lowerOutputFps /
                                static_cast<double>(multiplier - 1));
                            if (harness.scheduler.snapshot().rampEvaluationActive)
                                break;
                        }
                        require(harness.scheduler.snapshot().rampEvaluationActive,
                            "fresh lower-load evidence could not retry paced rejection");
                        for (size_t frame = 0; frame < 300; ++frame) {
                            harness.frameAtFps(144.0 / static_cast<double>(multiplier));
                            if (!harness.scheduler.snapshot().rampEvaluationActive)
                                break;
                        }
                        require(harness.scheduler.snapshot().pacedLoadValidationPending,
                            "revalidated load did not recheck its final pacing cost");
                        for (size_t frame = 0; frame < 100; ++frame) {
                            pacedLoadFrame(harness, settledFps, multiplier - 1, fifo);
                            if (!harness.scheduler.snapshot().pacedLoadValidationPending)
                                break;
                        }
                        backoff = harness.diagnostics.last("ramp-backoff");
                        require(backoff && backoff->previousLimit == 2 &&
                                backoff->duration == 15s,
                            "provisional acceptance erased completed paced rejection backoff");
                    }
                }
            }
        }
    }

    void testPacedLoadRequiresFreshContinuousEvidence() {
        for (const size_t multiplier : {3U, 4U, 5U}) {
            for (size_t interruption = 0; interruption < 6; ++interruption) {
                Harness harness(120, multiplier, true,
                    AdaptiveRecoveryPolicy::OrderedSdr, false, 2s,
                    120, false, true, true);
                promoteForPacedLoadTest(harness, multiplier,
                    multiplier == 3 ? 108.0 : 114.0);
                const double settledFps = 120.0 / static_cast<double>(multiplier);
                for (size_t frame = 0; frame < static_cast<size_t>(
                        std::ceil(settledFps * 0.8)); ++frame)
                    pacedLoadFrame(harness, settledFps, multiplier - 1, true);
                switch (interruption) {
                case 0:
                    harness.frameAtFps(settledFps); // VRR handoff ended.
                    break;
                case 1:
                    pacedLoadFrame(harness, settledFps, multiplier - 1, false);
                    break;
                case 2:
                    pacedLoadFrame(harness, settledFps, multiplier - 1, true, false);
                    pacedLoadFrame(harness, settledFps, multiplier - 1, true);
                    break;
                case 3:
                    harness.frameAtFps(settledFps, true);
                    break;
                case 4:
                    harness.scheduler.beginStabilization(harness.now, "test-menu");
                    break;
                case 5:
                    for (size_t frame = 0; frame < 20; ++frame)
                        pacedLoadFrame(harness, settledFps * 0.75,
                            multiplier - 1, true);
                    break;
                }
                require(!harness.scheduler.snapshot().pacedLoadValidationPending,
                    "interrupted pacing kept stale comparison authority: " +
                        std::to_string(multiplier) + "x case " +
                        std::to_string(interruption));
                const auto* result = harness.diagnostics.last("ramp-result");
                require(result && result->accepted,
                    "interrupted pacing demoted a previously accepted workload");
                require(harness.diagnostics.contains("adaptive-paced-load-cancelled"),
                    "interrupted pacing did not explain discarded evidence");
            }
        }

        Harness expired(120, 3, true, AdaptiveRecoveryPolicy::OrderedSdr,
            false, 2s, 120, false, true, true);
        promoteForPacedLoadTest(expired, 3, 108.0);
        expired.runAtFps(48.0, 9s);
        require(!expired.scheduler.snapshot().pacedLoadValidationPending &&
                !expired.diagnostics.contains("adaptive-paced-load-start"),
            "an unapplied pacing policy retained its baseline indefinitely");
        for (size_t frame = 0; frame < 80; ++frame) {
            pacedLoadFrame(expired, 40.0, 2, true);
            if (expired.scheduler.snapshot().efficiencyProbeGenerationLimit)
                break;
        }
        require(expired.diagnostics.contains("adaptive-paced-load-baseline-probe") &&
                expired.scheduler.snapshot().efficiencyProbeGenerationLimit == 1,
            "later integer pacing did not obtain fresh adjacent-load evidence");

        Harness unpaced(120, 3, true, AdaptiveRecoveryPolicy::OrderedSdr,
            false, 2s, 120, false, true, false);
        promoteForPacedLoadTest(unpaced, 3, 108.0);
        unpaced.runAtFps(48.0, 16s);
        for (size_t frame = 0; frame < 100; ++frame)
            pacedLoadFrame(unpaced, 40.0, 2, true);
        require(!unpaced.scheduler.snapshot().pacedLoadValidationPending,
            "a policy without automatic integer pacing armed a comparison");
        require(!unpaced.diagnostics.contains("adaptive-paced-load-baseline-probe"),
            "an ineligible policy entered delayed pacing validation");
    }

    void testDelayedIntegerPacingRefreshesAdjacentBaseline() {
        for (const bool fifo : {false, true}) {
            for (const size_t multiplier : {3U, 4U, 5U}) {
                for (const auto delay : {16s, 27s}) {
                    for (const bool paid : {false, true}) {
                        Harness harness(120, multiplier, true,
                            AdaptiveRecoveryPolicy::OrderedSdr, false, 2s,
                            120, false, true, true);
                        // The old deficit cannot authorize a higher load when
                        // the fresh lower workload already reaches the target.
                        const double lowerOutput = paid
                            ? (multiplier == 3 ? 108.0 : 114.0) : 120.0;
                        promoteForPacedLoadTest(harness, multiplier, 100.0);
                        harness.runAtFps(144.0 / static_cast<double>(multiplier), delay);
                        require(!harness.scheduler.snapshot().pacedLoadValidationPending,
                            "unapplied pacing blocked gameplay past its bounded watch");
                        const double pacedFps = 120.0 / static_cast<double>(multiplier);
                        for (size_t frame = 0; frame < 120; ++frame) {
                            pacedLoadFrame(harness, pacedFps, multiplier - 1, fifo);
                            if (harness.scheduler.snapshot().efficiencyProbeGenerationLimit)
                                break;
                        }
                        require(harness.scheduler.snapshot().efficiencyProbeGenerationLimit ==
                                multiplier - 2 &&
                                harness.diagnostics.contains("adaptive-paced-load-baseline-probe"),
                            "delayed pacing failed to start its fresh adjacent-load probe");
                        const double freshLowerFps = lowerOutput /
                            static_cast<double>(multiplier - 1);
                        for (size_t frame = 0; frame < 150; ++frame) {
                            if (fifo)
                                harness.frameAtFps(freshLowerFps);
                            else
                                pacedLoadFrame(harness, freshLowerFps, multiplier - 2, false);
                            if (!harness.scheduler.snapshot().pacedLoadValidationPending)
                                break;
                        }
                        const auto snapshot = harness.scheduler.snapshot();
                        require(!snapshot.pacedLoadValidationPending &&
                                !snapshot.efficiencyProbeGenerationLimit &&
                                snapshot.validatedGenerationLimit ==
                                    (paid ? multiplier - 1 : multiplier - 2),
                            "delayed pacing did not use its freshly measured lower workload");
                        require(snapshot.historyWarmupRemaining == 0 &&
                                !snapshot.discontinuityRecoveryActive &&
                                !snapshot.rearmRequired,
                            "fresh pacing comparison entered transport or history recovery");
                        if (paid) {
                            require(harness.diagnostics.contains("adaptive-paced-load-accepted"),
                                "paid delayed integer pacing was not retained");
                            for (size_t frame = 0; frame < 70; ++frame)
                                pacedLoadFrame(harness, pacedFps, multiplier - 1, fifo);
                            require(harness.diagnostics.count("adaptive-paced-load-baseline-probe") == 1 &&
                                    !harness.scheduler.snapshot().pacedLoadValidationPending,
                                "planned probe return recursively revalidated the same pacing owner");
                        } else {
                            const auto* result = harness.diagnostics.last("ramp-result");
                            require(result && !result->accepted &&
                                    result->reason == "paced-unpaid-real-frame-cost",
                                "unpaid delayed pacing lacked its measured rejection");
                            requireNear(static_cast<float>(result->previousBaseFps),
                                static_cast<float>(freshLowerFps), 0.01F,
                                "delayed pacing reused the expired promotion baseline");
                            const auto* backoff = harness.diagnostics.last("ramp-backoff");
                            require(backoff && backoff->duration == 5s &&
                                    snapshot.pacedLoadRollbackGenerationLimit == multiplier - 1,
                                "fresh rejection lost adjacent retry or planned handoff exit");
                        }
                    }
                }
            }
        }
    }

    void testFixedRefreshHandoffUsesSustainedSchedulerExit() {
        for (const uint32_t target : {60U, 90U, 120U}) {
            Harness harness(target, 3, true, AdaptiveRecoveryPolicy::OrderedSdr,
                false, 2s, target, false, true);
            harness.start();
            harness.runAtFps(target / 2.0, 12s);
            require(harness.scheduler.snapshot().stableCadenceLimit == 1,
                "fixed-refresh retention fixture never qualified 2x");
            ls::GameConf profile;
            profile.active_in = {"game"};
            profile.frame_generation_enabled = true;
            profile.adaptive = true;
            profile.adaptive_auto_base_fps_cap = true;
            profile.adaptive_stable_cadence = true;
            profile.adaptive_max_multiplier = 3;
            profile.target_fps = target;
            SmoothCadencePacerHandoff handoff;
            const auto step = [&](const double fps) {
                harness.now += std::chrono::duration_cast<TimePoint::duration>(
                    std::chrono::duration<double>{1.0 / fps});
                const auto decision = handoff.update(harness.now,
                    smoothCadencePacerHandoffGenerationLimit(profile,
                        true, false, target, harness.scheduler.snapshot(), {},
                        handoff.activeGenerationLimit()));
                const auto plan = harness.scheduler.planFrame(harness.now,
                    false, decision.generationLimit);
                harness.scheduler.reportGeneratedFrameDelivery({plan.size(), plan.size()});
                return decision.active;
            };
            require(step(target / 2.0), "qualified FIFO handoff did not enter");
            // Jitter both after initial turnover and much later must not
            // restart a minute-long cooldown while useful cadence is retained.
            for (size_t cycle = 0; cycle < 5; ++cycle) {
                for (size_t frame = 0; frame < 12; ++frame)
                    require(step(target * 0.485), "small cadence dip released FIFO");
                for (size_t frame = 0; frame < target; ++frame)
                    require(step(target / 2.0), "recovered cadence released FIFO");
            }
            bool released = false;
            for (size_t frame = 0; frame < target; ++frame) {
                if (!step(target * 0.42)) {
                    released = true;
                    break;
                }
            }
            require(released && !harness.scheduler.snapshot().stableCadenceLimit,
                "sustained cadence loss retained a fixed-refresh handoff");
            require(harness.diagnostics.contains("adaptive-stable-cadence-disabled"),
                "FIFO exit bypassed the scheduler's sustained cadence owner");
        }
    }

    void testPlannedPacingReturnKeepsValidatedLifetime() {
        for (const bool fifo : {false, true}) {
            for (const size_t multiplier : {3U, 4U, 5U}) {
                for (const auto delay : {100ms, 300ms, 1000ms, 3000ms}) {
                    Harness harness(120, multiplier, true,
                        AdaptiveRecoveryPolicy::OrderedSdr, false, 2s,
                        120, false, true, true);
                    promoteForPacedLoadTest(harness, multiplier, 100.0);
                    const double unpacedFps = 144.0 / multiplier;
                    const double pacedFps = 120.0 / multiplier;
                    const double lowerFps = 108.0 / (multiplier - 1);
                    harness.runAtFps(unpacedFps, 16s);
                    for (size_t frame = 0; frame < 150; ++frame) {
                        pacedLoadFrame(harness, pacedFps, multiplier - 1, fifo);
                        if (harness.scheduler.snapshot().efficiencyProbeGenerationLimit)
                            break;
                    }
                    require(harness.scheduler.snapshot().efficiencyProbeGenerationLimit ==
                            multiplier - 2, "return fixture never started its lower probe");
                    for (size_t frame = 0; frame < 150; ++frame) {
                        if (fifo)
                            harness.frameAtFps(lowerFps);
                        else
                            pacedLoadFrame(harness, lowerFps, multiplier - 2, false);
                        if (!harness.scheduler.snapshot().pacedLoadValidationPending)
                            break;
                    }
                    require(harness.diagnostics.count("adaptive-paced-load-accepted") == 1,
                        "return fixture failed to accept its useful higher workload");
                    // The estimator may delay FIFO re-entry, and the automatic
                    // cap may still be qualifying its retained higher rung.
                    const auto resumeAt = harness.now + delay;
                    while (harness.now < resumeAt) {
                        if (fifo)
                            harness.frameAtFps(unpacedFps);
                        else
                            pacedLoadFrame(harness, unpacedFps, multiplier - 2, false);
                    }
                    for (size_t frame = 0; frame < 150; ++frame)
                        pacedLoadFrame(harness, pacedFps, multiplier - 1, fifo);
                    require(harness.diagnostics.count("adaptive-paced-load-baseline-probe") == 1 &&
                            !harness.scheduler.snapshot().pacedLoadValidationPending,
                        "delayed planned return restarted its accepted comparison: FIFO=" +
                            std::to_string(fifo) + ", multiplier=" +
                            std::to_string(multiplier) + ", delay=" +
                            std::to_string(delay.count()));
                }
            }
        }
    }

    void testPlannedPacingReturnInvalidatesOnRealChanges() {
        for (size_t interruption = 0; interruption < 5; ++interruption) {
            Harness harness(120, 3, true, AdaptiveRecoveryPolicy::OrderedSdr,
                false, 2s, 120, false, true, true);
            promoteForPacedLoadTest(harness, 3, 100.0);
            harness.runAtFps(48.0, 16s);
            for (size_t frame = 0; frame < 100; ++frame) {
                pacedLoadFrame(harness, 40.0, 2, true);
                if (harness.scheduler.snapshot().efficiencyProbeGenerationLimit)
                    break;
            }
            for (size_t frame = 0; frame < 150; ++frame) {
                harness.frameAtFps(54.0);
                if (!harness.scheduler.snapshot().pacedLoadValidationPending)
                    break;
            }
            require(harness.diagnostics.count("adaptive-paced-load-accepted") == 1,
                "invalidation fixture did not accept the higher workload");
            switch (interruption) {
            case 0:
                harness.scheduler.resetTiming(harness.now);
                break;
            case 1:
                harness.scheduler.restoreGenerationLimit(harness.now, 1, "changed-workload");
                harness.scheduler.restoreGenerationLimit(harness.now, 2, "restored-workload");
                break;
            case 2:
                // Once the planned return finishes, a later unrelated release
                // must not inherit that comparison's exemption.
                pacedLoadFrame(harness, 40.0, 2, true);
                break;
            case 3:
                pacedLoadFrame(harness, 48.0, 1, false);
                break;
            case 4:
                harness.frameAtFps(48.0, true);
                break;
            }
            harness.runAtFps(48.0, 1s);
            for (size_t frame = 0; frame < 100; ++frame) {
                pacedLoadFrame(harness, 40.0, 2, true);
                if (harness.scheduler.snapshot().efficiencyProbeGenerationLimit)
                    break;
            }
            require(harness.diagnostics.count("adaptive-paced-load-baseline-probe") == 2,
                "real pacing change retained an obsolete comparison: " +
                    std::to_string(interruption));
        }
    }

    void testPacingProbeSurvivesBoundedTurnoverBurst() {
        for (const bool fifo : {false, true}) {
            for (const size_t multiplier : {3U, 4U, 5U}) {
                for (const auto burstDuration : {1ms, 50ms, 249ms, 250ms}) {
                    for (const bool higherPays : {false, true}) {
                        Harness harness(120, multiplier, true,
                            AdaptiveRecoveryPolicy::OrderedSdr, false, 2s,
                            120, false, true, true);
                        promoteForPacedLoadTest(harness, multiplier, 100.0);
                        harness.runAtFps(144.0 / multiplier, 16s);
                        for (size_t frame = 0; frame < 150; ++frame) {
                            pacedLoadFrame(harness, 120.0 / multiplier,
                                multiplier - 1, fifo);
                            if (harness.scheduler.snapshot().efficiencyProbeGenerationLimit)
                                break;
                        }
                        require(harness.scheduler.snapshot().efficiencyProbeGenerationLimit ==
                                multiplier - 2,
                            "burst fixture did not start its lower-load comparison");
                        const auto lowerFrame = [&](const double fps) {
                            return fifo ? harness.frameAtFps(fps)
                                : pacedLoadFrame(harness, fps, multiplier - 2, false);
                        };
                        const auto burstEnd = harness.now + burstDuration;
                        while (harness.now < burstEnd) {
                            require(lowerFrame(1000.0).empty(),
                                "turnover burst manufactured generated work");
                            require(harness.scheduler.snapshot().pacedLoadValidationPending,
                                "excluded turnover burst cancelled the lower-load comparison");
                        }
                        const double lowerFps = (higherPays ? 108.0 : 120.0) /
                            static_cast<double>(multiplier - 1);
                        for (size_t frame = 0; frame < 10; ++frame)
                            lowerFrame(lowerFps);
                        require(harness.scheduler.snapshot().pacedLoadValidationPending,
                            "turnover burst counted as a full measured lower-load sample");
                        for (size_t frame = 0; frame < 150; ++frame) {
                            lowerFrame(lowerFps);
                            if (!harness.scheduler.snapshot().pacedLoadValidationPending)
                                break;
                        }
                        require(!harness.scheduler.snapshot().pacedLoadValidationPending &&
                                harness.scheduler.snapshot().validatedGenerationLimit ==
                                    multiplier - (higherPays ? 1 : 2),
                            "turnover exemption changed the measured workload decision");
                        if (higherPays) {
                            for (size_t frame = 0; frame < 200; ++frame)
                                pacedLoadFrame(harness, 120.0 / multiplier,
                                    multiplier - 1, fifo);
                            require(harness.diagnostics.count("adaptive-paced-load-accepted") == 1 &&
                                    harness.diagnostics.count("adaptive-paced-load-baseline-probe") == 1,
                                "turnover burst restarted the completed comparison");
                        }
                    }
                }
            }
        }
    }

    void testPacingProbeTurnoverBurstCannotExtendSettling() {
        for (const bool fifo : {false, true}) {
            Harness harness(120, 3, true, AdaptiveRecoveryPolicy::OrderedSdr,
                false, 2s, 120, false, true, true);
            promoteForPacedLoadTest(harness, 3, 100.0);
            harness.runAtFps(48.0, 16s);
            for (size_t frame = 0; frame < 100; ++frame) {
                pacedLoadFrame(harness, 40.0, 2, fifo);
                if (harness.scheduler.snapshot().efficiencyProbeGenerationLimit)
                    break;
            }
            require(harness.scheduler.snapshot().efficiencyProbeGenerationLimit == 1,
                "bounded-burst fixture did not start its lower-load comparison");
            for (size_t frame = 0; frame < 251; ++frame) {
                if (fifo) harness.frameAtFps(1000.0);
                else pacedLoadFrame(harness, 1000.0, 1, false);
            }
            require(!harness.scheduler.snapshot().pacedLoadValidationPending &&
                    !harness.scheduler.snapshot().efficiencyProbeGenerationLimit &&
                    harness.scheduler.snapshot().validatedGenerationLimit == 2 &&
                    !harness.diagnostics.contains("adaptive-paced-load-accepted"),
                "persistent burst extended settling or validated stale lower-load evidence");
        }
    }

    void testPacingProbeTurnoverPreservesInvalidation() {
        for (const bool fifo : {false, true}) {
            for (size_t interruption = 0; interruption < 4; ++interruption) {
                Harness harness(120, 3, true, AdaptiveRecoveryPolicy::OrderedSdr,
                    false, 2s, 120, false, true, true);
                promoteForPacedLoadTest(harness, 3, 100.0);
                harness.runAtFps(48.0, 16s);
                for (size_t frame = 0; frame < 100; ++frame) {
                    pacedLoadFrame(harness, 40.0, 2, fifo);
                    if (harness.scheduler.snapshot().efficiencyProbeGenerationLimit)
                        break;
                }
                const auto lowerFrame = [&](const double fps) {
                    return fifo ? harness.frameAtFps(fps)
                        : pacedLoadFrame(harness, fps, 1, false);
                };
                lowerFrame(1000.0);
                require(harness.scheduler.snapshot().pacedLoadValidationPending,
                    "invalidation fixture lost the turnover probe");
                switch (interruption) {
                case 0: pacedLoadFrame(harness, 1000.0, 1, !fifo); break;
                case 1: harness.scheduler.resetTiming(harness.now); break;
                case 2: harness.frameAtFps(1000.0, true); break;
                case 3:
                    for (size_t frame = 0; frame < 35; ++frame)
                        lowerFrame(54.0);
                    lowerFrame(1000.0); // A burst in measured data is not turnover.
                    break;
                }
                require(!harness.scheduler.snapshot().pacedLoadValidationPending &&
                        !harness.scheduler.snapshot().efficiencyProbeGenerationLimit &&
                        harness.scheduler.snapshot().validatedGenerationLimit == 2 &&
                        !harness.diagnostics.contains("adaptive-paced-load-accepted"),
                    "turnover exemption hid a real interruption: " +
                        std::to_string(interruption));
            }
        }
    }

    void testFreshPacingProbeDiscardsInterruptedLowerEvidence() {
        for (const bool fifo : {false, true}) {
            for (size_t interruption = 0; interruption < 4; ++interruption) {
                Harness harness(120, 3, true, AdaptiveRecoveryPolicy::OrderedSdr,
                    false, 2s, 120, false, true, true);
                promoteForPacedLoadTest(harness, 3, 100.0);
                harness.runAtFps(48.0, 16s);
                for (size_t frame = 0; frame < 100; ++frame) {
                    pacedLoadFrame(harness, 40.0, 2, fifo);
                    if (harness.scheduler.snapshot().efficiencyProbeGenerationLimit)
                        break;
                }
                require(harness.scheduler.snapshot().efficiencyProbeGenerationLimit == 1,
                    "fresh interruption fixture never entered its lower-load probe");
                for (size_t frame = 0; frame < 35; ++frame) {
                    if (fifo)
                        harness.frameAtFps(54.0);
                    else
                        pacedLoadFrame(harness, 54.0, 1, false);
                }
                switch (interruption) {
                case 0:
                    if (fifo) {
                        harness.frameAtFps(54.0, false, false);
                        harness.scheduler.reportGeneratedFrameDelivery({1, 0});
                        harness.frameAtFps(54.0);
                    } else {
                        pacedLoadFrame(harness, 54.0, 1, false, false);
                        pacedLoadFrame(harness, 54.0, 1, false);
                    }
                    break;
                case 1:
                    pacedLoadFrame(harness, 54.0, 1, fifo);
                    break; // FIFO must remain released; cap must remain applied.
                case 2:
                    harness.scheduler.resetTiming(harness.now);
                    break;
                case 3:
                    for (size_t frame = 0; frame < 20; ++frame) {
                        if (fifo)
                            harness.frameAtFps(35.0);
                        else
                            pacedLoadFrame(harness, 35.0, 1, false);
                    }
                    break;
                }
                // For a cap owner, explicit loss is the interruption.
                if (interruption == 1 && !fifo)
                    harness.frameAtFps(54.0);
                const auto snapshot = harness.scheduler.snapshot();
                require(!snapshot.pacedLoadValidationPending &&
                        !snapshot.efficiencyProbeGenerationLimit &&
                        snapshot.validatedGenerationLimit == 2 &&
                        !harness.diagnostics.contains("adaptive-paced-load-accepted"),
                    "interrupted fresh lower-load sample changed a validated workload: " +
                        std::to_string(fifo) + " owner, case " +
                        std::to_string(interruption) + ", pending=" +
                        std::to_string(snapshot.pacedLoadValidationPending) + ", limit=" +
                        std::to_string(snapshot.validatedGenerationLimit));
                require(harness.diagnostics.contains("adaptive-paced-load-cancelled"),
                    "interrupted fresh comparison lacked a discard reason");
            }
        }
    }

    void testHandoffAtBaselineExpiryStartsFreshComparison() {
        Harness harness(120, 3, true, AdaptiveRecoveryPolicy::OrderedSdr,
            false, 2s, 120, false, true, true);
        promoteForPacedLoadTest(harness, 3, 100.0);
        const auto acceptedAt = harness.now;
        while (harness.now + 24ms < acceptedAt + 8s)
            harness.frameAtFps(48.0);
        require(harness.scheduler.snapshot().pacedLoadValidationPending,
            "expiry-boundary fixture expired before the applied handoff");
        pacedLoadFrame(harness, 40.0, 2, true);
        require(harness.scheduler.snapshot().pacedLoadValidationPending &&
                harness.diagnostics.contains("adaptive-paced-load-cancelled") &&
                harness.diagnostics.contains("adaptive-paced-load-start"),
            "handoff coinciding with baseline expiry lost its fresh validation");
        for (size_t frame = 0; frame < 100; ++frame) {
            pacedLoadFrame(harness, 40.0, 2, true);
            if (harness.scheduler.snapshot().efficiencyProbeGenerationLimit)
                break;
        }
        require(harness.diagnostics.contains("adaptive-paced-load-baseline-probe"),
            "expiry-boundary handoff reused the expired comparison baseline");
    }

    void testDelayedCapReturnStartsAnotherFreshComparison() {
        Harness harness(120, 3, true, AdaptiveRecoveryPolicy::OrderedSdr,
            false, 2s, 120, false, true, true);
        promoteForPacedLoadTest(harness, 3, 100.0);
        harness.runAtFps(48.0, 16s);
        for (size_t frame = 0; frame < 100; ++frame) {
            pacedLoadFrame(harness, 40.0, 2, false);
            if (harness.scheduler.snapshot().efficiencyProbeGenerationLimit)
                break;
        }
        for (size_t frame = 0; frame < 150; ++frame) {
            pacedLoadFrame(harness, 60.0, 1, false);
            if (!harness.scheduler.snapshot().pacedLoadValidationPending)
                break;
        }
        require(harness.scheduler.snapshot().validatedGenerationLimit == 1,
            "delayed cap return fixture did not restore its adjacent lower load");
        for (size_t frame = 0; frame < 1000; ++frame) {
            pacedLoadFrame(harness, 48.0, 1, false);
            if (harness.scheduler.snapshot().rampEvaluationActive)
                break;
        }
        require(harness.scheduler.snapshot().rampEvaluationActive,
            "delayed cap return fixture never retried its higher workload");
        for (size_t frame = 0; frame < 150; ++frame) {
            pacedLoadFrame(harness, 48.0, 1, false);
            if (!harness.scheduler.snapshot().rampEvaluationActive)
                break;
        }
        require(harness.scheduler.snapshot().validatedGenerationLimit == 2,
            "delayed cap return fixture did not accept its higher workload");
        for (size_t frame = 0; frame < 800; ++frame)
            pacedLoadFrame(harness, 48.0, 1, false);
        require(!harness.scheduler.snapshot().pacedLoadValidationPending,
            "delayed cap return fixture kept its expired promotion baseline");
        for (size_t frame = 0; frame < 100; ++frame) {
            pacedLoadFrame(harness, 40.0, 2, false);
            if (harness.scheduler.snapshot().efficiencyProbeGenerationLimit)
                break;
        }
        require(harness.scheduler.snapshot().efficiencyProbeGenerationLimit == 1 &&
                harness.diagnostics.count("adaptive-paced-load-baseline-probe") == 2,
            "a later 3x cap return was mistaken for its already checked lifetime");
    }

    void testFreshPacingProbeKeepsCadenceQualificationSeparate() {
        Harness harness(120, 3, true, AdaptiveRecoveryPolicy::OrderedSdr,
            false, 2s, 120, false, true, true);
        promoteForPacedLoadTest(harness, 3, 100.0);
        harness.runAtFps(48.0, 16s);
        // Start qualification shortly before the applied cap. It must not
        // enter its own trial while the pacing comparison owns delivery.
        harness.runAtFps(40.0, 1800ms);
        require(!harness.scheduler.snapshot().stableCadenceEvaluationActive,
            "fresh pacing fixture qualified a cadence before its handoff");
        for (size_t frame = 0; frame < 100; ++frame) {
            pacedLoadFrame(harness, 40.0, 2, false);
            const auto snapshot = harness.scheduler.snapshot();
            require(!snapshot.stableCadenceEvaluationActive,
                "constant-cadence qualification overlapped applied-pacing evidence");
            if (snapshot.efficiencyProbeGenerationLimit)
                break;
        }
        require(harness.scheduler.snapshot().efficiencyProbeGenerationLimit == 1,
            "separate cadence qualification prevented the fresh lower-load probe");
        for (size_t frame = 0; frame < 150; ++frame) {
            pacedLoadFrame(harness, 50.0, 1, false);
            if (!harness.scheduler.snapshot().pacedLoadValidationPending)
                break;
        }
        require(harness.diagnostics.contains("adaptive-paced-load-accepted") &&
                !harness.scheduler.snapshot().pacedLoadValidationPending,
            "fresh pacing comparison did not finish without a cadence trial");
    }

    void testDelayedFractionalHandoffUsesFreshProbe() {
        for (const bool paid : {false, true}) {
            Harness harness(120, 3, true, AdaptiveRecoveryPolicy::OrderedSdr,
                false, 2s, 120, false, false, true);
            promoteForPacedLoadTest(harness, 3, 100.0);
            harness.runAtFps(48.0, 16s);
            for (size_t frame = 0; frame < 500; ++frame) {
                harness.frameAtFps(40.0);
                const auto snapshot = harness.scheduler.snapshot();
                if (snapshot.stableCadenceLimit == 2 &&
                        !snapshot.stableCadenceEvaluationActive)
                    break;
            }
            require(harness.scheduler.snapshot().stableCadenceLimit == 2 &&
                    !harness.scheduler.snapshot().stableCadenceEvaluationActive,
                "delayed Fractional fixture never qualified a constant cadence");
            for (size_t frame = 0; frame < 100; ++frame) {
                pacedLoadFrame(harness, 40.0, 2, true);
                if (harness.scheduler.snapshot().efficiencyProbeGenerationLimit)
                    break;
            }
            require(harness.scheduler.snapshot().efficiencyProbeGenerationLimit == 1,
                "delayed accepted Fractional handoff skipped its fresh comparison");
            for (size_t frame = 0; frame < 150; ++frame) {
                harness.frameAtFps(paid ? 54.0 : 60.0);
                if (!harness.scheduler.snapshot().pacedLoadValidationPending)
                    break;
            }
            require(!harness.scheduler.snapshot().efficiencyProbeGenerationLimit &&
                    !harness.scheduler.snapshot().pacedLoadValidationPending &&
                    harness.scheduler.snapshot().validatedGenerationLimit == (paid ? 2U : 1U),
                "fresh Fractional comparison did not retain or restore its validated workload");
        }
    }

    void testAcceptedFractionalCadenceChecksVrrPacingCost() {
        for (const size_t multiplier : {3U, 4U, 5U}) {
            Harness harness(120, multiplier, true,
                AdaptiveRecoveryPolicy::OrderedSdr, false, 2s,
                120, false, false, true);
            promoteForPacedLoadTest(harness, multiplier, 100.0);
            const double settledFps = 120.0 / static_cast<double>(multiplier);
            for (size_t frame = 0; frame < 500; ++frame) {
                harness.frameAtFps(settledFps);
                const auto snapshot = harness.scheduler.snapshot();
                if (snapshot.stableCadenceLimit == multiplier - 1 &&
                        !snapshot.stableCadenceEvaluationActive)
                    break;
            }
            require(harness.scheduler.snapshot().pacedLoadValidationPending &&
                    harness.scheduler.snapshot().stableCadenceLimit == multiplier - 1 &&
                    !harness.scheduler.snapshot().stableCadenceEvaluationActive,
                "Fractional constant cadence could not qualify within the recent trial window");
            for (size_t frame = 0; frame < 100; ++frame) {
                pacedLoadFrame(harness, settledFps, multiplier - 1, true);
                if (!harness.scheduler.snapshot().pacedLoadValidationPending)
                    break;
            }
            require(harness.diagnostics.contains("adaptive-paced-load-accepted"),
                "accepted uncapped Fractional cadence did not validate its FIFO pacing cost");
        }
    }

    void testUnreachableIntegerPacingDoesNotDelayHigherWorkloads() {
        Harness harness(120, 5, true, AdaptiveRecoveryPolicy::OrderedSdr,
            false, 2s, 120, false, true, true);
        harness.start();
        harness.runAtFps(20.0, 18s);
        require(harness.scheduler.snapshot().validatedGenerationLimit == 4 &&
                !harness.scheduler.snapshot().pacedLoadValidationPending,
            "unreachable integer pacing delayed useful 4x/5x qualification");
        require(!harness.diagnostics.contains("adaptive-paced-load-start"),
            "a target-deficit source invented an integer pacing experiment");
    }

    void testHeadroomReleaseRechecksFractionalGeneratedLoad() {
        for (const size_t multiplier : {size_t{3}, size_t{5}}) {
            for (const bool sourceCanRecover : {false, true}) {
                Harness harness(90, multiplier, false, AdaptiveRecoveryPolicy::OrderedSdr);
                harness.start();
                harness.runAtFps(100.0 / multiplier, 30s);
                require(harness.scheduler.validatedGenerationLimit() == multiplier - 1 &&
                        !harness.diagnostics.contains("adaptive-efficiency-probe"),
                    "precondition: Fractional must retain its qualified higher load without unsolicited trials");
                harness.scheduler.requestHeadroomRecovery(harness.now, 45);
                auto plan = harness.frameAtFps(100.0 / multiplier);
                require(plan.size() == 1 && harness.diagnostics.contains("adaptive-efficiency-probe"),
                    "released Headroom cap did not test the existing cheaper workload");
                for (size_t frame = 0; frame < 180; ++frame)
                    plan = harness.frameAtFps(sourceCanRecover && plan.size() == 1 ? 45.0 : 100.0 / multiplier);
                require(harness.diagnostics.count("adaptive-efficiency-probe") == 1,
                    "one Headroom release became repeated lower-load probes");
                require(harness.scheduler.validatedGenerationLimit() == (sourceCanRecover ? 1 : multiplier - 1),
                    "Headroom recovery did not retain exactly the workload proven by sustained output");
                require(harness.diagnostics.contains(sourceCanRecover
                        ? "adaptive-efficiency-probe-accepted" : "adaptive-efficiency-probe-rejected"),
                    "Headroom recovery did not preserve the existing accept/rollback contract");
            }
        }
    }

    void testHeadroomReleaseHandlesLowAndInvalidSourceEvidence() {
        for (const double sourceCeiling : {20.0, 21.5}) {
            for (const bool sourceCanRecover : {false, true}) {
                Harness harness(90, 5, false, AdaptiveRecoveryPolicy::OrderedSdr);
                harness.start();
                harness.runAtFps(20.0, 30s);
                require(harness.scheduler.validatedGenerationLimit() == 4,
                    "precondition: heavy gameplay qualified 5x before Headroom release");
                harness.scheduler.requestHeadroomRecovery(harness.now, sourceCeiling);
                auto plan = harness.frameAtFps(20.0);
                require(plan.size() == 3 && harness.diagnostics.contains("adaptive-efficiency-probe"),
                    "a heavy scene's low source ceiling must not prevent a bounded adjacent recovery trial");
                // The lighter scene can sustain the target at the lower
                // workload. Observe this release trial before ordinary
                // efficiency probing becomes eligible several seconds later.
                for (size_t frame = 0; frame < 60; ++frame)
                    plan = harness.frameAtFps(sourceCanRecover && plan.size() <= 3 ? 25.0 : 20.0);
                require(harness.diagnostics.count("adaptive-efficiency-probe") == 1 &&
                        harness.scheduler.validatedGenerationLimit() == (sourceCanRecover ? 3 : 4),
                    "low-ceiling recovery must retain only a workload proven by current delivery");
                require(harness.diagnostics.contains(sourceCanRecover
                        ? "adaptive-efficiency-probe-accepted" : "adaptive-efficiency-probe-rejected"),
                    "low-ceiling recovery must preserve the bounded accept/rollback contract");
            }
        }
        for (const double sourceCeiling : {0.0, -1.0,
                std::numeric_limits<double>::infinity(),
                std::numeric_limits<double>::quiet_NaN()}) {
            Harness harness(90, 5, false, AdaptiveRecoveryPolicy::OrderedSdr);
            harness.start();
            harness.runAtFps(20.0, 30s);
            require(harness.scheduler.validatedGenerationLimit() == 4,
                "precondition: the slow source needs its qualified 5x workload");
            harness.scheduler.requestHeadroomRecovery(harness.now, sourceCeiling);
            harness.runAtFps(20.0, 3s);
            require(!harness.diagnostics.contains("adaptive-efficiency-probe") &&
                    harness.scheduler.validatedGenerationLimit() == 4,
                "invalid source evidence must not request a Headroom recovery trial");
        }
    }

    void testHeadroomRecoveryDoesNotSurviveHistoryReset() {
        Harness harness(90, 5, false, AdaptiveRecoveryPolicy::OrderedSdr);
        harness.start();
        harness.runAtFps(20.0, 30s);
        require(harness.scheduler.validatedGenerationLimit() == 4,
            "precondition: history reset starts from a qualified higher workload");
        harness.scheduler.requestHeadroomRecovery(harness.now, 45);
        harness.scheduler.beginHistoryWarmup(2, false);
        for (size_t frame = 0; frame < 2; ++frame) {
            harness.now += 50ms;
            harness.scheduler.consumeHistoryWarmupFrame(harness.now);
        }
        harness.runAtFps(20.0, 3s);
        require(!harness.diagnostics.contains("adaptive-efficiency-probe"),
            "fresh source history must invalidate a pending Headroom trial from the old scene");
        harness.scheduler.requestHeadroomRecovery(harness.now - 3s, 45);
        harness.runAtFps(20.0, 3s);
        require(!harness.diagnostics.contains("adaptive-efficiency-probe"),
            "expired Headroom hints must not trigger a delayed workload trial");
        harness.scheduler.requestHeadroomRecovery(harness.now, 45);
        require(harness.frameAtFps(20).size() == 1 &&
                harness.diagnostics.count("adaptive-efficiency-probe") == 1,
            "invalidating stale hints must still allow a later fresh release trial");
    }

    void testHeadroomCapDefersImpossibleEfficiencyProbe() {
        for (const uint32_t target : {90U, 120U, 144U}) {
            for (const size_t multiplier : {3U, 4U, 5U}) {
                const double sourceFps = static_cast<double>(target) / multiplier;
                if (sourceFps < 20.0)
                    continue;
                Harness harness(target, multiplier, true, AdaptiveRecoveryPolicy::OrderedSdr);
                harness.headroomSourceCapFps = sourceFps;
                harness.start();
                harness.runAtFps(sourceFps, 45s);
                require(harness.scheduler.validatedGenerationLimit() == multiplier - 1 &&
                        harness.scheduler.snapshot().stableCadenceLimit == multiplier - 1,
                    "Headroom-capped fixture did not qualify the target-rate workload");
                require(!harness.diagnostics.contains("adaptive-efficiency-probe"),
                    "active Headroom cap allowed a downshift that cannot reach target");

                // The same scene can recover when Headroom releases its cap.
                // A skipped trial must not create rejection history or prevent
                // the existing release hint from testing a useful lower load.
                harness.headroomSourceCapFps = 0.0;
                const double recoveredFps = static_cast<double>(target) / (multiplier - 1);
                harness.scheduler.requestHeadroomRecovery(harness.now, recoveredFps);
                auto plan = harness.frameAtFps(sourceFps);
                require(plan.size() == multiplier - 2,
                    "Headroom cap release did not permit a useful downshift");
                harness.runAtFps(recoveredFps, 2s);
                require(harness.scheduler.validatedGenerationLimit() == multiplier - 2 &&
                        harness.diagnostics.contains("adaptive-efficiency-probe-accepted"),
                    "Headroom cap release could not retain a proven lower workload");
            }
        }
    }

    void testHeadroomCapCancelsImpossibleActiveEfficiencyProbe() {
        for (const bool sampling : {false, true}) {
            Harness harness(120, 3, true, AdaptiveRecoveryPolicy::OrderedSdr);
            harness.start();
            for (size_t frame = 0; frame < 2400; ++frame) {
                harness.frameAtFps(40.0);
                if (harness.scheduler.snapshot().efficiencyProbeGenerationLimit)
                    break;
            }
            require(harness.scheduler.snapshot().efficiencyProbeGenerationLimit == 1,
                "cap-change fixture did not start a lower-load trial");
            if (sampling)
                harness.runAtFps(60.0, 300ms);
            harness.headroomSourceCapFps = 40.0;
            const auto plan = harness.frameAtFps(40.0);
            require(plan.size() == 2 &&
                    !harness.scheduler.snapshot().efficiencyProbeGenerationLimit &&
                    harness.scheduler.validatedGenerationLimit() == 2,
                "tightened Headroom cap did not restore the proven workload immediately");
            require(harness.diagnostics.contains("adaptive-efficiency-probe-cancelled") &&
                    !harness.diagnostics.contains("adaptive-efficiency-probe-rejected"),
                "intentional Headroom cap was recorded as a workload failure");
            harness.headroomSourceCapFps = 0.0;
            harness.scheduler.requestHeadroomRecovery(harness.now, 60.0);
            harness.frameAtFps(40.0);
            harness.runAtFps(60.0, 2s);
            require(harness.scheduler.validatedGenerationLimit() == 1,
                "cancelled Headroom trial prevented later target-preserving recovery");
        }
    }

    void testHeadroomCapAllowsReachableEfficiencyProbe() {
        for (const double cap : {60.0, 0.0, -1.0,
                std::numeric_limits<double>::infinity(),
                std::numeric_limits<double>::quiet_NaN()}) {
            Harness harness(120, 3, true, AdaptiveRecoveryPolicy::OrderedSdr);
            harness.headroomSourceCapFps = cap;
            harness.start();
            for (size_t frame = 0; frame < 2400; ++frame) {
                harness.frameAtFps(40.0);
                if (harness.scheduler.snapshot().efficiencyProbeGenerationLimit)
                    break;
            }
            require(harness.scheduler.snapshot().efficiencyProbeGenerationLimit == 1,
                "nonbinding or invalid Headroom cap blocked an ordinary downshift");
            harness.runAtFps(60.0, 2s);
            require(harness.scheduler.validatedGenerationLimit() == 1,
                "reachable downshift could not retain a proven lower workload");
        }
    }

    void testSmoothCadenceDownshiftsWhenLowerLoadPreservesTarget() {
        Harness harness(
            120, 3, true, AdaptiveRecoveryPolicy::OrderedSdr
        );
        harness.start();

        AdaptiveFramePlan plan;
        for (size_t frame = 0; frame < 2400; ++frame) {
            plan = harness.frameAtFps(40.0);
            if (harness.diagnostics.contains("adaptive-efficiency-probe"))
                break;
        }
        const auto* probe = harness.diagnostics.last(
            "adaptive-efficiency-probe"
        );
        require(probe && probe->testedLimit == 1 && plan.size() == 1,
            "qualified 3x cadence did not test the cheaper 2x policy");

        for (size_t frame = 0; frame < 120; ++frame) {
            plan = harness.frameAtFps(60.0, false, false);
            harness.scheduler.reportGeneratedFrameDelivery({
                .requested = plan.size(),
                .acceptedForPresentation = plan.size(),
            });
        }
        const auto snapshot = harness.scheduler.snapshot();
        const auto* accepted = harness.diagnostics.last(
            "adaptive-efficiency-probe-accepted"
        );
        require(accepted && accepted->testedLimit == 1,
            "target-preserving 2x efficiency probe was not accepted");
        require(snapshot.stableCadenceLimit == 1 &&
                snapshot.validatedGenerationLimit == 1 &&
                snapshot.generationLimit == 1,
            "accepted efficiency probe did not make 2x the qualified policy");
        require(plan.size() == 1,
            "accepted 2x efficiency probe resumed the previous 3x workload");
    }

    void testSmoothCadenceDownshiftRequiresSustainedTarget() {
        const auto check = [](const uint32_t target, const size_t multiplier,
                const bool automaticCap, const bool preservesTarget) {
            Harness harness(target, multiplier, true, AdaptiveRecoveryPolicy::OrderedSdr,
                false, 2s, target, false, automaticCap);
            harness.start();
            for (size_t frame = 0; frame < 2400; ++frame) {
                harness.frameAtFps(static_cast<double>(target) / multiplier);
                if (harness.scheduler.snapshot().efficiencyProbeGenerationLimit)
                    break;
            }
            const auto lowerLimit = multiplier - 2;
            require(harness.scheduler.snapshot().efficiencyProbeGenerationLimit == lowerLimit,
                "sustained downshift fixture did not enter its adjacent lower probe");

            // A brief release of queued work can look target-capable. The
            // marginal workload then falls six percent short, while the
            // healthy control sustains the target with less generated work.
            const double lowerTargetFps = static_cast<double>(target) / (multiplier - 1);
            harness.runAtFps(lowerTargetFps, 300ms);
            require(!harness.diagnostics.contains("adaptive-efficiency-probe-accepted"),
                "a brief target-rate burst permanently accepted the lower workload");
            const auto decisionDeadline = harness.now + 2s;
            while (harness.now < decisionDeadline &&
                    harness.scheduler.snapshot().efficiencyProbeGenerationLimit) {
                harness.frameAtFps(lowerTargetFps * (preservesTarget ? 1.0 : 0.94));
            }
            const auto snapshot = harness.scheduler.snapshot();
            if (!preservesTarget) {
                require(!harness.diagnostics.contains("adaptive-efficiency-probe-accepted") &&
                        harness.diagnostics.contains("adaptive-efficiency-probe-rejected") &&
                        snapshot.validatedGenerationLimit == multiplier - 1 &&
                        snapshot.stableCadenceLimit == multiplier - 1,
                    "transient target-rate burst displaced the proven cadence at " +
                        std::to_string(target) + " FPS / " + std::to_string(multiplier) + "x");
            } else {
                const auto* rejected = harness.diagnostics.last("adaptive-efficiency-probe-rejected");
                require(harness.diagnostics.contains("adaptive-efficiency-probe-accepted") &&
                        snapshot.validatedGenerationLimit == lowerLimit &&
                        snapshot.stableCadenceLimit == lowerLimit,
                    "sustained target-rate downshift did not retain its cheaper workload at " +
                        std::to_string(target) + " FPS / " + std::to_string(multiplier) +
                        "x auto=" + std::to_string(automaticCap) + " accepted=" +
                        std::to_string(harness.diagnostics.contains("adaptive-efficiency-probe-accepted")) +
                        " rejected=" + (rejected ? rejected->reason + " fps=" +
                            std::to_string(rejected->currentBaseFps) : "none"));
            }
        };
        constexpr std::array rates{
            std::pair{90U, 3U}, std::pair{90U, 4U},
            std::pair{120U, 3U}, std::pair{120U, 4U}, std::pair{120U, 5U},
            std::pair{144U, 3U}, std::pair{144U, 4U}, std::pair{144U, 5U},
        };
        for (const auto [target, multiplier] : rates)
            for (const bool automaticCap : {false, true})
                for (const bool preservesTarget : {false, true})
                    check(target, multiplier, automaticCap, preservesTarget);
    }

    void testSmoothCadenceDownshiftNeedsCompleteSampleDelivery() {
        for (const std::string_view interruption :
                {"missing", "partial", "duplicate", "backoff", "burst", "reset"}) {
            Harness harness(120, 3, true, AdaptiveRecoveryPolicy::OrderedSdr);
            harness.start();
            for (size_t frame = 0; frame < 2400; ++frame) {
                harness.frameAtFps(40.0);
                if (harness.scheduler.snapshot().efficiencyProbeGenerationLimit)
                    break;
            }
            require(harness.scheduler.snapshot().efficiencyProbeGenerationLimit == 1,
                "interrupted downshift fixture did not enter its 2x probe");
            harness.runAtFps(60.0, 500ms);
            if (interruption == "reset") {
                harness.scheduler.resetTiming(harness.now);
            } else if (interruption == "backoff") {
                harness.frameAtFps(60.0, true);
            } else if (interruption == "burst") {
                harness.frameAtFps(500.0);
            } else {
                const auto plan = harness.frameAtFps(60.0, false, false);
                if (interruption != "missing") {
                    harness.scheduler.reportGeneratedFrameDelivery({
                        plan.size(), interruption == "partial" ? 0 : plan.size(),
                    });
                    if (interruption == "duplicate")
                        harness.scheduler.reportGeneratedFrameDelivery({plan.size(), plan.size()});
                }
            }
            harness.runAtFps(60.0, 1s);
            require(!harness.diagnostics.contains("adaptive-efficiency-probe-accepted"),
                "incomplete downshift evidence accepted after " + std::string(interruption));
        }
    }

    void testSmoothCadenceDownshiftCannotUseRecoveredEndpointAlone() {
        Harness harness(120, 3, true, AdaptiveRecoveryPolicy::OrderedSdr);
        harness.start();
        for (size_t frame = 0; frame < 2400; ++frame) {
            harness.frameAtFps(40.0);
            if (harness.scheduler.snapshot().efficiencyProbeGenerationLimit)
                break;
        }
        require(harness.scheduler.snapshot().efficiencyProbeGenerationLimit == 1,
            "endpoint downshift fixture did not enter its 2x probe");
        harness.runAtFps(60.0, 300ms);
        harness.runAtFps(56.0, 650ms);
        const auto deadline = harness.now + 1s;
        while (harness.now < deadline &&
                harness.scheduler.snapshot().efficiencyProbeGenerationLimit)
            harness.frameAtFps(60.0);
        const auto snapshot = harness.scheduler.snapshot();
        const auto* rejected = harness.diagnostics.last("adaptive-efficiency-probe-rejected");
        require(snapshot.smoothedBaseFps >= 58.8,
            "endpoint fixture did not recover its final FPS estimate");
        require(rejected && rejected->reason == "target-deficit" &&
                rejected->currentBaseFps < 58.8 && snapshot.validatedGenerationLimit == 2 &&
                !harness.diagnostics.contains("adaptive-efficiency-probe-accepted"),
            "fast endpoint concealed a below-target measured downshift");
    }

    void testSmoothCadenceDownshiftAllowsPromisingRecoveryToSettle() {
        Harness harness(
            120, 3, true, AdaptiveRecoveryPolicy::OrderedSdr
        );
        harness.start();

        for (size_t frame = 0; frame < 2400; ++frame) {
            harness.frameAtFps(40.0);
            if (harness.diagnostics.contains("adaptive-efficiency-probe"))
                break;
        }
        require(harness.diagnostics.contains("adaptive-efficiency-probe"),
            "precondition failed: 3x efficiency probe did not begin");

        AdaptiveFramePlan plan;
        for (size_t frame = 0; frame < 120; ++frame) {
            plan = harness.frameAtFps(56.0, false, false);
            harness.scheduler.reportGeneratedFrameDelivery({
                .requested = plan.size(),
                .acceptedForPresentation = plan.size(),
            });
            if (harness.diagnostics.contains(
                    "adaptive-efficiency-probe-extended")) {
                break;
            }
        }
        const auto* extended = harness.diagnostics.last(
            "adaptive-efficiency-probe-extended"
        );
        require(extended && extended->reason == "base-recovering",
            "strong near-target base recovery did not receive settling grace");
        require(!harness.diagnostics.contains(
                "adaptive-efficiency-probe-rejected"),
            "promising lower-load recovery rolled back at the first deadline");
        require(plan.size() == 1,
            "settling grace did not retain the cheaper 2x workload");

        for (size_t frame = 0; frame < 120; ++frame) {
            plan = harness.frameAtFps(60.0, false, false);
            harness.scheduler.reportGeneratedFrameDelivery({
                .requested = plan.size(),
                .acceptedForPresentation = plan.size(),
            });
            if (harness.diagnostics.contains(
                    "adaptive-efficiency-probe-accepted")) {
                break;
            }
        }
        const auto snapshot = harness.scheduler.snapshot();
        require(harness.diagnostics.contains(
                "adaptive-efficiency-probe-accepted"),
            "settled target-preserving 2x recovery was not accepted");
        require(snapshot.stableCadenceLimit == 1 &&
                snapshot.validatedGenerationLimit == 1 &&
                snapshot.generationLimit == 1 && plan.size() == 1,
            "accepted settling grace did not retain the qualified 2x policy");
    }

    void testSmoothCadenceRejectsInsufficientDownshiftAndBacksOff() {
        Harness harness(
            120, 3, true, AdaptiveRecoveryPolicy::OrderedSdr
        );
        harness.start();

        for (size_t frame = 0; frame < 2400; ++frame) {
            harness.frameAtFps(40.0);
            if (harness.diagnostics.contains("adaptive-efficiency-probe"))
                break;
        }
        require(harness.diagnostics.contains("adaptive-efficiency-probe"),
            "precondition failed: 3x efficiency probe did not begin");

        const auto plan = harness.runAtFps(40.0, 2s);
        const auto snapshot = harness.scheduler.snapshot();
        const auto* rejected = harness.diagnostics.last(
            "adaptive-efficiency-probe-rejected"
        );
        require(rejected && rejected->reason == "target-deficit",
            "2x probe that could not preserve target was not rejected");
        require(snapshot.stableCadenceLimit == 2 &&
                snapshot.validatedGenerationLimit == 2 &&
                plan.size() == 2,
            "rejected efficiency probe did not immediately restore 3x");

        const size_t probes = harness.diagnostics.count(
            "adaptive-efficiency-probe"
        );
        harness.scheduler.beginHistoryWarmup(3, true);
        for (size_t frame = 0; frame < 3; ++frame) {
            harness.now += 33ms;
            harness.scheduler.consumeHistoryWarmupFrame(harness.now);
        }
        require(!harness.scheduler.historyWarmupActive(),
            "recovery history warm-up did not complete");
        harness.runAtFps(40.0, 299s);
        require(harness.diagnostics.count("adaptive-efficiency-probe") == probes,
            "recovery warm-up discarded the severe five-minute backoff");
        harness.runAtFps(40.0, 7s);
        require(harness.diagnostics.count("adaptive-efficiency-probe") > probes,
            "severe efficiency deficit did not retry after five-minute backoff");
    }

    TimePoint rejectSmoothCadenceDownshift(Harness& harness, const double fps) {
        harness.start();
        const auto deadline = harness.now + 80s;
        while (harness.now < deadline) {
            const auto plan = harness.frameAtFps(fps, false, false);
            harness.scheduler.reportGeneratedFrameDelivery({
                .requested = plan.size(),
                .acceptedForPresentation = plan.size(),
            });
            if (harness.diagnostics.contains("adaptive-efficiency-probe-rejected"))
                return harness.now;
        }
        throw TestFailure{"precondition failed: downshift was not rejected"};
    }

    void testSmoothCadenceDownshiftBackoffSurvivesRepeatedDips() {
        for (const uint32_t target : {60U, 90U, 120U}) {
            for (const size_t multiplier : {3U, 4U, 5U}) {
                for (const bool automaticCap : {false, true}) {
                    Harness harness(target, multiplier, true,
                        AdaptiveRecoveryPolicy::OrderedSdr, false, 2s,
                        target, true, automaticCap);
                    // Keep the 4x -> 3x result above the exact 75% boundary
                    // so floating-point source intervals cannot select 300s.
                    const double fps = 1.01 * target / multiplier;
                    const auto rejectedAt = rejectSmoothCadenceDownshift(harness, fps);
                    const auto retryDelay = multiplier == 3 ? 300s : 120s;
                    const auto probes = harness.diagnostics.count("adaptive-efficiency-probe");
                    for (size_t dip = 0; dip < 3; ++dip) {
                        harness.runAtFps(fps * 0.85, 3s);
                        require(!harness.scheduler.snapshot().stableCadenceLimit,
                            "precondition failed: source dip retained constant cadence");
                        harness.runAtFps(fps, 27s);
                        require(harness.scheduler.snapshot().stableCadenceLimit == multiplier - 1,
                            "source recovery did not requalify its useful multiplier");
                        require(harness.diagnostics.count("adaptive-efficiency-probe") == probes,
                            "cadence dip discarded rejected downshift backoff: target=" +
                                std::to_string(target) + " multiplier=" + std::to_string(multiplier) +
                                " automatic_cap=" + std::to_string(automaticCap));
                    }
                    const auto beforeRetry = rejectedAt + retryDelay - 1s;
                    harness.runAtFps(fps, beforeRetry - harness.now);
                    require(harness.diagnostics.count("adaptive-efficiency-probe") == probes,
                        "downshift retried before its original deadline");
                    harness.runAtFps(fps, 8s);
                    require(harness.diagnostics.count("adaptive-efficiency-probe") > probes,
                        "cadence recovery extended the original retry deadline indefinitely");
                }
            }
        }
    }

    void testSmoothCadenceDownshiftBackoffSurvivesInterruptions() {
        for (const bool automaticCap : {false, true}) {
            for (const auto interruption : {"stall", "focus", "transport"}) {
                Harness harness(120, 3, true, AdaptiveRecoveryPolicy::OrderedSdr,
                    false, 2s, 120, true, automaticCap);
                rejectSmoothCadenceDownshift(harness, 40.0);
                const auto probes = harness.diagnostics.count("adaptive-efficiency-probe");
                if (std::string_view(interruption) == "stall") {
                    harness.frame(300ms);
                } else if (std::string_view(interruption) == "focus") {
                    harness.now += 1s;
                    harness.scheduler.resumeAfterExternalInterruption(harness.now, true);
                } else {
                    harness.scheduler.beginTransportRecovery(harness.now, false);
                }
                while (harness.scheduler.historyWarmupActive()) {
                    harness.now += 25ms;
                    harness.scheduler.consumeHistoryWarmupFrame(harness.now);
                }
                harness.runAtFps(40.0, 40s);
                require(harness.scheduler.snapshot().stableCadenceLimit == 2,
                    "interruption did not recover the useful 3x cadence");
                require(harness.diagnostics.count("adaptive-efficiency-probe") == probes,
                    "interruption cleared rejected downshift backoff: " +
                        std::string(interruption));
            }
        }
    }

    void testSmoothCadenceDownshiftBackoffIsScopedToMultiplier() {
        for (const bool automaticCap : {false, true}) {
            Harness harness(120, 5, true, AdaptiveRecoveryPolicy::OrderedSdr,
                false, 2s, 120, true, automaticCap);
            rejectSmoothCadenceDownshift(harness, 40.4);
            const auto rejectedAt = harness.now;
            const auto originalProbes = harness.diagnostics.count("adaptive-efficiency-probe");
            require(harness.diagnostics.last("adaptive-efficiency-probe-rejected")->testedLimit == 1,
                "precondition failed: initial rejection was not 3x -> 2x");
            harness.runAtFps(24.24, 60s);
            const auto* nextProbe = harness.diagnostics.last("adaptive-efficiency-probe");
            require(nextProbe && nextProbe->testedLimit == 3,
                "failed 3x -> 2x probe blocked an independent 5x -> 4x probe");
            require(harness.now - rejectedAt < 300s,
                "independent probe check outlasted the original cooldown");
            harness.runAtFps(40.4, 40s);
            require(harness.scheduler.snapshot().stableCadenceLimit == 2,
                "source improvement did not recover a useful 3x cadence");
            size_t twoXProbes = 0;
            for (const auto& event : harness.diagnostics.events) {
                if (event.operation == "adaptive-efficiency-probe" && event.testedLimit == 1)
                    ++twoXProbes;
            }
            require(twoXProbes == originalProbes,
                "probing a different multiplier erased the previous rung's rejection");
        }
    }

    void testSmoothCadenceDownshiftBackoffAllowsProvenSourceRecovery() {
        for (const bool automaticCap : {false, true}) {
            Harness harness(120, 3, true, AdaptiveRecoveryPolicy::OrderedSdr,
                false, 2s, 120, true, automaticCap);
            rejectSmoothCadenceDownshift(harness, 40.0);
            const auto rejectedAt = harness.now;
            const auto probes = harness.diagnostics.count("adaptive-efficiency-probe");
            // Ordinary constant-cadence requalification keeps its existing
            // 15s retry; it must not inherit the failed experiment's 300s.
            const auto recoveredPlan = harness.runAtFps(60.0, 25s);
            require(harness.scheduler.snapshot().stableCadenceLimit == 1 &&
                    recoveredPlan.size() == 1,
                "rejected experiment prevented independently qualified 2x recovery");
            require(harness.diagnostics.count("adaptive-efficiency-probe") == probes,
                "source recovery unnecessarily launched another lower-load experiment");
            harness.runAtFps(119.0, 8s);
            require(harness.scheduler.snapshot().nearTargetNativePreference,
                "precondition failed: sustained native source did not reach target");
            harness.runAtFps(40.0, 40s);
            require(harness.now - rejectedAt < 300s &&
                    harness.diagnostics.count("adaptive-efficiency-probe") > probes,
                "proven native recovery retained obsolete lower-load rejection");
        }
    }

    void testSmoothCadenceModerateDownshiftDeficitBacksOffTwoMinutes() {
        Harness harness(
            120, 5, true, AdaptiveRecoveryPolicy::OrderedSdr
        );
        harness.start();

        for (size_t frame = 0; frame < 2400; ++frame) {
            harness.frameAtFps(24.0);
            if (harness.diagnostics.contains("adaptive-efficiency-probe"))
                break;
        }
        require(harness.diagnostics.contains("adaptive-efficiency-probe"),
            "precondition failed: moderate-deficit probe did not begin");

        for (size_t frame = 0; frame < 120; ++frame) {
            const auto plan = harness.frameAtFps(24.0, false, false);
            harness.scheduler.reportGeneratedFrameDelivery({
                .requested = plan.size(),
                .acceptedForPresentation = plan.size(),
            });
            if (harness.diagnostics.contains(
                    "adaptive-efficiency-probe-rejected")) {
                break;
            }
        }
        const auto* rejected = harness.diagnostics.last(
            "adaptive-efficiency-probe-rejected"
        );
        require(rejected && rejected->reason == "target-deficit",
            "moderate 4x target deficit was not rejected");

        const size_t probes = harness.diagnostics.count(
            "adaptive-efficiency-probe"
        );
        harness.runAtFps(24.0, 119s);
        require(harness.diagnostics.count("adaptive-efficiency-probe") == probes,
            "moderate efficiency deficit retried before two-minute backoff");
        harness.runAtFps(24.0, 7s);
        require(harness.diagnostics.count("adaptive-efficiency-probe") > probes,
            "moderate efficiency deficit did not retry after two-minute backoff");
    }

    void testSmoothCadenceDownshiftRejectsDeliveryPressure() {
        Harness harness(
            120, 3, true, AdaptiveRecoveryPolicy::OrderedSdr
        );
        harness.start();

        for (size_t frame = 0; frame < 2400; ++frame) {
            harness.frameAtFps(40.0);
            if (harness.diagnostics.contains("adaptive-efficiency-probe"))
                break;
        }
        require(harness.diagnostics.contains("adaptive-efficiency-probe"),
            "precondition failed: delivery-pressure probe did not begin");

        AdaptiveFramePlan plan;
        for (size_t frame = 0; frame < 60; ++frame) {
            plan = harness.frameAtFps(60.0, false, false);
            harness.scheduler.reportGeneratedFrameDelivery({
                .requested = plan.size(),
                .acceptedForPresentation = 0,
            });
            if (harness.diagnostics.contains(
                    "adaptive-efficiency-probe-rejected")) {
                break;
            }
        }
        const auto* rejected = harness.diagnostics.last(
            "adaptive-efficiency-probe-rejected"
        );
        require(rejected && rejected->reason == "delivery-pressure",
            "delivery loss did not reject the cheaper cadence probe");
        require(harness.scheduler.snapshot().stableCadenceLimit == 2 &&
                plan.size() == 2,
            "delivery-pressure rejection did not restore qualified 3x");

        const size_t probes = harness.diagnostics.count(
            "adaptive-efficiency-probe"
        );
        harness.runAtFps(40.0, 59s);
        require(harness.diagnostics.count("adaptive-efficiency-probe") == probes,
            "delivery-pressure probe retried before one-minute backoff");
        harness.runAtFps(40.0, 7s);
        require(harness.diagnostics.count("adaptive-efficiency-probe") > probes,
            "delivery-pressure probe did not retry after one-minute backoff");
    }

    void testSmoothCadenceDownshiftPausesDuringAcquireBackoff() {
        Harness harness(
            120, 3, true, AdaptiveRecoveryPolicy::OrderedSdr
        );
        harness.start();

        for (size_t frame = 0; frame < 2400; ++frame) {
            harness.frameAtFps(40.0);
            if (harness.diagnostics.contains("adaptive-efficiency-probe"))
                break;
        }
        require(harness.diagnostics.contains("adaptive-efficiency-probe"),
            "precondition failed: acquire-backoff probe did not begin");

        for (size_t frame = 0; frame < 120; ++frame)
            harness.frameAtFps(60.0, true);
        require(!harness.diagnostics.contains(
                "adaptive-efficiency-probe-accepted") &&
                !harness.diagnostics.contains(
                    "adaptive-efficiency-probe-rejected"),
            "generated-image backoff advanced the efficiency evaluation");

        AdaptiveFramePlan plan;
        for (size_t frame = 0; frame < 120; ++frame) {
            plan = harness.frameAtFps(60.0, false, false);
            harness.scheduler.reportGeneratedFrameDelivery({
                .requested = plan.size(),
                .acceptedForPresentation = plan.size(),
            });
        }
        require(harness.diagnostics.contains(
                "adaptive-efficiency-probe-accepted") &&
                harness.scheduler.snapshot().stableCadenceLimit == 1,
            "paused efficiency probe did not resume and accept healthy 2x");
    }

    void testSmoothCadenceDownshiftProbeIsOrderedSdrOnly() {
        Harness harness(
            120, 3, true, AdaptiveRecoveryPolicy::ConservativeHdr
        );
        harness.start();
        harness.runAtFps(40.0, 30s);
        require(harness.scheduler.snapshot().stableCadenceLimit == 2,
            "precondition failed: HDR cadence did not qualify 3x");
        require(!harness.diagnostics.contains("adaptive-efficiency-probe"),
            "nonblocking HDR transport performed a 3x-to-2x efficiency probe");
    }

    void testSmoothCadenceRetainsValidatedTwoXThroughMildDip() {
        Harness harness(120, 2, true);
        harness.start();
        harness.runAtFps(60.0, 12s);
        require(harness.scheduler.snapshot().phase ==
                AdaptiveSchedulerPhase::StableCadence,
            "precondition failed: 60 FPS did not settle on 2x for a 120 FPS target");

        const auto plan = harness.runAtFps(57.1, 3s);
        const auto snapshot = harness.scheduler.snapshot();
        require(snapshot.phase == AdaptiveSchedulerPhase::StableCadence &&
                snapshot.stableCadenceLimit == 1,
            "validated 2x cadence was discarded during a mild base-rate dip");
        require(plan.size() == 1,
            "mild base-rate dip resumed fractional generated-frame counts");
    }

    void testSmoothCadenceExitsBelowRetentionRange() {
        Harness harness(120, 2, true);
        harness.start();
        harness.runAtFps(60.0, 12s);
        require(harness.scheduler.snapshot().phase ==
                AdaptiveSchedulerPhase::StableCadence,
            "precondition failed: 60 FPS did not settle on 2x for a 120 FPS target");

        harness.runAtFps(56.5, 3s);
        require(harness.scheduler.snapshot().phase !=
                AdaptiveSchedulerPhase::StableCadence,
            "Smooth Cadence remained locked below its retention range");
        const auto* disabled = harness.diagnostics.last(
            "adaptive-stable-cadence-disabled"
        );
        require(disabled && disabled->reason == "outside-useful-range",
            "retention-range exit did not report the expected reason");
    }

    void testPersistentDeliveryLossRejectsSmoothCadenceProbe() {
        Harness harness(90, 2, true);
        harness.start();
        bool reportedPressure = false;
        for (size_t frame = 0; frame < 1000; ++frame) {
            const auto plan = harness.frameAtFps(47.0, false, false);
            const bool probeStarted = harness.diagnostics.contains(
                "adaptive-stable-cadence-probe"
            );
            if (probeStarted && !plan.empty()) {
                harness.scheduler.reportGeneratedFrameDelivery({
                    .requested = plan.size(),
                    .acceptedForPresentation = 0,
                });
                reportedPressure = true;
            } else {
                harness.scheduler.reportGeneratedFrameDelivery({
                    .requested = plan.size(),
                    .acceptedForPresentation = plan.size(),
                });
            }
            if (reportedPressure && harness.diagnostics.contains(
                    "adaptive-stable-cadence-rejected"))
                break;
        }
        require(reportedPressure && harness.diagnostics.contains(
                "adaptive-stable-cadence-rejected"),
            "persistent display admission loss did not reject Smooth Cadence");
        require(harness.scheduler.snapshot().phase !=
                AdaptiveSchedulerPhase::StableCadence,
            "Smooth Cadence retained a persistently delivery-late multiplier");
    }

    void testSmoothCadenceReturnsToTargetAfterBaseRecovery() {
        Harness harness(100, 2, true);
        harness.start();
        harness.runAtFps(50.0, 12s);
        require(harness.scheduler.snapshot().phase ==
                AdaptiveSchedulerPhase::StableCadence,
            "precondition failed: 50 FPS did not settle on 2x for a 100 FPS target");

        harness.runAtFps(60.0, 3s);
        require(harness.scheduler.snapshot().phase !=
                AdaptiveSchedulerPhase::StableCadence,
            "Smooth Cadence retained stale 2x output after native cadence recovered");
        const auto* disabled = harness.diagnostics.last(
            "adaptive-stable-cadence-disabled"
        );
        require(disabled && disabled->reason == "outside-useful-range",
            "native cadence recovery did not report a bounded Smooth Cadence exit");

        size_t outputs = 0;
        constexpr size_t sampleFrames = 600;
        for (size_t frame = 0; frame < sampleFrames; ++frame)
            outputs += 1 + harness.frameAtFps(60.0).size();
        const double estimatedOutputFps =
            static_cast<double>(outputs) / 10.0;
        require(std::abs(estimatedOutputFps - 100.0) <= 0.2,
            "strict scheduling did not return recovered cadence to the 100 FPS target");
    }

    void testFractionalRefreshGuardAcrossCutsceneGameplayTransitions() {
        for (const bool smooth : {false, true}) {
            for (const bool recovery : {false, true}) {
                for (const bool fifoFeedback : {false, true}) {
                    for (const double gameplayFps : {55.0, 58.0, 60.0}) {
                        ls::GameConf profile;
                        profile.adaptive = true;
                        profile.adaptive_auto_base_fps_cap = false;
                        profile.adaptive_max_multiplier = 2;
                        profile.adaptive_stable_cadence = smooth;
                        profile.dynamic_cadence_recovery = recovery;
                        profile.frame_generation_refresh_threshold = 50;
                        profile.adaptive_target_refresh_rate = true;
                        profile.target_fps = adaptiveTargetFpsForDisplay(
                            90, profile.adaptive,
                            profile.adaptive_target_refresh_rate, 60);
                        require(effectiveFrameGenerationEnabled(profile, 60) &&
                                effectiveBaseFpsCap(profile, 60) == 0.0,
                            "50 Hz guard changed uncapped Fractional policy on a 60 Hz display");
                        const auto policy = generationSchedulerPolicy(profile, 60);
                        require(policy && policy->targetFps == 60 &&
                                policy->dynamicCadenceRecovery == recovery,
                            "display matching or refresh guard changed native recovery selection");
                        Harness harness(policy->targetFps, policy->maximumMultiplier,
                            policy->stableCadence, AdaptiveRecoveryPolicy::OrderedSdr,
                            policy->dynamicCadenceRecovery,
                            ls::dynamicCadenceProbeIntervalDuration(
                                policy->dynamicCadenceProbeIntervalSeconds),
                            60, policy->nearTargetNativePreference);
                        harness.start();
                        AdaptiveFramePlan previous;
                        const auto phase = [&](const double sourceFps) {
                            const auto started = harness.now;
                            size_t settledGenerated = 0;
                            while (harness.now - started < 8s) {
                                // Model the application interval with and without
                                // generated FIFO work hiding a faster native rate.
                                const double observedFps = fifoFeedback && !previous.empty()
                                    ? std::min(sourceFps, 60.0 / (previous.size() + 1))
                                    : sourceFps;
                                previous = harness.deliveredFrameAtFps(observedFps);
                                requireValidTimestamps(previous, 1);
                                if (harness.now - started >= 6s)
                                    settledGenerated += previous.size();
                            }
                            return settledGenerated;
                        };
                        const auto context = " (smooth=" + std::to_string(smooth) +
                            ", recovery=" + std::to_string(recovery) +
                            ", fifo=" + std::to_string(fifoFeedback) +
                            ", gameplay=" + std::to_string(gameplayFps) + ")";
                        require(phase(30.0) > 50,
                            "30 FPS cutscene did not sustain 2x generation" + context);
                        const size_t gameplayGenerated = phase(gameplayFps);
                        if (gameplayFps >= 58.0 && (!fifoFeedback || recovery)) {
                            require(gameplayGenerated == 0,
                                "near-target gameplay retained generated frames" + context);
                        } else {
                            require(gameplayGenerated > 0,
                                "refresh guard became a native-FPS cutoff or enabled hidden recovery" + context);
                        }
                        require(phase(30.0) > 50,
                            "return to a 30 FPS cutscene did not resume generation" + context);
                    }
                }
            }
        }
    }

    void testDynamicCadenceRecoversSelfHiddenNativeRateIncrease() {
        Harness harness(
            60, 2, false, AdaptiveRecoveryPolicy::OrderedSdr, true
        );
        harness.start();
        AdaptiveFramePlan previousPlan = harness.runAtFps(30.0, 8s);
        require(previousPlan.size() == 1,
            "precondition failed: 30 FPS gameplay did not settle at 2x");

        for (size_t frame = 0;
                frame < 600 &&
                    !harness.diagnostics.contains(
                        "dynamic-cadence-recovered"
                    );
                ++frame) {
            const double observedFps = previousPlan.empty() ? 60.0 : 30.0;
            previousPlan = harness.frameAtFps(observedFps, false, false);
            harness.scheduler.reportGeneratedFrameDelivery({
                .requested = previousPlan.size(),
                .acceptedForPresentation = previousPlan.size(),
            });
        }

        require(harness.diagnostics.contains(
                "dynamic-cadence-probe-start"),
            "dynamic cadence recovery never exposed native cadence");
        require(harness.diagnostics.contains(
                "dynamic-cadence-recovered"),
            "native 60 FPS menu cadence remained hidden behind generated FIFO work");
        require(harness.frameAtFps(60.0).empty(),
            "recovered native target cadence continued generating frames");
    }

    void testDynamicCadenceQualifiesNearTargetWithoutGeneratedFeedback() {
        for (const uint32_t target : {60U, 90U, 120U, 144U}) {
            Harness harness(target, 2, false,
                AdaptiveRecoveryPolicy::OrderedSdr, true, 100ms);
            harness.start();
            auto previous = harness.runAtFps(target / 2.0, 8s);
            const auto recoveredAt = harness.now;
            // A single sparse generated output can put the next application
            // frame back on FIFO's two-refresh ladder. Native qualification
            // must finish while measuring the source without that feedback.
            while (harness.now - recoveredAt < 5s) {
                previous = harness.deliveredFrameAtFps(
                    previous.empty() ? target * (119.0 / 120.0) : target / 2.0);
            }
            require(harness.scheduler.snapshot().nearTargetNativePreference &&
                    previous.empty(),
                "native probe reintroduced sparse FIFO work before near-target qualification");
            require(harness.diagnostics.count(
                    "adaptive-near-target-native-enabled") == 1,
                "near-target native probe did not settle exactly once");
            harness.runAtFps(target / 2.0, 4s);
            require(!harness.scheduler.snapshot().nearTargetNativePreference &&
                    harness.scheduler.snapshot().validatedGenerationLimit == 1,
                "qualified native cadence stranded a later genuine source drop");
        }
    }

    void testDynamicCadenceQualifiesAcrossTargetBoundary() {
        for (const bool steady : {false, true}) {
            for (const size_t multiplier : {2U, 3U, 4U, 5U}) {
                Harness harness(120, multiplier, steady,
                    AdaptiveRecoveryPolicy::OrderedSdr, true, 100ms);
                harness.start();
                auto previous = harness.runAtFps(120.0 / multiplier, 22s);
                require(harness.scheduler.snapshot().validatedGenerationLimit == multiplier - 1,
                    "precondition failed: higher workload was not validated");
                const auto recoveredAt = harness.now;
                size_t nativeFrames = 0;
                while (harness.now - recoveredAt < 5s) {
                    // Queue turnover first measures just above target. The same
                    // recovered source then settles just below it. Any generated
                    // output hides that native rate behind ordered FIFO again.
                    const double nativeFps = nativeFrames < 6 ? 120.1 : 119.0;
                    const double fps = previous.empty() ? nativeFps :
                        120.0 / static_cast<double>(previous.size() + 1);
                    nativeFrames = previous.empty() ? nativeFrames + 1 : 0;
                    previous = harness.deliveredFrameAtFps(fps);
                }
                require(harness.scheduler.snapshot().nearTargetNativePreference &&
                        previous.empty(),
                    "recovered cadence crossing the target fell back into FIFO generation");
                harness.runAtFps(120.0 / multiplier, 22s);
                require(!harness.scheduler.snapshot().nearTargetNativePreference &&
                        harness.scheduler.snapshot().validatedGenerationLimit == multiplier - 1,
                    "native recovery suppressed a later genuine GPU-load increase");
            }
        }
    }

    void testDynamicCadenceQualificationSurvivesQueueTurnover() {
        for (const bool steady : {false, true}) {
            for (const bool bursty : {false, true}) {
                Harness harness(120, 3, steady,
                    AdaptiveRecoveryPolicy::OrderedSdr, true, 100ms);
                harness.start();
                auto previous = harness.runAtFps(40.0, 15s);
                const auto recoveredAt = harness.now;
                size_t recoveries = 0;
                size_t nativeFrames = 0;
                while (harness.now - recoveredAt < 5s) {
                    const size_t observed = harness.diagnostics.count("dynamic-cadence-recovered");
                    // One queued two-refresh frame may retire just after the
                    // three fast native samples. Later 1.25/15.42 ms intervals
                    // still deliver 120 real FPS; ignoring the fast half must
                    // not misclassify that native stream as about 65 FPS.
                    const bool turnover = observed > recoveries;
                    recoveries = observed;
                    nativeFrames = previous.empty() ? nativeFrames + 1 : 0;
                    const double nativeFps = bursty && nativeFrames > 6
                        ? 120.0 / (nativeFrames % 2 ? 0.15 : 1.85) : 119.0;
                    const double fps = !previous.empty()
                        ? 120.0 / static_cast<double>(previous.size() + 1)
                        : turnover ? 60.0 : nativeFps;
                    previous = harness.deliveredFrameAtFps(fps);
                }
                require(harness.scheduler.snapshot().nearTargetNativePreference && previous.empty(),
                    "queue-turnover intervals aborted proven native recovery");
                const auto deficitAt = harness.now;
                size_t frames = 0;
                size_t generated = 0;
                while (harness.now - deficitAt < 3s) {
                    const double fps = bursty
                        ? 100.0 / (++frames % 2 ? 0.15 : 1.85) : 100.0;
                    generated += harness.deliveredFrameAtFps(fps).size();
                }
                require(!harness.scheduler.snapshot().nearTargetNativePreference && generated > 0,
                    "native measurement concealed a real below-target source rate");
            }
        }
    }

    void testDynamicCadenceDrainsPreviouslyQueuedOutput() {
        for (const bool steady : {false, true}) {
            for (const uint32_t target : {60U, 120U, 240U}) {
                for (const size_t queuedRefreshes : {2U, 3U, 4U}) {
                    Harness harness(target, 3, steady,
                        AdaptiveRecoveryPolicy::OrderedSdr, true, 100ms);
                    harness.start();
                    auto previous = harness.runAtFps(target / 3.0, 15s);
                    const auto recoveredAt = harness.now;
                    const auto queueLead = std::chrono::duration_cast<AdaptiveScheduler::Clock::duration>(
                        std::chrono::duration<double>(
                            static_cast<double>(queuedRefreshes) / target));
                    auto generatedTail = harness.now + queueLead;
                    while (harness.now - recoveredAt < 5s) {
                        if (!previous.empty())
                            generatedTail = harness.now + queueLead;
                        // New real-only presents also advance the transport
                        // clock. They must not extend a probe's captured drain.
                        harness.queuedPresentationDeadline = harness.now + queueLead;
                        const double fps = harness.now < generatedTail
                            ? target / 2.0 : target * .99;
                        previous = harness.deliveredFrameAtFps(fps);
                    }
                    require(harness.scheduler.snapshot().nearTargetNativePreference &&
                            previous.empty(),
                        "native probe rejected queued bridge intervals before native cadence was observable");
                }
            }
        }
    }

    void testDynamicCadenceQueuedDrainRejectsTrueLowRate() {
        for (const bool steady : {false, true}) {
            Harness harness(120, 2, steady,
                AdaptiveRecoveryPolicy::OrderedSdr, true, 100ms);
            harness.start();
            harness.runAtFps(60.0, 8s);
            size_t nativeFrames = 0;
            size_t maximumNativeFrames = 0;
            for (size_t frame = 0; frame < 600; ++frame) {
                harness.queuedPresentationDeadline = harness.now + 34ms;
                const auto plan = harness.deliveredFrameAtFps(60.0);
                nativeFrames = plan.empty() ? nativeFrames + 1 : 0;
                maximumNativeFrames = std::max(maximumNativeFrames, nativeFrames);
            }
            require(maximumNativeFrames >= 2 && maximumNativeFrames <= 4,
                "queued-output drain was absent or extended by new real-only output");
            require(!harness.diagnostics.contains("dynamic-cadence-recovered") &&
                    harness.scheduler.snapshot().validatedGenerationLimit == 1,
                "queue drain falsely qualified a genuinely slower source or lost accepted work");
        }
    }

    void testDynamicCadenceBurstCanFinishQueuedDrain() {
        for (const bool steady : {false, true}) {
            for (const uint32_t target : {60U, 120U, 240U}) {
                for (const size_t multiplier : {2U, 3U, 5U}) {
                    for (const auto [recovers, burstFinishesDrain] : {
                            std::pair{false, false}, std::pair{false, true},
                            std::pair{true, false}, std::pair{true, true}}) {
                        Harness harness(target, multiplier, steady,
                            AdaptiveRecoveryPolicy::OrderedSdr, true, 100ms);
                        harness.start();
                        const auto interval = std::chrono::duration_cast<std::chrono::steady_clock::duration>(
                            std::chrono::duration<double>(1.0 / target));
                        const double base = static_cast<double>(target) / multiplier;
                        harness.runAtFps(base, 15s);
                        for (size_t frame = 0; frame < 100 &&
                                harness.scheduler.snapshot().nativeCadenceProbeActive; ++frame)
                            harness.deliveredFrameAtFps(base);
                        require(!harness.scheduler.snapshot().nativeCadenceProbeActive,
                            "precondition failed: earlier native probe did not end");
                        const auto probes = harness.diagnostics.count("dynamic-cadence-probe-start");
                        for (size_t frame = 0; frame < 2000 &&
                                harness.diagnostics.count("dynamic-cadence-probe-start") == probes;
                                ++frame) {
                            harness.queuedPresentationDeadline = harness.now + 6 * interval;
                            harness.deliveredFrameAtFps(base);
                        }
                        require(harness.scheduler.snapshot().nativeCadenceProbeActive,
                            "precondition failed: queued native probe did not begin");
                        const auto horizon = *harness.queuedPresentationDeadline;
                        const auto recoveries = harness.diagnostics.count("dynamic-cadence-recovered");
                        const auto rejected = harness.diagnostics.count("dynamic-cadence-probe-rejected");
                        do {
                            require(harness.frameAtFps(target * 4.0).empty(),
                                "queue drain generated work during an untrusted source burst");
                        } while (burstFinishesDrain && harness.now < horizon);
                        require(harness.diagnostics.count("dynamic-cadence-recovered") == recoveries,
                            "an untrusted burst qualified native recovery");
                        if (!burstFinishesDrain) {
                            require(harness.now < horizon,
                                "precondition failed: short burst exhausted queue drain");
                            require(harness.frame(horizon - harness.now).empty() &&
                                    harness.diagnostics.count("dynamic-cadence-probe-rejected") == rejected &&
                                    harness.diagnostics.count("dynamic-cadence-recovered") == recoveries,
                                "short burst prematurely cleared the drain or counted its crossing sample");
                        }
                        if (!recovers) {
                            const auto restored = harness.deliveredFrameAtFps(base);
                            require(!restored.empty() &&
                                    harness.diagnostics.count("dynamic-cadence-probe-rejected") == rejected + 1,
                                "a burst-cleared queue discarded an entirely post-drain slow sample");
                        } else {
                            for (size_t sample = 0; sample < 3; ++sample) {
                                harness.deliveredFrameAtFps(base * 1.5);
                                require(harness.diagnostics.count("dynamic-cadence-recovered") ==
                                        recoveries + (sample == 2 ? 1 : 0),
                                    "burst-cleared drain changed the three-valid-sample recovery boundary");
                            }
                        }
                    }
                }
            }
        }
    }

    void testDynamicCadenceProbeCannotSpanGeneratedAcquireBackoff() {
        for (const bool steady : {false, true}) {
            for (const uint32_t target : {30U, 60U, 90U, 120U, 240U}) {
                Harness harness(target, 2, steady,
                    AdaptiveRecoveryPolicy::OrderedSdr, true, 100ms);
                harness.start();
                harness.runAtFps(target / 2.0, 8s);
                const auto started = harness.now;
                while (!harness.scheduler.snapshot().nativeCadenceProbeActive) {
                    harness.deliveredFrameAtFps(target / 2.0);
                    require(harness.now - started < 1s, "native probe never started");
                }
                harness.deliveredFrameAtFps(target);
                const auto recovered = harness.diagnostics.count("dynamic-cadence-recovered");
                const auto validated = harness.scheduler.snapshot().validatedGenerationLimit;
                harness.frameAtFps(target / 2.0, true);
                harness.deliveredFrameAtFps(target);
                harness.deliveredFrameAtFps(target);
                require(harness.diagnostics.count("dynamic-cadence-recovered") == recovered,
                    "native recovery combined samples across an intervening generated-image probe");
                require(harness.scheduler.snapshot().validatedGenerationLimit == validated,
                    "discarding interrupted native evidence lost the accepted generated workload");

                // Cancellation must allow a later fresh probe, rather than
                // leaving the source trapped behind the previous FIFO batch.
                auto previous = harness.deliveredFrameAtFps(target / 2.0);
                const auto resumedAt = harness.now;
                while (harness.now - resumedAt < 5s) {
                    previous = harness.deliveredFrameAtFps(
                        previous.empty() ? target * .99 : target / 2.0);
                }
                require(harness.diagnostics.count("dynamic-cadence-recovered") > recovered &&
                        harness.scheduler.snapshot().nearTargetNativePreference && previous.empty(),
                    "native recovery did not resume after generated-acquire pressure cleared");
            }
        }
    }

    void testDynamicCadenceAbortsUnqualifiedNearTargetRise() {
        Harness harness(120, 2, false,
            AdaptiveRecoveryPolicy::OrderedSdr, true, 100ms);
        harness.start();
        auto previous = harness.runAtFps(60.0, 8s);
        const auto riseAt = harness.now;
        while (!harness.diagnostics.contains("dynamic-cadence-recovered")) {
            previous = harness.deliveredFrameAtFps(previous.empty() ? 119.0 : 60.0);
            require(harness.now - riseAt < 1s,
                "near-target abort test never obtained a native sample");
        }
        harness.runAtFps(119.0, 200ms);
        require(harness.scheduler.snapshot().nativeCadenceProbeActive &&
                !harness.scheduler.snapshot().nearTargetNativePreference,
            "short native sample bypassed the existing preference hold");
        harness.runAtFps(60.0, 500ms);
        require(!harness.scheduler.snapshot().nearTargetNativePreference &&
                !harness.diagnostics.contains("adaptive-near-target-native-enabled") &&
                harness.frameAtFps(60.0).size() == 1,
            "failed native qualification suppressed a genuinely slower source");
    }

    void testDynamicCadenceBoundsSelfHiddenRecoveryLatency() {
        Harness harness(
            60, 2, false, AdaptiveRecoveryPolicy::OrderedSdr, true
        );
        harness.start();
        constexpr auto recoveryLatencyBound =
            ls::dynamicCadenceProbeIntervalDuration(
                ls::GameConfDefaults::dynamicCadenceProbeIntervalSeconds
            ) + 100ms;

        while (!harness.diagnostics.contains(
                "dynamic-cadence-probe-rejected")) {
            harness.frameAtFps(30.0);
        }

        const auto transitionAt = harness.now;
        AdaptiveFramePlan previousPlan =
            AdaptiveFramePlan::evenlySpaced(1);
        while (!harness.diagnostics.contains("dynamic-cadence-recovered")) {
            const double observedFps = previousPlan.empty() ? 60.0 : 30.0;
            previousPlan = harness.frameAtFps(observedFps, false, false);
            harness.scheduler.reportGeneratedFrameDelivery({
                .requested = previousPlan.size(),
                .acceptedForPresentation = previousPlan.size(),
            });
            require(harness.now - transitionAt <= recoveryLatencyBound,
                "self-hidden native cadence recovery exceeded its latency bound");
        }

        require(harness.now - transitionAt <= recoveryLatencyBound,
            "self-hidden native cadence recovery did not complete promptly");
    }

    void testDynamicCadenceProbeIntervalUpdatesLive() {
        Harness harness(
            60, 2, false, AdaptiveRecoveryPolicy::OrderedSdr, true, 3s
        );
        harness.start();

        while (!harness.diagnostics.contains(
                "dynamic-cadence-probe-rejected")) {
            harness.frameAtFps(30.0);
        }

        const auto generationLimit =
            harness.scheduler.snapshot().generationLimit;
        const size_t stabilizationEvents =
            harness.diagnostics.count("stabilization");
        harness.scheduler.updateDynamicCadenceProbeInterval(harness.now, 100ms);
        require(harness.scheduler.snapshot().generationLimit == generationLimit,
            "live probe interval update reset the validated generation limit");
        require(harness.diagnostics.count("stabilization") ==
                stabilizationEvents,
            "live probe interval update restarted scheduler stabilization");

        const auto transitionAt = harness.now;
        AdaptiveFramePlan previousPlan =
            AdaptiveFramePlan::evenlySpaced(1);
        while (!harness.diagnostics.contains("dynamic-cadence-recovered")) {
            const double observedFps = previousPlan.empty() ? 60.0 : 30.0;
            previousPlan = harness.frameAtFps(observedFps, false, false);
            harness.scheduler.reportGeneratedFrameDelivery({
                .requested = previousPlan.size(),
                .acceptedForPresentation = previousPlan.size(),
            });
            require(harness.now - transitionAt <= 200ms,
                "live probe interval update did not reschedule the next probe");
        }
    }

    void testDynamicCadenceProbeRejectsTrueThirtyFpsCadence() {
        Harness harness(
            60, 2, false, AdaptiveRecoveryPolicy::OrderedSdr, true
        );
        harness.start();
        require(harness.runAtFps(30.0, 7s).size() == 1,
            "precondition failed: true 30 FPS cadence did not settle at 2x");

        size_t consecutiveNativeFrames = 0;
        size_t maximumConsecutiveNativeFrames = 0;
        for (size_t frame = 0; frame < 420; ++frame) {
            const auto plan = harness.frameAtFps(30.0);
            consecutiveNativeFrames = plan.empty()
                ? consecutiveNativeFrames + 1
                : 0;
            maximumConsecutiveNativeFrames = std::max(
                maximumConsecutiveNativeFrames, consecutiveNativeFrames
            );
        }

        require(harness.diagnostics.contains(
                "dynamic-cadence-probe-rejected"),
            "a true 30 FPS cadence did not reject the native-only probe");
        require(!harness.diagnostics.contains(
                "dynamic-cadence-recovered"),
            "a true 30 FPS cadence was mistaken for native recovery");
        require(maximumConsecutiveNativeFrames == 1,
            "a rejected native-cadence probe suppressed generation for multiple frames");
        require(harness.frameAtFps(30.0).size() == 1,
            "a rejected native-cadence probe did not resume 2x generation");
    }

    void testFractionalAutomaticDoesNotProbeWithoutRecovery() {
        for (const uint32_t target : {50U, 60U, 90U, 120U}) {
            for (const size_t multiplier : {2U, 3U, 5U}) {
                const double baseFps = double(target) / multiplier;
                if (baseFps < 12.0)
                    continue;
                for (const bool smooth : {false, true}) {
                    for (const uint32_t cap : {0U, target, target * 2}) {
                        ls::GameConf profile;
                        profile.adaptive = true;
                        profile.target_fps = target;
                        profile.adaptive_max_multiplier = multiplier;
                        profile.adaptive_auto_base_fps_cap = false;
                        profile.adaptive_fractional_real_frame_priority =
                            ls::AdaptiveFractionalRealFramePriority::Auto;
                        profile.adaptive_stable_cadence = smooth;
                        profile.base_fps_cap = cap;
                        profile.dynamic_cadence_recovery = false;
                        const auto policy = generationSchedulerPolicy(profile, target);
                        require(policy && policy->qualifyTargetNativeCadence &&
                                !policy->dynamicCadenceRecovery,
                            "precondition failed: Fractional Automatic did not qualify native output");
                        Harness harness(target, multiplier, smooth,
                            AdaptiveRecoveryPolicy::OrderedSdr, false, 2s, target,
                            policy->nearTargetNativePreference, false, false,
                            policy->qualifyTargetNativeCadence);
                        harness.start();
                        const auto until = harness.now + 30s;
                        while (harness.now < until) {
                            harness.deliveredFrameAtFps(baseFps);
                            require(!harness.scheduler.snapshot().nativeCadenceProbeActive,
                                "Fractional Automatic interrupted generation for an unrequested native probe");
                        }
                        require(harness.scheduler.snapshot().validatedGenerationLimit > 0,
                            "slow Fractional Automatic source lost its generated workload");
                    }
                }
            }
        }
    }

    void testDynamicCadenceRecoveryIsOptInAndSdrOnly() {
        Harness disabled(
            60, 2, false, AdaptiveRecoveryPolicy::OrderedSdr, false
        );
        disabled.start();
        disabled.runAtFps(30.0, 12s);
        require(!disabled.diagnostics.contains(
                "dynamic-cadence-probe-start"),
            "default Adaptive policy performed a native-cadence probe");

        Harness hdr(
            60, 2, false, AdaptiveRecoveryPolicy::ConservativeHdr, true
        );
        hdr.start();
        hdr.runAtFps(30.0, 12s);
        require(!hdr.diagnostics.contains(
                "dynamic-cadence-probe-start"),
            "nonblocking HDR transport performed an ordered-cadence probe");
    }

    void testSmoothCadenceDoesNotChatterOnOscillatingLoad() {
        Harness harness(110, 3, true);
        harness.start();
        harness.runAtFps(55.0, 10s);
        require(harness.scheduler.snapshot().phase ==
                AdaptiveSchedulerPhase::StableCadence,
            "precondition failed: stable 55 FPS did not settle on Smooth Cadence");

        harness.runAtFps(68.0, 2s);
        require(harness.scheduler.snapshot().phase !=
                AdaptiveSchedulerPhase::StableCadence,
            "native cadence recovery did not leave Smooth Cadence");

        const size_t probesBeforeOscillation = harness.diagnostics.count(
            "adaptive-stable-cadence-probe"
        );
        for (size_t cycle = 0; cycle < 6; ++cycle) {
            harness.runAtFps(55.0, 4s);
            harness.runAtFps(68.0, 2s);
        }
        const size_t probesAfterOscillation = harness.diagnostics.count(
            "adaptive-stable-cadence-probe"
        );
        require(probesAfterOscillation - probesBeforeOscillation <= 2,
            "oscillating load repeatedly toggled Smooth Cadence workload");
    }

    void testValidatedWorkloadIgnoresOrdinaryGameplaySlowdown() {
        for (const uint32_t multiplier : {2u, 3u, 4u, 5u}) {
            const double provenBaseFps = 120.0 /
                static_cast<double>(multiplier);
            Harness harness(
                120, multiplier, false, AdaptiveRecoveryPolicy::OrderedSdr,
                false, 2s, 120, false
            );
            harness.start();
            harness.runAtFps(provenBaseFps, 20s);
            require(harness.scheduler.snapshot().validatedGenerationLimit ==
                    multiplier - 1,
                "precondition failed: configured workload was not validated");

            harness.runAtFps(provenBaseFps * 0.70, 10s);
            const auto snapshot = harness.scheduler.snapshot();
            require(snapshot.validatedGenerationLimit == multiplier - 1 &&
                    snapshot.phase != AdaptiveSchedulerPhase::RescueMeasurement,
                "ordinary gameplay cadence changed an already validated workload");
        }
    }

    void testCommonWorkloadRuleCoversTwoXThroughFiveX() {
        for (const uint32_t multiplier : {2u, 3u, 4u, 5u}) {
            Harness harness(
                60 * multiplier, multiplier, false,
                AdaptiveRecoveryPolicy::OrderedSdr,
                false, 2s, 60 * multiplier, false
            );
            harness.start();
            for (size_t frame = 0; frame < 5000; ++frame) {
                const auto snapshot = harness.scheduler.snapshot();
                if (snapshot.rampEvaluationActive &&
                        snapshot.generationLimit == multiplier - 1) {
                    break;
                }
                harness.frameAtFps(60.0);
            }
            require(harness.scheduler.snapshot().rampEvaluationActive &&
                    harness.scheduler.snapshot().generationLimit ==
                        multiplier - 1,
                "precondition failed: final configured workload probe did not begin");

            while (harness.scheduler.snapshot().rampEvaluationActive)
                harness.frameAtFps(31.0);
            const auto* result = harness.diagnostics.last("ramp-result");
            require(result && !result->accepted &&
                    result->testedLimit == multiplier - 1 &&
                    result->reason == "unpaid-real-frame-cost" &&
                    harness.scheduler.snapshot().validatedGenerationLimit ==
                        multiplier - 2,
                "a 2x-5x workload bypassed the common adjacent-load rule at " +
                    std::to_string(multiplier) + "x: accepted=" +
                    std::to_string(result ? result->accepted : false) +
                    ", tested=" + std::to_string(
                        result ? result->testedLimit : 0
                    ) + ", retained=" + std::to_string(
                        harness.scheduler.snapshot().validatedGenerationLimit
                    ));
        }
    }

    void testFailedHigherLoadCannotRatchetToDegradedBaseline() {
        Harness harness(
            100, 3, false, AdaptiveRecoveryPolicy::OrderedSdr,
            false, 2s, 100, false
        );
        harness.start();
        for (size_t frame = 0; frame < 2000; ++frame) {
            const auto snapshot = harness.scheduler.snapshot();
            if (snapshot.rampEvaluationActive &&
                    snapshot.generationLimit == 2) {
                break;
            }
            harness.frameAtFps(47.7504);
        }
        require(harness.scheduler.snapshot().rampEvaluationActive &&
                harness.scheduler.snapshot().generationLimit == 2,
            "precondition failed: FF7-style 3x probe did not begin");

        while (harness.scheduler.snapshot().rampEvaluationActive)
            harness.frameAtFps(31.5);
        require(harness.scheduler.snapshot().validatedGenerationLimit == 1,
            "counterproductive below-target 3x probe was accepted");
        const size_t rampsAfterFailure = harness.diagnostics.count("ramp");

        // A lower source alone cannot rebase the failed trial without
        // continuous delivered evidence, even after the cooldown expires.
        harness.runAtFps(33.4459, 60s, false);
        require(harness.diagnostics.count("ramp") == rampsAfterFailure &&
                harness.scheduler.snapshot().validatedGenerationLimit == 1,
            "failed 3x probe retried against a degraded 2x baseline");

        for (size_t frame = 0; frame < 1000 &&
                !harness.scheduler.snapshot().rampEvaluationActive; ++frame) {
            harness.frameAtFps(48.0);
        }
        require(harness.scheduler.snapshot().rampEvaluationActive,
            "recovered 2x baseline did not permit a fresh adjacent probe");
        while (harness.scheduler.snapshot().rampEvaluationActive)
            harness.frameAtFps(23.8233);
        const auto* result = harness.diagnostics.last("ramp-result");
        require(result && !result->accepted &&
                result->reason == "unpaid-real-frame-cost" &&
                harness.scheduler.snapshot().validatedGenerationLimit == 1,
            "recovered retry forgot the original proven 2x baseline");
    }

    void testSmoothCadenceCollapseUsesRealOnlyMeasurement() {
        Harness harness(90, 2, true);
        harness.start();
        harness.runAtFps(47.0, 12s);
        require(harness.scheduler.snapshot().phase ==
                AdaptiveSchedulerPhase::StableCadence,
            "precondition failed: Smooth Cadence did not settle");

        for (size_t frame = 0;
                frame < 120 && !harness.diagnostics.contains("rescue-start");
                ++frame) {
            harness.frameAtFps(30.0);
        }
        const auto* rescueStart = harness.diagnostics.last("rescue-start");
        require(rescueStart &&
                rescueStart->reason == "stable-cadence-collapse",
            "collapsed Smooth Cadence did not start real-only measurement");
        require(harness.scheduler.snapshot().phase ==
                AdaptiveSchedulerPhase::RescueMeasurement,
            "Smooth Cadence rescue was not exposed as scheduler state");
        require(harness.frameAtFps(30.0).empty(),
            "Smooth Cadence rescue generated during real-only measurement");
    }

    void testOrderedSdrSmoothCollapseRestoresAutomaticCap() {
        Harness harness(90, 2, true, AdaptiveRecoveryPolicy::OrderedSdr,
            false, 2s, 90, true, true);
        harness.start();
        harness.runAtFps(45.0, 12s);
        for (size_t frame = 0; frame < 120 &&
                !harness.diagnostics.contains("rescue-start"); ++frame)
            harness.frameAtFps(30.0);
        require(harness.scheduler.snapshot().phase ==
                    AdaptiveSchedulerPhase::RescueMeasurement &&
                harness.scheduler.snapshot().automaticBaseCapSuppressed,
            "collapse did not temporarily release the automatic cap");
        const auto started = harness.now;
        while (harness.scheduler.snapshot().phase ==
                AdaptiveSchedulerPhase::RescueMeasurement &&
                harness.now - started < 2s)
            harness.frameAtFps(60.0);
        const auto* restored = harness.diagnostics.last("automatic-base-cap-restored");
        const auto* measured = harness.diagnostics.last("rescue-complete");
        require(!harness.scheduler.snapshot().automaticBaseCapSuppressed &&
                harness.now - started <= AdaptiveScheduler::rescueMeasurementDuration() + 17ms &&
                restored && restored->reason == "rescue-measurement-complete" &&
                measured && measured->reason == "verify-restored-policy",
            "native measurement did not restore the cap before verification");
        harness.runAtFps(45.0, 2s);
        const auto* verified = harness.diagnostics.last("rescue-complete");
        require(verified && verified->reason == "restored-policy-recovered" &&
                !harness.scheduler.snapshot().automaticBaseCapSuppressed,
            "healthy capped output did not complete bounded recovery");
    }

    void testSmoothRescueRestoresCapRegardlessOfNativeHeadroom() {
        for (const double measuredFps : {30.0, 45.0, 90.0}) {
            Harness harness(90, 2, true, AdaptiveRecoveryPolicy::OrderedSdr,
                false, 2s, 90, true, true);
            harness.start();
            harness.runAtFps(45.0, 12s);
            for (size_t frame = 0; frame < 120 &&
                    !harness.diagnostics.contains("rescue-start"); ++frame)
                harness.frameAtFps(30.0);
            require(harness.diagnostics.contains("rescue-start"),
                "precondition failed: collapse did not start rescue");
            for (size_t frame = 0; frame < 180 &&
                    harness.scheduler.snapshot().phase ==
                        AdaptiveSchedulerPhase::RescueMeasurement; ++frame)
                harness.frameAtFps(measuredFps);
            require(!harness.scheduler.snapshot().automaticBaseCapSuppressed,
                "native measurement left the automatic cap released");
            harness.runAtFps(30.0, 2s);
            const auto* result = harness.diagnostics.last("rescue-complete");
            require(result && (result->reason == "restored-policy-not-recovered" ||
                    result->reason == "timing-reset"),
                "persistent slowdown verification decision: " +
                    std::string(result ? result->reason : "missing") +
                    " native_fps=" + std::to_string(measuredFps));
            harness.runAtFps(30.0, 35s);
            require(harness.diagnostics.count("rescue-start") == 1 &&
                    !harness.scheduler.snapshot().automaticBaseCapSuppressed,
                "an unchanged heavy scene repeatedly started rescue or released its cap");
        }
    }

    void testSmoothRescueVerifiesRestoredGeneratedLoad() {
        Harness harness(90, 2, true, AdaptiveRecoveryPolicy::OrderedSdr,
            false, 2s, 90, true, true);
        harness.start();
        harness.runAtFps(45.0, 12s);
        for (size_t frame = 0; frame < 120 &&
                !harness.diagnostics.contains("rescue-start"); ++frame)
            harness.frameAtFps(30.0);
        require(harness.diagnostics.contains("rescue-start"),
            "precondition failed: collapse did not start rescue");
        for (size_t frame = 0; frame < 120 &&
                harness.scheduler.snapshot().phase ==
                    AdaptiveSchedulerPhase::RescueMeasurement; ++frame)
            harness.frameAtFps(60.0);
        require(!harness.scheduler.snapshot().automaticBaseCapSuppressed,
            "verification started without restoring the configured cap");
        harness.runAtFps(35.0, 2s);
        const auto* result = harness.diagnostics.last("rescue-complete");
        require(!harness.scheduler.snapshot().automaticBaseCapSuppressed &&
                result && result->reason == "restored-policy-not-recovered",
            "native-only improvement was accepted after generated load lost the benefit");
    }

    void testSmoothRescueRecoversAtTargetWithConfiguredCap() {
        for (const uint32_t targetFps : {90U, 120U}) {
            for (const bool nativeHeadroom : {false, true}) {
                Harness harness(targetFps, 2, true,
                    AdaptiveRecoveryPolicy::OrderedSdr, false, 2s,
                    targetFps, true, true);
                const double healthyBaseFps = targetFps / 2.0;
                harness.start();
                harness.runAtFps(healthyBaseFps, 12s);
                for (size_t frame = 0; frame < 120 &&
                        !harness.diagnostics.contains("rescue-start"); ++frame)
                    harness.frameAtFps(healthyBaseFps * 2.0 / 3.0);
                require(harness.diagnostics.contains("rescue-start"),
                    "precondition failed: collapse did not start rescue");
                for (size_t frame = 0; frame < 240 &&
                        harness.scheduler.snapshot().phase ==
                            AdaptiveSchedulerPhase::RescueMeasurement; ++frame)
                    harness.frameAtFps(nativeHeadroom ? targetFps : healthyBaseFps);
                const auto* nativeResult = harness.diagnostics.last("rescue-complete");
                require(nativeResult && nativeResult->reason == "verify-restored-policy" &&
                        !harness.scheduler.snapshot().automaticBaseCapSuppressed,
                    "measurement did not restore the cap before checking recovery");
                harness.runAtFps(healthyBaseFps, 2s);
                const auto* verified = harness.diagnostics.last("rescue-complete");
                require(!harness.scheduler.snapshot().automaticBaseCapSuppressed &&
                        verified && verified->reason == "restored-policy-recovered" &&
                        harness.scheduler.snapshot().generationLimit == 1,
                    "full-target capped output was rejected or left a cap override");
            }
        }
    }

    void testSmoothRescueCannotLeaveCapDisabledAfterSceneRecovery() {
        enum class Cause { SceneChange, ResettableCollapse, NeedsContinuousUncapping };
        for (const uint32_t targetFps : {90U, 120U}) {
            for (const auto cause : {Cause::SceneChange, Cause::ResettableCollapse,
                    Cause::NeedsContinuousUncapping}) {
                Harness harness(targetFps, 2, true,
                    AdaptiveRecoveryPolicy::OrderedSdr, false, 2s,
                    targetFps, true, true);
                ls::GameConf profile;
                profile.adaptive = true;
                profile.target_fps = targetFps;
                profile.adaptive_auto_base_fps_cap = true;
                profile.frame_generation_enabled = true;
                profile.frame_generation_provisioned = true;
                const double healthyFps = targetFps / 2.0;
                const double collapsedFps = targetFps / 3.0;
                // Apply the real presentation cap owner to the model's source
                // demand instead of merely checking the suppression flag.
                const auto step = [&](const double potentialFps) {
                    const double cap = effectiveBaseFpsCap(
                        profile, harness.scheduler.snapshot(), targetFps);
                    harness.frameAtFps(cap > 0.0
                        ? std::min(cap, potentialFps) : potentialFps);
                    const auto snapshot = harness.scheduler.snapshot();
                    if (snapshot.phase != AdaptiveSchedulerPhase::RescueMeasurement)
                        require(effectiveBaseFpsCap(profile, snapshot, targetFps) == healthyFps,
                            "recovery overrode the configured cap outside its native sample");
                };
                harness.start();
                harness.runAtFps(healthyFps, 12s);
                for (size_t frame = 0; frame < 180 &&
                        !harness.diagnostics.contains("rescue-start"); ++frame)
                    step(collapsedFps);
                require(harness.diagnostics.contains("rescue-start"),
                    "precondition failed: modeled collapse did not start rescue");
                const auto rescueStarted = harness.now;
                bool recovered = false;
                while (harness.now - rescueStarted < 5min) {
                    const bool nativeSample = harness.scheduler.snapshot().phase ==
                        AdaptiveSchedulerPhase::RescueMeasurement;
                    if (cause == Cause::SceneChange && harness.now - rescueStarted >= 250ms)
                        recovered = true; // Improvement is independent of cap policy.
                    if (cause == Cause::ResettableCollapse && nativeSample)
                        recovered = true; // A short break clears the modeled feedback loop.
                    const double potentialFps = nativeSample &&
                            (recovered || cause == Cause::NeedsContinuousUncapping)
                        ? targetFps : recovered ? healthyFps : collapsedFps;
                    step(potentialFps);
                }
                const auto* result = harness.diagnostics.last("rescue-complete");
                const bool expectedRecovery = cause != Cause::NeedsContinuousUncapping;
                const bool expectedDecision = result && (expectedRecovery
                    ? result->reason == "restored-policy-recovered"
                    : (result->reason == "restored-policy-not-recovered" ||
                        result->reason == "timing-reset"));
                require(expectedDecision &&
                        harness.diagnostics.count("rescue-start") == 1 &&
                        !harness.scheduler.snapshot().automaticBaseCapSuppressed,
                    "modeled recovery decision: " +
                        std::string(result ? result->reason : "missing") +
                        " expected_recovery=" + std::to_string(expectedRecovery) + " attempts=" +
                        std::to_string(harness.diagnostics.count("rescue-start")));
                require(profile.adaptive_auto_base_fps_cap && profile.target_fps == targetFps,
                    "recovery altered the saved cap policy");
            }
        }
    }

    void testSmoothRescueRequiresGeneratedDeliveryForVerification() {
        enum class Delivery { Complete, Missing, Partial, OneMissing };
        for (const auto delivery : {Delivery::Complete, Delivery::Missing,
                Delivery::Partial, Delivery::OneMissing}) {
            Harness harness(90, 2, true, AdaptiveRecoveryPolicy::OrderedSdr,
                false, 2s, 90, true, true);
            harness.start();
            harness.runAtFps(45.0, 12s);
            for (size_t frame = 0; frame < 120 &&
                    !harness.diagnostics.contains("rescue-start"); ++frame)
                harness.frameAtFps(30.0);
            require(harness.diagnostics.contains("rescue-start"),
                "precondition failed: collapse did not start rescue");
            for (size_t frame = 0; frame < 120 &&
                    harness.scheduler.snapshot().phase ==
                        AdaptiveSchedulerPhase::RescueMeasurement; ++frame)
                harness.frameAtFps(60.0);
            size_t generatedPlans = 0;
            for (size_t frame = 0; frame < 90; ++frame) {
                const auto plan = harness.frameAtFps(45.0, false, false);
                if (!plan.empty())
                    ++generatedPlans;
                if (delivery == Delivery::Missing ||
                        (delivery == Delivery::OneMissing && generatedPlans == 5))
                    continue;
                harness.scheduler.reportGeneratedFrameDelivery({
                    plan.size(), delivery == Delivery::Partial ? 0 : plan.size()});
            }
            const auto* result = harness.diagnostics.last("rescue-complete");
            require(generatedPlans >= 5 && result &&
                    result->reason == (delivery == Delivery::Complete
                        ? "restored-policy-recovered" : "restored-policy-not-recovered") &&
                    !harness.scheduler.snapshot().automaticBaseCapSuppressed,
                "restored-policy verification ignored incomplete generated delivery");
        }
    }

    void testSmoothRescueRestoresCapAcrossRepeatedCollapses() {
        Harness harness(90, 2, true, AdaptiveRecoveryPolicy::OrderedSdr,
            false, 2s, 90, true, true);
        harness.start();
        for (size_t episode = 1; episode <= 3; ++episode) {
            harness.runAtFps(45.0, 20s);
            for (size_t frame = 0; frame < 120 &&
                    harness.diagnostics.count("rescue-start") < episode; ++frame)
                harness.frameAtFps(30.0);
            require(harness.diagnostics.count("rescue-start") == episode,
                "newly qualified healthy cadence did not permit another bounded rescue");
            for (size_t frame = 0; frame < 120 &&
                    harness.scheduler.snapshot().phase ==
                        AdaptiveSchedulerPhase::RescueMeasurement; ++frame)
                harness.frameAtFps(60.0);
            harness.runAtFps(45.0, 2s);
            require(!harness.scheduler.snapshot().automaticBaseCapSuppressed &&
                    harness.diagnostics.count("automatic-base-cap-restored") == episode,
                "a later recovery inherited or retained an earlier cap override");
        }
    }

    void testSmoothRescueHandlesCollapseAfterStableExit() {
        Harness harness(90, 2, true, AdaptiveRecoveryPolicy::OrderedSdr,
            false, 2s, 90, true, true);
        harness.start();
        harness.runAtFps(45.0, 12s);
        harness.runAtFps(38.0, 800ms);
        require(harness.diagnostics.last("adaptive-stable-cadence-disabled") &&
                harness.diagnostics.last("adaptive-stable-cadence-disabled")->reason ==
                    "outside-useful-range" &&
                !harness.diagnostics.contains("rescue-start"),
            "precondition failed: ordinary cadence exit unexpectedly started rescue");
        // The reported late-session signature: five normal source frames,
        // then one with an additional 50 ms stall (about 33 FPS on average).
        for (size_t frame = 0; frame < 120 &&
                !harness.diagnostics.contains("rescue-start"); ++frame)
            harness.frame(frame % 6 == 5 ? 72222us : 22222us);
        require(harness.diagnostics.contains("rescue-start"),
            "bursty collapse after cadence exit lost its accepted baseline");
        for (size_t frame = 0; frame < 120; ++frame)
            harness.frame(frame % 6 == 5 ? 72222us : 22222us);
        require(!harness.scheduler.snapshot().automaticBaseCapSuppressed,
            "external-style stalls without native improvement left cap suppression active");
        require(harness.diagnostics.count("rescue-start") == 1,
            "bursty unrecovered source repeatedly started rescue");
    }

    void testSmoothRescueRollsBackInterruptedMeasurement() {
        enum class Interruption { TimingReset, FastBurst, AcquireBackoff, Stabilization };
        for (const bool duringVerification : {false, true}) {
            for (const auto interruption : {Interruption::TimingReset,
                    Interruption::FastBurst, Interruption::AcquireBackoff,
                    Interruption::Stabilization}) {
                Harness harness(90, 2, true, AdaptiveRecoveryPolicy::OrderedSdr,
                    false, 2s, 90, true, true);
                harness.start();
                harness.runAtFps(47.0, 12s);
                for (size_t frame = 0; frame < 120 &&
                        !harness.diagnostics.contains("rescue-start"); ++frame)
                    harness.frameAtFps(30.0);
                require(harness.diagnostics.contains("rescue-start"),
                    "precondition failed: collapse did not start rescue");
                if (duringVerification) {
                    for (size_t frame = 0; frame < 120 &&
                            harness.scheduler.snapshot().phase ==
                                AdaptiveSchedulerPhase::RescueMeasurement; ++frame)
                        harness.frameAtFps(60.0);
                    const auto* nativeResult = harness.diagnostics.last("rescue-complete");
                    require(nativeResult && nativeResult->reason == "verify-restored-policy" &&
                            !harness.scheduler.snapshot().automaticBaseCapSuppressed,
                        "precondition failed: native sample did not start verification");
                }
                if (interruption == Interruption::FastBurst)
                    harness.frame(1ms);
                else if (interruption == Interruption::AcquireBackoff)
                    harness.frameAtFps(30.0, true);
                else if (interruption == Interruption::Stabilization)
                    harness.scheduler.beginStabilization(harness.now, "policy-change");
                else
                    harness.scheduler.resetTiming(harness.now);
                require(!harness.scheduler.snapshot().automaticBaseCapSuppressed,
                    "interrupted rescue retained temporary automatic-cap suppression");
                harness.runAtFps(30.0, 2s);
                const auto* completed = harness.diagnostics.last("rescue-complete");
                require(!harness.scheduler.snapshot().automaticBaseCapSuppressed &&
                        (!completed || completed->reason != "restored-policy-recovered"),
                    "cancelled rescue later committed stale verification evidence");
            }
        }
    }

    void testSmoothRescueRejectsBriefNativeHeadroom() {
        for (const auto [peakFps, remainingFps] :
                {std::pair{90.0, 30.0}, std::pair{60.0, 40.0}}) {
            Harness harness(90, 2, true, AdaptiveRecoveryPolicy::OrderedSdr,
                false, 2s, 90, true, true);
            harness.start();
            harness.runAtFps(45.0, 12s);
            for (size_t frame = 0; frame < 120 &&
                    !harness.diagnostics.contains("rescue-start"); ++frame)
                harness.frameAtFps(30.0);
            require(harness.diagnostics.contains("rescue-start"),
                "precondition failed: collapse did not start rescue");
            // A short lighter interval must not outweigh the rest of a heavy
            // scene merely because it contains more frames per unit time.
            harness.runAtFps(peakFps, 100ms);
            harness.runAtFps(remainingFps, 2s);
            const auto* restored = harness.diagnostics.last("automatic-base-cap-restored");
            const auto* completed = harness.diagnostics.last("rescue-complete");
            require(!harness.scheduler.snapshot().automaticBaseCapSuppressed &&
                    restored && (!completed || completed->reason != "restored-policy-recovered"),
                "brief native headroom was mistaken for sustained cap benefit");
        }
    }

    void testSmoothRescueIgnoresBriefSceneDips() {
        for (const uint32_t targetFps : {60U, 90U, 120U}) {
            Harness harness(targetFps, 2, true,
                AdaptiveRecoveryPolicy::OrderedSdr, false, 2s,
                targetFps, true, true);
            harness.start();
            harness.runAtFps(targetFps / 2.0, 12s);
            for (size_t dip = 0; dip < 5; ++dip) {
                harness.runAtFps(targetFps / 3.0, 100ms);
                harness.runAtFps(targetFps / 2.0, 3s);
            }
            require(!harness.diagnostics.contains("rescue-start") &&
                    !harness.scheduler.snapshot().automaticBaseCapSuppressed,
                "brief ordinary scene dips unnecessarily started recovery");
        }
    }

    void testSmoothRescueWatchExpiresWithoutCollapse() {
        Harness harness(90, 2, true, AdaptiveRecoveryPolicy::OrderedSdr,
            false, 2s, 90, true, true);
        harness.start();
        harness.runAtFps(45.0, 12s);
        harness.runAtFps(38.0, 4s);
        harness.runAtFps(30.0, 4s);
        require(!harness.diagnostics.contains("rescue-start") &&
                !harness.scheduler.snapshot().automaticBaseCapSuppressed,
            "expired cadence-exit proof triggered rescue in a later heavy scene");
    }

    void testSmoothRescueFailurePreservesSceneAdaptation() {
        Harness harness(90, 4, true, AdaptiveRecoveryPolicy::OrderedSdr,
            false, 2s, 90, true, true);
        harness.start();
        harness.runAtFps(30.0, 15s);
        require(harness.scheduler.snapshot().stableCadenceLimit == 2,
            "precondition failed: 3x cadence was not accepted");
        // The restored-policy check reserves one second before ordinary
        // adjacent-workload adaptation can resume its existing probe.
        harness.runAtFps(20.0, 6s);
        require(harness.diagnostics.contains("rescue-start") &&
                !harness.scheduler.snapshot().automaticBaseCapSuppressed &&
                harness.scheduler.snapshot().validatedGenerationLimit == 3 &&
                !harness.scheduler.snapshot().rampEvaluationActive,
            "failed rescue blocked ordinary Adaptive workload trial: limit=" +
                std::to_string(harness.scheduler.snapshot().validatedGenerationLimit) +
                " evaluating=" + std::to_string(harness.scheduler.snapshot().rampEvaluationActive));
    }

    void testGeneratedImageRecoveryFallsBackToProvenLoad() {
        Harness harness(110, 3);
        harness.start();
        harness.runAtFps(50.0, 10s);
        const size_t recoveredLimit =
            harness.scheduler.snapshot().validatedGenerationLimit;
        const auto loadBaseline =
            harness.scheduler.generationLoadBaseline();
        require(recoveredLimit == 2 &&
                loadBaseline.fallbackGenerationLimit == 1 &&
                loadBaseline.baseFps > 0.0,
            "precondition failed: higher load had no lower-level baseline");

        harness.scheduler.beginTransportRecovery(harness.now);
        const auto recovery = harness.scheduler.snapshot();
        require(recovery.phase == AdaptiveSchedulerPhase::Stabilizing &&
                recovery.generationLimit == 1 &&
                recovery.validatedGenerationLimit == 1,
            "image pressure did not select the proven lower load for recovery");
        const auto* resume = harness.diagnostics.last(
            "adaptive-recovery-resume-scheduled"
        );
        require(resume &&
                resume->reason == "generated-image-pressure-fallback" &&
                resume->testedLimit == 1 &&
                resume->duration == 5s,
            "image-pressure fallback did not delay the next higher probe");

        harness.runAtFps(50.0, 5s);
        require(harness.scheduler.snapshot().validatedGenerationLimit == 1,
            "image recovery retried the failed higher load before its backoff");
    }

    void testTransportFailureDuringAnyMultiplierProbeRetainsProvenLoad() {
        struct ProbeCase {
            uint32_t targetFps;
            size_t maximumMultiplier;
            double baseFps;
            size_t testedGenerationLimit;
            size_t provenGenerationLimit;
        };
        constexpr std::array cases{
            ProbeCase{120, 3, 50.0, 2, 1},
            ProbeCase{180, 4, 50.0, 3, 2},
            ProbeCase{240, 5, 50.0, 4, 3},
        };

        for (const auto& test : cases) {
            Harness harness(
                test.targetFps,
                test.maximumMultiplier,
                false,
                AdaptiveRecoveryPolicy::OrderedSdr,
                false,
                ls::dynamicCadenceProbeIntervalDuration(
                    ls::GameConfDefaults::dynamicCadenceProbeIntervalSeconds
                ),
                std::nullopt,
                false
            );
            harness.start();

            bool probeStarted = false;
            for (size_t frame = 0; frame < 3000; ++frame) {
                harness.frameAtFps(test.baseFps);
                const auto snapshot = harness.scheduler.snapshot();
                if (snapshot.rampEvaluationActive &&
                        snapshot.generationLimit ==
                            test.testedGenerationLimit &&
                        snapshot.validatedGenerationLimit ==
                            test.provenGenerationLimit) {
                    probeStarted = true;
                    break;
                }
            }
            require(probeStarted,
                "precondition failed: generic higher-multiplier probe did not begin");

            require(harness.scheduler.rejectActiveRampForTransportMiss(
                    harness.now),
                "ordered transport miss did not reject the active multiplier probe");
            const auto recovery = harness.scheduler.snapshot();
            require(recovery.phase == AdaptiveSchedulerPhase::Stabilizing &&
                    recovery.generationLimit ==
                        test.provenGenerationLimit &&
                    recovery.validatedGenerationLimit ==
                        test.provenGenerationLimit,
                "transport failure discarded the last proven multiplier");
            const auto* resume = harness.diagnostics.last(
                "adaptive-recovery-resume-scheduled"
            );
            require(resume &&
                    resume->reason == "generated-image-pressure-fallback" &&
                    resume->testedLimit == test.provenGenerationLimit,
                "transport recovery did not resume its generic proven fallback");
            const auto* backoff = harness.diagnostics.last("ramp-backoff");
            require(backoff &&
                    backoff->testedLimit == test.testedGenerationLimit &&
                    backoff->previousLimit == 1,
                "transport-failed probe did not start bounded retry backoff");
        }
    }

    void testNonblockingAdmissionMissKeepsAcceptedLoad() {
        // A game-minimum pool can normally deliver 30 real + 30 generated
        // frames, yet occasionally have no image ready for a zero-wait poll.
        // Exercise the admission classifier together with real scheduler
        // delivery accounting so one missed output cannot create seconds of
        // native-only plans. Refresh and Smooth Cadence do not qualify a miss.
        for (const bool stableCadence : {false, true}) {
            for (const uint32_t refresh : {60U, 90U, 120U, 144U}) {
                Harness harness(60, 3, stableCadence,
                    AdaptiveRecoveryPolicy::OrderedSdr, false,
                    ls::dynamicCadenceProbeIntervalDuration(
                        ls::GameConfDefaults::dynamicCadenceProbeIntervalSeconds
                    ), refresh, false, true);
                harness.start();
                harness.runAtFps(30.0, 12s);
                require(harness.scheduler.snapshot().validatedGenerationLimit == 1 &&
                        !harness.scheduler.snapshot().rampEvaluationActive,
                    "precondition failed: 30-to-60 FPS load was not qualified");
                require(orderedGeneratedBatchNeedsNonblockingAdmission(3, 3, 1),
                    "game-minimum pool did not use zero-wait admission");
                const size_t backoffs = harness.diagnostics.count("ramp-backoff");
                const size_t recoveries = harness.diagnostics.count(
                    "adaptive-recovery-resume-scheduled");
                for (size_t miss = 0; miss < 3; ++miss) {
                    const auto plan = harness.frameAtFps(30.0, false, false);
                    require(plan.size() == 1,
                        "qualified 30-to-60 FPS plan lost its generated output");
                    require(!adaptiveOrderedDeliveryMissRequiresFallback(
                            true, true, plan.size(), 0,
                            harness.scheduler.snapshot().rampEvaluationActive),
                        "isolated zero-wait miss requested generated-load recovery");
                    harness.scheduler.reportGeneratedFrameDelivery({
                        .requested = plan.size(),
                        .acceptedForPresentation = 0,
                    });
                    require(harness.frameAtFps(30.0).size() == 1 &&
                            harness.scheduler.snapshot().validatedGenerationLimit == 1,
                        "generated output did not resume on the next real frame");
                    harness.runAtFps(30.0, 3s);
                }
                require(harness.diagnostics.count("ramp-backoff") == backoffs &&
                        harness.diagnostics.count(
                            "adaptive-recovery-resume-scheduled") == recoveries,
                    "isolated zero-wait misses started a scheduler cooldown");
            }
        }
    }

    void testQualifiedTransportFailureBacksOffAcceptedLoad() {
        Harness harness(
            100,
            3,
            true,
            AdaptiveRecoveryPolicy::OrderedSdr,
            false,
            ls::dynamicCadenceProbeIntervalDuration(
                ls::GameConfDefaults::dynamicCadenceProbeIntervalSeconds
            ),
            120,
            false
        );
        harness.start();
        harness.runAtFps(50.0, 10s);
        const auto before = harness.scheduler.snapshot();
        const auto baseline = harness.scheduler.generationLoadBaseline();
        require(before.validatedGenerationLimit == 1 &&
                baseline.fallbackGenerationLimit == 0 &&
                baseline.baseFps > 0.0,
            "precondition failed: accepted 2x had no native load baseline");

        harness.scheduler.beginTransportRecovery(harness.now, true);
        const auto recovery = harness.scheduler.snapshot();
        require(recovery.phase == AdaptiveSchedulerPhase::Stabilizing &&
                recovery.generationLimit == 0 &&
                recovery.validatedGenerationLimit == 0,
            "qualified generated-image pressure retried the failed 2x load");
        const auto* backoff = harness.diagnostics.last("ramp-backoff");
        require(backoff && backoff->testedLimit == 1 &&
                backoff->previousLimit == 1,
            "qualified 2x delivery failure did not retain retry backoff");
    }

    void testQualifiedTransportFailureDemotesAcceptedThreeXToTwoX() {
        Harness harness(
            120,
            3,
            false,
            AdaptiveRecoveryPolicy::OrderedSdr,
            false,
            ls::dynamicCadenceProbeIntervalDuration(
                ls::GameConfDefaults::dynamicCadenceProbeIntervalSeconds
            ),
            120,
            false
        );
        harness.start();
        harness.runAtFps(45.0, 10s);

        const auto before = harness.scheduler.snapshot();
        const auto baseline = harness.scheduler.generationLoadBaseline();
        require(before.validatedGenerationLimit == 2 &&
                baseline.fallbackGenerationLimit == 1 &&
                baseline.baseFps > 0.0,
            "precondition failed: accepted 3x had no proven 2x fallback");

        harness.scheduler.beginTransportRecovery(harness.now, true);
        const auto recovery = harness.scheduler.snapshot();
        require(recovery.phase == AdaptiveSchedulerPhase::Stabilizing &&
                recovery.generationLimit == 1 &&
                recovery.validatedGenerationLimit == 1,
            "qualified 3x admission pressure did not fall back to proven 2x");
        const auto* resume = harness.diagnostics.last(
            "adaptive-recovery-resume-scheduled"
        );
        require(resume &&
                resume->reason == "generated-image-pressure-fallback" &&
                resume->testedLimit == 1,
            "qualified 3x admission pressure lost its proven 2x resume level");
        const auto* backoff = harness.diagnostics.last("ramp-backoff");
        require(backoff && backoff->testedLimit == 2 &&
                backoff->previousLimit == 1,
            "qualified 3x admission pressure did not back off the failed load");
    }

    void testDeliveryPressureCannotBridgeToHigherMultiplier() {
        Harness harness(180, 3);
        harness.start();
        for (size_t frame = 0;
                frame < 600 &&
                    !harness.scheduler.snapshot().rampEvaluationActive;
                ++frame) {
            harness.frameAtFps(60.0);
        }
        require(harness.scheduler.snapshot().rampEvaluationActive,
            "precondition failed: initial multiplier probe did not begin");

        const size_t bridgesBefore = harness.diagnostics.count("bridge");
        for (size_t frame = 0; frame < 120; ++frame) {
            const auto plan = harness.frameAtFps(31.0, false, false);
            harness.scheduler.reportGeneratedFrameDelivery({
                .requested = plan.size(),
                .acceptedForPresentation = 0,
            });
            if (!harness.scheduler.snapshot().rampEvaluationActive)
                break;
        }

        const auto after = harness.scheduler.snapshot();
        const auto* result = harness.diagnostics.last("ramp-result");
        require(harness.diagnostics.count("bridge") == bridgesBefore &&
                result && !result->accepted && after.rearmRequired &&
                after.validatedGenerationLimit == 0,
            "failed generated delivery escalated into a higher bridge load");
    }

    void testOrdinaryTransportRecoveryDoesNotRejectMultiplierProbe() {
        struct SchedulerCase {
            bool dynamicCadenceRecovery;
            std::optional<uint32_t> displayRefreshFps;
            std::string_view mode;
        };
        constexpr std::array cases{
            SchedulerCase{false, std::nullopt, "Adaptive"},
            SchedulerCase{true, 120, "Fixed Dynamic Cadence Recovery"},
        };

        for (const auto& test : cases) {
            Harness harness(
                120,
                3,
                false,
                AdaptiveRecoveryPolicy::OrderedSdr,
                test.dynamicCadenceRecovery,
                ls::dynamicCadenceProbeIntervalDuration(
                    ls::GameConfDefaults::dynamicCadenceProbeIntervalSeconds
                ),
                test.displayRefreshFps,
                false
            );
            harness.start();

            bool probeStarted = false;
            for (size_t frame = 0; frame < 3000; ++frame) {
                harness.frameAtFps(50.0);
                const auto snapshot = harness.scheduler.snapshot();
                if (snapshot.rampEvaluationActive &&
                        snapshot.generationLimit == 2 &&
                        snapshot.validatedGenerationLimit == 1) {
                    probeStarted = true;
                    break;
                }
            }
            require(probeStarted,
                std::string(test.mode) +
                    " did not begin the higher-multiplier test precondition");

            const size_t abortedBefore =
                harness.diagnostics.count("probe-aborted");
            const size_t backoffsBefore =
                harness.diagnostics.count("ramp-backoff");
            harness.scheduler.beginTransportRecovery(harness.now, false);
            require(harness.scheduler.snapshot().phase ==
                    AdaptiveSchedulerPhase::Stabilizing,
                std::string(test.mode) +
                    " ordinary timeout did not retain transport stabilization");
            require(harness.diagnostics.count("probe-aborted") ==
                        abortedBefore + 1 &&
                    harness.diagnostics.count("ramp-backoff") ==
                        backoffsBefore,
                std::string(test.mode) +
                    " ordinary timeout did not retain the 3.3 interrupted-probe semantics");
        }
    }

    void testTransportProbeBackoffSurvivesCadenceRefresh() {
        Harness harness(
            120,
            3,
            false,
            AdaptiveRecoveryPolicy::OrderedSdr,
            false,
            ls::dynamicCadenceProbeIntervalDuration(
                ls::GameConfDefaults::dynamicCadenceProbeIntervalSeconds
            ),
            std::nullopt,
            false
        );
        harness.start();

        const auto reachThreeXProbe = [&] {
            for (size_t frame = 0; frame < 1200; ++frame) {
                harness.frameAtFps(50.0);
                const auto snapshot = harness.scheduler.snapshot();
                if (snapshot.rampEvaluationActive &&
                        snapshot.generationLimit == 2 &&
                        snapshot.validatedGenerationLimit == 1) {
                    return true;
                }
            }
            return false;
        };

        require(reachThreeXProbe(),
            "precondition failed: first 3x probe did not begin");
        harness.scheduler.beginTransportRecovery(harness.now, true);
        const auto* firstBackoff = harness.diagnostics.last("ramp-backoff");
        require(firstBackoff && firstBackoff->previousLimit == 1,
            "first transport failure did not record its retry history");

        harness.frame(200ms);
        require(harness.diagnostics.contains("cadence-refresh") &&
                harness.scheduler.snapshot().validatedGenerationLimit == 1,
            "cadence refresh discarded the proven 2x fallback");

        require(reachThreeXProbe(),
            "3x probe did not retry after its bounded cooldown");
        harness.scheduler.beginTransportRecovery(harness.now, true);
        const auto recovery = harness.scheduler.snapshot();
        const auto* secondBackoff = harness.diagnostics.last("ramp-backoff");
        require(recovery.validatedGenerationLimit == 1 &&
                secondBackoff && secondBackoff->testedLimit == 2 &&
                secondBackoff->previousLimit == 2,
            "cadence refresh reset transport-failure backoff escalation");
    }

    void testHigherLoadBackoffSurvivesFocusReturns() {
        for (const bool smooth : {false, true}) {
            for (const bool confirmedReturn : {false, true}) {
                Harness harness(
                    120, 3, smooth, AdaptiveRecoveryPolicy::OrderedSdr,
                    false, 2s, 120, false
                );
                harness.start();
                const auto reachThreeXProbe = [&] {
                    for (size_t frame = 0; frame < 4500; ++frame) {
                        harness.deliveredFrameAtFps(50.0);
                        const auto snapshot = harness.scheduler.snapshot();
                        if (snapshot.rampEvaluationActive &&
                                snapshot.generationLimit == 2 &&
                                snapshot.validatedGenerationLimit == 1)
                            return true;
                    }
                    return false;
                };
                const auto rejectThreeXProbe = [&] {
                    require(reachThreeXProbe(),
                        "precondition failed: 3x workload was never tested");
                    while (harness.scheduler.snapshot().rampEvaluationActive)
                        harness.deliveredFrameAtFps(30.0);
                    require(harness.scheduler.validatedGenerationLimit() == 1,
                        "costly 3x trial discarded the proven 2x fallback");
                };

                rejectThreeXProbe();
                // A menu must not erase the first failure, even after its
                // deadline has elapsed. The next rejection still escalates.
                harness.now += 8s;
                harness.scheduler.resumeAfterExternalInterruption(
                    harness.now, confirmedReturn
                );
                rejectThreeXProbe();
                const auto* second = harness.diagnostics.last("ramp-backoff");
                require(second && second->previousLimit == 2 &&
                        second->duration == 15s,
                    "focus return reset higher-load failure escalation");
                const auto rejectedAt = harness.now;
                const auto ramps = harness.diagnostics.count("ramp");

                // Repeated short menus neither shorten the original failed
                // trial's deadline nor invent another failure.
                for (size_t visit = 0; visit < 2; ++visit) {
                    harness.now += 500ms;
                    harness.scheduler.resumeAfterExternalInterruption(
                        harness.now, confirmedReturn
                    );
                    require(harness.scheduler.historyWarmupRemaining() == 3,
                        "backoff preservation bypassed fresh menu history");
                    for (size_t frame = 0; frame < 300; ++frame) {
                        harness.deliveredFrameAtFps(50.0);
                        require(harness.scheduler.validatedGenerationLimit() == 1 &&
                                harness.diagnostics.count("ramp") == ramps,
                            "menu return retried 3x before its failed-load deadline");
                    }
                }
                require(harness.now - rejectedAt < 15s,
                    "test failed to exercise an unexpired retry deadline");
                rejectThreeXProbe();
                const auto* third = harness.diagnostics.last("ramp-backoff");
                require(third && third->previousLimit == 3 &&
                        third->duration == 30s,
                    "repeated menu returns erased or inflated failure history");

                // A long menu cannot permanently suppress useful work in a
                // changed scene. The next trial can succeed after fresh proof.
                harness.now += 120s;
                harness.scheduler.resumeAfterExternalInterruption(
                    harness.now, confirmedReturn
                );
                require(reachThreeXProbe(),
                    "expired menu backoff prevented a bounded retry");
                while (harness.scheduler.snapshot().rampEvaluationActive)
                    harness.deliveredFrameAtFps(43.0);
                require(harness.scheduler.validatedGenerationLimit() == 2,
                    "preserved backoff rejected a newly beneficial 3x workload");
            }
        }
    }

    void testHigherLoadRetryAfterPacingChange() {
        for (const bool smooth : {false, true}) {
            for (const bool menuReturn : {false, true}) {
                for (const size_t multiplier : {3u, 4u, 5u}) {
                    Harness harness(120, multiplier, smooth, AdaptiveRecoveryPolicy::OrderedSdr,
                        false, 2s, 120, false);
                    harness.start();
                    const size_t testedLimit = multiplier - 1;
                    const double lowerFps = 100.0 / static_cast<double>(testedLimit);
                    harness.scheduler.restoreGenerationLimit(harness.now,
                        testedLimit - 1, "test-qualified-lower-load");
                    const auto reachProbe = [&] {
                        for (size_t frame = 0; frame < 4500; ++frame) {
                            harness.deliveredFrameAtFps(lowerFps);
                            const auto snapshot = harness.scheduler.snapshot();
                            if (snapshot.rampEvaluationActive && snapshot.generationLimit == testedLimit)
                                return;
                        }
                        require(false, "higher-load retry never reached its trial");
                    };
                    for (size_t failure = 0; failure < 3; ++failure) {
                        reachProbe();
                        require(!harness.scheduler.refreshHigherLoadRetry(harness.now),
                            "pacing change altered an active workload trial");
                        while (harness.scheduler.snapshot().rampEvaluationActive)
                            harness.deliveredFrameAtFps(lowerFps * 0.6);
                    }
                    require(harness.diagnostics.last("ramp-backoff")->duration == 30s,
                        "precondition failed: repeated rejections did not reach 30 seconds");
                    const auto before = harness.scheduler.snapshot();
                    const auto warmup = harness.scheduler.historyWarmupRemaining();
                    const auto ramps = harness.diagnostics.count("ramp");
                    require(harness.scheduler.refreshHigherLoadRetry(harness.now),
                        "confirmed pacing change retained the stale higher-load cooldown");
                    const auto after = harness.scheduler.snapshot();
                    require(after.generationLimit == before.generationLimit &&
                            after.validatedGenerationLimit == before.validatedGenerationLimit &&
                            after.smoothedBaseFps == before.smoothedBaseFps &&
                            harness.scheduler.historyWarmupRemaining() == warmup &&
                            harness.diagnostics.count("ramp") == ramps,
                        "pacing change reset cadence/history or promoted a workload");
                    require(!harness.scheduler.refreshHigherLoadRetry(harness.now),
                        "repeated notification restarted the refreshed retry");
                    if (menuReturn)
                        harness.scheduler.resumeAfterExternalInterruption(harness.now, true);
                    const auto changedAt = harness.now;
                    while (harness.now - changedAt < 5s) {
                        harness.deliveredFrameAtFps(lowerFps);
                        require(harness.diagnostics.count("ramp") == ramps,
                            "pacing change skipped the ordinary higher-probe settling delay");
                    }
                    // No delivery cannot qualify a fresh trial, even after the delay.
                    for (size_t frame = 0; frame < static_cast<size_t>(lowerFps * 3.0); ++frame) {
                        harness.deliveredFrameAtFps(lowerFps, std::nullopt);
                        require(harness.diagnostics.count("ramp") == ramps,
                            "pacing change reused old lower-load delivery evidence");
                    }
                    reachProbe();
                    require(harness.now - changedAt < 12s,
                        "pacing change kept the old 30-second retry deadline");
                    while (harness.scheduler.snapshot().rampEvaluationActive)
                        harness.deliveredFrameAtFps(120.0 / static_cast<double>(multiplier));
                    require(harness.scheduler.validatedGenerationLimit() == testedLimit,
                        "fresh beneficial higher trial could not qualify after pacing change");
                    require(!harness.scheduler.refreshHigherLoadRetry(harness.now),
                        "pacing change disturbed a qualified workload without a failed retry");
                }
            }
        }
    }


    void testDeterministicReplay() {
        Harness first(120, 4, true);
        Harness second(120, 4, true);
        first.start();
        second.start();

        const std::vector<std::chrono::nanoseconds> trace{
            17ms, 16ms, 17ms, 16ms, 50ms, 16ms, 17ms, 200ms,
            16ms, 16ms, 17ms, 1ms, 1ms, 16ms, 33ms, 34ms,
        };
        for (size_t replay = 0; replay < 40; ++replay) {
            for (const auto interval : trace) {
                const auto firstPlan = first.frame(interval);
                const auto secondPlan = second.frame(interval);
                require(firstPlan == secondPlan,
                    "identical cadence trace produced different plans");
                requireValidTimestamps(firstPlan, 3);
            }
        }

        const auto firstSnapshot = first.scheduler.snapshot();
        const auto secondSnapshot = second.scheduler.snapshot();
        require(firstSnapshot.phase == secondSnapshot.phase &&
                firstSnapshot.generationLimit ==
                    secondSnapshot.generationLimit &&
                firstSnapshot.validatedGenerationLimit ==
                    secondSnapshot.validatedGenerationLimit &&
                firstSnapshot.historyWarmupRemaining ==
                    secondSnapshot.historyWarmupRemaining,
            "identical cadence trace produced different final state");
    }

    struct TestCase {
        std::string_view name;
        void (*run)();
    };
}

int main() {
    const std::vector<TestCase> tests{
        {"startup warm-up is explicit", testStartupWarmupIsExplicit},
        {"swapchain recreation settles promptly", testSwapchainRecreationUsesBoundedSettlingGuard},
        {"transport recovery invalidates stable cadence", testTransportRecoveryInvalidatesStableCadence},
        {"explicit acquire timeout preserves validated cadence", testExplicitAcquireTimeoutPreservesValidatedCadence},
        {"busy warm-up notification is idempotent", testBusyWarmupNotificationIsIdempotent},
        {"transient busy frame does not rearm warm-up", testTransientBusyFrameDoesNotRearmCompletedWarmup},
        {"invalid configuration is rejected", testInvalidConfigurationIsRejectedAtBoundary},
        {"generated delivery window contract", testGeneratedDeliveryWindowContract},
        {"replacement backend stabilization is bounded", testReplacementBackendStabilizationIsBounded},
        {"scheduler characterization corpus", testCharacterizationTraceCorpus},
        {"60 to 120 settles at 2x", testSteadySixtyRampsToTwoXFor120Target},
        {"fractional target clock follows raw intervals", testFractionalTargetClockAssignsWorkToLongIntervals},
        {"fractional target clock starts center aligned", testFractionalTargetClockStartsCenterAligned},
        {"ordered fractional clock does not defer FIFO work", testOrderedFractionalClockDoesNotDeferFifoWork},
        {"fractional target clock ignores marginal placement", testFractionalTargetClockIgnoresMarginalPlacementBenefit},
        {"target clock covers steady and noisy cadence matrix", testTargetClockCoversSteadyAndNoisyCadenceMatrix},
        {"Automatic preserves native presentation above target", testAdaptiveNativePresentationAboveTarget},
        {"Fractional Automatic requires opt-in native probes", testFractionalAutomaticDoesNotProbeWithoutRecovery},
        {"target-native qualification is Fractional only", testTargetNativeQualificationIsFractionalOnly},
        {"near-target native preference covers steady sweep", testNearTargetNativePreferenceCoversSteadySweep},
        {"near-target native preference scales across targets", testNearTargetNativePreferenceScalesAcrossTargets},
        {"near-target native preference tolerates boundary measurement noise", testNearTargetNativePreferenceToleratesBoundaryMeasurementNoise},
        {"near-target native preference covers noisy sweep", testNearTargetNativePreferenceCoversNoisySweep},
        {"near-target native preference has hysteresis", testNearTargetNativePreferenceHasHysteresisAndNoChatter},
        {"near-target native preference resumes across noisy high excursions", testNearTargetNativePreferenceResumesAcrossNoisyHighExcursions},
        {"near-target native preference bypasses marginal ramp", testNearTargetNativePreferenceBypassesOnlyMarginalRamp},
        {"near-target native preference preserves Fixed recovery", testNearTargetNativePreferenceDoesNotChangeFixedRecoveryPolicy},
        {"target clock handles multi-level fractional cadence", testTargetClockHandlesMultiLevelFractionalCadence},
        {"target clock preserves noisy integer ceiling", testTargetClockPreservesNoisyIntegerCeiling},
        {"target clock recovers noisy 3x ceiling after throttle", testTargetClockRecoversNoisyThreeXCeilingAfterThrottle},
        {"deferred output repayment preserves pacing benefit", testDeferredOutputRepaymentPreservesPacingBenefit},
        {"target clock reset clears deferred output", testTargetClockResetClearsDeferredOutput},
        {"raw placement cannot mint generated work", testRawPlacementCannotMintGeneratedWork},
        {"target clock discards unreachable ceiling debt", testTargetClockDiscardsUnreachableCeilingDebt},
        {"pacing diagnostics restart after policy gap", testPacingDiagnosticsRestartAfterPolicyGap},
        {"isolated delivery miss keeps ramp", testIsolatedGeneratedFrameMissDoesNotRejectRamp},
        {"persistent delivery loss rejects ramp", testPersistentGeneratedFrameMissesRejectRamp},
        {"escalation closes 95-percent target gap", testEscalationClosesNinetyFivePercentTargetGap},
        {"near-target Adaptive rung does not probe higher multiplier", testNearTargetRungDoesNotProbeHigherMultiplier},
        {"multiplier ceiling deficit is reported once", testMultiplierCeilingDeficitIsReportedOnce},
        {"4x timestamps remain evenly spaced", testFourXPlanUsesEvenInterpolationTimestamps},
        {"5x timestamps remain evenly spaced", testFiveXPlanUsesEvenInterpolationTimestamps},
        {"above-target cadence remains real-only", testSchedulerCannotReduceAboveTargetCadence},
        {"acquire backoff freezes policy", testAcquireBackoffDoesNotAdvancePolicy},
        {"validated 2x uses common cadence-stall policy", testValidatedTwoXUsesCommonCadenceStallPolicy},
        {"HDR long hitch uses conservative recovery", testHdrLongHitchUsesConservativeDiscontinuityRecovery},
        {"healthy cadence restores validated level", testRecoveredCadenceRestoresValidatedLevel},
        {"discontinuity timeout restarts from zero", testDiscontinuityRecoveryTimesOutToFreshRamp},
        {"gameplay cadence drop rebases", testSustainedCadenceDropRebasesWithoutMenuRecovery},
        {"SDR long hitch keeps validated level", testSdrLongHitchRefreshesHistoryWithoutDroppingValidatedLevel},
        {"unconfirmed cadence drop retains slow samples", testUnconfirmedCadenceDropRetainsSlowSamples},
        {"bursty cadence retains both interval populations", testBurstySourceCadenceDoesNotLockOntoFastSamples},
        {"SDR cadence drop uses short refresh", testSdrCadenceDropRefreshesHistoryWithoutFullStabilization},
        {"history warm-up retains the present-start clock", testHistoryWarmupUsesPresentStartDespitePrivateWork},
        {"SDR hard stall avoids refresh loop", testSdrSustainedHardStallDoesNotRestartHistoryRefresh},
        {"fast-present burst preserves cadence", testImpossibleFastBurstDoesNotCorruptCadence},
        {"harmful first probe enters rearm", testRejectedFirstProbeEntersBoundedRearm},
        {"first-probe backoff survives focus returns", testRejectedFirstProbeBackoffSurvivesFocusReturns},
        {"interrupted probe rearms promptly", testInterruptedProbeRearmsWithoutFailurePenalty},
        {"rejected first probe rebases stable native deficit", testRejectedFirstProbeRebasesAfterPersistentNativeDeficit},
        {"counterproductive first step cannot escalate", testCounterproductiveFirstStepNeverEscalates},
        {"rejected higher level backs off", testRejectedHigherLevelRetainsProvenLoadAndBacksOff},
        {"ordered SDR rejects unpaid below-target 3x", testOrderedSdrRejectsUnpaidHigherLevelBelowTarget},
        {"Adaptive higher load needs meaningful net gain", testAdaptiveHigherLoadNeedsMeaningfulNetGain},
        {"higher promotion prefers measured target", testHigherPromotionPrefersMeasuredTarget},
        {"target preference needs whole-trial delivery", testTargetPreferenceRequiresWholeTrialDelivery},
        {"confirmed focus return has bounded fast resume", testConfirmedFocusReturnBoundedFastResume},
        {"menu return holds target-proven lower load", testMenuReturnHoldsTargetProvenLowerMultiplier},
        {"menu return requalifies changed scene across modes", testMenuReturnRequalifiesChangedSceneAcrossModes},
        {"menu return does not invent target proof", testMenuReturnDoesNotInventTargetProof},
        {"lower-load requalification coexists with native probes", testLowerLoadRequalificationCoexistsWithNativeProbes},
        {"lower-load requalification needs continuous evidence", testLowerLoadRequalificationNeedsContinuousEvidence},
        {"higher promotion waits for settled demand across modes", testHigherPromotionWaitsForSettledDemandAcrossModes},
        {"higher promotion needs continuous delivered evidence", testHigherPromotionNeedsContinuousDeliveredEvidence},
        {"ordinary promotion coexists with native probes", testOrdinaryPromotionCoexistsWithNativeProbes},
        {"higher promotion retains strongest lower-load baseline", testHigherPromotionUsesStrongestQualifiedLowerLoad},
        {"failed higher load requalifies changed scene", testFailedHigherLoadRequalifiesChangedScene},
        {"focus return retains conservative fallbacks", testFocusReturnRetainsConservativeFallbacks},
        {"fast focus return retains history and transport settling", testFastFocusReturnCannotBypassHistoryOrTransportSettling},
        {"confirmed focus return retains proven generation", testConfirmedFocusReturnRetainsProvenLevel},
        {"Smooth Cadence settles near integer demand", testSmoothCadenceSettlesNearIntegerDemand},
        {"Smooth Cadence converges Fractional 2x on matching refresh", testSmoothCadenceConvergesFractionalTwoXOnMatchingRefresh},
        {"Smooth Cadence rejects unproven 2x convergence", testSmoothCadenceRejectsTwoXThatDoesNotConverge},
        {"Smooth Cadence convergence requires matching ordered FIFO", testSmoothCadenceConvergenceRequiresTargetMatchedOrderedFifo},
        {"VRR FIFO uses only a validated higher rung", testVrrFullFifoUsesOnlyValidatedHigherRung},
        {"integer pacing prefers delivered target at 3x through 5x", testIntegerPacingPrefersDeliveredTargetAcrossMultipliers},
        {"paced load needs fresh continuous evidence", testPacedLoadRequiresFreshContinuousEvidence},
        {"delayed integer pacing refreshes its adjacent baseline", testDelayedIntegerPacingRefreshesAdjacentBaseline},
        {"fixed-refresh handoff uses sustained scheduler exit", testFixedRefreshHandoffUsesSustainedSchedulerExit},
        {"planned pacing return preserves accepted lifetime", testPlannedPacingReturnKeepsValidatedLifetime},
        {"planned pacing return invalidates on real changes", testPlannedPacingReturnInvalidatesOnRealChanges},
        {"pacing probes survive bounded turnover bursts", testPacingProbeSurvivesBoundedTurnoverBurst},
        {"pacing probe turnover preserves invalidation", testPacingProbeTurnoverPreservesInvalidation},
        {"pacing turnover bursts cannot extend settling", testPacingProbeTurnoverBurstCannotExtendSettling},
        {"fresh pacing probes discard interrupted lower evidence", testFreshPacingProbeDiscardsInterruptedLowerEvidence},
        {"handoff at baseline expiry starts fresh comparison", testHandoffAtBaselineExpiryStartsFreshComparison},
        {"delayed cap return starts another fresh comparison", testDelayedCapReturnStartsAnotherFreshComparison},
        {"fresh pacing probe keeps cadence qualification separate", testFreshPacingProbeKeepsCadenceQualificationSeparate},
        {"delayed Fractional handoff uses fresh probe", testDelayedFractionalHandoffUsesFreshProbe},
        {"accepted Fractional cadence checks VRR pacing cost", testAcceptedFractionalCadenceChecksVrrPacingCost},
        {"unreachable integer pacing does not delay higher loads", testUnreachableIntegerPacingDoesNotDelayHigherWorkloads},
        {"Headroom release rechecks Fractional generated load", testHeadroomReleaseRechecksFractionalGeneratedLoad},
        {"Headroom release handles low and invalid source evidence", testHeadroomReleaseHandlesLowAndInvalidSourceEvidence},
        {"Headroom recovery expires with source history", testHeadroomRecoveryDoesNotSurviveHistoryReset},
        {"Headroom cap defers impossible downshifts", testHeadroomCapDefersImpossibleEfficiencyProbe},
        {"Headroom cap cancels impossible active downshifts", testHeadroomCapCancelsImpossibleActiveEfficiencyProbe},
        {"Headroom cap permits reachable downshifts", testHeadroomCapAllowsReachableEfficiencyProbe},
        {"Smooth Cadence accepts target-preserving downshift", testSmoothCadenceDownshiftsWhenLowerLoadPreservesTarget},
        {"Smooth Cadence downshift requires sustained target", testSmoothCadenceDownshiftRequiresSustainedTarget},
        {"Smooth Cadence downshift requires complete delivery", testSmoothCadenceDownshiftNeedsCompleteSampleDelivery},
        {"Smooth Cadence downshift rejects endpoint-only recovery", testSmoothCadenceDownshiftCannotUseRecoveredEndpointAlone},
        {"Smooth Cadence lets promising downshift recovery settle", testSmoothCadenceDownshiftAllowsPromisingRecoveryToSettle},
        {"Smooth Cadence rejects insufficient downshift", testSmoothCadenceRejectsInsufficientDownshiftAndBacksOff},
        {"Smooth Cadence downshift backoff survives repeated dips", testSmoothCadenceDownshiftBackoffSurvivesRepeatedDips},
        {"Smooth Cadence downshift backoff survives interruptions", testSmoothCadenceDownshiftBackoffSurvivesInterruptions},
        {"Smooth Cadence downshift backoff is scoped to multiplier", testSmoothCadenceDownshiftBackoffIsScopedToMultiplier},
        {"Smooth Cadence downshift backoff allows proven source recovery", testSmoothCadenceDownshiftBackoffAllowsProvenSourceRecovery},
        {"Smooth Cadence moderate downshift deficit backs off", testSmoothCadenceModerateDownshiftDeficitBacksOffTwoMinutes},
        {"Smooth Cadence downshift rejects delivery pressure", testSmoothCadenceDownshiftRejectsDeliveryPressure},
        {"Smooth Cadence downshift pauses during acquire backoff", testSmoothCadenceDownshiftPausesDuringAcquireBackoff},
        {"Smooth Cadence downshift is ordered-SDR only", testSmoothCadenceDownshiftProbeIsOrderedSdrOnly},
        {"Smooth Cadence retains validated 2x through mild dip", testSmoothCadenceRetainsValidatedTwoXThroughMildDip},
        {"Smooth Cadence exits below retention range", testSmoothCadenceExitsBelowRetentionRange},
        {"persistent loss rejects Smooth Cadence", testPersistentDeliveryLossRejectsSmoothCadenceProbe},
        {"Smooth Cadence exits after native recovery", testSmoothCadenceReturnsToTargetAfterBaseRecovery},
        {"Fractional refresh guard survives cutscene/gameplay transitions", testFractionalRefreshGuardAcrossCutsceneGameplayTransitions},
        {"dynamic cadence recovers a self-hidden native rate", testDynamicCadenceRecoversSelfHiddenNativeRateIncrease},
        {"dynamic cadence discards interrupted native samples", testDynamicCadenceProbeCannotSpanGeneratedAcquireBackoff},
        {"dynamic cadence drains only previously queued output", testDynamicCadenceDrainsPreviouslyQueuedOutput},
        {"dynamic cadence finishes drain across untrusted bursts", testDynamicCadenceBurstCanFinishQueuedDrain},
        {"dynamic cadence queued drain rejects true low rates", testDynamicCadenceQueuedDrainRejectsTrueLowRate},
        {"dynamic cadence tolerates native qualification turnover", testDynamicCadenceQualificationSurvivesQueueTurnover},
        {"dynamic cadence qualifies across the target boundary", testDynamicCadenceQualifiesAcrossTargetBoundary},
        {"dynamic cadence aborts unqualified near-target rise", testDynamicCadenceAbortsUnqualifiedNearTargetRise},
        {"dynamic cadence qualifies near-target without generated feedback", testDynamicCadenceQualifiesNearTargetWithoutGeneratedFeedback},
        {"dynamic cadence bounds self-hidden recovery latency", testDynamicCadenceBoundsSelfHiddenRecoveryLatency},
        {"dynamic cadence probe interval updates live", testDynamicCadenceProbeIntervalUpdatesLive},
        {"dynamic cadence rejects true 30 FPS", testDynamicCadenceProbeRejectsTrueThirtyFpsCadence},
        {"dynamic cadence remains opt-in and SDR-only", testDynamicCadenceRecoveryIsOptInAndSdrOnly},
        {"Smooth Cadence resists oscillating-load chatter", testSmoothCadenceDoesNotChatterOnOscillatingLoad},
        {"validated workloads ignore ordinary gameplay slowdown", testValidatedWorkloadIgnoresOrdinaryGameplaySlowdown},
        {"common workload rule covers 2x through 5x", testCommonWorkloadRuleCoversTwoXThroughFiveX},
        {"failed higher load cannot ratchet to degraded baseline", testFailedHigherLoadCannotRatchetToDegradedBaseline},
        {"Smooth Cadence collapse measures real-only", testSmoothCadenceCollapseUsesRealOnlyMeasurement},
        {"Ordered SDR rescue bounds automatic-cap release", testOrderedSdrSmoothCollapseRestoresAutomaticCap},
        {"Smooth rescue restores cap regardless of headroom", testSmoothRescueRestoresCapRegardlessOfNativeHeadroom},
        {"Smooth rescue verifies generated load", testSmoothRescueVerifiesRestoredGeneratedLoad},
        {"Smooth rescue verifies full-target capped recovery", testSmoothRescueRecoversAtTargetWithConfiguredCap},
        {"Smooth rescue bounds overrides across scene outcomes", testSmoothRescueCannotLeaveCapDisabledAfterSceneRecovery},
        {"Smooth rescue verifies generated delivery", testSmoothRescueRequiresGeneratedDeliveryForVerification},
        {"Smooth rescue restores cap across repeated collapses", testSmoothRescueRestoresCapAcrossRepeatedCollapses},
        {"Smooth rescue catches post-exit collapse", testSmoothRescueHandlesCollapseAfterStableExit},
        {"Smooth rescue rolls back interruption", testSmoothRescueRollsBackInterruptedMeasurement},
        {"Smooth rescue rejects brief native headroom", testSmoothRescueRejectsBriefNativeHeadroom},
        {"Smooth rescue ignores brief scene dips", testSmoothRescueIgnoresBriefSceneDips},
        {"Smooth rescue watch expires", testSmoothRescueWatchExpiresWithoutCollapse},
        {"Smooth rescue preserves scene adaptation", testSmoothRescueFailurePreservesSceneAdaptation},
        {"image recovery uses proven lower load", testGeneratedImageRecoveryFallsBackToProvenLoad},
        {"transport-failed multiplier probes keep proven load", testTransportFailureDuringAnyMultiplierProbeRetainsProvenLoad},
        {"zero-wait admission misses keep accepted load", testNonblockingAdmissionMissKeepsAcceptedLoad},
        {"qualified transport failure backs off accepted load", testQualifiedTransportFailureBacksOffAcceptedLoad},
        {"qualified transport failure demotes accepted 3x to 2x", testQualifiedTransportFailureDemotesAcceptedThreeXToTwoX},
        {"delivery pressure cannot bridge upward", testDeliveryPressureCannotBridgeToHigherMultiplier},
        {"ordinary transport recovery keeps 3.3 multiplier semantics", testOrdinaryTransportRecoveryDoesNotRejectMultiplierProbe},
        {"transport probe backoff survives cadence refresh", testTransportProbeBackoffSurvivesCadenceRefresh},
        {"higher-load backoff survives focus returns", testHigherLoadBackoffSurvivesFocusReturns},
        {"higher-load retry refreshes after pacing change", testHigherLoadRetryAfterPacingChange},
        {"cadence replay is deterministic", testDeterministicReplay},
    };

    size_t failures = 0;
    for (const auto& test : tests) {
        try {
            test.run();
            std::cout << "PASS: " << test.name << '\n';
        } catch (const TestFailure& failure) {
            failures++;
            std::cerr << "FAIL: " << test.name << ": "
                      << failure.message << '\n';
        } catch (const std::exception& error) {
            failures++;
            std::cerr << "FAIL: " << test.name
                      << ": unexpected exception: " << error.what() << '\n';
        }
    }

    if (failures) {
        std::cerr << failures << " adaptive scheduler test(s) failed\n";
        return EXIT_FAILURE;
    }

    std::cout << tests.size() << " adaptive scheduler tests passed\n";
    return EXIT_SUCCESS;
}
