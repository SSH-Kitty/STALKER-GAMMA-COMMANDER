#!/usr/bin/env bash
# End-to-end contract for MAKO CLI language selection and command dispatch.
set -euo pipefail

cli=${1:?mako-cli path is required}
missing_config=/tmp/mako-cli-i18n-missing-config.toml

fail() {
    printf 'mako-cli i18n contract failed: %s\n' "$*" >&2
    exit 1
}

run_failure() {
    set +e
    command_output="$("$@" 2>&1)"
    command_status=$?
    set -e
    [[ $command_status -eq 1 ]] || fail "unexpected status $command_status: $command_output"
}

run_failure "$cli" validate --config "$missing_config"
[[ $command_output == 'Validation failed: configuration file does not exist' ]] ||
    fail "English validation output changed: $command_output"

run_failure "$cli" --lang pt-BR validate --config "$missing_config"
[[ $command_output == 'Falha na validação: arquivo de configuração não existe' ]] ||
    fail "Brazilian Portuguese validation output changed: $command_output"

run_failure "$cli" --lang=pt-PT validate --config "$missing_config"
[[ $command_output == 'Falha na validação: ficheiro de configuração não existe' ]] ||
    fail "European Portuguese validation output changed: $command_output"

run_failure "$cli" --lang es validate --config "$missing_config"
[[ $command_output == 'Falló la validación: el archivo de configuración no existe' ]] ||
    fail "Spanish validation output changed: $command_output"

run_failure "$cli" --lang invalid validate
[[ $command_output == *"unsupported language 'invalid'"* ]] ||
    fail "invalid language was not rejected: $command_output"

run_failure "$cli" --lang
[[ $command_output == *'--lang requires en, pt-BR, pt-PT, or es'* ]] ||
    fail "missing language value was not rejected: $command_output"

help_output="$("$cli" --help 2>&1)" || fail "--help failed: $help_output"
[[ $help_output == *'quality-regression'* ]] ||
    fail "MAKO quality-regression command disappeared from help"
[[ $help_output == *'inspect-dll'* ]] ||
    fail "MAKO inspect-dll command disappeared from help"
[[ $help_output == *'spatial-quality-regression'* ]] ||
    fail "MAKO spatial-quality-regression command disappeared from help"
[[ $help_output == *'combined-quality-regression'* ]] ||
    fail "MAKO combined-quality-regression command disappeared from help"
[[ $help_output == *'spatial-profile'* ]] ||
    fail "MAKO spatial-profile command disappeared from help"
[[ $help_output == *'synchronization-validation-canary'* ]] ||
    fail "MAKO synchronization-validation-canary command disappeared from help"
[[ $help_output == *'--width <INT>'* && $help_output == *'--height <INT>'* ]] ||
    fail "MAKO exact-resolution options disappeared from help"

run_failure "$cli" quality-regression --scene unknown-scene
[[ $command_output == 'error: unknown quality scene: unknown-scene' ]] ||
    fail "unknown procedural scene did not fail closed: $command_output"

run_failure "$cli" inspect-dll --dll /tmp/mako-cli-missing-lossless.dll
[[ $command_output == *'MAKO model DLL inspection failed: failed to stat dll file'* ]] ||
    fail "missing DLL inspection did not fail cleanly: $command_output"

for method in ls1 ls1-performance; do
    for sharpness in 0 0.25 0.5 0.75 1; do
        run_failure "$cli" inspect-dll --dll /tmp/mako-cli-missing-lossless.dll \
            --ls1 "$method" --sharpness "$sharpness"
        [[ $command_output == *'{"schema_version":1,"compatible":false}'* ]] ||
            fail "selected LS1 inspection did not emit its status contract: $command_output"
    done
done
run_failure "$cli" inspect-dll --dll /tmp/mako-cli-missing-lossless.dll --ls1 unrelated
[[ $command_output == 'error: --ls1 requires ls1 or ls1-performance' ]] ||
    fail "unknown LS1 method was not rejected: $command_output"
run_failure "$cli" inspect-dll --dll /tmp/mako-cli-missing-lossless.dll --ls1 ls1 --sharpness nan
[[ $command_output == *'requires a valid finite number'* ]] ||
    fail "non-finite LS1 sharpness was not rejected: $command_output"

run_failure "$cli" spatial-quality-regression --method unknown-method
[[ $command_output == 'error: unknown spatial quality method: unknown-method' ]] ||
    fail "unknown spatial method did not fail closed: $command_output"

run_failure "$cli" spatial-quality-regression --method native --factor 1.0
[[ $command_output == 'error: spatial quality factor must be above 1.0 and at most 2.0' ]] ||
    fail "Native scaling method parsing regressed: $command_output"

run_failure "$cli" spatial-profile --method unknown-method
[[ $command_output == 'error: unknown spatial profile method: unknown-method' ]] ||
    fail "unknown spatial profile method did not fail closed: $command_output"

run_failure "$cli" spatial-profile --method native --width +1280 --factor +1.0
[[ $command_output == 'error: spatial profile factor must be above 1.0 and at most 2.0' ]] ||
    fail "Native scaling or leading-plus parsing regressed: $command_output"

run_failure "$cli" spatial-profile --method mako --width nope
[[ $command_output == 'error: --width requires a valid finite number: nope' ]] ||
    fail "invalid spatial profile width did not fail cleanly: $command_output"

run_failure "$cli" spatial-profile --method mako --factor nan
[[ $command_output == 'error: --factor requires a valid finite number: nan' ]] ||
    fail "non-finite spatial profile factor did not fail cleanly: $command_output"

run_failure "$cli" combined-quality-regression --method unknown-method
[[ $command_output == 'error: unknown combined quality spatial method: unknown-method' ]] ||
    fail "unknown combined spatial method did not fail closed: $command_output"

run_failure "$cli" combined-quality-regression --method native --factor 1.0
[[ $command_output == 'error: combined quality factor must be above 1.0 and at most 2.0' ]] ||
    fail "Native combined-scaling method parsing regressed: $command_output"

printf 'mako-cli i18n contract: PASS\n'
