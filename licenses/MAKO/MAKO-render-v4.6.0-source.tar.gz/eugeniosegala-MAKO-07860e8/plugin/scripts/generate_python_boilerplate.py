#!/usr/bin/env python3
"""
Generate Python boilerplate from shared_config.py

This script generates repetitive Python code patterns from the canonical schema,
reducing manual maintenance when adding/removing configuration fields.
"""

import sys
from pathlib import Path

# Add project root to path to import shared_config
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from shared_config import CONFIG_SCHEMA_DEF, ConfigFieldType
from py_modules.mako_plugin.constants import (
    EXTERNAL_VULKAN_LAYER_ENV,
    HDR_EXPOSURE_DISABLE_ENV,
    MAKO_LAYER_DISABLE_ENV,
    SDL_AUDIO_DRIVER_ALSA_VALUE,
    SDL_AUDIO_DRIVER_ENV,
    STEAM_DECK_MODE_ENV,
    WINE_DLL_OVERRIDES_ENV,
    ZINK_DRIVER_VALUE,
    ZINK_GALLIUM_DRIVER_ENV,
    ZINK_GLX_VENDOR_ENV,
    ZINK_GLX_VENDOR_VALUE,
    ZINK_MESA_LOADER_ENV,
)


def get_python_type(field_type: ConfigFieldType) -> str:
    """Convert ConfigFieldType to Python type annotation"""
    type_map = {
        ConfigFieldType.BOOLEAN: "bool",
        ConfigFieldType.INTEGER: "int",
        ConfigFieldType.FLOAT: "float",
        ConfigFieldType.STRING: "str"
    }
    return type_map.get(field_type, "Any")


def get_env_var_name(field_name: str) -> str:
    """Convert field name to environment variable name"""
    env_map = {
        "disable_mako": MAKO_LAYER_DISABLE_ENV,
        "disable_hdr_exposure": HDR_EXPOSURE_DISABLE_ENV,
        "external_vulkan_layer": EXTERNAL_VULKAN_LAYER_ENV,
        "disable_steamdeck_mode": STEAM_DECK_MODE_ENV,
        "enable_zink": ZINK_GLX_VENDOR_ENV,
        "force_alsa_audio": SDL_AUDIO_DRIVER_ENV,
    }
    return env_map.get(field_name, field_name.upper())


def generate_typed_dict() -> str:
    """Generate ConfigurationData TypedDict"""
    lines = [
        "class ConfigurationData(TypedDict):",
        "    \"\"\"Type-safe configuration data structure - AUTO-GENERATED\"\"\""
    ]

    for field_name, field_def in CONFIG_SCHEMA_DEF.items():
        python_type = get_python_type(ConfigFieldType(field_def["fieldType"]))
        lines.append(f"    {field_name}: {python_type}")

    return "\n".join(lines)


def generate_patch_typed_dict() -> str:
    """Generate the public partial configuration update shape."""
    lines = [
        "class ConfigurationPatch(TypedDict, total=False):",
        '    """Validated partial profile update - AUTO-GENERATED"""',
    ]

    for field_name, field_def in CONFIG_SCHEMA_DEF.items():
        python_type = get_python_type(ConfigFieldType(field_def["fieldType"]))
        lines.append(f"    {field_name}: {python_type}")

    return "\n".join(lines)


def generate_wrapper_settings_typed_dict() -> str:
    """Generate the canonical persisted launcher-only settings shape."""
    lines = [
        "class WrapperSettingsData(TypedDict):",
        "    \"\"\"Canonical launcher-only profile settings - AUTO-GENERATED\"\"\"",
    ]

    for field_name, field_def in CONFIG_SCHEMA_DEF.items():
        if field_def["location"] != "script":
            continue
        python_type = get_python_type(ConfigFieldType(field_def["fieldType"]))
        lines.append(f"    {field_name}: {python_type}")

    return "\n".join(lines)


def generate_script_generation() -> str:
    """Generate script content generation logic"""
    lines = []

    script_fields = [
        (field_name, field_def)
        for field_name, field_def in CONFIG_SCHEMA_DEF.items()
        if field_def.get("location") == "script"
    ]

    for field_name, field_def in script_fields:
        if field_name == "gamescope_wsi_compatibility":
            # wrapper_generation.py combines this with Scaling Engine before
            # Vulkan instance creation; do not leak another environment knob.
            continue
        if field_name.startswith("vkbasalt_"):
            # wrapper_generation.py selects one validated managed config file
            # for the resolved profile. Individual settings never become
            # caller-visible environment variables.
            continue
        env_var = get_env_var_name(field_name)
        field_type = ConfigFieldType(field_def["fieldType"])

        if field_type == ConfigFieldType.BOOLEAN:
            if field_name == "disable_steam_overlay":
                # Keep an explicit local shell value for either saved choice;
                # the launch policy consumes it without exporting it to games.
                lines.append('        lines.append("mako_disable_steam_overlay=" +')
                lines.append('            ("1" if config.get("disable_steam_overlay", True) else "0"))')
            elif field_name == "disable_steamdeck_mode":
                # Special case: disable_steamdeck_mode=True should export SteamDeck=0
                lines.append(f'        if config.get("{field_name}", False):')
                lines.append(f'            lines.append("export {env_var}=0")')
            elif field_name == "enable_zink":
                # Special case: enable_zink=True should export multiple Zink environment variables
                lines.append(f'        if config.get("{field_name}", False):')
                lines.append(
                    f'            lines.append("export {ZINK_GLX_VENDOR_ENV}='
                    f'{ZINK_GLX_VENDOR_VALUE}")'
                )
                lines.append(
                    f'            lines.append("export {ZINK_MESA_LOADER_ENV}='
                    f'{ZINK_DRIVER_VALUE}")'
                )
                lines.append(
                    f'            lines.append("export {ZINK_GALLIUM_DRIVER_ENV}='
                    f'{ZINK_DRIVER_VALUE}")'
                )
            elif field_name == "force_alsa_audio":
                # SDL honours the native ALSA driver. Wine/Proton honours the
                # DLL override while retaining any caller-provided overrides.
                # When disabled, emit nothing so platform defaults are restored.
                lines.append(f'        if config.get("{field_name}", False):')
                lines.append('            lines.extend([')
                lines.append(
                    f'                "export {SDL_AUDIO_DRIVER_ENV}='
                    f'{SDL_AUDIO_DRIVER_ALSA_VALUE}",'
                )
                lines.append(
                    f'                \'case ";${{{WINE_DLL_OVERRIDES_ENV}:-}};" in\','
                )
                lines.append('                \'    *";winepulse.drv=d;"*) ;;\',')
                lines.append(
                    f'                \'    *) export {WINE_DLL_OVERRIDES_ENV}='
                    f'"${{{WINE_DLL_OVERRIDES_ENV}:+${WINE_DLL_OVERRIDES_ENV};}}'
                    'winepulse.drv=d" ;;\','
                )
                lines.append('                "esac",')
                lines.append(
                    f'                \'case ";${{{WINE_DLL_OVERRIDES_ENV}:-}};" in\','
                )
                lines.append('                \'    *";winealsa.drv=b;"*) ;;\',')
                lines.append(
                    f'                \'    *) export {WINE_DLL_OVERRIDES_ENV}='
                    f'"${{{WINE_DLL_OVERRIDES_ENV}:+${WINE_DLL_OVERRIDES_ENV};}}'
                    'winealsa.drv=b" ;;\','
                )
                lines.append('                "esac",')
                lines.append('            ])')
            else:
                lines.append(f'        if config.get("{field_name}", False):')
                lines.append(f'            lines.append("export {env_var}=1")')
        elif field_type in [ConfigFieldType.INTEGER, ConfigFieldType.FLOAT]:
            default = field_def["default"]
            lines.append(f'        {field_name} = config.get("{field_name}", {default})')
            lines.append(f'        if {field_name} != {default}:')
            lines.append(f'            lines.append(f"export {env_var}={{{field_name}}}")')
        elif field_type == ConfigFieldType.STRING:
            lines.append(f'        {field_name} = config.get("{field_name}", "")')
            if field_name == "external_vulkan_layer":
                # Always overwrite this internal selector so a caller cannot
                # leak another profile's external layer into the wrapper.
                lines.append(f'        lines.append(f"export {env_var}={{{field_name}}}")')
            else:
                lines.append(f'        if {field_name}:')
                lines.append(f'            lines.append(f"export {env_var}={{{field_name}}}")')

    return "\n".join(lines)


def generate_complete_schema_file() -> str:
    """Generate complete config_schema_generated.py file"""

    # Generate field name constants
    field_constants = []
    for field_name in CONFIG_SCHEMA_DEF.keys():
        const_name = field_name.upper()
        field_constants.append(f'{const_name} = "{field_name}"')

    lines = [
        '"""',
        'Auto-generated configuration schema components from shared_config.py',
        'DO NOT EDIT THIS FILE MANUALLY - it will be overwritten on build',
        '"""',
        '',
        'from typing import TypedDict, Dict, Any, Union',
        'from enum import Enum',
        '',
        'from shared_config import CONFIG_SCHEMA_DEF, ConfigFieldType',
        '',
        '# Field name constants for type-safe access',
    ] + field_constants + [
        '',
        '',
        generate_typed_dict(),
        '',
        '',
        generate_patch_typed_dict(),
        '',
        '',
        generate_wrapper_settings_typed_dict(),
        '',
        '',
        'def get_script_generation_logic():',
        '    """Return the script generation logic as a callable"""',
        '    def generate_script_lines(config):',
        '        lines = []',
        f'{generate_script_generation()}',
        '        return lines',
        '    return generate_script_lines',
        '',
        '',
        f'ALL_FIELDS = {list(CONFIG_SCHEMA_DEF.keys())}',
        ''
    ]

    return '\n'.join(lines)


def main():
    """Generate complete Python configuration files"""
    try:
        # Create generated files in the renamed MAKO Decky backend package.
        target_dir = project_root / "py_modules" / "mako_plugin"

        # Generate the complete schema file
        schema_content = generate_complete_schema_file()
        schema_file = target_dir / "config_schema_generated.py"
        schema_file.write_text(schema_content)
        print(f"Generated {schema_file.relative_to(project_root)}")

    except Exception as e:
        print(f"❌ Error generating Python files: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
