#!/usr/bin/env bash
# Update an installed local Decky plugin without rebuilding a release ZIP.
set -euo pipefail

project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
repository_root="$(cd "$project_dir/.." && pwd)"
flatpak_runtime_version_output="$(
  python3 "$project_dir/scripts/read_flatpak_runtime_contract.py" versions
)"
flatpak_runtime_bundle_output="$(
  python3 "$project_dir/scripts/read_flatpak_runtime_contract.py" bundles
)"
renderer_path_output="$(
  python3 "$project_dir/scripts/read_flatpak_runtime_contract.py" renderer-paths
)"
cli_relative_path="$(
  python3 "$project_dir/scripts/read_flatpak_runtime_contract.py" cli-path
)"
shader_tool_relative_path="$(
  python3 "$project_dir/scripts/read_flatpak_runtime_contract.py" shader-tool-path
)"
vkbasalt_path_output="$(
  python3 "$project_dir/scripts/read_flatpak_runtime_contract.py" vkbasalt-paths
)"
flatpak_runtime_versions=()
while IFS= read -r runtime_version; do
  [[ -n "$runtime_version" ]] && flatpak_runtime_versions+=("$runtime_version")
done <<< "$flatpak_runtime_version_output"
flatpak_runtime_bundles=()
while IFS= read -r runtime_bundle; do
  [[ -n "$runtime_bundle" ]] && flatpak_runtime_bundles+=("$runtime_bundle")
done <<< "$flatpak_runtime_bundle_output"
renderer_paths=()
while IFS= read -r renderer_path; do
  [[ -n "$renderer_path" ]] && renderer_paths+=("$renderer_path")
done <<< "$renderer_path_output"
vkbasalt_paths=()
while IFS= read -r vkbasalt_path; do
  [[ -n "$vkbasalt_path" ]] && vkbasalt_paths+=("$vkbasalt_path")
done <<< "$vkbasalt_path_output"
if ((${#flatpak_runtime_versions[@]} == 0 ||
      ${#flatpak_runtime_versions[@]} != ${#flatpak_runtime_bundles[@]})); then
  echo "The shared Flatpak runtime contract is empty or inconsistent." >&2
  exit 1
fi
if ((${#renderer_paths[@]} != 8)); then
  echo "The shared Renderer path contract is incomplete." >&2
  exit 1
fi
if ((${#vkbasalt_paths[@]} != 7)); then
  echo "The shared vkBasalt path contract is incomplete." >&2
  exit 1
fi
renderer_library_filename="${renderer_paths[0]}"
spatial_library_filename="${renderer_paths[3]}"
spatial_manifest_relative_path="${renderer_paths[6]}"
spatial_manifest32_relative_path="${renderer_paths[7]}"
vkbasalt_library_filename="${vkbasalt_paths[0]}"
vkbasalt_manifest_relative_path="${vkbasalt_paths[3]}"
vkbasalt_manifest32_relative_path="${vkbasalt_paths[4]}"
vkbasalt_shader_relative_path="${vkbasalt_paths[5]}"
vkbasalt_profile_shader_relative_path="${vkbasalt_paths[6]}"
flatpak_runtime_summary="$(
  python3 "$project_dir/scripts/read_flatpak_runtime_contract.py" summary
)"
if [[ -z "$flatpak_runtime_summary" ]]; then
  echo "The shared Flatpak runtime summary is empty." >&2
  exit 1
fi
plugin_dir="${DECKY_PLUGIN_DIR:-$HOME/homebrew/plugins/Mako}"
engine_repo="${MAKO_ENGINE_REPO:-$project_dir/../engine}"
local_vkbasalt_archive="${MAKO_VKBASALT_LOCAL_ARCHIVE:-}"
deploy_frontend=false
deploy_backend=false
deploy_engine=false
deploy_engine_32=false
deploy_flatpaks=false
reload_plugin=false
experimental_lsfg_fp16=false
action_selected=false

usage() {
  cat <<EOF
Usage: scripts/deploy-dev.sh [options]

Updates an already installed local MAKO Decky plugin in place.
With no options it rebuilds and deploys the Decky frontend and Python backend.
It never builds a ZIP, publishes anything, or runs the full test suite. Host
deployments validate and stage MAKO's pinned private vkBasalt dependency.
Flatpak options build local development extensions.

Options:
  --frontend              Rebuild and deploy dist/ with fresh dev-build metadata.
  --backend               Regenerate and deploy Python backend plus refreshed dev UI.
  --engine                Incrementally build/deploy the 64-bit host layers and CLI plus refreshed dev UI.
  --engine-32             Incrementally build/deploy the 32-bit host layer plus refreshed dev UI.
  --host                  Deploy Decky plus both 64-bit and 32-bit host layers.
  --flatpaks              Deploy Decky plus Flatpak runtimes $flatpak_runtime_summary.
  --e2e                   Deploy Decky, both host layers, and all Flatpak runtime bundles.
  --all                   Deploy frontend, backend, and engine.
  --experimental-lsfg-fp16 Build the native forced-FP16 experiment; uses the existing FP16 toggle.
  --reload                Reload only this plugin through Decky after deployment.
  --plugin-dir PATH       Installed Decky plugin directory.
  --engine-repo PATH      MAKO Renderer source directory for --engine.
  -h, --help              Show this help.

The plugin and a managed native Renderer must already be installed. Quit the test game
before --engine. Reload it from Decky's Developer menu after deployment, or
pass --reload to reload only this plugin automatically.
EOF
}

while (($#)); do
  case "$1" in
    --frontend)
      deploy_frontend=true
      action_selected=true
      ;;
    --backend)
      deploy_backend=true
      action_selected=true
      ;;
    --engine)
      deploy_engine=true
      action_selected=true
      ;;
    --engine-32)
      deploy_engine_32=true
      action_selected=true
      ;;
    --host)
      deploy_frontend=true
      deploy_backend=true
      deploy_engine=true
      deploy_engine_32=true
      action_selected=true
      ;;
    --flatpaks)
      deploy_frontend=true
      deploy_backend=true
      deploy_flatpaks=true
      action_selected=true
      ;;
    --e2e)
      deploy_frontend=true
      deploy_backend=true
      deploy_engine=true
      deploy_engine_32=true
      deploy_flatpaks=true
      action_selected=true
      ;;
    --all)
      deploy_frontend=true
      deploy_backend=true
      deploy_engine=true
      action_selected=true
      ;;
    --reload)
      reload_plugin=true
      action_selected=true
      ;;
    --experimental-lsfg-fp16)
      experimental_lsfg_fp16=true
      ;;
    --plugin-dir)
      if (($# < 2)); then
        echo "--plugin-dir requires a path" >&2
        exit 2
      fi
      plugin_dir="$2"
      shift
      ;;
    --engine-repo)
      if (($# < 2)); then
        echo "--engine-repo requires a path" >&2
        exit 2
      fi
      engine_repo="$2"
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unknown option: $1" >&2
      usage >&2
      exit 2
      ;;
  esac
  shift
done

if [[ "$experimental_lsfg_fp16" == true ]] &&
    { [[ "$deploy_engine" == false && "$deploy_engine_32" == false ]] ||
      [[ "$deploy_flatpaks" == true ]]; }; then
  echo "Experimental LSFG FP16 deployment requires a native Renderer scope without Flatpak builds." >&2
  exit 2
fi

if [[ "$action_selected" == false ]]; then
  deploy_frontend=true
  deploy_backend=true
fi

if [[ -n "$local_vkbasalt_archive" &&
      ( "$deploy_engine" == true || "$deploy_engine_32" == true ) ]]; then
  if [[ "$local_vkbasalt_archive" == /* || "$local_vkbasalt_archive" == *..* ||
        ! -f "$repository_root/$local_vkbasalt_archive" ]]; then
    echo "MAKO_VKBASALT_LOCAL_ARCHIVE must be an existing repository-relative archive." >&2
    exit 1
  fi
fi

# Every direct development deployment refreshes the visible status box. An
# engine-only or backend-only run therefore also rebuilds the small frontend.
if [[ "$deploy_backend" == true || "$deploy_engine" == true ||
      "$deploy_engine_32" == true || "$deploy_flatpaks" == true ]]; then
  deploy_frontend=true
fi

if [[ "$deploy_flatpaks" == true ]] && ! command -v flatpak-builder >/dev/null 2>&1; then
  echo "Flatpak runtime packaging needs flatpak-builder." >&2
  echo "On SteamOS, install it with:" >&2
  echo "  sudo steamos-readonly disable" >&2
  echo "  sudo pacman -S flatpak-builder" >&2
  echo "  sudo steamos-readonly enable" >&2
  exit 1
fi

if [[ "$plugin_dir" != /* ]]; then
  plugin_dir="$PWD/$plugin_dir"
fi
if [[ "$engine_repo" != /* ]]; then
  engine_repo="$PWD/$engine_repo"
fi

if [[ ! -f "$plugin_dir/plugin.json" ]]; then
  echo "Installed Decky plugin not found: $plugin_dir" >&2
  echo "Install this plugin once through Decky, or pass --plugin-dir PATH." >&2
  exit 1
fi

plugin_name="$(python3 -c '
import json
import sys
with open(sys.argv[1], encoding="utf-8") as source:
    print(json.load(source).get("name", ""))
' "$plugin_dir/plugin.json")"
if [[ "$plugin_name" != "MAKO Decky" &&
      "$plugin_name" != "MAKO" && "$plugin_name" != "Mako" &&
      "$plugin_name" != "MAKO - Frame Generation" ]]; then
  echo "Refusing to modify a different Decky plugin: $plugin_dir" >&2
  exit 1
fi

copy_file() {
  local source_path="$1"
  local destination_path="$2"
  local destination_dir
  local temporary_path

  if [[ -f "$destination_path" ]] && cmp -s "$source_path" "$destination_path"; then
    return
  fi

  destination_dir="$(dirname "$destination_path")"
  mkdir -p "$destination_dir"
  if [[ -w "$destination_dir" ]]; then
    temporary_path="$(mktemp "$destination_dir/.${destination_path##*/}.XXXXXX")"
    cp "$source_path" "$temporary_path"
    chmod --reference="$source_path" "$temporary_path"
    mv -f "$temporary_path" "$destination_path"
  elif [[ -f "$destination_path" && -w "$destination_path" ]]; then
    # Decky's installer can leave the plugin root owned by root while handing
    # individual payload files to the deck user. Rename-based atomic updates
    # need directory write permission, so replace only that writable file.
    echo "Replacing writable file in a protected Decky directory: $destination_path"
    cp "$source_path" "$destination_path"
    chmod --reference="$source_path" "$destination_path"
  else
    echo "Cannot update $destination_path; neither its directory nor file is writable." >&2
    exit 1
  fi
}

verify_private_layer_manifest() {
  local manifest_path="$1"
  local installed_manifest_path="$2"
  local installed_library_path="$3"
  local expected_identity="$4"
  python3 - "$manifest_path" "$installed_manifest_path" \
      "$installed_library_path" "$expected_identity" <<'PY'
import json
from pathlib import Path
import sys

manifest_path = Path(sys.argv[1])
installed_manifest_path = Path(sys.argv[2])
installed_library_path = Path(sys.argv[3]).resolve()
expected_identity = sys.argv[4]
try:
    layer = json.loads(manifest_path.read_text(encoding="utf-8"))["layer"]
    identity = layer["name"]
    library_path = Path(layer["library_path"])
except (OSError, KeyError, TypeError, json.JSONDecodeError) as error:
    raise SystemExit(f"Invalid development layer manifest {manifest_path}: {error}")
if identity != expected_identity:
    raise SystemExit(
        f"Development layer manifest identifies {identity!r}, "
        f"expected {expected_identity!r}"
    )
resolved = (
    library_path.resolve()
    if library_path.is_absolute()
    else (installed_manifest_path.parent / library_path).resolve()
)
if resolved != installed_library_path:
    raise SystemExit(
        f"Development layer manifest resolves {resolved}, "
        f"expected {installed_library_path}"
    )
PY
}

rewrite_private_layer_manifest() {
  local manifest_path="$1"
  local installed_library_path="$2"
  python3 - "$manifest_path" "$installed_library_path" <<'PY'
import json
from pathlib import Path
import sys

manifest_path = Path(sys.argv[1])
installed_library_path = Path(sys.argv[2]).resolve()
try:
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    layer = manifest["layer"]
except (OSError, KeyError, TypeError, json.JSONDecodeError) as error:
    raise SystemExit(f"Invalid development layer manifest {manifest_path}: {error}")
layer["library_path"] = str(installed_library_path)
manifest_path.write_text(json.dumps(manifest, indent=4) + "\n", encoding="utf-8")
PY
}

built_layer_64=""
built_cli=""
built_remote_play_sdr=""
installed_cli=""
built_layer_32=""
built_renderer_manifest_64=""
built_renderer_manifest_32=""
installed_renderer_manifests_64=()
installed_renderer_manifests_32=()
built_spatial_layer_64=""
built_spatial_layer_32=""
built_spatial_manifest_64=""
built_spatial_manifest_32=""
built_vkbasalt_library_64=""
built_vkbasalt_library_32=""
built_vkbasalt_manifest_64=""
built_vkbasalt_manifest_32=""
installed_layer_64=""
installed_layer_32=""
installed_spatial_layer_64=""
installed_spatial_layer_32=""
installed_spatial_manifest_64=""
installed_spatial_manifest_32=""
installed_vkbasalt_library_64=""
installed_vkbasalt_library_32=""
installed_vkbasalt_manifest_64=""
installed_vkbasalt_manifest_32=""
flatpak_archive=""
flatpak_unpack_dir=""
vkbasalt_stage_dir=""
cleanup() {
  if [[ -n "$flatpak_unpack_dir" ]]; then
    rm -rf "$flatpak_unpack_dir"
  fi
  if [[ -n "$vkbasalt_stage_dir" ]]; then
    rm -rf "$vkbasalt_stage_dir"
  fi
}
trap cleanup EXIT

if [[ "$deploy_engine" == true || "$deploy_engine_32" == true ]]; then
  # Resolve selection before building or changing the installed plugin. A
  # standalone install may own the shared manifests even when Decky's payload
  # is still present. Never infer active selection from that inactive copy.
  for bits in 64 32; do
    if [[ "$bits" == 64 && "$deploy_engine" == false ]] ||
        [[ "$bits" == 32 && "$deploy_engine_32" == false ]]; then
      continue
    fi
    selected_path_output="$(python3 "$project_dir/scripts/dev-renderer-selection.py" --bits "$bits")"
    mapfile -t selected_paths <<< "$selected_path_output"
    if ((${#selected_paths[@]} != 3)); then
      echo "Incomplete active Renderer selection for $bits-bit deployment." >&2
      exit 1
    fi
    if [[ "$bits" == 64 ]]; then
      installed_layer_64="${selected_paths[0]}"
      installed_spatial_layer_64="${selected_paths[1]}"
      installed_vkbasalt_library_64="${selected_paths[2]}"
    else
      installed_layer_32="${selected_paths[0]}"
      installed_spatial_layer_32="${selected_paths[1]}"
      installed_vkbasalt_library_32="${selected_paths[2]}"
    fi
  done

  if [[ ! -x "$engine_repo/scripts/build-steamos-dev.sh" ]]; then
    echo "Incremental engine builder not found: $engine_repo/scripts/build-steamos-dev.sh" >&2
    exit 1
  fi
  if [[ ! -x "$engine_repo/scripts/mako-vrr-lease" ]]; then
    echo "Gamescope VRR helper not found: $engine_repo/scripts/mako-vrr-lease" >&2
    exit 1
  fi

  engine_build_args=()
  if [[ "$experimental_lsfg_fp16" == true ]]; then
    engine_build_args+=(--experimental-lsfg-fp16)
  fi
  if [[ "$deploy_engine" == true && "$deploy_engine_32" == true ]]; then
    engine_build_args+=(--with-32-bit)
  elif [[ "$deploy_engine_32" == true ]]; then
    engine_build_args+=(--32-bit-only)
  fi
  "$engine_repo/scripts/build-steamos-dev.sh" "${engine_build_args[@]}"

  if [[ ! -x "$engine_repo/scripts/manage-vkbasalt-release.py" ]]; then
    echo "Pinned vkBasalt manager not found: $engine_repo/scripts/manage-vkbasalt-release.py" >&2
    exit 1
  fi
  mkdir -p "$engine_repo/build/work"
  vkbasalt_stage_dir="$(mktemp -d "$engine_repo/build/work/vkbasalt-dev.XXXXXX")"
  vkbasalt_stage_args=(
    --stage-native "$vkbasalt_stage_dir"
    --cache-dir "$engine_repo/build/cache/vkbasalt"
  )
  if [[ "$deploy_engine_32" == false ]]; then
    vkbasalt_stage_args+=(--64-bit-only)
  fi
  if [[ -n "$local_vkbasalt_archive" ]]; then
    vkbasalt_stage_args+=(--local-archive "$repository_root/$local_vkbasalt_archive")
  fi
  python3 "$engine_repo/scripts/manage-vkbasalt-release.py" \
    "${vkbasalt_stage_args[@]}"

  engine_build_dir="${MAKO_BUILD_DIR:-$engine_repo/build/steamos-dev}"
  if [[ "$engine_build_dir" != /* ]]; then
    engine_build_dir="$engine_repo/$engine_build_dir"
  fi
  if [[ "$deploy_engine" == true ]]; then
    built_layer_64="$engine_build_dir/mako-render/$renderer_library_filename"
    built_cli="$engine_build_dir/mako-cli/${cli_relative_path##*/}"
    built_remote_play_sdr="$engine_build_dir/scripts/mako_remote_play/libmako-remote-play-sdr.so"
    installed_cli="$HOME/$cli_relative_path"
    built_spatial_layer_64="$engine_build_dir/mako-render/$spatial_library_filename"
    built_spatial_manifest_64="$engine_build_dir/mako-render/private-scaling-manifest/${spatial_manifest_relative_path##*/}"
    installed_spatial_manifest_64="$HOME/$spatial_manifest_relative_path"
    built_vkbasalt_library_64="$vkbasalt_stage_dir/lib/vkbasalt/$vkbasalt_library_filename"
    built_vkbasalt_manifest_64="$vkbasalt_stage_dir/share/mako-render/vulkan/vkbasalt.d/${vkbasalt_manifest_relative_path##*/}"
    installed_vkbasalt_manifest_64="$HOME/$vkbasalt_manifest_relative_path"
  fi
  if [[ "$deploy_engine_32" == true ]]; then
    engine_build_32_dir="${MAKO_BUILD_32_DIR:-${engine_build_dir}-32}"
    if [[ "$engine_build_32_dir" != /* ]]; then
      engine_build_32_dir="$engine_repo/$engine_build_32_dir"
    fi
    built_layer_32="$engine_build_32_dir/mako-render/$renderer_library_filename"
    built_spatial_layer_32="$engine_build_32_dir/mako-render/$spatial_library_filename"
    built_spatial_manifest_32="$engine_build_32_dir/mako-render/private-scaling-manifest/${spatial_manifest32_relative_path##*/}"
    installed_spatial_manifest_32="$HOME/$spatial_manifest32_relative_path"
    built_vkbasalt_library_32="$vkbasalt_stage_dir/lib32/vkbasalt/$vkbasalt_library_filename"
    built_vkbasalt_manifest_32="$vkbasalt_stage_dir/share/mako-render/vulkan/vkbasalt.d/${vkbasalt_manifest32_relative_path##*/}"
    installed_vkbasalt_manifest_32="$HOME/$vkbasalt_manifest32_relative_path"
  fi
  for layer_path in \
      "$built_cli" \
      "$built_remote_play_sdr" \
      "$built_layer_64" "$built_layer_32" \
      "$built_spatial_layer_64" "$built_spatial_layer_32" \
      "$built_spatial_manifest_64" "$built_spatial_manifest_32" \
      "$built_vkbasalt_library_64" "$built_vkbasalt_library_32" \
      "$built_vkbasalt_manifest_64" "$built_vkbasalt_manifest_32"; do
    if [[ -n "$layer_path" && ! -f "$layer_path" ]]; then
      echo "Incremental engine build did not produce: $layer_path" >&2
      exit 1
    fi
  done
  if [[ -n "$built_cli" && ! -x "$built_cli" ]]; then
    echo "Incremental engine build produced a non-executable CLI: $built_cli" >&2
    exit 1
  fi
  for bits in 64 32; do
    if [[ "$bits" == 64 && "$deploy_engine" == false ]] ||
        [[ "$bits" == 32 && "$deploy_engine_32" == false ]]; then
      continue
    fi
    renderer_build_dir="$engine_build_dir/mako-render"
    if [[ "$bits" == 32 ]]; then
      renderer_build_dir="$engine_build_32_dir/mako-render"
    fi
    staged_manifest="$vkbasalt_stage_dir/renderer-$bits.json"
    manifest_path_output="$(python3 "$project_dir/scripts/dev-renderer-selection.py" \
      --bits "$bits" --prepare-manifest "$renderer_build_dir" "$staged_manifest")"
    mapfile -t manifest_paths <<< "$manifest_path_output"
    if ((${#manifest_paths[@]} != 2)); then
      echo "Incomplete Renderer manifest selection for $bits-bit deployment." >&2
      exit 1
    fi
    if [[ "$bits" == 64 ]]; then
      built_renderer_manifest_64="$staged_manifest"
      installed_renderer_manifests_64=("${manifest_paths[@]}")
    else
      built_renderer_manifest_32="$staged_manifest"
      installed_renderer_manifests_32=("${manifest_paths[@]}")
    fi
  done
  for installed_path in "$installed_layer_64" "$installed_layer_32"; do
    if [[ -n "$installed_path" && ! -f "$installed_path" ]]; then
      echo "MAKO Renderer is not installed yet: $installed_path" >&2
      echo "Use MAKO Decky's 'Install MAKO Renderer' action once before deploying host layers." >&2
      exit 1
    fi
  done
  if [[ -n "$built_spatial_manifest_64" ]]; then
    cp "$built_spatial_manifest_64" "$vkbasalt_stage_dir/spatial-64.json"
    built_spatial_manifest_64="$vkbasalt_stage_dir/spatial-64.json"
    rewrite_private_layer_manifest "$built_spatial_manifest_64" "$installed_spatial_layer_64"
    verify_private_layer_manifest \
      "$built_spatial_manifest_64" "$installed_spatial_manifest_64" \
      "$installed_spatial_layer_64" "VK_LAYER_MAKO_spatial_scaling"
  fi
  if [[ -n "$built_spatial_manifest_32" ]]; then
    cp "$built_spatial_manifest_32" "$vkbasalt_stage_dir/spatial-32.json"
    built_spatial_manifest_32="$vkbasalt_stage_dir/spatial-32.json"
    rewrite_private_layer_manifest "$built_spatial_manifest_32" "$installed_spatial_layer_32"
    verify_private_layer_manifest \
      "$built_spatial_manifest_32" "$installed_spatial_manifest_32" \
      "$installed_spatial_layer_32" "VK_LAYER_MAKO_spatial_scaling"
  fi
  if [[ -n "$built_vkbasalt_manifest_64" ]]; then
    rewrite_private_layer_manifest \
      "$built_vkbasalt_manifest_64" "$installed_vkbasalt_library_64"
    verify_private_layer_manifest \
      "$built_vkbasalt_manifest_64" "$installed_vkbasalt_manifest_64" \
      "$installed_vkbasalt_library_64" "VK_LAYER_VKBASALT_post_processing"
  fi
  if [[ -n "$built_vkbasalt_manifest_32" ]]; then
    rewrite_private_layer_manifest \
      "$built_vkbasalt_manifest_32" "$installed_vkbasalt_library_32"
    verify_private_layer_manifest \
      "$built_vkbasalt_manifest_32" "$installed_vkbasalt_manifest_32" \
      "$installed_vkbasalt_library_32" "VK_LAYER_VKBASALT_post_processing"
  fi
fi

if [[ "$deploy_flatpaks" == true ]]; then
  if [[ ! -x "$engine_repo/scripts/package-flatpaks.sh" ]]; then
    echo "Flatpak packager not found: $engine_repo/scripts/package-flatpaks.sh" >&2
    exit 1
  fi
  engine_version="$(tr -d '[:space:]' < "$engine_repo/VERSION")"
  flatpak_archive="$engine_repo/out/MAKO-Renderer-v$engine_version-steamos-dev-flatpaks.tar.xz"
  build_cache_root="${MAKO_BUILD_CACHE_ROOT:-$engine_repo/build/cache}"
  build_work_root="${MAKO_BUILD_WORK_ROOT:-$engine_repo/build/work}"
  flatpak_cache_root="${MAKO_FLATPAK_CACHE_ROOT:-$build_cache_root/flatpak}"
  flatpak_tmp_root="${MAKO_FLATPAK_TMP_ROOT:-$build_work_root/flatpak}"
  if [[ "$flatpak_cache_root" != /* ]]; then
    flatpak_cache_root="$engine_repo/$flatpak_cache_root"
  fi
  if [[ "$flatpak_tmp_root" != /* ]]; then
    flatpak_tmp_root="$engine_repo/$flatpak_tmp_root"
  fi
  mkdir -p "$flatpak_tmp_root"
  echo "Building all MAKO Flatpak runtime bundles..."
  TMPDIR="$flatpak_tmp_root" MAKO_FLATPAK_WORK_ROOT="$flatpak_tmp_root" \
    MAKO_FLATPAK_CACHE_ROOT="$flatpak_cache_root" \
    "$engine_repo/scripts/package-flatpaks.sh" "$flatpak_archive"
  flatpak_unpack_dir="$(mktemp -d "${TMPDIR:-/tmp}/mako-flatpaks.XXXXXX")"
  tar -xJf "$flatpak_archive" -C "$flatpak_unpack_dir"
  for ((runtime_index = 0; runtime_index < ${#flatpak_runtime_versions[@]}; runtime_index++)); do
    runtime_version="${flatpak_runtime_versions[$runtime_index]}"
    flatpak_bundle="$flatpak_unpack_dir/${flatpak_runtime_bundles[$runtime_index]}"
    if [[ ! -s "$flatpak_bundle" ]]; then
      echo "Flatpak archive is missing runtime $runtime_version: $flatpak_bundle" >&2
      exit 1
    fi
  done
fi

dev_build_info_path="$project_dir/.dev-build-info.json"
dev_build_info_args=(
  --output "$dev_build_info_path"
  --plugin-repo "$project_dir"
  --frontend-deployed "$deploy_frontend"
  --backend-deployed "$deploy_backend"
)
if [[ -n "$built_layer_64" || -n "$built_layer_32" || -n "$flatpak_archive" ]]; then
  dev_build_info_args+=(
    --engine-repo "$engine_repo"
  )
  if [[ -n "$built_layer_64" ]]; then
    dev_build_info_args+=(--engine-layer-64 "$built_layer_64")
  fi
  if [[ -n "$built_layer_32" ]]; then
    dev_build_info_args+=(--engine-layer-32 "$built_layer_32")
  fi
  if [[ -n "$flatpak_archive" ]]; then
    dev_build_info_args+=(--flatpak-archive "$flatpak_archive")
  fi
fi
node "$project_dir/scripts/generate-dev-build-info.mjs" "${dev_build_info_args[@]}"

# Direct development deployments use the same runtime flag as local ZIPs.
# Copy only this generated flavour override; published packages retain the
# tracked default from py_modules/mako_plugin/build_flavor.py.
copy_file "$project_dir/defaults/build_flavor.dev.py" \
  "$plugin_dir/py_modules/mako_plugin/build_flavor.py"

if [[ "$deploy_frontend" == true || "$deploy_backend" == true ]]; then
  echo "Generating configuration bindings..."
  python3 "$project_dir/scripts/generate_ts_schema.py"
fi

if [[ "$deploy_frontend" == true ]]; then
  echo "Building Decky frontend..."
  (
    cd "$project_dir"
    MAKO_LOCAL_RELEASE_BUILD=1 \
      MAKO_DEV_BUILD_INFO_PATH="$dev_build_info_path" \
      node "$project_dir/scripts/build-frontend.mjs"
  )
  copy_file "$project_dir/dist/index.js" "$plugin_dir/dist/index.js"
  if cmp -s "$project_dir/plugin.json" "$plugin_dir/plugin.json"; then
    :
  elif [[ -w "$plugin_dir" || -w "$plugin_dir/plugin.json" ]]; then
    copy_file "$project_dir/plugin.json" "$plugin_dir/plugin.json"
  else
    echo "Skipped protected Decky manifest; reinstall the next ZIP to apply manifest changes."
  fi
  if [[ -f "$project_dir/dist/index.js.map" ]]; then
    copy_file "$project_dir/dist/index.js.map" "$plugin_dir/dist/index.js.map"
  fi
  echo "Deployed Decky frontend."
fi

if [[ "$deploy_backend" == true ]]; then
  echo "Deploying Python backend..."
  copy_file "$project_dir/main.py" "$plugin_dir/main.py"
  copy_file "$project_dir/shared_config.py" "$plugin_dir/shared_config.py"
  copy_file "$project_dir/shared_flatpak_runtimes.py" "$plugin_dir/shared_flatpak_runtimes.py"
  copy_file "$repository_root/scripts/mako-diagnostics" \
    "$plugin_dir/bin/mako-diagnostics"
  cp -a "$project_dir/py_modules/." "$plugin_dir/py_modules/"
  copy_file "$project_dir/defaults/build_flavor.dev.py" \
    "$plugin_dir/py_modules/mako_plugin/build_flavor.py"
  find "$plugin_dir/py_modules" -type f \( -name '*.pyc' -o -name '*.pyo' \) -delete
  find "$plugin_dir/py_modules" -type d -name '__pycache__' -prune -exec rm -rf {} +
  echo "Deployed Decky Python backend and diagnostics helper."
fi

if [[ "$deploy_backend" == true || "$deploy_engine" == true ||
      "$deploy_engine_32" == true ]]; then
  source_vkbasalt_shader_dir="$project_dir/py_modules/mako_plugin/vkbasalt_shaders"
  for shader_relative_path in "$vkbasalt_shader_relative_path" \
      "$vkbasalt_profile_shader_relative_path"; do
    installed_vkbasalt_shader_dir="$HOME/$shader_relative_path"
    if [[ -d "$installed_vkbasalt_shader_dir" ]]; then
      while IFS= read -r -d '' shader_asset; do
        copy_file "$shader_asset" \
          "$installed_vkbasalt_shader_dir/${shader_asset##*/}"
      done < <(find "$source_vkbasalt_shader_dir" -maxdepth 1 -type f -print0)
      echo "Deployed the complete private vkBasalt shader catalog to $installed_vkbasalt_shader_dir."
    fi
  done
fi

if [[ -n "$built_layer_64" ]]; then
  copy_file "$built_layer_64" "$installed_layer_64"
  for manifest in "${installed_renderer_manifests_64[@]}"; do
    copy_file "$built_renderer_manifest_64" "$manifest"
  done
  copy_file "$built_spatial_layer_64" "$installed_spatial_layer_64"
  copy_file "$built_spatial_manifest_64" "$installed_spatial_manifest_64"
  copy_file "$built_vkbasalt_library_64" "$installed_vkbasalt_library_64"
  copy_file "$built_vkbasalt_manifest_64" "$installed_vkbasalt_manifest_64"
  copy_file "$built_cli" "$installed_cli"
  if [[ -x "$vkbasalt_stage_dir/bin/mako-shader-tool" ]]; then
    copy_file "$vkbasalt_stage_dir/bin/mako-shader-tool" "$HOME/$shader_tool_relative_path"
  else
    rm -f -- "$HOME/$shader_tool_relative_path"
  fi
  copy_file "$built_remote_play_sdr" \
    "$HOME/.local/share/mako-render/mako_remote_play/libmako-remote-play-sdr.so"
  if ! cmp -s "$built_remote_play_sdr" \
      "$HOME/.local/share/mako-render/mako_remote_play/libmako-remote-play-sdr.so"; then
    echo "Installed Remote Play SDR helper differs from the development build." >&2
    exit 1
  fi
  if [[ ! -x "$installed_cli" ]] || ! cmp -s "$built_cli" "$installed_cli"; then
    echo "Installed Renderer CLI differs from the development build: $installed_cli" >&2
    exit 1
  fi
  cli_checksum="$(sha256sum "$installed_cli")"
  echo "MAKO Renderer: verified installed 64-bit CLI $installed_cli; sha256=${cli_checksum%% *}"
  python3 "$project_dir/scripts/dev-renderer-selection.py" --bits 64 \
    --verify "$built_layer_64" "$built_spatial_layer_64" "$built_vkbasalt_library_64"
  echo "Deployed incremental 64-bit Renderer layers, CLI, and private vkBasalt layers."
fi
if [[ -n "$built_layer_32" ]]; then
  copy_file "$built_layer_32" "$installed_layer_32"
  for manifest in "${installed_renderer_manifests_32[@]}"; do
    copy_file "$built_renderer_manifest_32" "$manifest"
  done
  copy_file "$built_spatial_layer_32" "$installed_spatial_layer_32"
  copy_file "$built_spatial_manifest_32" "$installed_spatial_manifest_32"
  copy_file "$built_vkbasalt_library_32" "$installed_vkbasalt_library_32"
  copy_file "$built_vkbasalt_manifest_32" "$installed_vkbasalt_manifest_32"
  python3 "$project_dir/scripts/dev-renderer-selection.py" --bits 32 \
    --verify "$built_layer_32" "$built_spatial_layer_32" "$built_vkbasalt_library_32"
  echo "Deployed incremental 32-bit Renderer and private vkBasalt layers."
fi
if [[ "$deploy_engine" == true || "$deploy_engine_32" == true ]]; then
  copy_file "$engine_repo/scripts/mako-vrr-lease" \
    "$HOME/.local/share/mako-render/bin/mako-vrr-lease"
  echo "Deployed the Gamescope VRR launch helper."
fi
if [[ -n "$flatpak_archive" ]]; then
  for flatpak_bundle in "${flatpak_runtime_bundles[@]}"; do
    copy_file "$flatpak_unpack_dir/$flatpak_bundle" "$plugin_dir/bin/$flatpak_bundle"
  done
  echo "Deployed Flatpak runtime bundles $flatpak_runtime_summary."
fi

if [[ "$reload_plugin" == true ]]; then
  node "$project_dir/scripts/reload-decky-plugin.mjs" "$plugin_name"
else
  echo "Reload MAKO Decky from Decky's Developer menu before testing."
fi
