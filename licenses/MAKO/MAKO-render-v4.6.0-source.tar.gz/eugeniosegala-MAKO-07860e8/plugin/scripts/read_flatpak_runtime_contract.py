#!/usr/bin/env python3
"""Print the canonical MAKO Decky Flatpak runtime contract for shell tools."""

import argparse
from pathlib import Path
import sys


PLUGIN_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PLUGIN_ROOT))

from py_modules.mako_plugin.constants import (  # noqa: E402
    CLI_DIR,
    CLI_FILENAME,
    SHADER_TOOL_FILENAME,
    CONFIG_DIR,
    FLATPAK_RUNTIME_BUNDLES,
    LIB_FILENAME,
    LOCAL_LIB,
    LOCAL_LIB32,
    SPATIAL_SCALING_JSON32_FILENAME,
    SPATIAL_SCALING_JSON_FILENAME,
    SPATIAL_SCALING_LAYER_DIR,
    SPATIAL_SCALING_LIB_FILENAME,
    VKBASALT_LAYER_DIR,
    VKBASALT_LIB32_DIR,
    VKBASALT_LIB_DIR,
    VKBASALT_LIB_FILENAME,
    VKBASALT_MANIFEST_FILENAME_32,
    VKBASALT_MANIFEST_FILENAME_64,
    VKBASALT_PROFILE_CONFIG_DIRNAME,
    VKBASALT_SHADER_DIR,
)


def _summary(versions: tuple[str, ...]) -> str:
    if len(versions) == 1:
        return versions[0]
    if len(versions) == 2:
        return f"{versions[0]} and {versions[1]}"
    return f"{', '.join(versions[:-1])}, and {versions[-1]}"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "field",
        choices=(
            "versions",
            "bundles",
            "summary",
            "renderer-paths",
            "cli-path",
            "shader-tool-path",
            "vkbasalt-paths",
        ),
    )
    args = parser.parse_args()
    versions = tuple(FLATPAK_RUNTIME_BUNDLES)

    if args.field == "versions":
        print(*versions, sep="\n")
    elif args.field == "bundles":
        print(
            *(bundle.filename for bundle in FLATPAK_RUNTIME_BUNDLES.values()),
            sep="\n",
        )
    elif args.field == "summary":
        print(_summary(versions))
    elif args.field == "cli-path":
        print(f"{CLI_DIR}/{CLI_FILENAME}")
    elif args.field == "shader-tool-path":
        print(f"{CLI_DIR}/{SHADER_TOOL_FILENAME}")
    elif args.field == "renderer-paths":
        print(
            LIB_FILENAME,
            f"{LOCAL_LIB}/{LIB_FILENAME}",
            f"{LOCAL_LIB32}/{LIB_FILENAME}",
            SPATIAL_SCALING_LIB_FILENAME,
            f"{LOCAL_LIB}/{SPATIAL_SCALING_LIB_FILENAME}",
            f"{LOCAL_LIB32}/{SPATIAL_SCALING_LIB_FILENAME}",
            f"{SPATIAL_SCALING_LAYER_DIR}/{SPATIAL_SCALING_JSON_FILENAME}",
            f"{SPATIAL_SCALING_LAYER_DIR}/{SPATIAL_SCALING_JSON32_FILENAME}",
            sep="\n",
        )
    else:
        print(
            VKBASALT_LIB_FILENAME,
            f"{VKBASALT_LIB_DIR}/{VKBASALT_LIB_FILENAME}",
            f"{VKBASALT_LIB32_DIR}/{VKBASALT_LIB_FILENAME}",
            f"{VKBASALT_LAYER_DIR}/{VKBASALT_MANIFEST_FILENAME_64}",
            f"{VKBASALT_LAYER_DIR}/{VKBASALT_MANIFEST_FILENAME_32}",
            VKBASALT_SHADER_DIR,
            f"{CONFIG_DIR}/{VKBASALT_PROFILE_CONFIG_DIRNAME}/shaders",
            sep="\n",
        )


if __name__ == "__main__":
    main()
