export * from "./generatedConfigSchema";
