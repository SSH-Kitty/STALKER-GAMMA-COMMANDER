import { PanelSectionRow } from "@decky/ui";
import type { ConfigurationData } from "../config/configSchema";
import type { RuntimeScalingUiState } from "../utils/runtimeScalingUtils";
import t from "../i18n/i18n";
import {
  MakoSectionHeader,
  MakoSectionTail,
  makoAccentColor,
  makoPanelDivider,
  makoPanelStyle,
} from "./MakoUi";

function methodLabel(method: string): string {
  switch (method) {
    case "mako":
      return t("SCALING_METHOD_MAKO", "MAKO Scaler");
    case "ls1":
      return t("SCALING_METHOD_LS1", "LS1 Quality");
    case "ls1-performance":
      return t("SCALING_METHOD_LS1_PERFORMANCE", "LS1 Performance");
    default:
      return t("SCALING_METHOD_NATIVE", "Native Resolution");
  }
}

function liveMethodLabel(method: string): string {
  switch (method) {
    case "native":
      return t("LIVE_STATUS_NATIVE", "Native");
    case "ls1-performance":
      return t("LIVE_STATUS_LS1_PERFORMANCE", "LS1 Perf");
    default:
      return methodLabel(method);
  }
}

function resolution(width: number, height: number): string {
  return width > 0 && height > 0 ? `${width} × ${height}` : "—";
}

function scalingInactiveNotice(reason: string | null): string | null {
  switch (reason) {
    case "variable-surface-memory-budget":
      return t(
        "LIVE_STATUS_SCALING_MEMORY_LIMIT",
        "The requested render resolution exceeds this GPU's memory safety limit. Lower the in-game resolution.",
      );
    case "gamescope-presentation-target-no-headroom":
    case "variable-surface-no-headroom":
      return t(
        "LIVE_STATUS_SCALING_NO_HEADROOM",
        "This input already fills the display target. Try Windowed mode, lower the in-game resolution, or enable Quality Supersampling.",
      );
    default:
      return null;
  }
}

function StatusDetail({
  label,
  value,
}: {
  label: string;
  value: React.ReactNode;
}) {
  return (
    <div
      data-mako-live-status-detail="true"
      style={{
        display: "grid",
        gridTemplateColumns: "minmax(0, 0.8fr) minmax(0, 1.2fr)",
        gap: "5px",
        alignItems: "baseline",
        marginTop: "2px",
      }}
    >
      <span style={{ color: "#839da5" }}>{label}</span>
      <span
        style={{
          color: "#d7e7eb",
          textAlign: "right",
          overflowWrap: "anywhere",
        }}
      >
        {value}
      </span>
    </div>
  );
}

function StatusRow({
  label,
  active,
  separated,
  children,
}: {
  label: string;
  active: boolean;
  separated?: boolean;
  children: React.ReactNode;
}) {
  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "8px minmax(0, 1fr)",
        columnGap: "6px",
        padding: "6px 8px",
        borderLeft: separated ? makoPanelDivider : undefined,
      }}
    >
      <span
        aria-hidden="true"
        style={{
          width: "7px",
          height: "7px",
          marginTop: "3px",
          borderRadius: "50%",
          background: active ? "#5fe3b1" : "#738891",
          boxShadow: active ? "0 0 7px rgba(95, 227, 177, 0.55)" : "none",
        }}
      />
      <div style={{ minWidth: 0 }}>
        <div style={{ color: "#edf8fb", fontSize: "10px", fontWeight: 650 }}>
          {label}
        </div>
        <div
          style={{
            marginTop: "2px",
            color: "#b6c9cf",
            fontSize: "9px",
            lineHeight: 1.3,
          }}
        >
          {children}
        </div>
      </div>
    </div>
  );
}

type StatusNotice = {
  key: string;
  content: React.ReactNode;
  color?: string;
};

function StatusFooterNotices({ notices }: { notices: StatusNotice[] }) {
  const noticeContent = (notice: StatusNotice) => (
    <span style={{ color: notice.color }}>{notice.content}</span>
  );

  return (
    <div
      data-mako-live-status-footer="true"
      style={{
        display: "grid",
        gap: "4px",
        padding: "6px 10px",
        borderTop: makoPanelDivider,
        color: "#f7d9b4",
        fontSize: "9px",
        lineHeight: 1.35,
      }}
    >
      {notices.length > 1 ? (
        <ul
          data-mako-live-status-notice-list="true"
          style={{ margin: 0, paddingLeft: "16px", listStyleType: "disc" }}
        >
          {notices.map((notice) => (
            <li key={notice.key}>{noticeContent(notice)}</li>
          ))}
        </ul>
      ) : (
        noticeContent(notices[0])
      )}
    </div>
  );
}

export function RuntimeStatusCard({
  runtimeState,
  activeConfig,
}: {
  runtimeState: RuntimeScalingUiState;
  activeConfig?: Pick<
    ConfigurationData,
    | "frame_generation_provisioned"
    | "frame_generation_enabled"
    | "scaling_enabled"
  > &
    Partial<Pick<ConfigurationData, "gpu_headroom_percent">>;
}) {
  // Configuration explains absent telemetry; it must not override live reports.
  const featuresOff =
    !runtimeState.hasContext &&
    activeConfig?.scaling_enabled === false &&
    (activeConfig.frame_generation_provisioned === false ||
      activeConfig.frame_generation_enabled === false);
  const inactiveNotice =
    runtimeState.scalingEnabled && !runtimeState.scalingActive
      ? scalingInactiveNotice(runtimeState.inactiveReason)
      : null;
  const memoryConstraintNotice =
    runtimeState.scalingActive &&
    runtimeState.constraintReason === "variable-surface-memory-budget" &&
    runtimeState.requestedFactor > runtimeState.effectiveFactor + 0.005;
  const pendingNotice =
    runtimeState.frameGenerationPending || runtimeState.scalingPending;
  const notices: StatusNotice[] = [];

  if (
    runtimeState.frameGenerationEnabled &&
    (runtimeState.gpuHeadroomPercent > 0 ||
      (runtimeState.hasContext &&
        runtimeState.gpuHeadroomState === "unavailable" &&
        (activeConfig?.gpu_headroom_percent ?? 0) > 0))
  ) {
    if (
      ["telemetry-unavailable", "unavailable"].includes(
        runtimeState.gpuHeadroomState,
      )
    ) {
      notices.push({
        key: "headroom-unavailable",
        content: t(
          "LIVE_STATUS_HEADROOM_UNAVAILABLE",
          "GPU Headroom is waiting for supported GPU readings; normal pacing remains active.",
        ),
      });
    } else if (runtimeState.gpuHeadroomState === "frame-rate-floor") {
      notices.push({
        key: "headroom-floor",
        content: t(
          "LIVE_STATUS_HEADROOM_FLOOR",
          "GPU Headroom reached the real-frame floor. The selected generation capacity may prevent further GPU savings.",
        ),
      });
    }
  }

  if (runtimeState.frameGenerationEnabled) {
    notices.push({
      key: "frame-generation-menu-policy",
      content: t(
        "LIVE_STATUS_FG_MENU_SUSPENDED",
        "Frame Generation is disabled while a Steam or Decky menu is open.",
      ),
    });
  }
  if (runtimeState.supersamplingActive) {
    notices.push({
      key: "supersampling",
      color: makoAccentColor,
      content: t("LIVE_STATUS_SUPERSAMPLING", "Quality Supersampling active."),
    });
  }
  if (memoryConstraintNotice) {
    notices.push({
      key: "memory-constraint",
      content: t(
        "LIVE_STATUS_SCALING_MEMORY_CONSTRAINED",
        "Requested {requested}×; limited to {effective}× by this GPU's memory safety limit.",
        {
          requested: runtimeState.requestedFactor.toFixed(2),
          effective: runtimeState.effectiveFactor.toFixed(2),
        },
      ),
    });
  }
  if (inactiveNotice) {
    notices.push({ key: "scaling-inactive", content: inactiveNotice });
  }
  if (runtimeState.fallbackReason) {
    notices.push({
      key: "scaling-fallback",
      content: t(
        "LIVE_STATUS_SCALING_FALLBACK",
        "You selected {requested}; MAKO is using {active} instead.",
        {
          requested: methodLabel(runtimeState.requestedMethod),
          active: methodLabel(runtimeState.activeMethod),
        },
      ),
    });
  }
  if (pendingNotice) {
    notices.push({
      key: "pending",
      content: t(
        "LIVE_STATUS_PENDING",
        "A saved change is still applying or needs a restart.",
      ),
    });
  }

  return (
    <>
      <MakoSectionHeader>
        {t("LIVE_STATUS_TITLE", "Live Status")}
      </MakoSectionHeader>
      <PanelSectionRow>
        <MakoSectionTail>
          <div
            aria-label={t("LIVE_STATUS_TITLE", "Live Status")}
            style={{ ...makoPanelStyle, width: "100%", marginTop: "8px" }}
          >
            <div
              style={{
                padding: "4px 8px",
                display: "flex",
                alignItems: "baseline",
                justifyContent: "flex-end",
                gap: "8px",
              }}
            >
              <span
                style={{
                  color: runtimeState.hasContext ? makoAccentColor : "#93a5ab",
                  fontSize: "8.5px",
                  fontWeight: 600,
                  textTransform: "uppercase",
                }}
              >
                {runtimeState.hasContext
                  ? t("LIVE_STATUS_CONNECTED", "MAKO is active")
                  : featuresOff
                    ? t("LIVE_STATUS_OFF", "Off")
                    : t("LIVE_STATUS_WAITING", "Waiting for MAKO")}
              </span>
            </div>

            {!runtimeState.hasContext ? (
              <div
                style={{
                  padding: "8px 10px",
                  borderTop: makoPanelDivider,
                  color: "#b6c9cf",
                  fontSize: "10px",
                  lineHeight: 1.4,
                }}
              >
                {featuresOff
                  ? t(
                      "LIVE_STATUS_FEATURES_OFF_DESC",
                      "Frame Generation and Scaling are off in this profile.",
                    )
                  : t(
                      "LIVE_STATUS_WAITING_DESC",
                      "Live metrics unavailable; MAKO may still work. Some games/emulators may not report them. Check Frame Generation or Scaling manually.",
                    )}
              </div>
            ) : (
              <>
                <div
                  data-mako-live-status-grid="compact-two-column"
                  style={{
                    display: "grid",
                    gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
                    borderTop: makoPanelDivider,
                  }}
                >
                  <StatusRow
                    label={t("CONTENT_FPS_MULTIPLIER", "Frame Generation")}
                    active={runtimeState.frameGenerationActive}
                  >
                    {runtimeState.frameGenerationActive ? (
                      <>
                        <StatusDetail
                          label={t("LIVE_STATUS_MODE", "Mode")}
                          value={
                            runtimeState.frameGenerationMode === "adaptive"
                              ? t("ADAPTIVE_VALUE", "Adaptive")
                              : t("LIVE_STATUS_FIXED_VALUE", "Fixed")
                          }
                        />
                        {runtimeState.frameGenerationMode === "adaptive" ? (
                          <>
                            <StatusDetail
                              label={t("LIVE_STATUS_ADAPTIVE_STYLE", "Style")}
                              value={
                                runtimeState.frameGenerationAdaptiveStyle ===
                                "steady"
                                  ? t("LIVE_STATUS_STEADY_VALUE", "Steady")
                                  : t(
                                      "LIVE_STATUS_FRACTIONAL_VALUE",
                                      "Fractional",
                                    )
                              }
                            />
                            <StatusDetail
                              label={t("LIVE_STATUS_TARGET", "Target")}
                              value={`${runtimeState.frameGenerationTargetFps ?? "—"} FPS`}
                            />
                            <StatusDetail
                              label={t(
                                "LIVE_STATUS_MAX_MULTIPLIER",
                                "Max factor",
                              )}
                              value={`${runtimeState.frameGenerationMultiplier ?? "—"}×`}
                            />
                          </>
                        ) : (
                          <StatusDetail
                            label={t("LIVE_STATUS_MULTIPLIER", "Factor")}
                            value={`${runtimeState.frameGenerationMultiplier ?? "—"}×`}
                          />
                        )}
                      </>
                    ) : runtimeState.frameGenerationEnabled ? (
                      t(
                        "LIVE_STATUS_FG_INACTIVE",
                        "On in settings, but not currently generating frames.",
                      )
                    ) : (
                      t("LIVE_STATUS_OFF", "Off")
                    )}
                  </StatusRow>
                  <StatusRow
                    label={t("FEATURE_UPSCALING_TAB", "Upscaling")}
                    active={runtimeState.scalingActive}
                    separated
                  >
                    {runtimeState.scalingActive ? (
                      <>
                        <StatusDetail
                          label={t("LIVE_STATUS_MODEL", "Model")}
                          value={liveMethodLabel(runtimeState.activeMethod)}
                        />
                        <StatusDetail
                          label={t("LIVE_STATUS_ORIGINAL_RESOLUTION", "Input")}
                          value={resolution(
                            runtimeState.sourceWidth,
                            runtimeState.sourceHeight,
                          )}
                        />
                        {runtimeState.supersamplingActive ? (
                          <>
                            <StatusDetail
                              label={t(
                                "LIVE_STATUS_RENDER_RESOLUTION",
                                "Render",
                              )}
                              value={resolution(
                                runtimeState.presentationWidth,
                                runtimeState.presentationHeight,
                              )}
                            />
                            <StatusDetail
                              label={t(
                                "LIVE_STATUS_DISPLAY_RESOLUTION",
                                "Display",
                              )}
                              value={resolution(
                                runtimeState.gamescopeTargetWidth,
                                runtimeState.gamescopeTargetHeight,
                              )}
                            />
                          </>
                        ) : (
                          <StatusDetail
                            label={t("LIVE_STATUS_SCALED_RESOLUTION", "Output")}
                            value={resolution(
                              runtimeState.presentationWidth,
                              runtimeState.presentationHeight,
                            )}
                          />
                        )}
                        <StatusDetail
                          label={t("LIVE_STATUS_MULTIPLIER", "Factor")}
                          value={`${runtimeState.effectiveFactor.toFixed(2)}×`}
                        />
                      </>
                    ) : runtimeState.scalingEnabled ? (
                      runtimeState.scalingActivationSupported === false ? (
                        t(
                          "LIVE_STATUS_SCALING_UNAVAILABLE",
                          "Unavailable for this running surface.",
                        )
                      ) : (
                        t(
                          "LIVE_STATUS_SCALING_INACTIVE",
                          "On in settings, but the game image is not being upscaled.",
                        )
                      )
                    ) : (
                      t("LIVE_STATUS_OFF", "Off")
                    )}
                  </StatusRow>
                </div>
                {notices.length > 0 && (
                  <StatusFooterNotices notices={notices} />
                )}
              </>
            )}
          </div>
        </MakoSectionTail>
      </PanelSectionRow>
    </>
  );
}
